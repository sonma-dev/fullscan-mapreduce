# OrionDesk One-Level Evaluation — Complete Artifacts

Evaluation protocol: 10.6
Specification generation method: onelevel
Specification generation reasoning effort: low
External evaluation model used: gpt-6.2-sol (as recorded in the execution artifacts)

Directory layout
- phase-0/inputs: Original uploaded protocol, PDF, eight Markdown specifications, and frozen R/N reference inputs.
- phase-1 through phase-6: Unmodified outputs for the corresponding phases.
- phase-6/external_execution: Complete original Azure result JSONL, run state, summary, and the original ZIP of 265 batch journals.
- phase-6/evaluator_provenance: Original supplied evaluator sources, distinct from the Phase 06 execution derivative.
- phase-7.1: Phase 07 Shard 01 and original sharding-plan manifest and item files.
- phase-7.2: Phase 07 Shard 02 and the separate superseding adjudications; original shard results are preserved.
- phase-8: Reconciliation artifacts, including the completed final ledger and prior incomplete audit artifacts.
- phase-9: Final metrics, validations, and computation script.

No phase-7 directory is used: phase-7.1 and phase-7.2 replace it.
