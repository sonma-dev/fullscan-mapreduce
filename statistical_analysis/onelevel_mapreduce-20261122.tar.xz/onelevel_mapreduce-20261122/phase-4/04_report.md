# Phase 04 — Reciprocal TP/FN Evidence Audit

**Protocol:** OrionDesk One-Pass Atomic Evaluation Protocol 10.6  
**Generation method:** `onelevel`  
**Operator-declared generation reasoning effort:** `low`  
**Status:** `PHASE_COMPLETED` (Phase 04 evidence discovery/audit only)

## Scope and provenance

The immutable original PDF (90 physical pages), 638 frozen source-positive requirements, 142 frozen negative controls, and all eight uploaded original Markdown roles passed the Phase 01 SHA-256 identity checks. The 3,615 eligible generated occurrences and their 3,432 Phase 02 classes were retained unchanged. Phase 03's 638 source discovery rows and 275 potential contextual/universal/cross-file bridges were audited without modifying earlier-phase files.

## Reciprocal challenge

- **638/638 source requirements:** independently indexed for required predicates and competing generated evidence, with original-file line locations and verified digests.
- **571 stronger or contextual retrieval candidates:** each inspected for the difference between text similarity and entire-proposition entailment; all appear in `04_tp_evidence_audit.jsonl`. Phase 03 had not committed any provisional TP.
- **67 weak retrieval candidates:** independently challenged against the complete 3,615-occurrence generated corpus; no weak retrieval result was counted as a proven FN. The complete root-cause challenge inventory covers all 638 source IDs.
- **275 bridge candidates:** preserved for subsequent independent checks; no cross-file conjunction was accepted solely because of word overlap or a generic universal statement.
- **33 component-specific source items:** the tested generated candidate text did not demonstrate the individually named component mapping. A generic register-category assertion is not automatically equivalent to its application to a named component. These are evidence warnings, not proven FNs.

## Provisional text-level diagnostic (not accuracy scores)

| Candidate evidence state | Source requirements |
|---|---:|
| Direct full-statement wording candidate | 8 |
| Direct wording for all separately listed predicates | 6 |
| Lexical candidates for all predicates, meaning-level review still required | 547 |
| Named component scope not established by candidate text | 33 |
| Some predicate lacks a sufficient textual witness in checked candidates | 44 |
| **Total** | **638** |

There were 594 requirements with a text-level witness for every listed predicate, but those witnesses **do not establish semantic coverage**; contextual scope, modality, exceptions, actor and state/timing predicates still require substantive judgment. All 638 items are kept pending for semantic adjudication in later phases. In particular, none was assigned a TP or FN from a retrieval rank, an incomplete keyword match, or a lack of a top-18 match.

## Specific challenged examples

`04_targeted_case_checks.jsonl` preserves ten concrete examples, including: the distinction between a stateless HTTP API deployment requirement and generic HTTP API wording (`PDF-0006`); the full endpoint/auth/idempotency conjunction (`PDF-0101`); permission for partial connector-sync continuation (`PDF-0201`); the PlanNode-specific classification versus a generic register label (`PDF-0301`); and whether dated architecture decisions are actually required for all selections (`PDF-0638`). These examples are not an extrapolated semantic-error rate.

## Exact outputs

- `04_coverage_audit.jsonl`: complete R-by-R reciprocal-evidence audit (638 rows).
- `04_tp_evidence_audit.jsonl`: challenge of all Phase 03 stronger/contextual candidate records (571 rows).
- `04_fn_root_cause_audit.jsonl`: challenge of all apparent miss or partial-match risks (638 rows).
- `04_targeted_case_checks.jsonl`: source-based qualitative challenge notes (10 rows).
- `04_audit_summary.json`, `04_integrity_check.json`: totals, provenance and consistency checks.
- `04_reciprocal_audit.py`: reproducible retrieval and quote-integrity routine.

## Limitation and phase boundary

The lexical audit is intentionally conservative. It does **not** claim that independently reviewed source scope, cross-file conjunction applicability, or full semantic entailment has been proven for all 638 requirements. No Phase 04 inference is a final TP/FN label. Phase 05 must inspect effective generated claims and excluded passages; the Phase 06 evaluator records original v5 suggestions; Phase 07 is responsible for the final item-level evidence-grounded classification, and Phase 08/09 reconcile and compute scores. Nothing in this report replaces those phases.
