# Phase 06 — Negative Controls, Provisional Residuals and Exhaustive External Queue

Method: `onelevel`; generation effort: `low`; external evaluator protocol effort: `high`. Protocol: `10.6`.

## Inventory and selection

- Frozen PDF-positive R: **638**.
- Frozen negative controls N: **142**.
- Effective GO: **3663**; effective GC: **3460**.
- Every N examined via reciprocal candidate retrieval; no similarity treated as affirmative assertion.
- Every effective GC indexed as a provisional generated-only residual candidate; N/F overlaps require full semantic review.
- Accepted prior semantic decisions: **0**. Pending C=K=**4240**, all queued exactly once.
- Batch size: **8**; planned batches: **530**; concurrency: **4**; 3 additional per-batch retries.
- External calls: **0**.

## Evidence and implementation checks

- Original v5 judgment prompt, result schema, `suggest()`, `read_queue()` and `check_evidence()` match the source AST.
- Filename alias tests cover exact/canonical/copy names, changed/ambiguous sources, line ranges and literal quotations.
- The supplied unlimited evaluator set reasoning to `medium`, inconsistent with protocol `high`. A new separately named derivative changes the operational reasoning effort to `high` and accepts the Phase 01 PDF lock's explicit `pdf_sha256` field; the original files remain untouched.
- Queue rows are original-v5 `UNRELIABLE_ITEM` records, including `unreliable=true`, full statements and provisional current cells that are **not** canonical scores.

## External execution blocker

The Azure execution requires `AZURE_OPENAI_ENDPOINT` and `AZURE_OPENAI_API_KEY`. They were absent from this runtime. No external model call was made and no `semantic_decisions.jsonl` or synthetic batch journal was invented. The handoff is blocked until a credentialed execution is available. Phase 07 must not treat a missing external result as evidence for any cell.

## Semantic and duplicate caveats

The Phase 05 class map is the provisional semantic occurrence consolidation (3,663 GO into 3,460 GC). Final PDF support, unsupported residual equivalence and N/F exclusion need source-grounded Phase 07 and Phase 08 adjudication; absent full-proposition evidence, neither FP nor TN is claimed. Phase 06 preserves every candidate rather than pruning the external queue to a convenience budget.
