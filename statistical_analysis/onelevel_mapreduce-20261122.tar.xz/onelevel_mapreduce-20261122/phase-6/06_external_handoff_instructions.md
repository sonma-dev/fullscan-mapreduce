# Phase 06 — External Evaluation Handoff

Protocol version: 10.6. Generation method: `onelevel`; generation reasoning effort: `low`. The external evaluator uses the protocol-required `high` reasoning effort and deployment `gpt-6.1-sol`.

## Prerequisites

- The original locked 90-page PDF, eight original Markdown files, and Phase 01 lock must remain unchanged.
- The validated queue `06_llm_queue_v10.6.jsonl` has 4,240 pending items; SHA-256 `3255ec553e87388c351295b8f50c5b61ca81bf3f3bc50549c210bb50c0173f24`.
- The correction to the separately named evaluator applies the protocol-required `high` reasoning effort and the Phase 01 `pdf_sha256` source-lock format. The original uploaded scripts are unchanged. Semantic judgment prompt, output schema, `suggest()`, `check_evidence()` and queue parser are unchanged.
- All 37 filename-alias regression tests and the independent original-quotation checks have passed.
- This environment does not provide an authorized Azure endpoint or API key. Do not include secrets in reports or the queue.

## Run settings

- Azure model deployment: `gpt-6.1-sol`
- Reasoning effort: `high`
- Confidence threshold: `0.90`
- Batch size: `8` (530 batches; no truncation)
- Concurrency: `4`
- Additional retries: `3` per batch, on explicitly permitted failure classes only
- Source attachment: exactly the original PDF and eight original Markdown files
- Prompt-cache breakpoint: explicitly at the end of the ninth file block

## Safe execution command

Run in an environment where `AZURE_OPENAI_ENDPOINT`, `AZURE_OPENAI_API_KEY`, and the appropriate Azure deployment are already securely configured; do not paste credentials into the command or report.

```bash
python /mnt/data/onelevel_v10_6/phase06/semantic_decision_evaluator_v10.6_unlimited.py \
  --pdf '/mnt/data/OrionDesk_AI_Detailed_Design_Specification(6).pdf' \
  --spec-dir '/mnt/data' \
  --source-lock '/mnt/data/onelevel_v10_6/phase01/01_reference_lock.json' \
  --queue '/mnt/data/onelevel_v10_6/phase06/06_llm_queue_v10.6.jsonl' \
  --out-dir '/mnt/data/onelevel_v10_6/phase06/external_output' \
  --model gpt-6.1-sol \
  --concurrency 4 --batch-size 8 --batch-retries 3 \
  --confidence-threshold 0.90
```

An external execution must preserve the immutable source and queue hashes and use complete, hash-verified batch journals. Never fabricate external suggestions on failure or retry ambiguous billable submissions without explicit resume authorization. Phase 07 independently adjudicates every item not supported by an accepted evidence-based decision, including failed/ambiguous external outcomes.

## Current status

Queue and dry-run: passed. Paid Azure submissions: zero. Phase 06 external handoff: blocked by missing endpoint/API key. Phase 07: not started. No numeric confusion-matrix scores are authorized.
