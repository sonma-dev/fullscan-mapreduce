#!/usr/bin/env python3
import json
from pathlib import Path
D=Path('/mnt/data/onelevel_v10_6/phase08')
a=json.load(open(D/'08_quotation_validation.json'))
mm=a['mismatch_examples']
with (D/'08_quote_exceptions.jsonl').open('w',encoding='utf-8') as f:
 for i,x in enumerate(mm,1):
  x={'record_type':'UNRESOLVED_LITERAL_QUOTE_LOCATION','quote_audit_id':f'P08-QUOTE-{i:03d}',**x,
     'semantic_decision_changed':False,'verification_required':'Visual/page-layout or alternate faithful PDF extraction review; do not invent a literal text match.'}
  f.write(json.dumps(x,ensure_ascii=False,sort_keys=True)+'\n')
with (D/'08_reconciliation_audit.jsonl').open('a',encoding='utf-8') as f:
 f.write(json.dumps({'record_type':'SOURCE_QUOTATION_DIAGNOSTIC','check':'Independent NFKC-whitespace exact text extraction',
   'generated_exact_line_matches':a['counts']['generated_quote_exact_line_ok'],
   'pdf_exact_page_text_matches':a['counts']['pdf_quote_exact_page_ok'],
   'pdf_unmatched_text_extraction':a['counts']['pdf_quote_mismatch'],
   'marked_visual_review_required':a['counts']['pdf_visual_review_needed'],
   'not_marked_visual_review_required':a['counts']['pdf_quote_mismatch']-a['counts']['pdf_visual_review_needed'],
   'meaning':'This diagnostic alone does not prove a quotation is false; figure/complex-table text may be visually present while absent or reordered in PDF text extraction.',
   'status':'REQUIRES_VISUAL_OR_LAYOUT_REVIEW_BEFORE_FINAL_EVIDENCE_ACCEPTANCE'},sort_keys=True)+'\n')
status=json.load(open(D/'08_integrity_check.json'))
status['independent_quote_validation']={k:v for k,v in a['counts'].items()}
status['quote_validation_note_en']='8608 original Markdown quotations match exact line spans; 99 PDF quotes do not occur as contiguous NFKC-normalized PDF text on reported physical pages, 90 of which explicitly require visual review. The nine other cases include layout-reordered table excerpts or visually sourced diagram text; they are not automatically invalidated, but require separate location review before finalizing canonical evidence.'
status['full_semantic_and_quote_validation_complete']=False
(D/'08_integrity_check.json').write_text(json.dumps(status,ensure_ascii=False,sort_keys=True,indent=2)+'\n')
c=json.load(open(D/'08_binary_counts.json'))
c['additional_unverified_pdf_text_quotes']=a['counts']['pdf_quote_mismatch']
(D/'08_binary_counts.json').write_text(json.dumps(c,ensure_ascii=False,sort_keys=True,indent=2)+'\n')
report=(D/'08_report.md').read_text()
report+=f'''\n## Independent original-quotation verification (additional incomplete evidence check)\n\n- Original Markdown quotations: **{a['counts']['generated_quote_exact_line_ok']} / {a['counts']['generated_evidence_items']}** exact normalized literal matches within the stated line spans.\n- Original PDF quotations: **{a['counts']['pdf_quote_exact_page_ok']} / {a['counts']['pdf_evidence_items']}** contiguous normalized matches in the extracted text of the claimed physical page.\n- **{a['counts']['pdf_quote_mismatch']}** do not match contiguous extracted PDF text: **{a['counts']['pdf_visual_review_needed']}** were already flagged as requiring visual verification, and **{a['counts']['pdf_quote_mismatch']-a['counts']['pdf_visual_review_needed']}** were not. Complex table column layouts and figures can explain a subset; mismatches must be reviewed against the original page image or faithful page-layout extraction rather than silently deemed verified or fabricated.\n- Exact original positions and the complete mismatch list appear in `08_quote_exceptions.jsonl`. This further prevents Phase 08 from being certified complete in this response.\n'''
(D/'08_report.md').write_text(report)
print(len(mm),'appended')
