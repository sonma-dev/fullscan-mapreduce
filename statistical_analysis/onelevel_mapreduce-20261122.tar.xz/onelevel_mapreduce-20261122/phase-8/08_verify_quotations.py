#!/usr/bin/env python3
"""Verify Phase 07 quoted evidence at original source positions; no semantic relabeling."""
import collections,hashlib,json,re,unicodedata
from pathlib import Path
import fitz
ROOT=Path('/mnt/data/onelevel_v10_6'); OUT=ROOT/'phase08'
lock=json.load(open(ROOT/'phase01/01_reference_lock.json'))
sources={e['actual_filename']:{'lines':Path(e['original_path']).read_text(encoding='utf-8-sig').splitlines(),'sha':e['sha256']} for e in lock['source_files']}
pdf=fitz.open('/mnt/data/OrionDesk_AI_Detailed_Design_Specification(6).pdf')
pages=[p.get_text(sort=False) for p in pdf]
def norm(s):return ' '.join(unicodedata.normalize('NFKC',str(s)).split()).casefold()
Npages=[norm(s) for s in pages]
c=collections.Counter();bad=[]
for shard in ['shard01','shard02']:
 for raw in open(ROOT/'phase07'/shard/'07_decision_audit.jsonl'):
  d=json.loads(raw)
  for x in d.get('generated_evidence',[]):
   c['generated_evidence_items']+=1
   fn=x.get('actual_file'); ls=x.get('line_start');le=x.get('line_end');q=norm(x.get('quote_en',''))
   source=sources.get(fn)
   ok=bool(source and type(ls)==int and type(le)==int and 1<=ls<=le<=len(source['lines']) and q and q in norm('\n'.join(source['lines'][ls-1:le])))
   if ok:c['generated_quote_exact_line_ok']+=1
   else:
    c['generated_quote_mismatch']+=1
    if len(bad)<100:bad.append({'item_id':d['item_id'],'kind':'G','file':fn,'line_start':ls,'line_end':le,'quote_preview':x.get('quote_en','')[:200],'record_claim_verified':x.get('verified_current_original_exact')})
  for x in d.get('pdf_evidence',[]):
   c['pdf_evidence_items']+=1
   page=x.get('physical_page');q=norm(x.get('quote_en',''))
   ok=bool(type(page)==int and 1<=page<=len(pages) and q and q in Npages[page-1])
   if ok:c['pdf_quote_exact_page_ok']+=1
   else:
    c['pdf_quote_mismatch']+=1
    if x.get('visual_review_required'):c['pdf_visual_review_needed']+=1
    if len(bad)<100:bad.append({'item_id':d['item_id'],'kind':'PDF','page':page,'quote_preview':x.get('quote_en','')[:200],'visual_review_required':x.get('visual_review_required'),'record_claim_verified':x.get('verified_current_original_exact')})
result={'record_type':'INDEPENDENT_PHASE08_QUOTATION_VALIDATION','method':'onelevel','protocol_version':'10.6','counts':dict(c),'number_of_mismatch_examples':len(bad),'mismatch_examples':bad,'status':'PASSED' if c['generated_quote_mismatch']==0 and c['pdf_quote_mismatch']==0 else 'NEEDS_REVIEW','description_en':'NFKC-whitespace normalized literal quotations checked at exact existing original Markdown line spans and PDF physical pages. This does not establish semantic entailment.'}
(OUT/'08_quotation_validation.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'status':result['status'],'counts':result['counts'],'first_examples':bad[:3]},ensure_ascii=False))
