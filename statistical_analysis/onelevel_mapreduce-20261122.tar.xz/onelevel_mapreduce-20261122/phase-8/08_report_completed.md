# Phase 08 — Completed Independent Reconciliation

Protocol version: 10.6. Method: onelevel. Generation reasoning effort: low.

**Status: PHASE_COMPLETED.**

## Explicit Phase 07 supersessions

Seven source-grounded supersessions are saved separately in `../phase07/supersessions/07_superseding_adjudications.jsonl`. Six original G:FP cells were corrected to diagnostic G:TP; one G:FP cell was preserved with an exact unsupported-residual explanation. All original Shard 01/02 decisions and v5 external model results are immutable and unchanged. The four related API-001 corrections include the three previously blocking contradictions plus the adjacent API-001 business-context case. Two additional clear PDF passages resolve the run termination and regional recovery requirements.

## Canonical Phase 08 ledger

- Frozen positive source R: 638 = 599 TP + 39 FN.
- Frozen negative N: 142 = 142 TN + 0 asserted counterfactuals.
- Effective generated classes: 3,460, of which 2,885 PDF-supported, 78 PDF-unsupported affirmative, and 497 excluded as nondefinitive by Phase 07.
- Unsupported generated-only semantic residuals: 66 unique FP units after consolidation; N/F overlap: 0.
- Canonical FP: 66; canonical universe: 846 = 638 + 142 + 66.
- Full final ledger: 4,306 rows, including 497 explicit non-scoring class exclusion records.

A shared unsupported *residual* may be present in several source-generated classes. See `08_residual_consolidation_audit.jsonl` for each grouped and singleton residual with full source class IDs and an explicit semantic reason. Two independent residual obligations in one compound logging class are counted independently; no group is collapsed merely because it mentions the same API or keyword.

## Evidence and model conditions

The entire 4,240-item external result (265 committed journals) and original 90-page PDF, eight generated Markdown files and fixed R/N were hash-validated in the preceding independent audit. The 99 previously flagged noncontiguous PDF text excerpts are **not** rewritten as literal matches; they remain traceable in `08_quote_exception_dispositions.jsonl`. All scored final rows retain separate verified PDF evidence, and all generated quotes retain original source-file lines. Example UI figures are not converted into normative requirements.

The external evaluation executed on **gpt-6.2-sol**. The operator confirms that the other compared generation methods also used gpt-6.2-sol; the literal v10.6 text specifies gpt-6.1-sol, so this difference is documented as a common operator-approved deployment convention rather than used to arbitrarily disqualify the onelevel scores. Other cross-method conditions must still be independently checked when comparing metrics.

**No Phase 09 Precision/Recall/F1 values were computed in this phase.**
