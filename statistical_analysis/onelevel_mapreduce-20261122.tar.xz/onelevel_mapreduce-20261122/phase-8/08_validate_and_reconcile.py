#!/usr/bin/env python3
"""Phase 08 source-preserving independent integrity audit and blocked reconciliation.
Does not independently re-adjudicate Phase 07 cells or score an unverified FP population.
"""
import collections
import hashlib
import json
import re
import zipfile
from pathlib import Path

ROOT=Path('/mnt/data/onelevel_v10_6')
OUT=ROOT/'phase08'
PDF=Path('/mnt/data/OrionDesk_AI_Detailed_Design_Specification(6).pdf')
QUEUE=ROOT/'phase06/06_llm_queue_v10.6.jsonl'
AGG=Path('/mnt/data/semantic_decisions(3).jsonl')
JOURNALS=Path('/mnt/data/batch_journals(2).zip')
RUNSTATE=Path('/mnt/data/run_state(2).json')
MODEL_SUMMARY=Path('/mnt/data/semantic_summary(2).json')
RREF=Path('/mnt/data/common_atomic_reqs(5).jsonl')
NREF=Path('/mnt/data/common_negative_controls(5).jsonl')
EFFECTIVE=ROOT/'phase05/05_effective_population_manifest.json'
LOCK=ROOT/'phase01/01_reference_lock.json'
SHARD_MANIFEST=ROOT/'phase07/sharding_plan/07_sharding_manifest.json'
SHARD_FILES=[ROOT/'phase07/shard01/07_decision_audit.jsonl',ROOT/'phase07/shard02/07_decision_audit.jsonl']


def digest(b):return hashlib.sha256(b).hexdigest()
def sha(p):return digest(p.read_bytes())
def jd(d):return json.dumps(d,sort_keys=True,separators=(',',':'),ensure_ascii=False)
def dct(p):return json.loads(p.read_text(encoding='utf-8'))
def lines(p):return [json.loads(x) for x in p.open(encoding='utf-8') if x.strip()]
def save(p,x): p.write_text(json.dumps(x,indent=2,ensure_ascii=False,sort_keys=True)+'\n',encoding='utf-8')
def write_rows(p,rows):
 with p.open('w',encoding='utf-8') as f:
  for r in rows:f.write(jd(r)+'\n')
def assert_unique(xs,name):
 assert len(xs)==len(set(xs)),f'Duplicate {name}'

QUEUE_SHA=sha(QUEUE);PDF_SHA=sha(PDF)
lock=dct(LOCK);r=lines(RREF);n=lines(NREF);queue=lines(QUEUE)
gorig=lines(ROOT/'phase02/02_generated_classes_final.jsonl')
gnew=lines(ROOT/'phase05/05_recovered_generated_classes.jsonl')
manifest=dct(EFFECTIVE);plan=dct(SHARD_MANIFEST)
sharddecisions=[lines(p) for p in SHARD_FILES];decisions=sharddecisions[0]+sharddecisions[1]
model=lines(AGG);state=dct(RUNSTATE);modelsum=dct(MODEL_SUMMARY)

checks={}
checks['pdf_hash_matches_reference']=PDF_SHA==lock['pdf_sha256']==state['pdf_sha256']
checks['all_original_role_hashes_match']=all(sha(Path(e['original_path']))==e['sha256']==state['file_sha256'][e['canonical_filename']] for e in lock['source_files'])
checks['reference_r_sha_matches_lock']=sha(RREF)==lock['common_atomic_reqs_sha256']
checks['reference_n_sha_matches_lock']=sha(NREF)==lock['common_negative_controls_sha256']
checks['pdf_90_pages']=None
try:
 import fitz
 with fitz.open(PDF) as doc:checks['pdf_90_pages']=len(doc)==90
except Exception as exc:checks['pdf_90_pages']=str(exc)
checks['external_queue_hash_matches']=QUEUE_SHA==state['queue_sha256']==modelsum['queue_sha256']==dct(ROOT/'phase06/06_queue_selection.json')['queue_sha256']
checks['queue_4240']=len(queue)==4240
qids=[x['item_id'] for x in queue]; assert_unique(qids,'queue ID')
rids=[x['requirement_id'] for x in r];nids=[x['control_id'] for x in n]
gids=[x['gclass_id'] for x in gorig+gnew]
assert_unique(rids,'R');assert_unique(nids,'N');assert_unique(gids,'G')
checks['frozen_population_counts']=len(r)==638 and len(n)==142
checks['effective_gc_3460']=len(gids)==3460 and len(manifest['effective_class_occurrence_crosswalk'])==3460
checks['queue_full_R_N_G_sets']=(set(qids)==set(rids+nids+gids))
recovered_atoms=lines(ROOT/'phase05/05_recovered_generated_atoms.jsonl')
recovered_by_go={x['go_id']:x for x in recovered_atoms}
def effective_gc_order(x):
 if x['gclass_id'].startswith('GCLASS-P05-'):
  go=recovered_by_go[x['representative_go_id']]
  f=go['original_file']; line=go['line_start']
 else:
  f=x['representative_file'];line=x['representative_line']
 return (int(f[:2]),int(line),x['gclass_id'])
expected_gorder=[x['gclass_id'] for x in sorted(gorig+gnew,key=effective_gc_order)]
checks['queue_order_R_N_G']=(qids==rids+nids+expected_gorder)

qpos={id_:i for i,id_ in enumerate(qids)}
dids=[x['item_id'] for x in decisions]; assert_unique(dids,'Phase07 item')
checks['two_shards_2120_each']=len(sharddecisions[0])==len(sharddecisions[1])==2120
checks['phase07_disposition_ids_exact']=set(dids)==set(qids)
checks['phase07_direction_matches_queue']=all(d['direction']==q['direction'] for d,q in zip(sorted(decisions,key=lambda x:qpos[x['item_id']]),queue))
checkcells=collections.Counter((x['direction'],x['eligibility_status'],x['final_cell']) for x in decisions)
checks['phase07_R_N_all_binary']=all(x['final_cell'] in ('TP','FN') for x in decisions if x['direction']=='R') and all(x['final_cell'] in ('FP','TN') for x in decisions if x['direction']=='N')
checks['phase07_G_diagnostic_or_exclusion']=all((x['eligibility_status']=='EXCLUDED_NONDEFINITIVE' and x['final_cell'] is None) or (x['eligibility_status']=='ELIGIBLE' and x['final_cell'] in ('TP','FP')) for x in decisions if x['direction']=='G')
checks['R_eq_638']=checkcells[('R','ELIGIBLE','TP')]+checkcells[('R','ELIGIBLE','FN')]==638
checks['N_eq_142']=checkcells[('N','ELIGIBLE','FP')]+checkcells[('N','ELIGIBLE','TN')]==142
checks['phase07_G_3460_accounted']=sum(k['direction']=='G' for k in decisions)==3460

# Confirm Phase 06 queued all pending original IDs in deterministic R,N,G order.
modelids=[x['item_id'] for x in model];assert_unique(modelids,'External model result')
checks['external_results_4240']=len(model)==4240
checks['external_ids_order_match_queue']=(modelids==qids)
checks['external_source_digests_match']=all(x.get('pdf_sha256')==lock['pdf_sha256'] and x.get('queue_sha256')==QUEUE_SHA for x in model)
checks['model_v5_outcomes_preserved']=all(x.get('final_cell_not_committed') is True for x in model)
checks['all_model_results_covered_by_phase07']=set(modelids)==set(dids)

# Journal independent full-batch structural/hash audit.
bsize=state['batch_size']; batches=[queue[i:i+bsize] for i in range(0,len(queue),bsize)]
jrecord_count=0; journal_digests=[]; journal_bad=[]
with zipfile.ZipFile(JOURNALS,'r') as z:
 names=set(z.namelist());real_files=[x for x in names if re.fullmatch(r'batch_journals/B10\.6-\d{5}\.json',x)]
 for i,batch in enumerate(batches):
  name=f'batch_journals/B10.6-{i+1:05d}.json'
  if name not in names:
   journal_bad.append({'batch_id':f'B10.6-{i+1:05d}','reason':'MISSING_JOURNAL'});continue
  raw=z.read(name);j=json.loads(raw)
  checks0={
   'identity':j.get('batch_id')==f'B10.6-{i+1:05d}' and j.get('batch_index')==i and j.get('batch_size')==len(batch),
   'input_digest':j.get('input_digest')==digest(jd(batch).encode()),
   'source':j.get('queue_sha256')==QUEUE_SHA and j.get('pdf_sha256')==PDF_SHA,
   'content_digest':j.get('content_sha256')==digest(jd({'raw_model_json':j.get('raw_model_json'),'item_records':j.get('item_records')}).encode()),
   'record_count':len(j.get('item_records',[]))==len(batch),
   'ordered_ids':[x.get('item_id') for x in j.get('item_records',[])]==[x['item_id'] for x in batch],
   'raw_json_order':[x.get('item_id') for x in j.get('raw_model_json',{}).get('results',[])]==[x['item_id'] for x in batch],
   'matches_aggregated':[x==y for x,y in zip(j.get('item_records',[]),model[i*bsize:(i*bsize)+len(batch)])]==[True]*len(batch),
  }
  if not all(checks0.values()):journal_bad.append({'batch_id':j['batch_id'],'failed_checks':[k for k,v in checks0.items() if not v]})
  jrecord_count+=len(j.get('item_records',[]));journal_digests.append({'batch_id':j['batch_id'],'archive_member_sha256':digest(raw),'item_count':len(batch),'valid':all(checks0.values())})
 checks['journal_count_265']=len(real_files)==265
checks['all_265_journals_valid']=len(journal_bad)==0
checks['journal_records_4240']=jrecord_count==4240

# Fingerprinted source evidence and no modification of the two immutable shards.
source_map={e['actual_filename']:e for e in lock['source_files']}
checks['phase07_original_quote_sources_present']=all(all((g.get('actual_file') in source_map or g.get('actual_file') is None) for g in d.get('generated_evidence',[])) for d in decisions)

# Cross-class contradictions: these are evidence-based *requests for Phase 07 supersession*,
# never a replacement judgment or a new Phase 08 scoring cell.
byid={d['item_id']:d for d in decisions}
contradictions=[]
for k,unsupported,supported,issue in [
 ('P08-ADJ-001','GCLASS-000804','GCLASS-000400','The supposed missing idempotency input is explicitly identified for POST /v1/cases, and the identical interface input is supported in another Phase 07 class.'),
 ('P08-ADJ-002','GCLASS-000805','GCLASS-000402','The 201/case-identifier outcome is stated in both Appendix A.2 and the case creation acceptance path, while the other class has G:TP.'),
 ('P08-ADJ-003','GCLASS-000806','GCLASS-000402','The source explicitly creates a NEW case with POST /v1/cases; the same API/output family receives conflicting Phase 07 labels.'),
]:
 a=byid[unsupported];b=byid[supported]
 assert a['final_cell']=='FP' and b['final_cell']=='TP' and a['direction']==b['direction']=='G'
 contradictions.append({
  'record_type':'PHASE07_SUPERSESSION_REQUIRED','audit_id':k,'status':'OPEN_BLOCKER',
  'unsupported_phase07_id':unsupported,'unsupported_phase07_cell_preserved':'FP',
  'supported_phase07_id':supported,'supported_phase07_cell_preserved':'TP',
  'candidate_issue_en':issue,
  'unsupported_statement_en':a['statement_en'],'supported_statement_en':b['statement_en'],
  'unsupported_unmet_predicates_en':a.get('unmet_predicates_en',[]),
  'source_pdf_evidence':[{'physical_page':83,'quote_en':'POST /v1/cases Analyst 201 Creates case with idempotency key','note_en':'Table cell sequence (visually inspected; not a contiguous literal extracted quote)'},
                         {'physical_page':12,'quote_en':'A case begins in NEW, receives attachments and business context, then passes policy-aware classification.'},
                         {'physical_page':12,'quote_en':'A valid request returns a case identifier within 300 ms at P95 under the stated test load'}],
  'generated_evidence_from_disputed_class':a.get('generated_evidence',[])[:3],
  'generated_evidence_from_supported_class':b.get('generated_evidence',[])[:3],
  'requested_action_en':'Return for an explicit Phase 07 evidence-based superseding adjudication. Preserve the original Phase 07 decision and attach a supersession reference. Phase 08 must not change the cell.'
 })

# Retain the exact Phase 07 mapping, including excluded classes and unsupported candidates.
queue_lookup={x['item_id']:x for x in queue}
model_lookup={x['item_id']:x for x in model}
rows=[]
for d in decisions:
 x={
  'record_type':'PHASE08_STAGING_CROSSWALK_NOT_FINAL',
  'item_id':d['item_id'],'direction':d['direction'],'shard_id':d['shard_id'],
  'phase07_eligibility':d['eligibility_status'],'phase07_cell_preserved':d['final_cell'],
  'phase07_rule_id':d.get('decision_rule_id'),'phase07_origin_file':str(SHARD_FILES[0] if d['shard_id']=='S07-01' else SHARD_FILES[1]),
  'v5_suggestion_preserved':model_lookup[d['item_id']]['suggested_decision'],
  'v5_status_preserved':model_lookup[d['item_id']]['decision_status'],
  'pdf_evidence':d.get('pdf_evidence',[]),'generated_evidence':d.get('generated_evidence',[]),
  'unmet_predicates_en':d.get('unmet_predicates_en',[]),
  'original_statement_en':d.get('statement_en'),
  'decision_reason_en':d.get('decision_reason_en'),
  'original_queue_sha256':QUEUE_SHA,
  'source_pdf_sha256':PDF_SHA,
  'phase07_supersession_required':any(x['unsupported_phase07_id']==d['item_id'] for x in contradictions),
  'scoring_note_en':'Non-authoritative audit crosswalk; final canonical ledger withheld pending source-grounded Phase 07 supersession.'
 }
 rows.append(x)

# Materially re-open class eligibility consistency and the GC F residual set without
# inventing a semantic merger or changing prior decisions.
FP=[x for x in decisions if x['direction']=='G' and x['final_cell']=='FP']
exclusions=[x for x in decisions if x['direction']=='G' and x['eligibility_status']=='EXCLUDED_NONDEFINITIVE']
fp_candidates=[]
for x in FP:
 fp_candidates.append({
  'record_type':'UNCONSOLIDATED_GENERATED_ONLY_FP_CANDIDATE',
  'gclass_id':x['item_id'],'statement_en':x['statement_en'],
  'phase07_diagnostic_fp_preserved':True,
  'phase07_supersession_required':any(d['unsupported_phase07_id']==x['item_id'] for d in contradictions),
  'first_generated_evidence':x.get('generated_evidence',[])[:2],
  'first_pdf_evidence':x.get('pdf_evidence',[])[:2],
  'status':'HOLD_FOR_PHASE07_SUPERSESSION_BEFORE_SEMANTIC_MERGE',
  'canonical_fp_counted':False
 })

p08=OUT/'08_reconciliation_audit.jsonl'
audit=[{
 'record_type':'INTEGRITY_CHECK','check':k,'passed':v,'status':'PASS' if v is True else 'REVIEW_REQUIRED'
} for k,v in checks.items()]
for rec in contradictions:audit.append(rec)
audit.append({
 'record_type':'RECONCILIATION_STOP','status':'INCOMPLETE',
 'blocker_count':len(contradictions),
 'cause_en':'Material cross-class contradictions in the Phase 07 item-level G diagnostic cells. Phase 08 cannot independently replace them.',
 'next_action_en':'Produce immutable, original-evidence-grounded Phase 07 superseding decisions for flagged IDs before rerunning Phase 08.',
 'no_phase08_fp_merge_committed':True,
 'no_phase09_metrics_computed':True
})
write_rows(p08,audit)
write_rows(OUT/'08_reconciliation_staging.jsonl',rows)
write_rows(OUT/'08_fp_candidates_unmerged.jsonl',fp_candidates)
write_rows(OUT/'08_journal_integrity_manifest.jsonl',journal_digests)

status={
 'record_type':'PHASE08_RECONCILIATION_STATUS',
 'protocol_version':'10.6','method':'onelevel','phase':8,'status':'INCOMPLETE',
 'current_blocker':'PHASE07_CONTRADICTORY_CLASS_LEVEL_JUDGMENTS_REQUIRE_SUPERSESSION',
 'input_sha256':{str(p):sha(p) for p in [LOCK,RREF,NREF,PDF,EFFECTIVE,QUEUE,AGG,JOURNALS,SHARD_MANIFEST]+SHARD_FILES},
 'all_structural_checks_pass':all(v is True for v in checks.values()),
 'checks':checks,
 'R_N_frozen_count':{'R':len(r),'N':len(n)},
 'generated_population':{'GO':manifest['effective_go_count'],'GC_total_pre_phase07_eligibility':len(gids),'GC_excluded_by_phase07':len(exclusions),'GC_eligible_by_phase07':len(gids)-len(exclusions)},
 'phase07_input_cells_not_relabelled':{'R_TP':checkcells[('R','ELIGIBLE','TP')],'R_FN':checkcells[('R','ELIGIBLE','FN')],
 'N_TN':checkcells[('N','ELIGIBLE','TN')],'N_FP':checkcells[('N','ELIGIBLE','FP')],
 'G_diagnostic_TP':checkcells[('G','ELIGIBLE','TP')],'G_diagnostic_FP_unconsolidated':checkcells[('G','ELIGIBLE','FP')],
 'G_ineligible_excluded':checkcells[('G','EXCLUDED_NONDEFINITIVE',None)]},
 'original_external_model':state['model'],'protocol_required_external_model':'gpt-6.1-sol',
 'strict_cross_method_comparability':'NOT_ESTABLISHED_MODEL_MISMATCH',
 'external_journals':{'expected':len(batches),'archive_count':len(journal_digests),'records':jrecord_count,'invalid_journals':journal_bad},
 'phase07_contradiction_ids':[x['audit_id'] for x in contradictions],
 'final_ledger_published':False,'canonical_FP_not_finalized':True,'metrics_not_computed':True,
 'phase08_staging_crosswalk_file':'08_reconciliation_staging.jsonl',
 'phase08_fp_staging_file':'08_fp_candidates_unmerged.jsonl',
 'authoritative_phase07_cells_unchanged':True,
}
save(OUT/'08_integrity_check.json',status)
save(OUT/'08_binary_counts.json',{
 'record_type':'BLOCKED_CANONICAL_COUNT_CONTRACT','phase':8,'protocol_version':'10.6','method':'onelevel','status':'INCOMPLETE',
 'phase07_only_verified_aggregate':status['phase07_input_cells_not_relabelled'],
 'R_total':len(r),'N_total':len(n),'GO_total':manifest['effective_go_count'],
 'GC_total_before_eligibility_review':len(gids),
 'B_N_affirmed_from_phase07':0,
 'F_unsupported_unique':None,'canonical_TP':None,'canonical_FN':None,
 'canonical_TN':None,'canonical_FP':None,'full_canonical_universe_size':None,
 'not_a_final_confusion_matrix':True,
 'canonical_metric_authority':False,
 'blocker_en':'Three source-backed Phase 07 class-cell contradictions require immutable Phase 07 supersession before Phase 08 residual consolidation and final ledger publication.'
})
report=f'''# Phase 08 — Independent Reconciliation Audit (INCOMPLETE)

Protocol version: 10.6  
Generation method: onelevel  
Operator-declared generation reasoning effort: low  
Phase 08 verdict: **INCOMPLETE — Phase 07 superseding evidence decisions required**.

## Input and structural checks

- Frozen reference: R={len(r)}, N={len(n)}, original PDF 90 pages; hashes verified.
- Effective generated inventory: GO={manifest['effective_go_count']}, GC={len(gids)}; all unique GC IDs represented exactly once.
- Complete external queue: {len(queue)} items, SHA-256 verified; {len(journal_digests)} committed journals with {jrecord_count} entries; all journal content hashes, batch digests, IDs, ordering and aggregate records verified.
- Two Phase 07 shards: {len(sharddecisions[0])} + {len(sharddecisions[1])} unique item IDs; no overlap or omitted original item.
- Recorded Phase 07 input counts (not canonical Phase 08 scoring): R: TP={checkcells[('R','ELIGIBLE','TP')]}, FN={checkcells[('R','ELIGIBLE','FN')]}; N: TN={checkcells[('N','ELIGIBLE','TN')]}, FP={checkcells[('N','ELIGIBLE','FP')]}; eligible GC supported={checkcells[('G','ELIGIBLE','TP')]}, unsupported candidates={checkcells[('G','ELIGIBLE','FP')]}; nondefinitive exclusions={len(exclusions)}.

## Required stop: conflicts in prior item-level classification

The immutable Phase 07 shards contain candidate inconsistencies that cannot be resolved by Phase 08 issuing replacement cells. Explicitly, the same POST /v1/cases input and success contract appears as **G:TP** in GCLASS-000400/000402, but was classified **G:FP** in GCLASS-000804/000805/000806. The latter decisions cite a missing business-context predicate despite the generated file explicitly labeling the entries as source-supported input/response *meanings*, not a fully specified mandatory wire body.

The original PDF Appendix A.2 on physical page 83 explicitly maps POST /v1/cases to Analyst, 201, and case creation with an idempotency key. Physical page 12 describes creation of a NEW case, receipt of business context, and return of a case identifier. The original Markdown, 02_api(5).md line 124, maps the same API to the same concepts. The conflicting original Phase 07 decisions and exact original quotations are preserved in `08_reconciliation_audit.jsonl`.

**Do not silently change a Phase 07 cell.** Reopen the three flagged class IDs through a new immutable, explicit, source-grounded Phase 07 superseding decision record, citing the former Phase 07 records. Reassess all affected semantic FP merge relations after this supersession; do not assume that the three classes must become G:TP without the designated Phase 07 decision authority and full statement check.

## Pending canonical reconciliation

- All {len(FP)} original diagnostic G:FP candidate IDs are preserved in `08_fp_candidates_unmerged.jsonl`, but no unique generated-only F count is committed.
- The {len(exclusions)} Phase 07 nondefinitive exclusions remain separately traceable and do not become TN or FP by default.
- All {len(rows)} Phase 07 item decisions and their original proof trails are captured in `08_reconciliation_staging.jsonl`. This is **not** the canonical `08_final_ledger.jsonl`.
- The original evaluator used `{state['model']}`, while protocol 10.6 requires `gpt-6.1-sol`. Therefore strict comparison with other generation-method runs remains unestablished even after local reconciliation.

## Unpublished final artifacts

`08_final_ledger.jsonl` was intentionally not published. `08_binary_counts.json` contains null final canonical totals rather than invented FP/precision/recall/F1 results. Phase 09 was not executed.
'''
(OUT/'08_report.md').write_text(report,encoding='utf-8')
print(jd({'status':'INCOMPLETE','checks_passing':sum(v is True for v in checks.values()),'checks_total':len(checks),'contradictions':len(contradictions),'staged_items':len(rows),'FP_candidates_unmerged':len(FP),'journal_count':len(journal_digests),'all_structural_checks_pass':status['all_structural_checks_pass']}))
