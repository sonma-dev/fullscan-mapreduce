# Phase 08 — Independent Reconciliation Audit (INCOMPLETE)

Protocol version: 10.6  
Generation method: onelevel  
Operator-declared generation reasoning effort: low  
Phase 08 verdict: **INCOMPLETE — Phase 07 superseding evidence decisions required**.

## Input and structural checks

- Frozen reference: R=638, N=142, original PDF 90 pages; hashes verified.
- Effective generated inventory: GO=3663, GC=3460; all unique GC IDs represented exactly once.
- Complete external queue: 4240 items, SHA-256 verified; 265 committed journals with 4240 entries; all journal content hashes, batch digests, IDs, ordering and aggregate records verified.
- Two Phase 07 shards: 2120 + 2120 unique item IDs; no overlap or omitted original item.
- Recorded Phase 07 input counts (not canonical Phase 08 scoring): R: TP=599, FN=39; N: TN=142, FP=0; eligible GC supported=2879, unsupported candidates=84; nondefinitive exclusions=497.

## Required stop: conflicts in prior item-level classification

The immutable Phase 07 shards contain candidate inconsistencies that cannot be resolved by Phase 08 issuing replacement cells. Explicitly, the same POST /v1/cases input and success contract appears as **G:TP** in GCLASS-000400/000402, but was classified **G:FP** in GCLASS-000804/000805/000806. The latter decisions cite a missing business-context predicate despite the generated file explicitly labeling the entries as source-supported input/response *meanings*, not a fully specified mandatory wire body.

The original PDF Appendix A.2 on physical page 83 explicitly maps POST /v1/cases to Analyst, 201, and case creation with an idempotency key. Physical page 12 describes creation of a NEW case, receipt of business context, and return of a case identifier. The original Markdown, 02_api(5).md line 124, maps the same API to the same concepts. The conflicting original Phase 07 decisions and exact original quotations are preserved in `08_reconciliation_audit.jsonl`.

**Do not silently change a Phase 07 cell.** Reopen the three flagged class IDs through a new immutable, explicit, source-grounded Phase 07 superseding decision record, citing the former Phase 07 records. Reassess all affected semantic FP merge relations after this supersession; do not assume that the three classes must become G:TP without the designated Phase 07 decision authority and full statement check.

## Pending canonical reconciliation

- All 84 original diagnostic G:FP candidate IDs are preserved in `08_fp_candidates_unmerged.jsonl`, but no unique generated-only F count is committed.
- The 497 Phase 07 nondefinitive exclusions remain separately traceable and do not become TN or FP by default.
- All 4240 Phase 07 item decisions and their original proof trails are captured in `08_reconciliation_staging.jsonl`. This is **not** the canonical `08_final_ledger.jsonl`.
- The original evaluator used `gpt-6.2-sol`, while protocol 10.6 requires `gpt-6.1-sol`. Therefore strict comparison with other generation-method runs remains unestablished even after local reconciliation.

## Unpublished final artifacts

`08_final_ledger.jsonl` was intentionally not published. `08_binary_counts.json` contains null final canonical totals rather than invented FP/precision/recall/F1 results. Phase 09 was not executed.

## Independent original-quotation verification (additional incomplete evidence check)

- Original Markdown quotations: **8608 / 8608** exact normalized literal matches within the stated line spans.
- Original PDF quotations: **18649 / 18748** contiguous normalized matches in the extracted text of the claimed physical page.
- **99** do not match contiguous extracted PDF text: **90** were already flagged as requiring visual verification, and **9** were not. Complex table column layouts and figures can explain a subset; mismatches must be reviewed against the original page image or faithful page-layout extraction rather than silently deemed verified or fabricated.
- Exact original positions and the complete mismatch list appear in `08_quote_exceptions.jsonl`. This further prevents Phase 08 from being certified complete in this response.
