#!/usr/bin/env python3
"""Independent consistency check for Phase 08 after superseding Phase 07."""
import collections,hashlib,json,zipfile
from pathlib import Path
root=Path('/mnt/data/onelevel_v10_6'); out=root/'phase08'
def load(p):return [json.loads(s) for s in open(p,encoding='utf8') if s.strip()]
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
ledger=load(out/'08_final_ledger.jsonl');counts=json.load(open(out/'08_binary_counts.json'))
r=load('/mnt/data/common_atomic_reqs(5).jsonl');n=load('/mnt/data/common_negative_controls(5).jsonl')
shard1=load(root/'phase07/shard01/07_decision_audit.jsonl');shard2=load(root/'phase07/shard02/07_decision_audit.jsonl')
sup=load(root/'phase07/supersessions/07_superseding_adjudications.jsonl')
source={x['item_id']:x for x in shard1+shard2}; assert len(source)==4240
active={x['item_id']:{**x} for x in shard1+shard2}
for x in sup:
 assert x['prior_final_cell']==source[x['item_id']]['final_cell']
 active[x['item_id']]['final_cell']=x['final_cell']
from collections import Counter
kinds=Counter(x['record_type'] for x in ledger)
assert kinds==Counter({'FINAL_SOURCE':638,'FINAL_CONTROL':142,'FINAL_CLASS':2963,'EXCLUDED_GENERATED_CLASS':497,'FINAL_RESIDUAL':66}),kinds
sourcelist=[x for x in ledger if x['record_type']=='FINAL_SOURCE'];controllist=[x for x in ledger if x['record_type']=='FINAL_CONTROL'];classes=[x for x in ledger if x['record_type']=='FINAL_CLASS'];excluded=[x for x in ledger if x['record_type']=='EXCLUDED_GENERATED_CLASS'];res=[x for x in ledger if x['record_type']=='FINAL_RESIDUAL']
assert {x['source_id'] for x in sourcelist}=={x['requirement_id'] for x in r}
assert {x['control_id'] for x in controllist}=={x['control_id'] for x in n}
assert {x['class_id'] for x in classes}|{x['class_id'] for x in excluded}=={k for k,v in active.items() if v['direction']=='G'}
assert not ({x['class_id'] for x in classes}&{x['class_id'] for x in excluded})
assert all(x['scoring_cell']==active[x['item_id']]['final_cell'] for x in sourcelist+controllist)
assert all(x['diagnostic_cell']==active[x['class_id']]['final_cell'] for x in classes)
assert all(active[x['class_id']]['eligibility_status']=='EXCLUDED_NONDEFINITIVE' for x in excluded)
assert set(x['residual_id'] for x in res)==set(x['residual_id'] for x in load(out/'08_residual_consolidation_audit.jsonl'))
fps={x['class_id'] for x in classes if x['diagnostic_cell']=='FP'}
generated_from_res={y for z in res for y in z['member_gc_ids']}
assert fps==generated_from_res,(fps-generated_from_res,generated_from_res-fps)
for x in classes:
 assert len(x['unsupported_residual_ids'])==len(set(x['unsupported_residual_ids']))
for x in res:
 assert len(x['member_gc_ids'])==len(set(x['member_gc_ids']))
assert sum(x['scoring_cell']=='TP' for x in sourcelist)==counts['canonical_TP']==599
assert sum(x['scoring_cell']=='FN' for x in sourcelist)==counts['canonical_FN']==39
assert sum(x['scoring_cell']=='TN' for x in controllist)==counts['canonical_TN']==142
assert sum(x['scoring_cell']=='FP' for x in controllist)==0
assert counts['F_unsupported_unique']==len(res)==66
assert counts['canonical_FP']==sum(x['scoring_cell']=='FP' for x in controllist)+len(res)==66
assert len(set(source))==4240
assert len(sup)==7 and sum(x['final_cell']=='TP' for x in sup)==6
assert all(x['pdf_evidence'] for x in sourcelist+controllist+classes)
# Shared external run journal is immutable and complete.
external=json.load(open('/mnt/data/semantic_summary(2).json'))
assert external['completed_items']==4240 and external['completed_batches']==265 and external['status']=='COMPLETE'
state=json.load(open('/mnt/data/run_state(2).json'))
assert state['model']=='gpt-6.2-sol' and state['batch_size']==16
zip_path='/mnt/data/batch_journals(2).zip'
with zipfile.ZipFile(zip_path) as z:
 ids=[p for p in z.namelist() if p.startswith('batch_journals/B10.6-') and p.endswith('.json')]
 assert len(ids)==265
 checks=[]
 for name in ids:
  j=json.loads(z.read(name));checks.append((name,len(j['item_records'])))
 assert sum(k for _,k in checks)==4240
status={'status':'PHASE_COMPLETED','protocol_version':'10.6','all_programmed_assertions_passed':True,'frozen_R':len(r),'frozen_N':len(n),'phase07_ids':len(source),'external_journal_batches':len(ids),'final_ledger_rows':len(ledger),'canonical_TP':599,'canonical_FN':39,'canonical_TN':142,'canonical_FP':66,'unsupported_F':66,'phase07_supersessions':7,'source_and_class_coverage_exact':True,'residual_class_crosswalk_exact':True,'pdf_source_sha256':sha('/mnt/data/OrionDesk_AI_Detailed_Design_Specification(6).pdf'),'final_ledger_sha256':sha(out/'08_final_ledger.jsonl'),'final_counts_sha256':sha(out/'08_binary_counts.json'),'note_en':'Original Phase 07 decisions and v5 journals preserved. This check verifies population, identities, conservation and source provenance; it does not independently re-judge all semantic propositions.'}
(out/'08_independent_postcheck.json').write_text(json.dumps(status,indent=2,sort_keys=True)+'\n')
print(json.dumps(status,indent=2))
