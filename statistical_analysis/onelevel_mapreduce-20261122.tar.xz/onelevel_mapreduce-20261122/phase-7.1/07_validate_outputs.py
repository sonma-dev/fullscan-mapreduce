#!/usr/bin/env python3
"""Independent mechanical acceptance checks for Phase 07 Shard 01."""
import collections,hashlib,json
from pathlib import Path
from sklearn.feature_extraction.text import TfidfVectorizer
root=Path('/mnt/data/onelevel_v10_6/phase07/shard01')
r=lambda name: [json.loads(s) for s in (root/name).open() if s.strip()]
a=r('07_assistant_adjudications.jsonl');q=r('07_decision_audit.jsonl');ex=r('07_excluded_nondefinitive.jsonl');b=r('07_input_blockers.jsonl')
summary=json.loads((root/'07_adjudication_summary.json').read_text())
assert len(q)==2120 and len(a)==1872 and len(ex)==248 and not b
assert set(x['item_id'] for x in a).isdisjoint({x['item_id'] for x in ex})
assert {x['item_id'] for x in a}|{x['item_id'] for x in ex}=={x['item_id'] for x in q}
assert len({x['item_id'] for x in q})==len(q)
assert all(x['final_cell'] is not None and x['decision_origin']=='PHASE07_ASSISTANT' for x in a)
assert all(x['final_cell'] is None and x['eligibility_status']=='EXCLUDED_NONDEFINITIVE' for x in ex)
assert all(any(z['verified_current_original_exact'] for z in x['pdf_evidence']) for x in a)
assert all(any(z['verified_current_original_exact'] for z in x['generated_evidence']) for x in a+ex)
c=collections.Counter((x['direction'],x['final_cell']) for x in a)
assert c[('R','TP')]==300 and c[('R','FN')]==19 and c[('N','TN')]==71
assert c[('G','TP')]==1444 and c[('G','FP')]==38
assert len([x for x in ex if x['direction']=='G'])==248
assert sum(c.values())==1872
assert all((x['direction'] in ('R','G') and x['final_cell'] in ('TP','FN','FP')) or (x['direction']=='N' and x['final_cell'] in ('TN','FP')) for x in a)
# Check evidence proofs against the exact original locked bytes, once more.
byfile={f.name:f.read_text(encoding='utf-8').splitlines() for f in Path('/mnt/data').glob('*.md')}
expected=summary['source_digests']['eight_original_markdown']
checks=0
for x in a+ex:
 for e in x['generated_evidence']:
  lines=byfile[e['actual_file']]
  source=' '.join(' '.join(lines[e['line_start']-1:e['line_end']]).split()).lower()
  quote=' '.join(e['quote_en'].split()).lower()
  assert quote in source, (x['item_id'],e['actual_file'])
  assert hashlib.sha256(Path('/mnt/data',e['actual_file']).read_bytes()).hexdigest()==e['source_sha256']
  checks+=1

# Identify, but DO NOT consolidate, closely resembling generated FP and TP claims.
g=[x for x in a if x['direction']=='G'];fp=[x for x in g if x['final_cell']=='FP'];tp=[x for x in g if x['final_cell']=='TP']
v=TfidfVectorizer(stop_words='english',ngram_range=(1,2),sublinear_tf=True)
z=v.fit_transform([x['statement_en'] for x in fp+tp]);similar=z[:len(fp)]@z[len(fp):].T
cross=[]
for i,x in enumerate(fp):
 scores=similar[i].toarray().ravel();ids=scores.argsort()[-3:][::-1]
 pairs=[{'tp_class_id':tp[j]['item_id'],'score':round(float(scores[j]),6),
         'near_statement_en':tp[j]['statement_en']} for j in ids if scores[j]>=0.55]
 if pairs:
  cross.append({'record_type':'PHASE07_CROSS_LABEL_RECHECK_CANDIDATE','fp_class_id':x['item_id'],
  'fp_statement_en':x['statement_en'],'fp_unmet_predicates_en':x['unmet_predicates_en'],
  'nearby_pdf_supported_classes':pairs,
  'decision_policy_en':'Do not infer same semantic claim from similar wording. The unsupported residual may be a material additional scope or modality. Phase 08 must check for an exact semantic contradiction and return any genuine inconsistency for Phase 07 supersession.'})
with (root/'07_cross_label_candidates.jsonl').open('w',encoding='utf-8') as f:
 for x in cross:f.write(json.dumps(x,ensure_ascii=False,sort_keys=True)+'\n')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
originals=['07_assistant_adjudications.jsonl','07_decision_audit.jsonl','07_excluded_nondefinitive.jsonl','07_input_blockers.jsonl','07_adjudication_summary.json','07_cross_label_candidates.jsonl']
check={
 'record_type':'PHASE07_SHARD01_INDEPENDENT_MECHANICAL_VALIDATION',
 'protocol_version':'10.6','shard_id':'S07-01','status':'MECHANICAL_CHECKS_PASSED',
 'checks':{
  'all_2120_items_accounted_once':True,'1872_eligible_final_cells_present':True,
  '248_nondefinitive_classes_excluded_not_scored':True,
  'all_R_source_binary':True,'R_TP_FN_319':True,'all_N_source_binary':True,'N_FP_TN_71':True,
  'all_eligible_G_diagnostic_binary':True,'all_eligible_verified_pdf_quotes':True,
  'all_eligible_verified_markdown_quotes':True,'no_semantic_unresolved_eligible':True,
  'no_canonical_metrics_computed':True,
  'external_model_configuration_matches_protocol':False,
 },
 'counts':{'shard_items':len(q),'eligible':len(a),'excluded_ineligible':len(ex),'blockers':len(b),
 'final_R_TP':c[('R','TP')],'final_R_FN':c[('R','FN')],
 'final_N_TN':c[('N','TN')],'final_N_FP':c[('N','FP')],
 'final_G_supported':c[('G','TP')],'final_G_unsupported_candidate':c[('G','FP')],
 'quote_to_original_line_confirmations':checks,'FP_nearby_supported_semantic_inspection_candidates':len(cross)},
 'files_sha256':{n:sha(root/n) for n in originals},
 'note_en':'Cross-label candidates are similarity diagnostics only, not new decisions or deduplicated FP totals. The uploaded external results use gpt-6.2-sol rather than the specified gpt-6.1-sol; cross-method score comparability remains blocked without a protocol-approved correction.'
}
(root/'07_integrity_check.json').write_text(json.dumps(check,ensure_ascii=False,indent=2,sort_keys=True)+'\n',encoding='utf-8')
report=f'''# Phase 07 — Shard 01: Evidence-Grounded Adjudication Report

Protocol: 10.6. Method: onelevel. Generation reasoning effort: low. External evaluator effort observed: high.

## Execution outcome

All 2,120 original Shard 01 queue IDs were accounted for exactly once. The external run contains 4,240 item results across 265 complete, hash-verified 16-item batch journals, including every Shard 01 item. This phase does not modify the original PDF, source Markdown, reference R/N files, prior generated outputs, or external v5 result records.

The assistant adjudication records contain {len(a):,} substantive definitive items. {len(ex):,} other GC entries were independently marked nondefinitive or editorial, and were retained as explicit exclusions rather than converted into false-positive or true-negative counts. No eligible Shard 01 item remains semantically undecided.

| Shard 01 direction | Source-supported / positive | Source-uncovered / unsupported | Ineligible exclusions | Total |
|---|---:|---:|---:|---:|
| R | TP {c[('R','TP')]} | FN {c[('R','FN')]} | 0 | 319 |
| N | TN {c[('N','TN')]} | FP {c[('N','FP')]} | 0 | 71 |
| G diagnostic | Supported {c[('G','TP')]} | Unsupported residual candidates {c[('G','FP')]} | {len(ex)} | 1,730 |

The GC diagnostic TP count does not increment canonical TP; the GC unsupported candidates are **not** canonical FP before exact semantic consolidation and N/F overlap review in Phase 08. The R/N counts above apply **only to Shard 01**, not the complete benchmark.

## Evidence procedure

1. Verified the 90-page original PDF and all eight source Markdown files against the frozen SHA-256 identity.
2. Validated every original external batch journal's content hash, ordered IDs, batch index, source hashes, and final v5 item results; preserved all raw v5 JSON unchanged.
3. For every Shard 01 item, inspected source-anchored PDF and exact original Markdown line quotations, with an independent reciprocal text-index candidate trail. An original quotation proves provenance, not entailment by itself.
4. Kept v5 suggestions as evidence only. Corrected original atom scope where the model had combined separate predicates; distinguished genuine source gaps from documentary open questions and verified supported context and negative-control prohibitions.
5. Preserved nondefinitive/illustrative/open-question material separately. G classes cannot be counted as FP simply because the PDF does not contain an editorial aside or a proposed, unapproved design choice.
6. Rechecked closely similar G:FP and G:TP candidate phrases without collapsing them. {len(cross)} cross-label pairs are queued for Phase 08 mechanical contradiction detection; genuine conflicts must return to Phase 07 for explicit source-grounded supersession.

## Important provenance discrepancy

The supplied external run used **{summary['external_evaluator']['model_in_uploaded_result']}**, whereas the governing protocol specifies **gpt-6.1-sol**. This is a configuration deviation. The individual Phase 07 source-grounded decisions are retained, but the experiment **must not claim strict cross-method comparability** on these external runs without approved, consistent settings or a corrected handoff. The source hashes and original v5 responses were not changed.

## Status and next gate

Shard 01 adjudication: complete with the recorded provenance deviation and 248 documented ineligible GC classes. Phase 07 globally remains incomplete until Shard 02 is adjudicated with the same source-meaning rules. Phase 08 and Phase 09 have not been performed. No canonical Precision/Recall/F1 has been computed. The Phase 08 eligibility reconciliation must explicitly account for the 248 G classes excluded here without rewriting prior phase artifacts.
'''
(root/'07_report.md').write_text(report,encoding='utf-8')
print(json.dumps({'checks_passed':True,'cross_label_candidates':len(cross),'quote_checks':checks,'report':str(root/'07_report.md')},ensure_ascii=False))
