# Phase 07 — Shard 01: Evidence-Grounded Adjudication Report

Protocol: 10.6. Method: onelevel. Generation reasoning effort: low. External evaluator effort observed: high.

## Execution outcome

All 2,120 original Shard 01 queue IDs were accounted for exactly once. The external run contains 4,240 item results across 265 complete, hash-verified 16-item batch journals, including every Shard 01 item. This phase does not modify the original PDF, source Markdown, reference R/N files, prior generated outputs, or external v5 result records.

The assistant adjudication records contain 1,872 substantive definitive items. 248 other GC entries were independently marked nondefinitive or editorial, and were retained as explicit exclusions rather than converted into false-positive or true-negative counts. No eligible Shard 01 item remains semantically undecided.

| Shard 01 direction | Source-supported / positive | Source-uncovered / unsupported | Ineligible exclusions | Total |
|---|---:|---:|---:|---:|
| R | TP 300 | FN 19 | 0 | 319 |
| N | TN 71 | FP 0 | 0 | 71 |
| G diagnostic | Supported 1444 | Unsupported residual candidates 38 | 248 | 1,730 |

The GC diagnostic TP count does not increment canonical TP; the GC unsupported candidates are **not** canonical FP before exact semantic consolidation and N/F overlap review in Phase 08. The R/N counts above apply **only to Shard 01**, not the complete benchmark.

## Evidence procedure

1. Verified the 90-page original PDF and all eight source Markdown files against the frozen SHA-256 identity.
2. Validated every original external batch journal's content hash, ordered IDs, batch index, source hashes, and final v5 item results; preserved all raw v5 JSON unchanged.
3. For every Shard 01 item, inspected source-anchored PDF and exact original Markdown line quotations, with an independent reciprocal text-index candidate trail. An original quotation proves provenance, not entailment by itself.
4. Kept v5 suggestions as evidence only. Corrected original atom scope where the model had combined separate predicates; distinguished genuine source gaps from documentary open questions and verified supported context and negative-control prohibitions.
5. Preserved nondefinitive/illustrative/open-question material separately. G classes cannot be counted as FP simply because the PDF does not contain an editorial aside or a proposed, unapproved design choice.
6. Rechecked closely similar G:FP and G:TP candidate phrases without collapsing them. 7 cross-label pairs are queued for Phase 08 mechanical contradiction detection; genuine conflicts must return to Phase 07 for explicit source-grounded supersession.

## Important provenance discrepancy

The supplied external run used **gpt-6.2-sol**, whereas the governing protocol specifies **gpt-6.1-sol**. This is a configuration deviation. The individual Phase 07 source-grounded decisions are retained, but the experiment **must not claim strict cross-method comparability** on these external runs without approved, consistent settings or a corrected handoff. The source hashes and original v5 responses were not changed.

## Status and next gate

Shard 01 adjudication: complete with the recorded provenance deviation and 248 documented ineligible GC classes. Phase 07 globally remains incomplete until Shard 02 is adjudicated with the same source-meaning rules. Phase 08 and Phase 09 have not been performed. No canonical Precision/Recall/F1 has been computed. The Phase 08 eligibility reconciliation must explicitly account for the 248 G classes excluded here without rewriting prior phase artifacts.
