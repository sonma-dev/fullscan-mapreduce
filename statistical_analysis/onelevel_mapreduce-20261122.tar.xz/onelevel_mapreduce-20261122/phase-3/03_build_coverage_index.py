#!/usr/bin/env python3
"""Phase 03, Protocol v10.6: exhaustive R->generated evidence candidate discovery.
Discovery hypotheses are NOT semantic TP/FN/FP judgments. Input originals and earlier phase outputs are read-only.
"""
from __future__ import annotations
import os, re, json, math, hashlib, unicodedata, collections
from pathlib import Path
import numpy as np
import fitz
from sklearn.feature_extraction.text import TfidfVectorizer

BASE=Path('/mnt/data')
ROOT=BASE/'onelevel_v10_6'
OUT=ROOT/'phase03'
PDF=BASE/'OrionDesk_AI_Detailed_Design_Specification(6).pdf'
REF=BASE/'common_atomic_reqs(5).jsonl'
NEG=BASE/'common_negative_controls(5).jsonl'
FROZEN=BASE/'reference_freeze(5).json'
GO=ROOT/'phase02/02_generated_atoms_final.jsonl'
GC=ROOT/'phase02/02_generated_classes_final.jsonl'
LOCK=ROOT/'phase01/01_reference_lock.json'
AUDIT=ROOT/'phase02/02_integrity_check.json'

def sha(p):
 h=hashlib.sha256()
 with open(p,'rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''): h.update(b)
 return h.hexdigest()

def jlines(p):
 with open(p,encoding='utf-8') as f:
  for s in f:
   if s.strip():yield json.loads(s)

def save_jl(p,items):
 with open(p,'w',encoding='utf-8') as f:
  for x in items: f.write(json.dumps(x,ensure_ascii=False,sort_keys=True)+'\n')

def normalize(s):
 return re.sub(r'\s+',' ',unicodedata.normalize('NFKC',str(s)).replace('\u00ad','').replace('\u2011','-').replace('\u2010','-')).strip().lower()

def get_pages(s):
 # Sources cite p.57 / pp.57–59, 83; only explicit page citations qualify.
 found=[]
 for m in re.finditer(r'(?<![a-z])pp?\.\s*([0-9][0-9\s,\-–]*)(?![a-z])',s,flags=re.I):
  text=m.group(1)
  if not text.strip(): continue
  for t in re.findall(r'\d+\s*[-–]\s*\d+|\d+',text):
   if '-' in t or '–' in t:
    a,b=map(int,re.split(r'\s*[-–]\s*',t));found.extend(range(a,b+1) if a<=b and b-a<12 else [])
   else:found.append(int(t))
 return sorted(set(x for x in found if 1<=x<=90))

lock=json.load(open(LOCK,encoding='utf-8'))
assert lock['protocol_version']=='10.6' and lock['method']=='onelevel' and lock['phase_status']=='PHASE_COMPLETED'
assert json.load(open(AUDIT,encoding='utf-8'))['phase_status']=='PHASE_COMPLETED'
assert len(fitz.open(PDF))==90
assert sha(PDF)==lock['pdf_sha256'] and sha(REF)==lock['common_atomic_reqs_sha256']
assert sha(NEG)==lock['common_negative_controls_sha256'] and sha(FROZEN)==lock['reference_freeze_sha256']
role_sources={}
for r in lock['source_files']:
 assert sha(r['original_path'])==r['sha256'],f"Source changed: {r['original_path']}"
 lines=Path(r['original_path']).read_text(encoding='utf-8').splitlines()
 assert len(lines)==r['line_count']
 role_sources[r['actual_filename']]=(r,lines)
Rs=list(jlines(REF));GOs=list(jlines(GO));GCs=list(jlines(GC))
assert len(Rs)==638 and len(GOs)==3615 and len(GCs)==3432
assert len(set(x['requirement_id'] for x in Rs))==len(Rs)
assert len(set(x['go_id'] for x in GOs))==len(GOs)
assert len(set(x['gclass_id'] for x in GCs))==len(GCs)
by_go={x['go_id']:x for x in GOs}
assert all(x['generated_class_id'] in {c['gclass_id'] for c in GCs} for x in GOs)

D=fitz.open(PDF)
pdf_texts=[normalize(p.get_text()) for p in D]
pdf_checks=[]
for r in Rs:
 for ev in r['pdf_evidence']:
  p=ev['physical_page']; assert 1<=p<=90
  q=ev.get('quote',ev.get('visible_text',''))
  if ev['pdf_verification']=='PDF_VISUAL_INSPECTED':
   pdf_checks.append({'requirement_id':r['requirement_id'],'physical_page':p,'status':'PREVIOUS_VISUAL_INSPECTION_SHA_LOCKED','quote_en':q,'visual_locator':ev.get('visual_locator')})
   continue
  assert ev['pdf_verification']=='PDF_TEXT_EXACT' and normalize(q) in pdf_texts[p-1],(r['requirement_id'],p,q)
  pdf_checks.append({'requirement_id':r['requirement_id'],'physical_page':p,'status':'REVERIFIED_EXACT_ORIGINAL_PDF','quote_en':q})

gen_checks=collections.Counter()
for g in GOs:
 r,lines=role_sources[g['actual_filename']]
 assert g['role']==r['role'] and g['source_sha256']==r['sha256']
 s,e=g['line_start'],g['line_end']
 assert 1<=s<=e<=len(lines)
 span='\n'.join(lines[s-1:e])
 raw=g['source_quote_en']
 assert normalize(raw) in normalize(span),(g['go_id'],g['actual_filename'],s,raw[:100])
 gen_checks['full_source_line_quote_reverified']+=1

# Search entire 8 files through every definitive occurrence with original headings and row context.
# Build multiple independent retrieval channels to reduce phrase/synonym and topic bias.
def context(g):
 h=' / '.join(g['heading_path'][-3:])
 return ' '.join([g['statement_en'],g.get('row_label') or '',g.get('inherited_context_en') or '',h])

texts=[g['statement_en'] for g in GOs]
contexts=[context(g) for g in GOs]
q_stmt=[r['statement_en'] for r in Rs]
q_exp=[r['statement_en']+' '+' '.join(r.get('required_predicates',[])) for r in Rs]
q_quotes=[' '.join(ev.get('quote',ev.get('visible_text','')) for ev in r['pdf_evidence'][:3]) or r['statement_en'] for r in Rs]

# Sparse TF-IDF, distinct query types. Every R is evaluated against all eligible GO.
word=TfidfVectorizer(stop_words='english',ngram_range=(1,2),sublinear_tf=True,max_features=100000)
word.fit(texts+contexts+q_stmt+q_exp+q_quotes)
W=word.transform(texts); Wc=word.transform(contexts)
Q=word.transform(q_stmt); Qe=word.transform(q_exp); Qp=word.transform(q_quotes)
S_w=(Q@W.T).toarray().astype(np.float32)
S_e=(Qe@W.T).toarray().astype(np.float32)
S_q=(Qp@W.T).toarray().astype(np.float32)
S_c=(Q@Wc.T).toarray().astype(np.float32)
char=TfidfVectorizer(analyzer='char_wb',ngram_range=(3,5),sublinear_tf=True,min_df=2,max_features=160000,dtype=np.float32)
char.fit(texts+q_stmt)
C=char.transform(texts); QC=char.transform(q_stmt)
S_ch=(QC@C.T).toarray().astype(np.float32)

page_sets=[set(get_pages(g.get('source_quote_en',''))) for g in GOs]
r_pages=[set(r['source_physical_pages']) for r in Rs]

# Lexical predicate coverage is a hint only: no automatic semantic FULL proof.
stop=set(word.get_stop_words())|{'confirmed','source','need','needs','confirmation','requirement','requires','required','implementation','system','must','shall','p','pp','api','dat','bat','scr','flow'}
def terms(s):
 return {x for x in re.findall(r'[a-z][a-z0-9_-]{2,}',normalize(s)) if x not in stop}
Gterms=[terms(g['statement_en']+' '+(g.get('inherited_context_en') or '')) for g in GOs]
Rterms=[terms(r['statement_en']) for r in Rs]

def topidx(scores,n):
 n=min(n,len(scores))
 k=np.argpartition(-scores,n-1)[:n]
 return sorted(k,key=lambda i:(-float(scores[i]),int(i)))

def rec_evidence(g,score,features):
 return {'go_id':g['go_id'],'gclass_id':g['generated_class_id'],
         'actual_file':g['actual_filename'],'source_role':g['role'],
         'source_sha256':g['source_sha256'],'line_start':g['line_start'],'line_end':g['line_end'],
         'table_cell':g.get('cell_index'),'table_row':g.get('row_label'),
         'heading_path':g.get('heading_path'),
         'statement_en':g['statement_en'],
         'verified_original_quote_en':g['source_quote_en'],
         'quote_verified_against_locked_original':True,
         'rank_retrieval_score':round(float(score),5),
         'retrieval_features':{k:round(float(v),5) for k,v in features.items()}}

def predicate_hints(r,inds):
 out=[]
 for pred in r.get('required_predicates',[]):
  ts=terms(pred)
  if not ts: continue
  scored=[]
  for j in inds:
   sim=len(ts&Gterms[j])/len(ts)
   if sim>=0.20:scored.append((sim,j))
  scored.sort(key=lambda x:(-x[0],x[1]))
  out.append({'predicate_en':pred,'nonsemantic_term_overlap':round(scored[0][0],3) if scored else 0.0,
              'go_candidates':[GOs[j]['go_id'] for sim,j in scored[:3]],
              'warning':'Term overlap is not semantic entailment.'})
 return out

coverage=[];bridges=[];selection_stats=collections.Counter();src_roles=collections.Counter();misses=[]
for i,r in enumerate(Rs):
 # Inclusion union of independent retrieval methods; page is only a cross-check.
 page_bonus=np.zeros(len(GOs),dtype=np.float32)
 if 1<=len(r_pages[i])<=5:
  for j,pg in enumerate(page_sets):
   if pg and pg & r_pages[i]: page_bonus[j]=0.08
 combined=(0.31*S_w[i]+0.22*S_e[i]+0.22*S_ch[i]+0.13*S_c[i]+0.08*S_q[i]+page_bonus)
 pool=set()
 for mat,n in [(S_w,15),(S_e,15),(S_ch,15),(S_c,12),(S_q,10)]:pool.update(topidx(mat[i],n))
 pool.update(topidx(combined,32))
 if np.any(page_bonus):
  eligible=np.flatnonzero(page_bonus)
  eligible=sorted(eligible,key=lambda j:(-combined[j],j))[:10]
  pool.update(eligible)
 # Diverse selection includes evidence across roles when strongly competitive.
 order=sorted(pool,key=lambda j:(-combined[j],j))
 selected=order[:18]
 # Force at most 1 extra from unrepresented source files, if nearby (no irrelevant fillers).
 present={GOs[j]['role'] for j in selected}
 for role in [x['role'] for x in lock['source_files']]:
  if role in present: continue
  cand=next((j for j in order[18:] if GOs[j]['role']==role and combined[j]>=max(0.08,combined[order[0]]*0.55)),None)
  if cand is not None: selected.append(cand);present.add(role)
 selected.sort(key=lambda j:(-combined[j],j))
 selected=selected[:24]
 if not selected: raise RuntimeError('No candidate entries for '+r['requirement_id'])
 cands=[]
 for j in selected:
  feats={'word':S_w[i,j],'predicate_query':S_e[i,j],'char_ngrams':S_ch[i,j],
         'context':S_c[i,j],'pdf_quote_search':S_q[i,j],
         'citation_page_boost':page_bonus[j]}
  cands.append(rec_evidence(GOs[j],combined[j],feats));src_roles[GOs[j]['role']]+=1
 hints=predicate_hints(r,selected)
 # Distinct facet indicators do not judge truth, especially broad conditional predicates.
 best=selected[0];high=combined[best]
 if high>=.44: status='STRONG_RETRIEVAL_CANDIDATE_UNADJUDICATED'
 elif high>=.23: status='CONTEXTUAL_RETRIEVAL_CANDIDATE_UNADJUDICATED'
 else: status='WEAK_RETRIEVAL_CANDIDATE_EXPLICIT_UNCERTAINTY'
 selection_stats[status]+=1
 if high<.23:misses.append(r['requirement_id'])
 # Potential complete proof split across multiple GO classes, never count a source TP here.
 chosen=[];uncovered=set()
 pts=[terms(x) for x in r.get('required_predicates',[]) if terms(x)]
 if not pts: pts=[Rterms[i]]
 for facet in pts:
  if facet: uncovered.update(facet)
 for j in selected[:12]:
  reduction=len(uncovered & Gterms[j])
  if reduction>=2 or (not chosen and reduction>=1):
   chosen.append(j); uncovered -= Gterms[j]
  if len(chosen)>=6 or not uncovered:break
 # Explicit bridge candidate for multi-facet conjunction OR broad universal application.
 universal=bool(re.search(r'(?i)\b(every|all|any|never|across every|for each|regardless of|throughout all)\b',r['statement_en']))
 if len(pts)>1 or universal or (len(chosen)>1 and len(r['statement_en'])>70):
  role_count=len({GOs[j]['role'] for j in chosen})
  bridge={'record_type':'SEMANTIC_COVERAGE_BRIDGE_CANDIDATE','protocol_version':'10.6','method':'onelevel',
     'source_id':r['requirement_id'],'required_predicates_en':r.get('required_predicates',[]),
     'bridge_kind':('UNIVERSAL_SCOPE_APPLICABILITY_CANDIDATE' if universal and len(pts)<=1 else 'CROSS_FILE_CONJUNCTION_CANDIDATE' if role_count>1 else 'MULTI_OCCURRENCE_CONTEXT_CANDIDATE'),
     'universal_scoped_source_statement':universal,
     'independently_verified_source':True,'candidate_go_ids':[GOs[j]['go_id'] for j in chosen],
     'candidate_gclass_ids':list(dict.fromkeys(GOs[j]['generated_class_id'] for j in chosen)),
     'candidate_roles':sorted({GOs[j]['role'] for j in chosen}),
     'term_coverage_fraction':round(1-(len(uncovered)/max(1,len(set.union(*pts)))),4),
     'unresolved_proof_obligation_en':'Check each actor, condition, timing, negative exception and outcome against the original; a cross-file topical association is not sufficient.',
     'semantic_entailment_committed':False,'candidate_evidence':[rec_evidence(GOs[j],combined[j],{'retrieval':combined[j]}) for j in chosen]}
  bridges.append(bridge)
 coverage.append({'record_type':'SOURCE_COVERAGE_DISCOVERY','protocol_version':'10.6','method':'onelevel',
   'source_id':r['requirement_id'],'source_statement_en':r['statement_en'],
   'source_scope_en':r.get('source_scope'),'required_predicates_en':r.get('required_predicates',[]),
   'pdf_sha256':lock['pdf_sha256'],'original_pdf_evidence':[{'physical_page':x['physical_page'],
         'quote_en':x.get('quote',x.get('visible_text','')),
         'verification':x['pdf_verification'],'visual_locator':x.get('visual_locator')} for x in r['pdf_evidence']],
   'pdf_original_evidence_verified':True,
   'search_scope_roles':[x['role'] for x in lock['source_files']],
   'all_eligible_go_searched':len(GOs),'all_effective_gc_indexed':len(GCs),
   'candidate_count':len(cands),'candidate_evidence':cands,
   'predicate_search_hints':hints,'coverage_discovery_status':status,
   'highest_candidate_score':round(float(high),5),
   'uncertainty_en':'Candidate retrieval, quotation existence and page alignment are not proof of complete semantic entailment. Phase 04 must challenge every proposed match and miss; no TP or FN is committed.',
   'future_phase04_full_predicate_audit_required':True,
   'scoring_cell':None})

assert len(coverage)==len(Rs)==638
assert all(c['candidate_count']>0 and c['pdf_original_evidence_verified'] for c in coverage)
assert all(c['scoring_cell'] is None for c in coverage)
assert len({c['source_id'] for c in coverage})==638
save_jl(OUT/'03_source_coverage.jsonl',coverage)
save_jl(OUT/'03_semantic_coverage_bridges.jsonl',bridges)
save_jl(OUT/'03_pdf_evidence_verification.jsonl',pdf_checks)

# Machine-readable audit: hash lock and accounting; no incorrect provisional TP claims.
verification={'record_type':'PHASE03_COVERAGE_VERIFICATION','protocol_version':'10.6','phase':'03',
  'method':'onelevel','phase_status':'PHASE_COMPLETED','generation_reasoning_effort_operator_declared':'low',
  'R':len(Rs),'eligible_GO':len(GOs),'effective_GC':len(GCs),
  'all_R_searched':True,'source_evidence_pdf_exact_reverified':sum(x['status']=='REVERIFIED_EXACT_ORIGINAL_PDF' for x in pdf_checks),
  'source_evidence_visual_from_sha_locked_phase01':sum(x['status']=='PREVIOUS_VISUAL_INSPECTION_SHA_LOCKED' for x in pdf_checks),
  'generated_evidence_quote_reverified_against_actual_original':gen_checks['full_source_line_quote_reverified'],
  'source_candidates_have_original_sha_verified':True,'source_candidates_have_verified_original_range':True,
  'retrieval_channels':['word_tfidf','predicate_tfidf','character_ngrams','context_tfidf','pdf_quote_tfidf','pdf_page_citation_hint'],
  'repeated_scoring_occurrences_not_counted':True,'semantic_candidate_status_counts':dict(selection_stats),
  'candidate_rows_total':sum(x['candidate_count'] for x in coverage),
  'bridge_candidates_total':len(bridges),
  'explicit_weak_evidence_item_ids':misses,
  'bridge_assertions_fully_adjudicated':0,
  'semantic_tp_fn_committed':0,
  'coverage_status':'EVIDENCE_DISCOVERY_ONLY_WITH_EXPLICIT_UNCERTAINTY',
  'phase04_started':False,
  'input_digests':{'pdf':sha(PDF),'reference_R':sha(REF),'reference_N':sha(NEG),'reference_freeze':sha(FROZEN),
                   'phase02_go':sha(GO),'phase02_gc':sha(GC),
                   'eight_markdown_roles':{x['role']:sha(x['original_path']) for x in lock['source_files']}},
  'outputs':{'03_source_coverage.jsonl':sha(OUT/'03_source_coverage.jsonl'),
             '03_semantic_coverage_bridges.jsonl':sha(OUT/'03_semantic_coverage_bridges.jsonl'),
             '03_pdf_evidence_verification.jsonl':sha(OUT/'03_pdf_evidence_verification.jsonl')},
  'limitations_en':['This stage discovers evidence candidates for every R and does not decide full semantic entailment.','No pretrained semantic-embedding or LLM judgment was used. Lexical and page-citation retrieval can rank an incomplete proposition highly and miss paraphrases.','Phase 04 must challenge candidate TPs and all provisional gaps, including contextual applicability and predicate coverage.','Figure-based PDF evidence is inherited from Phase 01 visual inspection with immutable PDF SHA-256.','Phase 05 will revisit Phase 02 exclusions and validate entire GC against the source.']}
with open(OUT/'03_coverage_audit.json','w',encoding='utf-8') as f:json.dump(verification,f,indent=2,ensure_ascii=False,sort_keys=True);f.write('\n')
print(json.dumps({'R':len(Rs),'GO':len(GOs),'GC':len(GCs),'bridge_count':len(bridges),'status_counts':dict(selection_stats),'candidate_rows':verification['candidate_rows_total'],'source_pdf_evidence_checked':len(pdf_checks)},indent=2))
