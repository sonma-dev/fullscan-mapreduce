# Phase 05 — Generated Validity Review (Protocol 10.6)

Method: **onelevel**. Generation reasoning-effort input: **low**.

The frozen 90-page PDF is the only normative source. All 3,432 original eligible generated classes were checked against the original PDF text and assigned source-page-verified candidate passages. All 3,010 Phase 02 exclusion records were revisited with their inherited provenance. The Phase 01–04 artifacts and R/N reference bytes are untouched.

## Inventory

- Frozen source-positive requirements: **638** (unchanged).
- Frozen negative controls: **142** (unchanged).
- Original definitive GO / GC: **3,615 / 3,432**.
- Additional independently definite GO recovered from exclusions: **48**.
- New provisional distinct recovered GC: **28**.
- Effective GO / GC after additive Phase 05 recovery: **3,663 / 3,460**.
- Recovered GO assigned to a previously existing semantic class: **9**.

## Evidence status

{
  "PDF_TEXT_CANDIDATE_PROVISIONAL": 1116,
  "STRONG_PDF_TEXT_RETRIEVAL_PROVISIONAL": 532,
  "WEAK_OR_NO_PDF_TEXT_MATCH_REQUIRES_REVIEW": 1778,
  "EXACT_NORMALIZED_PDF_TEXT_SPAN_PROVISIONAL": 6
}

The labels above are **candidate-discovery outcomes, not supported/unsupported final decisions**. A verified PDF quotation proves that words occur on a physical page, not that an assertion's entire predicate (including actor, condition, exception and timing) is entailed. Every class has an explicit unresolved semantic-adjudication status for Phase 06/07. Weak/no retrieved support must not be converted to a false positive.

## Exclusion audit

{
  "EXCLUDED_NONDEFINITIVE_CONTEXT_OR_EXAMPLE": 1135,
  "RETAIN_EXCLUSION_WITH_CONTEXT_CAUTION": 1836,
  "RECOVERED_DEFINITIVE": 39
}

Recovery adds a new GO only when an original excluded phrase is a separately testable definite requirement in context; narrative, examples, unresolved options and source citations do not create an eligible implementation claim. Source quote and line are verified for each recovered GO.

## Required downstream safeguards

- Phase 06 must examine **all 142 fixed N controls**, deduplicate residual unsupported assertions, and build an exhaustive v5-compatible queue for all genuinely pending R/N/GC.
- The effective G population comprises the **3,432 original GCs plus 28 new recovered GCs**, and each recovered GO mapped to an original class contributes an additional occurrence, not a new class.
- Phase 07 must independently adjudicate whole propositions before final metrics or FP claims. No Phase 05 textual-search status is a canonical TP, TN, FP or FN.
- The original Phase 02 duplicate statistic is preserved as historical. Recompute the effective raw GO/GC duplication metric from reconciled population only after the later semantic duplicate audit, rather than assuming Phase 05 automated retrieval proves equivalence.

## Limitations

- Original PDF text blocks were indexed exhaustively; dense/lexical retrieval can miss paraphrases, tables or qualified conditions. Candidate citations are included with real physical-page text; figures from the already validated Phase 01 visual evidence remain available.
- The exclusion selection is conservatively curated and not an LLM proof of all separable mixed fragments. `RETAIN_EXCLUSION_WITH_CONTEXT_CAUTION` records exist for substantive later challenges.
- No source R/N ledger was modified, no canonical metric computed, and no future phase was executed.
