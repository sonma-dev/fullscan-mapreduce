# Phase 09 — Coverage, Audit Scope, and Limitations

## Completed validations

- Validated the 90-physical-page PDF SHA-256 and all eight Markdown role/digest identities; frozen R/N JSONL hashes and IDs remain immutable.
- Independently enumerated every Phase 08 row: 638 R, 142 N, 2,963 definitive G, 497 nondefinitive excluded G, and 66 distinct FP residuals = 4,306 entries.
- Verified the original 4,240-item Phase 06 queue and its 265 committed 16-item external batch journals, including every batch's content SHA-256, input SHA-256, preserved item order, source identity, retries and completed item coverage.
- Recomputed R/N four-cell counts, effective GO/GC eligibility, generated-class validity, N/F overlap, unsupported-residual references, duplicate counts and the single canonical score without trust in Phase 08 aggregate arithmetic.
- Verified that superseding Phase 07 records remain separate and that unchanged v5 suggestions do not become authoritative classification cells.

## Qualification of measurements

- Precision, Recall, and F1 measure semantic compliance of these generated specifications with the **fictional** OrionDesk PDF reference, not deployment correctness or general model accuracy.
- The frozen reference was produced with bounded semantic audit: the original reference manifest discloses 730 unreviewed working items, incomplete independent shard/model validation and possible residual atomization issues. These quality limitations cannot be converted into changed R/N denominators during this run.
- This independent Phase 09 program verifies the existence, identity, and reconciled provenance of evidence. It does not perform a fresh semantic re-judgment of each of the 4,240 Phase 07 decisions; those remain an auditable classification layer and are not guaranteed correct by mechanical consistency alone.
- The Phase 08 quote-exception audit retained 99 previously mismatched auxiliary extracted PDF excerpts; this final ledger uses other verified support and retains the exceptions without altering their wording. Visual-only/nonstrict extraction remains a limitation where no exact text was available.
- A complete all-pairs semantic paraphrase/deduplication audit of all generated occurrences was not independently repeated here. The final 66 FP residuals represent Phase 08's evidence-justified consolidation, not a proof of absolute global semantic uniqueness.
- Raw Phase 05 GO/GC counts contain 497 subsequently excluded classes, so they are not the final **eligible** duplication denominator. The metric uses GO=3164 and GC=2963. The raw 3663/3460 ratio is retained solely as a pre-eligibility diagnostic.
- The generated-only F residuals are not the same as raw G:FP classes or 8-way repetition of one specification. The 78 diagnostic unsupported GC classes yielded 66 deduplicated residuals, and no duplicate with a frozen N violation was found.
- Operator states that fullload and twolevel also used `gpt-6.2-sol`, but their actual input manifests and all execution setting hashes are not inspected in this onelevel Phase 09. The deployment differs from the immutable protocol literal `gpt-6.1-sol`; interpretation is a common disclosed experimental convention, **not independently verified experiment invariance**.
- Phase 06 planned eight items per request; actual external 16-item batches are within protocol-approved choices, but direct cross-method comparability also requires matching batch size and all other method-invariant conditions.
- v5 confidence estimates are model self-reports, not calibrated probabilities. A successful file hash and valid quotation do not alone prove semantic entailment.

## Error-analysis traceability

- The final R source ledger and Phase 04 FN audit preserve source IDs, candidate evidence and unmet predicates. Do not derive counts for `TRUE_MISSING`, `PARTIAL_ENTAILMENT`, or corrected matcher misses from lexical search scores alone.
- The 497 exclusions and 2,885 supported/78 unsupported generated classes each have Phase 07 provenance and unaltered source locators.
- The 66 final F residual records and the `08_residual_consolidation_audit.jsonl` map unsupported affirmative obligations to one or more generated classes with independent justification. No unsupported generated residual was multiplied by repetition across eight Markdown files.
- Phase 03's 275 candidate bridges cannot be promoted to separate verified contextual proof counts without item-specific audit. The Phase 07–08 ledgers retain the applicable links.

## Final score scope

Single complete within-method score: Precision 90.0751879699%; Recall 93.8871473354%; F1 91.9416730622%. Comparison with another method is **conditional** upon verifying its frozen R/N bytes, model prompt/decision logic, eligible GO/GC rules, full-batch selection, evidence and dedup policies, and execution parameters.
