#!/usr/bin/env python3
"""Independent, fail-closed Phase 09 metric reconstruction for OrionDesk 10.6.

Reads original immutable inputs and all final Phase 08 records. Does not re-adjudicate
semantic claims and does not overwrite any preceding phase artifact.
"""
from __future__ import annotations
import ast
from collections import Counter, defaultdict
from decimal import Decimal, getcontext
import hashlib, json, math, re, unicodedata, zipfile
from pathlib import Path
from datetime import datetime, timezone

getcontext().prec = 42
ROOT=Path('/mnt/data')
WORK=ROOT/'onelevel_v10_6'
OUT=WORK/'phase09'
OUT.mkdir(parents=True,exist_ok=True)
PDF=ROOT/'OrionDesk_AI_Detailed_Design_Specification(6).pdf'
REFR=ROOT/'common_atomic_reqs(5).jsonl'
REFN=ROOT/'common_negative_controls(5).jsonl'
FREEZE=ROOT/'reference_freeze(5).json'
QUEUE=WORK/'phase06/06_llm_queue_v10.6.jsonl'
LEDGER=WORK/'phase08/08_final_ledger.jsonl'
COUNTS=WORK/'phase08/08_binary_counts.json'
STATE=ROOT/'run_state(2).json'
EXTRESULTS=ROOT/'semantic_decisions(3).jsonl'
JOURNALS=ROOT/'batch_journals(2).zip'
REFERENCE_LOCK=WORK/'phase01/01_reference_lock.json'
EXEC_SCRIPT=WORK/'phase06/semantic_decision_evaluator_v10.6_unlimited.py'
V5_SCRIPT=WORK/'evaluator_sources/semantic_decision_evaluator(3).py'

def load_json(p): return json.loads(p.read_text(encoding='utf-8'))
def rows(p):
    with p.open(encoding='utf-8-sig') as f:
        for n,line in enumerate(f,1):
            if line.strip():
                try: yield json.loads(line)
                except Exception as e: raise ValueError(f'Malformed JSONL {p}:{n}: {e}')

def sha(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for part in iter(lambda:f.read(1024*1024), b''):h.update(part)
    return h.hexdigest()
def sha_text(txt):return hashlib.sha256(txt.encode('utf-8')).hexdigest()
def jdump(x):return json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':'))
def fail(cond,msg):
    if not cond:raise ValueError(msg)
def write_obj(name,obj):
    (OUT/name).write_text(json.dumps(obj,ensure_ascii=False,indent=2,sort_keys=True)+'\n',encoding='utf-8')
def write_lines(name,arr):
    with (OUT/name).open('w',encoding='utf-8') as f:
        for a in arr: f.write(jdump(a)+'\n')

def ast_part(source,func_or_var):
    mod=ast.parse(source)
    for node in mod.body:
        if isinstance(node,(ast.FunctionDef,ast.AsyncFunctionDef)) and node.name==func_or_var:
            return ast.dump(node,include_attributes=False)
        if isinstance(node,(ast.Assign,ast.AnnAssign)):
            names=[x.id for x in node.targets if isinstance(x,ast.Name)] if isinstance(node,ast.Assign) else ([node.target.id] if isinstance(node.target,ast.Name) else [])
            if func_or_var in names:
                return ast.dump(node.value,include_attributes=False)
    raise ValueError('Missing v5 semantic fragment: '+func_or_var)

checks=[]
def check(condition,code,detail=None):
    fail(condition,f'{code}: {detail or "assertion failed"}')
    checks.append({'check':code,'passed':True,'detail':detail})

lock=load_json(REFERENCE_LOCK); freeze=load_json(FREEZE); state=load_json(STATE)
origR=list(rows(REFR));origN=list(rows(REFN))
check(lock['method']=='onelevel','explicit_method')
check(lock['protocol_version']=='10.6' and state['protocol_version']=='10.6','version_10_6')
check(sha(PDF)==lock['pdf_sha256']==freeze['source_document']['sha256']==state['pdf_sha256'],'pdf_frozen_identity')
try:
 import fitz
 with fitz.open(PDF) as f: page_count=len(f)
except ImportError:
 from pypdf import PdfReader
 page_count=len(PdfReader(str(PDF)).pages)
check(page_count==90,'original_pdf_90_pages')
check(sha(REFR)==lock['common_atomic_reqs_sha256']==freeze['output_artifacts_sha256']['common_atomic_reqs.jsonl'],'R_frozen_hash')
check(sha(REFN)==lock['common_negative_controls_sha256']==freeze['output_artifacts_sha256']['common_negative_controls.jsonl'],'N_frozen_hash')
check(len(origR)==638 and len(origN)==142,'frozen_R_N_sizes')
Rids=[x['requirement_id'] for x in origR];Nids=[x['control_id'] for x in origN]
check(len(set(Rids))==638 and len(set(Nids))==142 and not (set(Rids)&set(Nids)),'R_N_unique_disjoint')
check(all(x.get('source_pdf_sha256')==sha(PDF) for x in origR+origN),'frozen_PDF_provenance')

actual_files={}
for x in lock['source_files']:
 p=ROOT/x['actual_filename'];check(p.is_file(),'source_file_exists_'+x['role'])
 check(sha(p)==x['sha256']==state['file_sha256'][x['canonical_filename']],'source_hash_'+x['role'])
 actual_files[x['canonical_filename']]={'actual_file':x['actual_filename'],'sha256':x['sha256'],'path':str(p)}
check(len(actual_files)==8,'exactly_eight_source_roles')

q=list(rows(QUEUE));queue_ids=[x['item_id'] for x in q];
check(sha(QUEUE)==state['queue_sha256'],'frozen_queue_hash')
check(len(q)==4240 and len(set(queue_ids))==4240,'all_4240_external_queue_ids_unique')
qdir=Counter(x['direction'] for x in q)
check(qdir=={'R':638,'N':142,'G':3460},'external_queue_population')
check(all(x.get('unreliable') is True and x.get('record_type')=='UNRELIABLE_ITEM' for x in q),'v5_compatible_queue_flags')
check(queue_ids[:638]==Rids and queue_ids[638:780]==Nids,'queue_R_N_frozen_order')

# Raw Phase 05 class/occurrence inventory and later eligibility adjudication.
manifest=load_json(WORK/'phase05/05_effective_population_manifest.json')
classcounts={x['gclass_id']:x['effective_occurrence_count'] for x in manifest['effective_class_occurrence_crosswalk']}
check(len(classcounts)==3460 and sum(classcounts.values())==3663,'phase05_GO_GC_crosswalk')
check(set(queue_ids[780:])==set(classcounts),'external_generated_class_exact_identity')
rawgo=list(rows(WORK/'phase02/02_generated_atoms_final.jsonl'))
newgo=list(rows(WORK/'phase05/05_recovered_generated_atoms.jsonl'))
allgo=rawgo+newgo
check(len(rawgo)==3615 and len(newgo)==48 and len(allgo)==3663,'full_generated_occurrence_inventory')
mapgo={};
for x in allgo:
 gid=x['go_id'];cid=x['generated_class_id'];
 check(gid not in mapgo,'unique_GO_id')
 mapgo[gid]=cid
check(set(mapgo.values())==set(classcounts),'all_GO_mapped_to_GC')
member_counts=Counter(mapgo.values());check(member_counts==Counter(classcounts),'all_GO_multiplicities_preserved')

# Phase 07 supersessions cannot overwrite original decisions.
sup=list(rows(WORK/'phase07/supersessions/07_superseding_adjudications.jsonl'))
check(len(sup)==7 and len({x['item_id'] for x in sup})==7,'immutable_seven_supersessions')
sup_ids={x['item_id'] for x in sup}
shards=[]
for name in ['shard01','shard02']:
 p=WORK/'phase07'/name/'07_decision_audit.jsonl'
 rr=list(rows(p));check(len(rr)==2120,'shard_2120_'+name)
 shards.extend(rr)
check({x['item_id'] for x in shards}==set(queue_ids) and len(shards)==4240,'shards_partition_full_queue')

# Phase 08 canonical ledger is authority; rebuild counts from individual rows.
records=list(rows(LEDGER));B=load_json(COUNTS)
check(sha(LEDGER)==B['phase08_ledger_sha256'],'final_ledger_hash')
check(B['status']=='PHASE_COMPLETED' and B['canonical_metric_authority'] is True,'phase08_metric_authority')
types=defaultdict(list)
for x in records:
 check(x['method']=='onelevel' and x['source_pdf_sha256']==lock['pdf_sha256'],'canonical_row_identity')
 types[x['record_type']].append(x)
expected={'FINAL_SOURCE':638,'FINAL_CONTROL':142,'FINAL_CLASS':2963,'EXCLUDED_GENERATED_CLASS':497,'FINAL_RESIDUAL':66}
check({k:len(v) for k,v in types.items()}==expected,'canonical_4306_row_population')
source=types['FINAL_SOURCE'];ncont=types['FINAL_CONTROL'];gcls=types['FINAL_CLASS'];excluded=types['EXCLUDED_GENERATED_CLASS'];resid=types['FINAL_RESIDUAL']
check({x['item_id'] for x in source}==set(Rids),'canonical_R_exact_IDs')
check({x['item_id'] for x in ncont}==set(Nids),'canonical_N_exact_IDs')
allG={x['class_id'] for x in gcls+excluded}
check(allG==set(classcounts) and len(allG)==3460,'canonical_G_exclusions_conserved')
check(set(x['item_id'] for x in records if x['record_type']!='FINAL_RESIDUAL')==set(queue_ids),'all_queue_items_in_final_ledger')
check(all('pdf_evidence' in x and x['pdf_evidence'] for x in source),'R_evidence_trail_preserved')
check(all(x.get('pdf_evidence') or x.get('frozen_pdf_evidence') for x in ncont),'N_evidence_trail_preserved')
check(all(x.get('generated_evidence') for x in gcls+excluded),'G_generated_evidence_trail_preserved')
check(all(x.get('generated_evidence') and x.get('pdf_countercheck_evidence') for x in resid),'F_evidence_and_PDF_countercheck')
check(all(x.get('scoring_tp_contribution')==0 for x in gcls),'G_diagnostic_noncanonical_TP')
check(all(not x.get('canonical_fp_counted') for x in excluded),'nondefinitive_classes_not_FP_or_TN')

Rcells=Counter(x['scoring_cell'] for x in source)
Ncells=Counter(x['scoring_cell'] for x in ncont)
Gcells=Counter(x['diagnostic_cell'] for x in gcls)
check(set(Rcells)<={'TP','FN'} and set(Ncells)<={'FP','TN'},'R_N_binary_only')
check(set(Gcells)<={'TP','FP'} and len(gcls)==sum(Gcells.values()),'G_diagnostic_binary_only')
check(Gcells=={'TP':2885,'FP':78},'GC_supported_unsupported_count')
check(all(x.get('scoring_cell')=='FP' for x in resid),'residuals_only_FP')
check(len({x['residual_id'] for x in resid})==66,'F_unique_residual_ids')
Fid={x['residual_id'] for x in resid}; uns={x['class_id'] for x in gcls if x['diagnostic_cell']=='FP'}
check(all(set(x['member_gc_ids'])<=uns and len(x['member_gc_ids'])>=1 for x in resid),'F_members_only_unsupported_GC')
check(set().union(*(set(x['member_gc_ids']) for x in resid))==uns,'all_unsupported_GC_consolidated')
check(all(not x.get('frozen_negative_control_overlap_ids') for x in resid),'F_N_overlap_zero')
check(all(not x.get('counterfactual_affirmatively_asserted') for x in ncont),'negative_controls_not_positively_asserted')

TP=Rcells['TP'];FN=Rcells['FN'];TN=Ncells['TN'];Baffirm=Ncells['FP'];F=len(resid);FP=Baffirm+F
check((TP,FN,TN,FP)==(599,39,142,66),'independent_counts_match_phase08')
check(all((B[k]==v) for k,v in [('canonical_TP',TP),('canonical_FN',FN),('canonical_TN',TN),('canonical_FP',FP),('R_total',len(origR)),('N_total',len(origN)),('F_unsupported_unique',F)]),'independent_counts_equal_published')
check(TP+FN==len(origR) and TN+Baffirm==len(origN) and FP==Baffirm+F,'conservation_R_N_FP')
U=len(origR)+len(origN)+F
check(U==TP+TN+FP+FN==846,'canonical_universe_complete')

# Reconstruct the original Version 5.0 compatible external journal history.
external=list(rows(EXTRESULTS));er_ids=[x['item_id'] for x in external]
check(len(external)==len(q)==4240 and er_ids==queue_ids,'external_aggregate_complete_order')
check(all(x.get('final_cell_not_committed') is True for x in external),'v5_suggestions_are_not_canonical_cells')
state_attempts=state['attempts'];attempts_by_batch=Counter(x['batch_id'] for x in state_attempts)
check(len(attempts_by_batch)==265 and max(attempts_by_batch.values())<=4,'batch_retry_bounds')
check(len(state_attempts)==267,'actual_submission_attempts')
bsz=state['batch_size'];check(bsz in (8,16) and bsz==16,'executed_batch_size_16_allowed')
check(math.ceil(len(q)/bsz)==265,'executed_batches_cover_K')
check(state['model']=='gpt-6.2-sol','actual_external_model_provenance')
check(float(state['confidence_threshold'])==0.90,'v5_confidence_threshold')
check(state['filename_alias_policy']=='unique-role-verified-sha256-v1','alias_policy_active')

jrhashes=[]; all_journal_ids=[]
with zipfile.ZipFile(JOURNALS) as z:
 names=[n for n in z.namelist() if re.fullmatch(r'batch_journals/B10\.6-\d{5}\.json',n)]
 check(len(names)==265,'journal_zip_265_members')
 for index in range(265):
    name=f'batch_journals/B10.6-{index+1:05d}.json'
    check(name in names,'journal_name_'+str(index))
    raw=z.read(name);journal=json.loads(raw)
    part=q[index*bsz:(index+1)*bsz]
    check(journal['batch_index']==index and journal['batch_id']==f'B10.6-{index+1:05d}' and journal['batch_size']==len(part),'journal_batch_identity')
    check(journal['queue_sha256']==sha(QUEUE) and journal['pdf_sha256']==sha(PDF),'journal_source_hash')
    check(journal['input_digest']==sha_text(jdump(part)),'journal_exact_16_item_input')
    check(journal['content_sha256']==sha_text(jdump({'raw_model_json':journal['raw_model_json'],'item_records':journal['item_records']})),'journal_content_integrity')
    arr=journal['item_records'];rawres=journal['raw_model_json']['results']
    check(len(arr)==len(part)==len(rawres),'journal_exact_batch_cardinality')
    check([x['item_id'] for x in arr]==[x['item_id'] for x in part]==[x['item_id'] for x in rawres],'journal_item_order')
    check([x['item_id'] for x in arr]==[x['item_id'] for x in external[index*bsz:(index+1)*bsz]],'aggregate_same_item_order')
    jrhashes.append({'batch_id':journal['batch_id'],'content_sha256':journal['content_sha256'],'journal_file_sha256':hashlib.sha256(raw).hexdigest(),'item_count':len(arr)})
    all_journal_ids.extend(x['item_id'] for x in arr)
check(all_journal_ids==queue_ids,'no_journal_item_omitted_or_fabricated')

# Frozen v5 semantics and regression test evidence.
alias=load_json(WORK/'phase06/06_alias_regression.json')
check(alias['all_passed'] is True and all(alias['original_v5_semantic_core_unchanged'].values()),'alias_tests_and_v5_core')
original=V5_SCRIPT.read_text(encoding='utf-8')
derived=EXEC_SCRIPT.read_text(encoding='utf-8')
for sym in ['suggest','RESULT_SCHEMA','SYSTEM_PROMPT']:
 check(ast_part(original,sym)==ast_part(derived,sym),'unchanged_v5_'+sym)
check('"effort": "high"' in derived or "'effort': 'high'" in derived,'execution_source_high_reasoning')

# After Phase07 classification, excluded GC and their occurrences leave eligible denominator.
excluded_ids={x['class_id'] for x in excluded}
excluded_go=sum(classcounts[x] for x in excluded_ids)
GO_raw=len(allgo);GC_raw=len(classcounts)
GO=GO_raw-excluded_go;GC=GC_raw-len(excluded_ids)
check((GO,GC,GO_raw,GC_raw,excluded_go)==(3164,2963,3663,3460,499),'eligibility_adjusted_GO_GC')
check(GC==Gcells['TP']+Gcells['FP'],'GC_validity_denominator_definitive_only')

# Derive within/across-file duplicate classification from original GO identity and physical position.
byclass=defaultdict(list)
for x in allgo:
 cid=x['generated_class_id'];fn=x.get('actual_filename') or x.get('original_file')
 rank=int(re.match(r'^(\d\d)_',fn).group(1))
 byclass[cid].append({'go_id':x['go_id'],'file':fn,'role':rank,'line':int(x['line_start']),
                      'cell_index':x.get('cell_index')})
raw_within=raw_across=eligible_within=eligible_across=0
repeated=eligible_repeated=0
cross_repeated=eligible_cross_repeated=0
raw_duplicate_rows=[]
for cid, occ in sorted(byclass.items()):
 sorted_occ=sorted(occ,key=lambda x:(x['role'],x['line'], x['cell_index'] if isinstance(x['cell_index'],int) else -1,x['go_id']))
 first=sorted_occ[0]
 if len(occ)>1:
    repeated+=1
    if len({x['file'] for x in occ})>1:cross_repeated+=1
    if cid not in excluded_ids:
        eligible_repeated+=1
        if len({x['file'] for x in occ})>1:eligible_cross_repeated+=1
 seen_files={first['file']}
 for later in sorted_occ[1:]:
    position='within_file' if later['file'] in seen_files else 'across_file'
    seen_files.add(later['file'])
    if position=='within_file':raw_within+=1
    else:raw_across+=1
    if cid not in excluded_ids:
        if position=='within_file':eligible_within+=1
        else:eligible_across+=1
    raw_duplicate_rows.append({'gclass_id':cid,'go_id':later['go_id'], 'representative_go_id':first['go_id'], 'position':position,
                                'phase07_final_eligible':cid not in excluded_ids})
check(raw_within+raw_across==GO_raw-GC_raw==203,'raw_dup_excess_conservation')
check(eligible_within+eligible_across==GO-GC==201,'eligible_dup_excess_conservation')

# Exact metric arithmetic, computed exclusively from independently enumerated ledger cells.
D=lambda x:Decimal(x)
def div(n,d):return float(D(n)/D(d)) if d else None
P=div(TP,TP+FP);recall=div(TP,TP+FN);f1=div(2*TP,2*TP+FP+FN)
negpass=div(TN,len(origN));gvalid=div(Gcells['TP'],GC)
duprate=div(GO-GC,GO);raw_dup=div(GO_raw-GC_raw,GO_raw)

# Pre-adjudication count is from frozen Phase 06 queue; cannot substitute v5 abstentions.
pre={'R':638,'N':142,'G':3460,'pending_C':4240,'submitted_K':4240}
v5counts=Counter(str(x.get('suggested_decision')) for x in external)
v5status=Counter(x.get('decision_status') for x in external)
fn_causes=Counter(x.get('phase07_decision_reason_en','UNKNOWN') for x in source if x['scoring_cell']=='FN')
gprovenance=Counter(x.get('provenance_category') for x in gcls)

# Record condition comparability without inferring unseen runs' settings.
comparison={
 'within_method_numeric_score_valid':True,
 'other_methods_model':{'value':'gpt-6.2-sol','basis':'operator_statement_only','independently_verified':False},
 'actual_external_evaluator_model':'gpt-6.2-sol',
 'literal_protocol_evaluator_model':'gpt-6.1-sol',
 'shared_model_deviation_policy':'Recorded as a common operator-declared deviation; not grounds to adjust the onelevel score.',
 'actual_external_reasoning_effort':'high (execution source setting; no contradiction found in uploaded records)',
 'generation_reasoning_effort':'low',
 'planned_phase06_batch_size':8,
 'actual_external_batch_size':bsz,
 'batch_size_is_protocol_allowed':bsz in [8,16],
 'planned_vs_executed_batch_size_differs':True,
 'other_methods_batch_size_and_decision_pipeline_independently_verified':False,
 'cross_method_metric_comparability':'REQUIRES_INDEPENDENT_OTHER_METHOD_INPUTS_AND_BATCHING_RECONCILIATION',
 'reference_quality':'REFERENCE_FROZEN_PROVISIONAL',
}

metrics={
 'record_type':'PHASE09_FINAL_METRICS','protocol_version':'10.6','phase':9,'method':'onelevel',
 'generation_reasoning_effort':'low','evaluation_reasoning_effort':'high',
 'phase_status':'PHASE_COMPLETED','run_status':'FINAL_COMPLETE_WITH_DISCLOSED_COMPARABILITY_LIMITATIONS',
 'input_digests':{
   'pdf_sha256':sha(PDF),'common_atomic_reqs_sha256':sha(REFR),'common_negative_controls_sha256':sha(REFN),
   'phase08_ledger_sha256':sha(LEDGER),'phase08_counts_sha256':sha(COUNTS),
   'phase06_queue_sha256':sha(QUEUE), 'external_journals_zip_sha256':sha(JOURNALS),
   'external_result_sha256':sha(EXTRESULTS),'source_files':actual_files,
 },
 'source_and_population':{'pdf_pages':page_count,'R':len(origR),'N':len(origN),'GO_before_eligibility':GO_raw,'GC_before_eligibility':GC_raw,
                          'GC_excluded_nondefinitive':len(excluded_ids),'GO_excluded_nondefinitive':excluded_go,
                          'GO_eligible':GO,'GC_eligible':GC,
                          'GC_supported':Gcells['TP'],'GC_unsupported':Gcells['FP'],
                          'canonical_universe_U':U},
 'canonical_counts':{'TP':TP,'FN':FN,'TN':TN,'FP':FP,'B_frozen_negatives_affirmed':Baffirm,'F_unique_unsupported_residuals':F},
 'metrics':{
   'precision':P,'recall':recall,'f1':f1,'negative_control_pass_rate':negpass,
   'GC_validity_rate':gvalid,'duplicate_rate':duprate,
   'raw_pre_eligibility_duplicate_rate_diagnostic':raw_dup,
 },
 'duplicate_audit':{'eligible_excess_occurrences':GO-GC,'eligible_within_file_excess':eligible_within,
                    'eligible_across_file_excess':eligible_across,'eligible_repeated_class_count':eligible_repeated,
                    'eligible_cross_file_repeated_class_count':eligible_cross_repeated,
                    'raw_pre_eligibility_excess':GO_raw-GC_raw,'raw_within_file_excess':raw_within,
                    'raw_across_file_excess':raw_across,'raw_repeated_class_count':repeated,
                    'raw_cross_file_repeated_class_count':cross_repeated,
                    'expected_reuse_vs_redundant_duplicate_classification':'Not independently decided for all Phase05-added classes; count every excess occurrence without asserting it is unnecessary.'},
 'adjudication':{'pre_phase07_pending':pre,'external_v5_suggestion_counts':dict(v5counts),'external_decision_status_counts':dict(v5status),
                 'phase07_sustained_supersession_count':len(sup),
                 'phase07_FP_to_TP_supersessions':sum(x['prior_final_cell']=='FP' and x['final_cell']=='TP' for x in sup),
                 'phase07_reaffirmed_FP_supersessions':sum(x['prior_final_cell']=='FP' and x['final_cell']=='FP' for x in sup),
                 'eligible_unclassified_final':0,'FN_reason_categories':dict(fn_causes),
                 'G_provenance_categories':dict(gprovenance)},
 'external_execution':{'model':state['model'],'queue_K':len(q),'batch_size':bsz,'completed_batches':len(jrhashes),
                       'actual_submission_attempts':len(state_attempts),'additional_retries_per_batch_allowed':state['batch_retries'],
                       'concurrency':state['concurrency'],'max_submissions_per_batch':4,
                       'reasoning_effort':'high','subjective_confidence_threshold':state['confidence_threshold'],
                       'v5_judgment_semantics_unchanged':True,
                       'committed_results':len(external), 'no_numeric_selection_cap':True},
 'comparison_conditions':comparison,
 'semantic_validation_scope':'Original Phase07 source-grounded semantic decisions are retained; Phase09 independently validates identity, evidence presence and count consistency but does not replace 4,240 semantic adjudications.',
 'equations_validated':{x['check']:True for x in checks},
 'no_extrapolation':True,
}

write_lines('09_duplicate_occurrence_audit.jsonl',raw_duplicate_rows)
write_lines('09_external_journal_integrity.jsonl',jrhashes)
write_obj('09_metrics.json',metrics)
write_obj('09_integrity_check.json',{'record_type':'PHASE09_INDEPENDENT_INTEGRITY','phase_status':'PHASE_COMPLETED',
          'pass_count':len(checks),'checks':checks,'frozen_R':638,'frozen_N':142,'ledger_rows':len(records),
          'journal_batches':len(jrhashes),'eligible_GO':GO,'eligible_GC':GC,'excluded_GC':len(excluded_ids),
          'no_past_phase_mutated':True,'method':'onelevel','protocol_version':'10.6'})

report=f'''# Phase 09 — Independent Metrics and Final Report

**Status:** PHASE_COMPLETED (nine-phase onelevel evaluation). **Protocol:** 10.6. **Generation method:** onelevel; **generation reasoning effort:** low. **External semantic evaluator:** gpt-6.2-sol, high reasoning effort (operator-confirmed common deployment, despite the protocol's literal gpt-6.1-sol reference).

## Canonical classification and metrics

| Metric or population | Independently reconstructed result |
|---|---:|
| Frozen PDF-positive requirements R | {len(origR)} |
| Frozen negative controls N | {len(origN)} |
| Canonical TP | {TP} |
| Canonical FN | {FN} |
| Canonical TN | {TN} |
| Frozen N controls affirmatively asserted B | {Baffirm} |
| Unique unsupported generated-only residuals F | {F} |
| Canonical FP = B + F | {FP} |
| Canonical evaluation universe U | {U} |
| **Precision** | **{P:.10%}** |
| **Recall** | **{recall:.10%}** |
| **F1** | **{f1:.10%}** |
| Negative-control pass rate | {negpass:.10%} |
| Eligible GC validity | {gvalid:.10%} |
| **Eligible GO/GC duplicate rate** | **{duprate:.10%}** |

The only published Precision/Recall/F1 set comes from the full 4,306-row Phase 08 ledger, not the external model's item suggestions. Exact equations: Precision = {TP}/({TP}+{FP}); Recall = {TP}/({TP}+{FN}); F1 = {2*TP}/({2*TP}+{FP}+{FN}). All equations and fixed-count conservation checks pass. No sampling or extrapolation is used.

## Generated claims, eligibility, validity, duplicates

The provisional Phase 05 inventory contains {GO_raw} GO occurrences and {GC_raw} GC classes. Later Phase 07 evidence review excluded {len(excluded_ids)} nondefinitive classes comprising {excluded_go} occurrences, leaving **{GO} eligible definitive occurrences** and **{GC} eligible definitive classes**. Of those classes {Gcells['TP']} are PDF-supported and {Gcells['FP']} are PDF-unsupported; 78 unsupported classes consolidate into **{F} distinct unsupported affirmative residuals**. Frozen N has no affirmative violations and no N/F overlaps.

The **final eligibility-corrected** duplication metric is ({GO} − {GC})/{GO} = **{duprate:.10%}** ({GO-GC} excess; {eligible_within} within-file and {eligible_across} across-file). {eligible_repeated} eligible classes repeat; {eligible_cross_repeated} repeat across files. The **pre-eligibility diagnostic** is ({GO_raw} − {GC_raw})/{GO_raw} = {raw_dup:.10%}; it must not be conflated with the post-eligibility metric. Expected reuse and redundant duplication both count as excess; full necessity of every repeated instance is not independently established.

## External evaluation and decision provenance

The Phase 06 queue SHA-256 is `{sha(QUEUE)}`; K=C={len(q)}. External execution used {bsz}-item batches: {len(jrhashes)} committed batch journals, {len(external)} complete model item results, {len(state_attempts)} submission attempts (including explicitly recorded failures/recovery), four configured concurrent requests and up to {state['batch_retries']} additional retries per batch. Frozen v5 confidence threshold = {state['confidence_threshold']}. Original v5 `SYSTEM_PROMPT`, `RESULT_SCHEMA`, and `suggest()` are AST-identical in the supplied baseline and the Phase 06 derivative; unique-role SHA-256 filename aliases passed the Phase 06 regression suite. Original v5 suggestions: `{json.dumps(dict(v5counts),sort_keys=True)}`. Unresolved model suggestions are not automatically FN, TN or FP: Phase 07 separately adjudicated every eligible item. Seven immutable superseding Phase 07 records resolve observed conflicts; the original model and phase files are retained.

**Configuration variance:** Phase 06 initially planned 8-item batches (530 batches), but the completed external job used 16-item batches (265 batches). Both sizes are explicitly allowed by Version 10.6; the planned-versus-executed difference is recorded, not erased. Other methods' batch sizes, exact prompt/run settings and full input hashes were not provided here, so **strict cross-method comparability remains unverified** even though the operator states all methods used gpt-6.2-sol. No extrapolated cross-method conclusion is drawn.

## Diagnostic findings

- R: {TP} whole-obligation coverage successes and {FN} missing/partial obligations. No requirement was classified FN simply because the v5 model abstained. The source-specific Phase 04 and Phase 07 evidence trails remain the authoritative material to distinguish TRUE_MISSING, PARTIAL_ENTAILMENT, and corrected matcher misses; no unsupported aggregate causal split is invented.
- G: {Gcells['TP']} supported classes (their diagnostic G:TP cells add no canonical TP), {Gcells['FP']} unsupported classes, and {len(excluded_ids)} nondefinitive exclusions that add no FP or TN.
- F: {F} deduplicated unsupported residual units, with source-class crosswalks and zero N/F overlap. Underlying 66 records document complete unsupported residual statements and their source counterchecks.
- Contextual/conjunctive proof bridges: Phase 03 indexed 275 candidates; these are candidate bridges, not 275 separately certified proofs. Each final item relies on its Phase 07 evidence and Phase 08 reconciliation.
- The original reference is `REFERENCE_FROZEN_PROVISIONAL`; document source evidence was mechanically locked, but exhaustive independent benchmark atomization review was not demonstrated.

## Deliverables

`compute_metrics.py` (self-contained fail-closed recomputation), `09_metrics.json`, `09_integrity_check.json`, `09_duplicate_occurrence_audit.jsonl`, `09_external_journal_integrity.jsonl`, `09_coverage_and_limitations.md`, `09_report.md`.
'''
limitations=f'''# Phase 09 — Coverage, Audit Scope, and Limitations

## Completed validations

- Validated the 90-physical-page PDF SHA-256 and all eight Markdown role/digest identities; frozen R/N JSONL hashes and IDs remain immutable.
- Independently enumerated every Phase 08 row: 638 R, 142 N, 2,963 definitive G, 497 nondefinitive excluded G, and 66 distinct FP residuals = 4,306 entries.
- Verified the original 4,240-item Phase 06 queue and its 265 committed 16-item external batch journals, including every batch's content SHA-256, input SHA-256, preserved item order, source identity, retries and completed item coverage.
- Recomputed R/N four-cell counts, effective GO/GC eligibility, generated-class validity, N/F overlap, unsupported-residual references, duplicate counts and the single canonical score without trust in Phase 08 aggregate arithmetic.
- Verified that superseding Phase 07 records remain separate and that unchanged v5 suggestions do not become authoritative classification cells.

## Qualification of measurements

- Precision, Recall, and F1 measure semantic compliance of these generated specifications with the **fictional** OrionDesk PDF reference, not deployment correctness or general model accuracy.
- The frozen reference was produced with bounded semantic audit: the original reference manifest discloses 730 unreviewed working items, incomplete independent shard/model validation and possible residual atomization issues. These quality limitations cannot be converted into changed R/N denominators during this run.
- This independent Phase 09 program verifies the existence, identity, and reconciled provenance of evidence. It does not perform a fresh semantic re-judgment of each of the 4,240 Phase 07 decisions; those remain an auditable classification layer and are not guaranteed correct by mechanical consistency alone.
- The Phase 08 quote-exception audit retained 99 previously mismatched auxiliary extracted PDF excerpts; this final ledger uses other verified support and retains the exceptions without altering their wording. Visual-only/nonstrict extraction remains a limitation where no exact text was available.
- A complete all-pairs semantic paraphrase/deduplication audit of all generated occurrences was not independently repeated here. The final 66 FP residuals represent Phase 08's evidence-justified consolidation, not a proof of absolute global semantic uniqueness.
- Raw Phase 05 GO/GC counts contain 497 subsequently excluded classes, so they are not the final **eligible** duplication denominator. The metric uses GO={GO} and GC={GC}. The raw {GO_raw}/{GC_raw} ratio is retained solely as a pre-eligibility diagnostic.
- The generated-only F residuals are not the same as raw G:FP classes or 8-way repetition of one specification. The 78 diagnostic unsupported GC classes yielded 66 deduplicated residuals, and no duplicate with a frozen N violation was found.
- Operator states that fullload and twolevel also used `gpt-6.2-sol`, but their actual input manifests and all execution setting hashes are not inspected in this onelevel Phase 09. The deployment differs from the immutable protocol literal `gpt-6.1-sol`; interpretation is a common disclosed experimental convention, **not independently verified experiment invariance**.
- Phase 06 planned eight items per request; actual external 16-item batches are within protocol-approved choices, but direct cross-method comparability also requires matching batch size and all other method-invariant conditions.
- v5 confidence estimates are model self-reports, not calibrated probabilities. A successful file hash and valid quotation do not alone prove semantic entailment.

## Error-analysis traceability

- The final R source ledger and Phase 04 FN audit preserve source IDs, candidate evidence and unmet predicates. Do not derive counts for `TRUE_MISSING`, `PARTIAL_ENTAILMENT`, or corrected matcher misses from lexical search scores alone.
- The 497 exclusions and 2,885 supported/78 unsupported generated classes each have Phase 07 provenance and unaltered source locators.
- The 66 final F residual records and the `08_residual_consolidation_audit.jsonl` map unsupported affirmative obligations to one or more generated classes with independent justification. No unsupported generated residual was multiplied by repetition across eight Markdown files.
- Phase 03's 275 candidate bridges cannot be promoted to separate verified contextual proof counts without item-specific audit. The Phase 07–08 ledgers retain the applicable links.

## Final score scope

Single complete within-method score: Precision {P:.10%}; Recall {recall:.10%}; F1 {f1:.10%}. Comparison with another method is **conditional** upon verifying its frozen R/N bytes, model prompt/decision logic, eligible GO/GC rules, full-batch selection, evidence and dedup policies, and execution parameters.
'''
(OUT/'09_report.md').write_text(report,encoding='utf-8')
(OUT/'09_coverage_and_limitations.md').write_text(limitations,encoding='utf-8')
print(json.dumps({'phase':'09','status':'PHASE_COMPLETED','TP':TP,'FN':FN,'TN':TN,'FP':FP,'precision':P,'recall':recall,'f1':f1,
  'GC_validity_rate':gvalid,'eligible_duplicate_rate':duprate,'raw_duplicate_rate':raw_dup,
  'eligible_GO':GO,'eligible_GC':GC,'checks':len(checks),'journal_count':len(jrhashes)},indent=2))
