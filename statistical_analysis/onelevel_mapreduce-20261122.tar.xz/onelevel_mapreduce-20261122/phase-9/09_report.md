# Phase 09 — Independent Metrics and Final Report

**Status:** PHASE_COMPLETED (nine-phase onelevel evaluation). **Protocol:** 10.6. **Generation method:** onelevel; **generation reasoning effort:** low. **External semantic evaluator:** gpt-6.2-sol, high reasoning effort (operator-confirmed common deployment, despite the protocol's literal gpt-6.1-sol reference).

## Canonical classification and metrics

| Metric or population | Independently reconstructed result |
|---|---:|
| Frozen PDF-positive requirements R | 638 |
| Frozen negative controls N | 142 |
| Canonical TP | 599 |
| Canonical FN | 39 |
| Canonical TN | 142 |
| Frozen N controls affirmatively asserted B | 0 |
| Unique unsupported generated-only residuals F | 66 |
| Canonical FP = B + F | 66 |
| Canonical evaluation universe U | 846 |
| **Precision** | **90.0751879699%** |
| **Recall** | **93.8871473354%** |
| **F1** | **91.9416730622%** |
| Negative-control pass rate | 100.0000000000% |
| Eligible GC validity | 97.3675329058% |
| **Eligible GO/GC duplicate rate** | **6.3527180784%** |

The only published Precision/Recall/F1 set comes from the full 4,306-row Phase 08 ledger, not the external model's item suggestions. Exact equations: Precision = 599/(599+66); Recall = 599/(599+39); F1 = 1198/(1198+66+39). All equations and fixed-count conservation checks pass. No sampling or extrapolation is used.

## Generated claims, eligibility, validity, duplicates

The provisional Phase 05 inventory contains 3663 GO occurrences and 3460 GC classes. Later Phase 07 evidence review excluded 497 nondefinitive classes comprising 499 occurrences, leaving **3164 eligible definitive occurrences** and **2963 eligible definitive classes**. Of those classes 2885 are PDF-supported and 78 are PDF-unsupported; 78 unsupported classes consolidate into **66 distinct unsupported affirmative residuals**. Frozen N has no affirmative violations and no N/F overlaps.

The **final eligibility-corrected** duplication metric is (3164 − 2963)/3164 = **6.3527180784%** (201 excess; 8 within-file and 193 across-file). 118 eligible classes repeat; 115 repeat across files. The **pre-eligibility diagnostic** is (3663 − 3460)/3663 = 5.5419055419%; it must not be conflated with the post-eligibility metric. Expected reuse and redundant duplication both count as excess; full necessity of every repeated instance is not independently established.

## External evaluation and decision provenance

The Phase 06 queue SHA-256 is `3255ec553e87388c351295b8f50c5b61ca81bf3f3bc50549c210bb50c0173f24`; K=C=4240. External execution used 16-item batches: 265 committed batch journals, 4240 complete model item results, 267 submission attempts (including explicitly recorded failures/recovery), four configured concurrent requests and up to 3 additional retries per batch. Frozen v5 confidence threshold = 0.9. Original v5 `SYSTEM_PROMPT`, `RESULT_SCHEMA`, and `suggest()` are AST-identical in the supplied baseline and the Phase 06 derivative; unique-role SHA-256 filename aliases passed the Phase 06 regression suite. Original v5 suggestions: `{"EXCLUDED_NONDEFINITIVE": 486, "FN": 1, "NOT_FP": 2731, "None": 430, "TN": 1, "TP": 591}`. Unresolved model suggestions are not automatically FN, TN or FP: Phase 07 separately adjudicated every eligible item. Seven immutable superseding Phase 07 records resolve observed conflicts; the original model and phase files are retained.

**Configuration variance:** Phase 06 initially planned 8-item batches (530 batches), but the completed external job used 16-item batches (265 batches). Both sizes are explicitly allowed by Version 10.6; the planned-versus-executed difference is recorded, not erased. Other methods' batch sizes, exact prompt/run settings and full input hashes were not provided here, so **strict cross-method comparability remains unverified** even though the operator states all methods used gpt-6.2-sol. No extrapolated cross-method conclusion is drawn.

## Diagnostic findings

- R: 599 whole-obligation coverage successes and 39 missing/partial obligations. No requirement was classified FN simply because the v5 model abstained. The source-specific Phase 04 and Phase 07 evidence trails remain the authoritative material to distinguish TRUE_MISSING, PARTIAL_ENTAILMENT, and corrected matcher misses; no unsupported aggregate causal split is invented.
- G: 2885 supported classes (their diagnostic G:TP cells add no canonical TP), 78 unsupported classes, and 497 nondefinitive exclusions that add no FP or TN.
- F: 66 deduplicated unsupported residual units, with source-class crosswalks and zero N/F overlap. Underlying 66 records document complete unsupported residual statements and their source counterchecks.
- Contextual/conjunctive proof bridges: Phase 03 indexed 275 candidates; these are candidate bridges, not 275 separately certified proofs. Each final item relies on its Phase 07 evidence and Phase 08 reconciliation.
- The original reference is `REFERENCE_FROZEN_PROVISIONAL`; document source evidence was mechanically locked, but exhaustive independent benchmark atomization review was not demonstrated.

## Deliverables

`compute_metrics.py` (self-contained fail-closed recomputation), `09_metrics.json`, `09_integrity_check.json`, `09_duplicate_occurrence_audit.jsonl`, `09_external_journal_integrity.jsonl`, `09_coverage_and_limitations.md`, `09_report.md`.
