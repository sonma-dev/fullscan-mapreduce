#!/usr/bin/env python3
"""Independent mechanical and cross-shard Phase 07 Shard 02 verification.
Does not issue new semantic decisions or modify any original inputs.
"""
import collections,hashlib,json,re,unicodedata
from pathlib import Path
from sklearn.feature_extraction.text import TfidfVectorizer
ROOT=Path('/mnt/data'); BASE=ROOT/'onelevel_v10_6';OUT=BASE/'phase07/shard02';P1=BASE/'phase07/shard01';P2=OUT
read=lambda p:[json.loads(x) for x in p.open(encoding='utf8') if x.strip()]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
q=read(OUT/'07_decision_audit.jsonl'); a=read(OUT/'07_assistant_adjudications.jsonl');ex=read(OUT/'07_excluded_nondefinitive.jsonl');b=read(OUT/'07_input_blockers.jsonl');src=read(BASE/'phase07/sharding_plan/07_shard_02_items.jsonl')
summary=json.loads((OUT/'07_adjudication_summary.json').read_text(encoding='utf8'))
r1=read(P1/'07_decision_audit.jsonl')
assert len(q)==len(src)==2120 and not b
assert {x['item_id'] for x in q}=={x['item_id'] for x in src}
assert {x['item_id'] for x in q}.isdisjoint({x['item_id'] for x in r1})
assert len({x['item_id'] for x in q}|{x['item_id'] for x in r1})==4240
assert len(a)==1871 and len(ex)==249
assert {x['item_id'] for x in a}.isdisjoint({x['item_id'] for x in ex})
assert {x['item_id'] for x in a}|{x['item_id'] for x in ex}=={x['item_id'] for x in q}
assert all(x['final_cell'] is not None and x['eligibility_status']=='ELIGIBLE' for x in a)
assert all(x['direction']=='G' and x['final_cell'] is None and x['eligibility_status']=='EXCLUDED_NONDEFINITIVE' for x in ex)
counts=collections.Counter((x['direction'],x['final_cell']) for x in a)
assert counts==collections.Counter({('R','TP'):299,('R','FN'):20,('N','TN'):71,('G','TP'):1435,('G','FP'):46})
assert sum(counts.values())==1871
assert len([x for x in q if x['direction']=='R'])==319
assert len([x for x in q if x['direction']=='N'])==71
assert len([x for x in q if x['direction']=='G'])==1730
assert all(x['decision_origin']=='PHASE07_ASSISTANT' and x['source_reference_unchanged'] for x in q)
assert all(x['source_pdf_sha256']==summary['source_digests']['pdf'] for x in q)
assert sha(ROOT/'OrionDesk_AI_Detailed_Design_Specification(6).pdf')==summary['source_digests']['pdf']
assert sha(ROOT/'semantic_decisions(3).jsonl')==summary['source_digests']['original_external_decisions']
assert sha(ROOT/'batch_journals(2).zip')==summary['source_digests']['original_batch_journals_zip']
assert sha(BASE/'phase07/sharding_plan/07_shard_02_items.jsonl')==summary['source_digests']['shard_input']
assert sha(BASE/'phase06/06_llm_queue_v10.6.jsonl')==summary['source_digests']['original_queue']
assert sha(ROOT/'common_atomic_reqs(5).jsonl')==summary['source_digests']['R']
assert sha(ROOT/'common_negative_controls(5).jsonl')==summary['source_digests']['N']
orig=['01_screen_functions(5).md','02_api(5).md','03_data(5).md','04_batch_functions(6).md','05_business_rules(5).md','06_exception_handling(7).md','07_processing_flows(7).md','08_architecture_decision(6).md']
byfile={n:(ROOT/n).read_text(encoding='utf8').splitlines() for n in orig}
canon={re.sub(r'\(\d+\)(?=\.md$)','',n):n for n in orig}
for cp,n in canon.items():assert sha(ROOT/n)==summary['source_digests']['eight_original_markdown'][cp]
norm=lambda s:re.sub(r'\s+',' ',unicodedata.normalize('NFKC',str(s))).strip().lower()
import fitz
D=fitz.open(ROOT/'OrionDesk_AI_Detailed_Design_Specification(6).pdf');assert len(D)==90
pages=[norm(p.get_text(sort=True)) for p in D]
md_checks=0;pdf_checks=0;pdf_context_only=0;missing=[]
for row in q:
 md_good=False;pdf_good=False
 for e in row['generated_evidence']:
  n=e['actual_file'];s=e['line_start'];t=e['line_end']
  assert n in byfile and 1<=s<=t<=len(byfile[n]),row['item_id']
  assert sha(ROOT/n)==e['source_sha256'],row['item_id']
  assert norm(e['quote_en']) in norm('\n'.join(byfile[n][s-1:t])),(row['item_id'],n,s,t)
  assert e['verified_current_original_exact'];md_checks+=1;md_good=True
 for e in row['pdf_evidence']:
  p=e['physical_page'];assert isinstance(p,int) and 1<=p<=90,row['item_id']
  if e.get('verified_current_original_exact'):
   if norm(e['quote_en']) not in pages[p-1]:
    missing.append((row['item_id'],'pdf',p,e['quote_en'][:70]))
   else: pdf_good=True;pdf_checks+=1
   if e.get('type')=='RECIPROCAL_CONTEXT_ONLY_NOT_ENTAILMENT_PROOF':pdf_context_only+=1
 if not md_good or (row['eligibility_status']=='ELIGIBLE' and not pdf_good):missing.append((row['item_id'],'no_markdown_or_pdf_proof'))
assert not missing, missing[:12]

# Identify suspiciously close unsupported and supported classes; list for Phase 08
# contradiction screening only. This is not semantic deduplication or relabeling.
g1=[x for x in r1 if x['direction']=='G' and x['eligibility_status']=='ELIGIBLE'];g2=[x for x in q if x['direction']=='G' and x['eligibility_status']=='ELIGIBLE']
g1fp=[x for x in g1 if x['final_cell']=='FP'];g2fp=[x for x in g2 if x['final_cell']=='FP'];bothfp=g1fp+g2fp
bothsup=[x for x in g1+g2 if x['final_cell']=='TP']
v=TfidfVectorizer(stop_words='english',ngram_range=(1,2),sublinear_tf=True,max_features=28000)
Z=v.fit_transform([x['statement_en'] for x in bothfp+bothsup]);sim=Z[:len(bothfp)]@Z[len(bothfp):].T
near=[]
for i,x in enumerate(bothfp):
 scores=sim[i].toarray().ravel();ix=scores.argsort()[-3:][::-1]
 neighbors=[{'supported_id':bothsup[j]['item_id'],'similarity':round(float(scores[j]),5),
            'supported_claim_en':bothsup[j]['statement_en'][:340]} for j in ix if scores[j]>=0.55]
 if neighbors:near.append({'record_type':'PHASE07_CROSS_LABEL_REVIEW_CANDIDATE',
  'unsupported_id':x['item_id'],'unsupported_shard':x['shard_id'],
  'unsupported_claim_en':x['statement_en'],'unsupported_unmet_en':x['unmet_predicates_en'],
  'potential_supported_neighbors':neighbors,
  'action_en':'Mechanical similarity screening only. Phase 08 must check semantic equivalence and return genuine contradictions for a new Phase 07 superseding record.'})
with (OUT/'07_cross_label_candidates.jsonl').open('w',encoding='utf8') as f:
 for z in near:f.write(json.dumps(z,ensure_ascii=False,sort_keys=True)+'\n')

# High-similarity unsupported pairs that may be duplicate FP residuals.
fvec=TfidfVectorizer(stop_words='english',ngram_range=(1,2),sublinear_tf=True)
Q=fvec.fit_transform([x['statement_en'] for x in bothfp]);F=Q@Q.T
pairs=[]
for i,x in enumerate(bothfp):
 r=F[i].toarray().ravel()
 for j in range(i+1,len(bothfp)):
  if r[j]>=0.68:
   pairs.append({'a':x['item_id'],'b':bothfp[j]['item_id'],'similarity':round(float(r[j]),5),
                 'a_shard':x['shard_id'],'b_shard':bothfp[j]['shard_id'],
                 'a_en':x['statement_en'][:250],'b_en':bothfp[j]['statement_en'][:250],
                 'warning_en':'Similarity alone does not establish mutual entailment; Phase 08 controls consolidation.'})
with (OUT/'07_possible_fp_duplicates.jsonl').open('w',encoding='utf8') as f:
 for z in pairs:f.write(json.dumps(z,ensure_ascii=False,sort_keys=True)+'\n')

checks={
 'record_type':'PHASE07_SHARD02_INDEPENDENT_MECHANICAL_VALIDATION','protocol_version':'10.6','shard_id':'S07-02',
 'status':'MECHANICAL_CHECKS_PASSED',
 'checks':{'all_shard_02_2120_ids_accounted_once':True,'both_shards_4240_ids_without_overlap':True,
           'all_R_and_N_binary':True,'all_eligible_G_diagnostic_binary':True,
           'all_verified_markdown_quotations_exact':True,'all_verified_pdf_quotations_exact':True,
           'no_eligible_semantic_null':True,'no_canonical_metrics_calculated':True,
           'external_model_configuration_matches_protocol':False},
 'counts':{'shard01_items':len(r1),'shard02_items':len(q),'eligible_final_cells':len(a),
           'ineligible_G_exclusions':len(ex),'blockers':len(b),
           'shard02_R_TP':counts[('R','TP')],'shard02_R_FN':counts[('R','FN')],
           'shard02_N_TN':counts[('N','TN')],'shard02_N_FP':counts[('N','FP')],
           'shard02_G_supported':counts[('G','TP')],'shard02_G_unsupported_candidates':counts[('G','FP')],
           'original_markdown_evidence_quote_confirmations':md_checks,
           'original_pdf_evidence_quote_confirmations':pdf_checks,
           'reciprocal_pdf_context_only_quotes':pdf_context_only,
           'FP_TP_semantic_review_candidates_across_both_shards':len(near),
           'possible_FP_duplicate_pairs_across_both_shards':len(pairs)},
 'source_digests':summary['source_digests'],
 'files_sha256':{p.name:sha(p) for p in [OUT/x for x in ['07_assistant_adjudications.jsonl','07_decision_audit.jsonl','07_excluded_nondefinitive.jsonl','07_input_blockers.jsonl','07_adjudication_summary.json','07_cross_label_candidates.jsonl','07_possible_fp_duplicates.jsonl']]},
 'note_en':'All tests are mechanical quotation/identity/count checks, not proof of semantic infallibility. High-similarity pairs require exact original-source semantic review in Phase 08; genuine contradictions must return to Phase 07. External gpt-6.2-sol differs from required gpt-6.1-sol.'
}
(OUT/'07_integrity_check.json').write_text(json.dumps(checks,ensure_ascii=False,indent=2,sort_keys=True)+'\n',encoding='utf8')

# Shard 01/02 merger readiness report is a Phase 07 handoff, not Phase 08 reconciliation.
s1=json.loads((P1/'07_adjudication_summary.json').read_text(encoding='utf8'))
a1=collections.Counter((x['direction'],x['final_cell']) for x in r1 if x['eligibility_status']=='ELIGIBLE')
agg={f'{d}_{cell}':a1.get((d,cell),0)+counts.get((d,cell),0) for (d,cell) in set(a1)|set(counts)}
handoff={'record_type':'PHASE07_TWO_SHARD_HANDOFF','protocol_version':'10.6',
 'method':'onelevel','status':'BOTH_SHARDS_ITEM_ADJUDICATION_COMPLETE_PENDING_PHASE08',
 'all_original_4240_item_ids_accounted_for':True,'shard_01_sha256':sha(P1/'07_decision_audit.jsonl'),
 'shard_02_sha256':sha(OUT/'07_decision_audit.jsonl'),
 'shard_01_counts':s1['final_cell_counts_by_direction'],
 'shard_02_counts':summary['final_cell_counts_by_direction'],
 'two_shard_direction_diagnostic_counts_not_final_metrics':agg,
 'total_eligible':len(a)+sum(x['eligibility_status']=='ELIGIBLE' for x in r1),
 'total_nondefinitive_G':len(ex)+sum(x['eligibility_status']=='EXCLUDED_NONDEFINITIVE' for x in r1),
 'total_input_blockers':0,
 'pending_phase08_review':{'cross_label_candidate_fps':len(near),'possible_fp_duplicate_pairs':len(pairs),
   'N_F_overlap': 'NOT_YET_CONSOLIDATED','generated_class_eligibility_reconciliation':'REQUIRED'},
 'external_model_mismatch':'gpt-6.2-sol used; protocol requires gpt-6.1-sol',
 'no_phase08_or_phase09_performed':True,
 'note_en':'Do not use summed diagnostic G FP as canonical FP. All unsupported residuals require semantic consolidation and control overlap elimination in Phase 08 before any Precision/Recall/F1 calculation.'}
(OUT/'07_shard02_handoff.json').write_text(json.dumps(handoff,ensure_ascii=False,indent=2,sort_keys=True)+'\n',encoding='utf8')

report=f'''# Phase 07 — Shard 02: Evidence-grounded adjudication report

Protocol: 10.6. Method: onelevel. Generation reasoning effort: low. External evaluator reasoning effort: high.

## Input verification and execution

The 90-physical-page original PDF and eight original Markdown specifications, frozen positive and negative source inventories, immutable Phase 06 4,240-item queue, Shard 02 2,120-item selection, Version 5.0 original model output and all 265 external 16-item batch journals were checked by SHA-256, original line/page references and batch ordering. All Shard 02 IDs exist once in the original queue and v5 output. Previous phase files, original documents, and Shard 01 outputs have not been modified.

## Shard 02 adjudication results

| Direction | Supported/negative control pass | Uncovered/unsupported | Nondefinitive exclusions | Original items |
|---|---:|---:|---:|---:|
| R | TP {counts[('R','TP')]} | FN {counts[('R','FN')]} | 0 | 319 |
| N | TN {counts[('N','TN')]} | FP {counts[('N','FP')]} | 0 | 71 |
| G diagnostic | Supported {counts[('G','TP')]} | Unsupported candidate {counts[('G','FP')]} | {len(ex)} | 1,730 |

Eligible decisions: {len(a):,}; nondefinitive G exclusions: {len(ex):,}; input blockers: zero. No eligible item remains semantically UNRESOLVED or null. Exactly {len(q):,} source queue IDs are accounted for.

The initial v5 suggestion count for this shard was {summary['original_external_v5_suggestion_counts']}. All 22 R items without accepted TP suggestions received item-specific PDF/Markdown comparison: two TP corrections and twenty FN. All 147 G v5 abstentions received individually selected support, unsupported-residual or nondefinitive dispositions, not a blind PARTIAL-to-FP/UNRESOLVED-to-negative conversion.

## Evidence and limitations

- Verified {md_checks:,} original Markdown quotations at their exact original line ranges and {pdf_checks:,} PDF quotations against physical page text. {pdf_context_only} reciprocal PDF excerpts serve as inspected context, not independent proof of entailment.
- The assistant gave separate claim-specific explanations for the unaccepted R results and G unsupported residuals; model suggestions remain immutable and are cited only as prior evidence.
- The generated prediction extraction contains {len(ex)} Shard 02 classes whose source text is an open decision, editorial statement, example or nondefinitive qualification. Phase 08 must reconcile these with the originally frozen GO/GC membership rather than changing older records.
- A diagnostic `G:TP` does not create another canonical R true positive. The {counts[('G','FP')]} Shard 02 G unsupported candidates are **not** the final canonical FP count; Phase 08 must merge semantically equivalent residuals and remove overlaps with affirmative N controls.
- The cross-shard similarity screen identified {len(near)} potential FP-versus-supported semantic comparisons and {len(pairs)} potential unsupported-residual duplicate pairs. These are *review prompts*, not actual inconsistencies or automatic merges. Genuine contradictions require explicit Phase 07 superseding decisions.
- Entailment judgments remain interpretable and may require later contradiction correction. Mechanical quotation checks prove the cited text exists, not the conclusion by themselves.

## External-evaluator comparability deviation

The uploaded run used gpt-6.2-sol, whereas protocol Version 10.6 specifies gpt-6.1-sol. The original model responses are preserved without modification. The two-Shard arrangement was authorized by the operator, but the external model change is not thereby accepted as cross-method comparable. Do not claim strict method comparability without consistent configurations or an approved protocol amendment.

## Completion gate

Shard 02 is completed with documented provenance deviation. Both Shards cover all 4,240 original Phase 06 IDs once; their item-level R/N binary judgments are complete. Phase 08 semantic reconciliation and Phase 09 metric calculation have **not** been executed. The two-shard aggregate is available only as a handoff diagnostic.
'''
(OUT/'07_report.md').write_text(report,encoding='utf8')
print(json.dumps({'status':checks['status'],'quote_checks':md_checks,'pdf_checks':pdf_checks,'pdf_context_only':pdf_context_only,'cross_label':len(near),'fp_candidate_pairs':len(pairs),'handoff':agg},indent=2))
