#!/usr/bin/env python3
"""Source-verified Phase 07 Shard 02 adjudication, Protocol v10.6.

Does not alter original PDF, Markdown, R/N, GO/GC, external v5 results,
or previous phase artifacts. An index hit is used only for reciprocal evidence
inspection, not as an automatic semantic judgment.
"""
import collections
import hashlib
import json
import re
import unicodedata
import zipfile
from datetime import datetime, timezone
from pathlib import Path

import fitz
from sklearn.feature_extraction.text import TfidfVectorizer

ROOT=Path('/mnt/data')
BASE=ROOT/'onelevel_v10_6'
OUT=BASE/'phase07/shard02'
SHARD=BASE/'phase07/sharding_plan/07_shard_02_items.jsonl'
QUEUE=BASE/'phase06/06_llm_queue_v10.6.jsonl'
PDF=ROOT/'OrionDesk_AI_Detailed_Design_Specification(6).pdf'
ORIGINALS=[
'01_screen_functions(5).md','02_api(5).md','03_data(5).md',
'04_batch_functions(6).md','05_business_rules(5).md',
'06_exception_handling(7).md','07_processing_flows(7).md',
'08_architecture_decision(6).md']
V5=ROOT/'semantic_decisions(3).jsonl'
RUNSTATE=ROOT/'run_state(2).json'
SUMMARY=ROOT/'semantic_summary(2).json'
ZIP=ROOT/'batch_journals(2).zip'

def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def jread(p): return json.loads(p.read_text(encoding='utf-8'))
def rows(p): return [json.loads(line) for line in p.open(encoding='utf-8') if line.strip()]
def norm(s): return re.sub(r'\s+',' ',unicodedata.normalize('NFKC',str(s))).strip().lower()
def digest(x): return hashlib.sha256(json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode('utf-8')).hexdigest()
def writel(path,its):
 with path.open('w',encoding='utf-8') as f:
  for item in its: f.write(json.dumps(item,ensure_ascii=False,sort_keys=True)+'\n')
def wjson(path,x):path.write_text(json.dumps(x,ensure_ascii=False,indent=2,sort_keys=True)+'\n',encoding='utf-8')

lock=jread(BASE/'phase01/01_reference_lock.json')
manifest=jread(BASE/'phase07/sharding_plan/07_sharding_manifest.json')
run=jread(RUNSTATE);summary=jread(SUMMARY)
queue=rows(QUEUE);shard=rows(SHARD);v5list=rows(V5)
PDF_HASH=sha(PDF); QUEUE_HASH=sha(QUEUE); SHARD_HASH=sha(SHARD); V5_HASH=sha(V5); ZIP_HASH=sha(ZIP); R_HASH=sha(ROOT/'common_atomic_reqs(5).jsonl'); N_HASH=sha(ROOT/'common_negative_controls(5).jsonl')
assert sha(PDF)==lock['pdf_sha256']==run['pdf_sha256']
assert sha(QUEUE)==manifest['source_queue_sha256']==run['queue_sha256']
assert sha(SHARD)==manifest['shards'][1]['sha256']
assert len(queue)==4240 and len(shard)==2120 and len(v5list)==4240
assert len(set(x['item_id'] for x in queue))==4240
assert len(set(x['item_id'] for x in shard))==2120
assert {x['item_id'] for x in shard}.issubset({x['item_id'] for x in queue})
assert summary['status']=='COMPLETE' and summary['completed_items']==4240
assert summary['completed_batches']==265 and summary['failed_batches']==0
assert run['protocol_version']==run['execution_version']=='10.6'
assert run['reasoning_effort'] if 'reasoning_effort' in run else True
assert {x['direction']:sum(q['direction']==x['direction'] for q in shard) for x in shard}=={'R':319,'N':71,'G':1730}

files={};canon={};canon_to_actual={};actual_to_canon={}
for p in ORIGINALS:
 role=p.split('_')[0]
 cp=re.sub(r'\(\d+\)(?=\.md$)','',p)
 raw=(ROOT/p).read_text(encoding='utf-8');ls=raw.splitlines()
 assert hashlib.sha256((ROOT/p).read_bytes()).hexdigest()==run['file_sha256'][cp]
 files[p]=ls;canon[cp]=ls;canon_to_actual[cp]=p;actual_to_canon[p]=cp
pdf=fitz.open(PDF)
assert len(pdf)==90
pages=[p.get_text(sort=True) for p in pdf]
page_fold=[norm(t) for t in pages]

# Validate immutable external journals, including their content checksums and IDs.
external_by_id={x['item_id']:x for x in v5list}
assert len(external_by_id)==4240
assert all(x['queue_sha256']==QUEUE_HASH for x in v5list)
assert all(x['reasoning_effort']=='high' for x in v5list)
assert all(x['model']==run['model'] for x in v5list)
assert set(external_by_id)=={x['item_id'] for x in queue}
committed=set();jcount=0
with zipfile.ZipFile(ZIP) as z:
 assert z.testzip() is None
 for name in sorted(z.namelist()):
  if not name.endswith('.json'):continue
  jj=json.loads(z.read(name));jcount+=1
  assert digest({'raw_model_json':jj['raw_model_json'],'item_records':jj['item_records']})==jj['content_sha256'],name
  assert jj['queue_sha256']==QUEUE_HASH and jj['pdf_sha256']==PDF_HASH
  assert jj['batch_size']==len(jj['item_records'])==16
  ix=jj['batch_index'];expected=queue[ix*16:(ix+1)*16]
  assert [r['item_id'] for r in jj['item_records']]==[r['item_id'] for r in expected]
  for r in jj['item_records']:
   assert r['item_id'] not in committed
   assert digest(r)==digest(external_by_id[r['item_id']])
   committed.add(r['item_id'])
assert jcount==265 and len(committed)==4240

# Make a full-text reciprocal query index independent of the external judgment.
line_entries=[];gen_texts=[]
for ap in ORIGINALS:
 for num,line in enumerate(files[ap],1):
  if len(line.strip())<8:continue
  line_entries.append((ap,num,line));gen_texts.append(line)
vec=TfidfVectorizer(stop_words='english',ngram_range=(1,2),max_features=42000,sublinear_tf=True)
all_text=pages+gen_texts
matrix=vec.fit_transform(all_text)
page_mat=matrix[:90]
line_mat=matrix[90:]

def query_index(statement,direction):
 # Retrieval only; nearest evidence still must be read in source context.
 x=vec.transform([statement]); mat=page_mat if direction=='G' else line_mat
 scores=(mat@x.T).toarray().ravel();n=min(4,len(scores))
 ix=scores.argsort()[-n:][::-1]
 if direction=='G':
  return [{'physical_page':int(i)+1,'score':round(float(scores[i]),5),'excerpt':pages[int(i)][:250]} for i in ix]
 return [{'actual_file':line_entries[int(i)][0], 'line':line_entries[int(i)][1],
          'score':round(float(scores[i]),5),'excerpt':line_entries[int(i)][2][:250]} for i in ix]


def pdf_evidence(item,ext):
 cand=(ext['model_json'].get('pdf_evidence') or [])+(item.get('pdf_evidence_hints') or [])
 out=[];seen=set()
 for c in cand:
  page=c.get('physical_page');q=c.get('quote_en') or ''
  if not isinstance(page,int) or page<1 or page>90 or not q:continue
  key=(page,norm(q))
  if key in seen:continue
  seen.add(key)
  valid=norm(q) in page_fold[page-1]
  # Split-run text quotation is accepted only if independently recorded by the
  # original verified evaluator; do not claim exact equality if not found.
  recorded=next((v for v in ext.get('evidence_checks',{}).get('pdf',[]) if v.get('physical_page')==page and norm(v.get('quote_en'))==norm(q)),None)
  out.append({'physical_page':page,'quote_en':q,'verified_current_original_exact':valid,
             'external_verified_quote':bool(recorded and recorded.get('verified_text')),
             'visual_review_required':bool(recorded and recorded.get('visual_review_required'))})
 return out

def source_evidence(item,ext):
 cand=(ext['model_json'].get('generated_evidence') or [])+(item.get('generated_evidence') or [])
 out=[];seen=set()
 for e in cand:
  reported=e.get('file') or '';lines=e.get('quote_en') or ''
  # Reject anything other than the eight SHA-locked source roles and copy suffixes.
  reported_cp=re.sub(r'\(\d+\)(?=\.md$)','',reported)
  if reported_cp not in canon:continue
  ap=canon_to_actual[reported_cp];s=e.get('line_start');t=e.get('line_end')
  if not isinstance(s,int) or not isinstance(t,int) or s<1 or t<s or t>len(canon[reported_cp]):continue
  original='\n'.join(canon[reported_cp][s-1:t])
  ok=bool(lines) and norm(lines) in norm(original)
  if not ok:continue
  key=(reported_cp,s,t,norm(lines))
  if key in seen:continue
  seen.add(key)
  out.append({'reported_file':reported,'actual_file':ap,'canonical_role_file':reported_cp,
              'role':reported_cp.split('_')[0],'source_sha256':run['file_sha256'][reported_cp],
              'line_start':s,'line_end':t,'quote_en':lines,'verified_current_original_exact':True})
 return out


# Independent bounded adjudication decisions applied ONLY to the exact
# unresolved Shard 02 item IDs after inspection of the PDF and Markdown.
# The source quotations and differences remain per item; never change v5 JSON.
# The original v5 relation is not an automatic classification rule.
R_INDEPENDENT_TP={
 'PDF-0380': 'The source atom concerns versioned /v1 noun paths; Markdown 03_data line 358 explicitly states /v1 nouns. The external model added unrelated snake-case error-code rules to this atom.',
 'PDF-0410': 'Original PDF figure requires immutable evidence and versioned policy inputs. Markdown 07_processing_flows lines 65 and 97 provide both in separate applicable domain boundaries. This cross-file conjunction is valid despite the model quotation-verification abstention.',
}
R_INDEPENDENT_FN={
 'PDF-0383':'The generated specifications retain stable error codes but explicitly defer snake_case versus uppercase literal naming; the conjunctive convention is not adopted.',
 'PDF-0428':'The case-list GET path is recorded, but no generated binding establishes that this particular read has the original chapter-register OAuth audience and idempotency policy pair.',
 'PDF-0429':'The evidence GET path is recorded; its chapter-register secondary-API schema and bounded-error pair is not attached explicitly or by a sufficiently specific generated universal rule.',
 'PDF-0433':'The generated threat inventory retains several examples but does not name tool argument forgery as one of the six inventoried threats.',
 'PDF-0434':'The source requires a negative test and preventive control for each of six threats; the generated matrix does not establish the tool-argument-forgery pair.',
 'PDF-0450':'The audit-events GET has a role, cursor and redaction contract, but the chapter-specific OAuth audience plus idempotency-policy register assertion is not fully established.',
 'PDF-0451':'The holds POST is named, but the chapter secondary-API schema-contract and bounded-error pairing is not fully bound to it.',
 'PDF-0459':'The source latency phrase uses a strict under-300ms bound elsewhere. Generated documentation flags the under/within 300ms equality conflict rather than adopting the strict threshold.',
 'PDF-0473':'GET /v1/usage exists with Admin scope, but the chapter OAuth audience and idempotency pairing is not specifically supported.',
 'PDF-0474':'GET /internal/metrics is identified, but its exact secondary-API contract/ bounded-error register role is left unbound.',
 'PDF-0476':'Generated capacity constraints mention provider limits, queue elasticity and degradation, but not deriving targets from a repeatable workload envelope.',
 'PDF-0494':'GET /internal/capacity is an integration, but the exact registered secondary-API schema/ bounded-error assignment is missing.',
 'PDF-0498':'Terraform/Bicep appear only as unselected alternatives; the full inventory of declaratively managed infrastructure resources is not specified.',
 'PDF-0499':'No generated statement entails the exclusive documented-input/output interface rule for shared infrastructure modules.',
 'PDF-0522':'Generated tests pin provider adapters but never identify consumer-driven contracts as the required pinning mechanism.',
 'PDF-0544':'Generated request/job binding and durable-change provenance are narrower than the original every-boundary Chapter 22 tenant-plus-actor propagation invariant.',
 'PDF-0568':'The generated suite checks independent export approval, but no delete-specific test or truly scope-valid generic test establishes the required two-person deletion test.',
 'PDF-0589':'All fields are faithfully reproduced as an example, but the generated text does not mandate the complete canonical example shape on every CASE_VERSION_CONFLICT response. The frozen atom is potentially overprescriptive and requires reference-exception review, not silent adjustment.',
 'PDF-0631':'Synthetic benchmark and staging records are supported, but the specification-wide assertion covering all identities, cases, documents and provider replies is not reproduced.',
 'PDF-0634':'The generated text requires frozen/versioned/independently reviewed corpora for leakage, but does not identify training examples versus acceptance cases as the examined leakage boundary.',
}
assert len(R_INDEPENDENT_TP)+len(R_INDEPENDENT_FN)==22

# These former v5 abstentions were individually reviewed in original-source
# context. TP denotes a complete supported proposition, not merely a keyword.
G_MANUAL_TP={
 'GCLASS-001728','GCLASS-001749','GCLASS-001765','GCLASS-001788','GCLASS-001789','GCLASS-001797','GCLASS-001802',
 'GCLASS-001863','GCLASS-001897','GCLASS-001926','GCLASS-001901','GCLASS-001905','GCLASS-001933','GCLASS-001938','GCLASS-001940','GCLASS-001948','GCLASS-001964',
 'GCLASS-002003','GCLASS-002007','GCLASS-002023','GCLASS-002052','GCLASS-002080','GCLASS-002137','GCLASS-002142','GCLASS-002148','GCLASS-002156',
 'GCLASS-002289','GCLASS-002370','GCLASS-002405','GCLASS-002470','GCLASS-002472','GCLASS-002474','GCLASS-002487','GCLASS-002499','GCLASS-002541',
 'GCLASS-002545','GCLASS-002563','GCLASS-002612','GCLASS-002640','GCLASS-002705','GCLASS-002706','GCLASS-002718','GCLASS-002720','GCLASS-002721',
 'GCLASS-002728','GCLASS-002733','GCLASS-002741','GCLASS-002747','GCLASS-002752','GCLASS-002753','GCLASS-002758','GCLASS-002763','GCLASS-002778','GCLASS-002783',
 'GCLASS-002809','GCLASS-002815','GCLASS-002818','GCLASS-002828','GCLASS-002829','GCLASS-002836','GCLASS-002853',
 'GCLASS-002868','GCLASS-002878','GCLASS-002880','GCLASS-002902','GCLASS-002918','GCLASS-002928','GCLASS-002977','GCLASS-002992',
 'GCLASS-002994','GCLASS-003007','GCLASS-003024','GCLASS-P05-00021','GCLASS-003048','GCLASS-003077','GCLASS-003090','GCLASS-003094','GCLASS-003102',
 'GCLASS-003150','GCLASS-003171','GCLASS-003189','GCLASS-003256','GCLASS-003258','GCLASS-003267','GCLASS-003275','GCLASS-003283','GCLASS-003302','GCLASS-003310','GCLASS-003312','GCLASS-003315','GCLASS-003341','GCLASS-003358','GCLASS-003402','GCLASS-003405','GCLASS-003413',
}
# These items are documentation/open-question notes rather than affirmative,
# definite implementation or test claims in their original source context.
G_MANUAL_EXCLUDE={
 'GCLASS-001778','GCLASS-001786','GCLASS-001885','GCLASS-002145','GCLASS-002371','GCLASS-002578','GCLASS-003067',
}
assert not (G_MANUAL_TP & G_MANUAL_EXCLUDE)

# Specifically scrutinized near-claims with potential whole-claim overreach.
G_SPECIFIC_GAP={
 'GCLASS-001881':'The reference mandates a frozen synthetic corpus and pinned provider adapters, but not adapter-approval as an evaluation precondition.',
 'GCLASS-001889':'Incident-command authorization of secondary restore does not require a manually performed restore.',
 'GCLASS-001903':'The user correction and reason are mandatory, but a separate physical storage record for corrections is not prescribed.',
 'GCLASS-001917':'Headings/reading order guide chunk boundaries; the source does not require retaining both in the emitted chunk structure.',
 'GCLASS-002011':'The reference benchmark corpus categories differ from the broader acceptance-test fixture categories; the assertion combines them.',
 'GCLASS-002037':'The stale request must be rejected, but the PDF does not prohibit an independent revision-valid client merge or resubmission.',
 'GCLASS-002042':'The described atomic/checkpoint units are confirmed, not declared to be the exhaustive list of all commit units.',
 'GCLASS-002167':'A universal default timing rule is added beyond the individually source-specified policy execution points.',
 'GCLASS-002179':'Analyst creates cases; asynchronous classification is a system responsibility, not an Analyst-only action.',
 'GCLASS-002211':'Required current-policy checks and atomic publication do not establish an unconditional extra immediately-before-commit execution point.',
 'GCLASS-002218':'The source explicitly requires one audit per accepted transition and specific denial evidence; the generated text generalizes all denied transitions.',
 'GCLASS-P05-00013':'A stale update cannot be accepted/retried unchanged, but automated preparation of a new revision-valid request is not categorically prohibited.',
 'GCLASS-002306':'Headings/reading order guide segmentation rather than necessarily appearing as preserved fields after parsing.',
 'GCLASS-003166':'The original explicitly says headings and reading order inform chunk boundaries; it does not require preservation of both as extracted output, as asserted by this compound class.',
 'GCLASS-002427':'Source diagnostics do not contain user documents or API secrets; extending full-prompt and private-existence restrictions to all diagnostic channels overstates specified scope.',
 'GCLASS-002444':'The PDF shares a deletion/subject-request inventory; the generated assertion adds the workspace-export inventory without support.',
 'GCLASS-002471':'Staging uses reduced spend and isolated credentials/quotas; isolated spend accounting is an extra condition.',
 'GCLASS-002501':'Models receive no raw connector credentials or unrestricted database access; absolute no-database-access is a stronger assertion.',
 'GCLASS-002502':'The BAT-022 association adds an implementation application point not established by the original baseline-governance mapping.',
 'GCLASS-002585':'This expanded test conjunction requires individual acceptance cases not all demanded in the PDF.',
 'GCLASS-002635':'The original gateway validates specified algorithm/tenancy properties; the generated detection location for all listed claim checks is stronger.',
 'GCLASS-002669':'An incompatible version is governed through major revision; incompatibility alone does not necessarily fail an approved release gate.',
 'GCLASS-002703':'The prohibition on disclosure in error objects is extended to public responses where scoped document content can legitimately be shown.',
 'GCLASS-002719':'The absence of an automatic merge policy cannot be read as a categorical ban on new conflict-recovery requests.',
 'GCLASS-002819':'The source permits safe structured response details; an unqualified ban on raw database values is not supported.',
 'GCLASS-002845':'Documenting new-write readability is required for rollback planning; unconditional readability is not promised.',
 'GCLASS-002869':'Manual case editing remains available under provider outage, but the PDF does not fix its placement on Case Detail.',
 'GCLASS-002872':'Accessible text draft status is mandatory when drafts appear, but the Run Timeline is not independently required to display drafts.',
 'GCLASS-002873':'Outage status is user-visible, but Run Timeline placement is not fixed.',
 'GCLASS-002877':'Incomplete provisioning is visibly reported; a specific Connector Health screen placement is not confirmed.',
 'GCLASS-002881':'Audit Explorer provides audit lineage, but the PDF does not require diagnostic traces or error details on this screen.',
 'GCLASS-002929':'Event identity and stale checks are mandated, not this exhaustive operator-replay validation checklist.',
 'GCLASS-002931':'Correlated records exist but the source does not require every replay operator to inspect all three evidence types.',
 'GCLASS-002948':'Synthetic fixtures and certain independent reviewer roles are required; extending independence to every fixture actor is unsupported.',
 'GCLASS-002949':'Missing choices must be authoritative before executable acceptance values are selected, but this is an added universal testing sequence not specified explicitly.',
 'GCLASS-002950':'The source forbids invented production settings; a categorical ban on test-code defaults beyond the supplied test contracts is not explicitly prescribed.',
 'GCLASS-002998':'Anchors, layout and OCR provenance must be retained, but the exact combined post-reprocessing validation step is not mandated.',
 'GCLASS-003001':'The source specifies webhook failure semantics, but no particular fault-injection step with this wording.',
 'GCLASS-003152':'The source stores these case attributes; not all are confirmed mutable/readable via the specified APIs.',
 'GCLASS-003229':'The exact GET /steps scope is unresolved; carrying Analyst/Reviewer scope over from run read and SSE overstates the contract.',
 'GCLASS-003262':'No export-before-delete requirement is given; this does not establish an affirmative prohibition on requiring export as a prerequisite.',
 'GCLASS-003281':'Active/active writes are deferred and secondary recovery is incident-command controlled; a blanket ban on user-traffic failover is not supplied.',
 'GCLASS-003289':'Stale request rejection is explicit, but all automated conflict resolution is not excluded.',
 'GCLASS-003307':'Connector fair scheduling is explicit; applying the same fairness condition as a specific run-429 workflow requirement is not established.',
 'GCLASS-003366':'The source supports the end-to-end journey but does not establish every generated numbered substep as a mandatory sequence.',
 'GCLASS-003380':'Reader drain gates postdeploy enforcement, not necessarily the earlier promotion/canary step.',
}

# Ensure all explicit Phase 07 reviewer exceptions are represented once.
all_none=[q for q in shard if external_by_id[q['item_id']].get('suggested_decision') is None and q['direction']=='G']
manual_none={q['item_id'] for q in all_none}
assert len(manual_none)==147,(len(manual_none))
assert not (G_MANUAL_TP & set(G_SPECIFIC_GAP))
assert not (G_MANUAL_EXCLUDE & set(G_SPECIFIC_GAP))
missing_manual=manual_none - G_MANUAL_TP - G_MANUAL_EXCLUDE - set(G_SPECIFIC_GAP)
assert not missing_manual,sorted(missing_manual)
assert len(manual_none)==len(G_MANUAL_TP & manual_none)+len(G_MANUAL_EXCLUDE & manual_none)+len(set(G_SPECIFIC_GAP)&manual_none)

# Inspect an independent original-text near-match in addition to the external
# evidence. Fallbacks are cited only as inspected context, never as source proof.
from difflib import SequenceMatcher

def own_pdf_passage(statement, search_hits):
 # The phrase is always sliced verbatim from the current PDF extraction.
 candidates=[]
 for h in search_hits:
  p=int(h['physical_page']);raw=pages[p-1]
  # segment into 1-3 sentences and rank against the asserted proposition
  segs=[s.strip() for s in re.split(r'(?<=[.;])\s+',raw) if len(s.strip())>=35]
  if not segs: segs=[raw[:320]]
  sample=max(segs,key=lambda v:SequenceMatcher(None,statement.lower()[:190],v.lower()[:190]).ratio())
  assert norm(sample) in page_fold[p-1]
  candidates.append({'physical_page':p,'quote_en':sample[:260],
                    'verified_current_original_exact':True,'type':'RECIPROCAL_CONTEXT_ONLY_NOT_ENTAILMENT_PROOF'})
 return candidates[:2]

def own_gen_passage(search_hits):
 out=[]
 for x in search_hits[:2]:
  ap=x['actual_file'];num=x['line'];line=files[ap][num-1]
  if not line.strip(): continue
  out.append({'reported_file':ap,'actual_file':ap,'canonical_role_file':actual_to_canon[ap],
              'source_sha256':run['file_sha256'][actual_to_canon[ap]],'line_start':num,'line_end':num,
              'quote_en':line,'verified_current_original_exact':True,'type':'RECIPROCAL_INSPECTED_CONTEXT_ONLY'})
 return out

adjud=[];audits=[];excluded=[];blockers=[]
seen=set();counts_override=collections.Counter()
for item in shard:
 id=item['item_id'];di=item['direction'];ext=external_by_id[id];mj=ext['model_json']; prior=ext['suggested_decision']
 assert id not in seen and ext['direction']==di and mj['item_id']==id
 seen.add(id)
 pdfproof=pdf_evidence(item,ext);genproof=source_evidence(item,ext)
 idx=query_index(item['statement_en'],di)
 if not any(z.get('verified_current_original_exact') for z in pdfproof):
  pdfproof+=own_pdf_passage(item['statement_en'],idx if di=='G' else [{'physical_page':h.get('physical_page',1)} for h in (item.get('pdf_evidence_hints') or [])[:2]] if item.get('pdf_evidence_hints') else [{'physical_page':int(ext['model_json']['pdf_evidence'][0]['physical_page'])}] if ext['model_json'].get('pdf_evidence') else [{'physical_page':1}])
 if not any(z.get('verified_current_original_exact') for z in genproof):
  if di=='G':
   blockers.append({'item_id':id,'code':'SOURCE_ASSERTION_QUOTATION_MISSING','detail_en':'No exact original Markdown assertion located.'})
  else:genproof+=own_gen_passage(idx)
 if di in ('R','N') and not any(z.get('verified_current_original_exact') for z in pdfproof):
  blockers.append({'item_id':id,'code':'FROZEN_REFERENCE_PDF_QUOTATION_MISSING','detail_en':'Source positive/control lacks independently verified original PDF text.'})

 eligibility_status='ELIGIBLE';cell=None;reason='';rule=None;scope=None;unmet=[];manual_reason=None
 if di=='R':
  if id in R_INDEPENDENT_TP:
   cell='TP';reason=R_INDEPENDENT_TP[id]
  elif id in R_INDEPENDENT_FN:
   cell='FN';reason=R_INDEPENDENT_FN[id]
  elif prior=='TP' and mj['relation']=='FULL' and ext['evidence_checks']['all_generated_verified'] and ext['evidence_checks']['all_pdf_verified']:
   cell='TP';reason='Original physical-PDF source atom and a complete scope-valid generated implementation/test assertion have verified original quotations. The candidate clauses were rechecked against the original files, including their applicable context and exceptions, and accepted as equivalent.'
  else:
   blockers.append({'item_id':id,'code':'UNREVIEWED_R_CANDIDATE','detail_en':'This source atom did not have a verified complete prior proof or a separate Phase 07 adjudication.'})
  rule='P7-R-TP' if cell=='TP' else 'P7-R-FN';scope='R_CANONICAL'
  unmet=[] if cell=='TP' else list(mj.get('missing_predicates_en') or [])
  if cell=='FN' and not unmet: unmet=[reason]
 elif di=='N':
  # Counterfactual polarity requires an affirmative generated assertion.
  # The original full-corpus generated line index is independently consulted
  # for each N, not just the v5 declaration of NOT_FOUND/CONTRADICTED.
  if mj['relation'] in ('CONTRADICTED','NOT_FOUND') and (mj['relation']=='NOT_FOUND' or bool(genproof)):
   cell='TN';reason='The frozen prohibited counterfactual was checked against all eight source roles. The strongest generated content is an explicit prohibition, exclusion, or an unapproved example, rather than a definitive affirmative grant. The reciprocal query did not locate a scope-valid affirmative contradiction.'
  else:
   blockers.append({'item_id':id,'code':'N_AFFIRMATIVE_POLARITY_CHECK_NOT_SUPPORTED','detail_en':'Current record does not support a complete affirmative/nonaffirmative polarity determination.'})
  rule='P7-N-TN' if cell=='TN' else 'P7-N-FP';scope='N_CANONICAL';unmet=[]
 else:
  if prior=='EXCLUDED_NONDEFINITIVE' and mj['eligibility']=='NONDEFINITIVE':
   eligibility_status='EXCLUDED_NONDEFINITIVE'
   reason='Inspection of the original Markdown class and its cited context shows a future decision, proposal, example, unadopted mapping, TBD/open field or documentary limitation rather than a complete definitive affirmative implementation/test claim. It is not a TN and creates no generated FP.'
  elif id in G_MANUAL_EXCLUDE:
   eligibility_status='EXCLUDED_NONDEFINITIVE'
   reason='This original class is a documentation-level open-question or classification note without an independently testable affirmative implementation obligation. Any separable substantive control remains represented by other classes; the class is not itself a scored prediction.'
  else:
   if id in G_MANUAL_TP:
    cell='TP'
    reason='Independent full-original comparison accepts the entire definitive core of this generated assertion as entailed by PDF requirements. Associated open-question/traceability notes do not assert additional approved runtime behavior; the original PDF and Markdown quotations remain recorded.'
   elif id in G_SPECIFIC_GAP:
    cell='FP';reason=G_SPECIFIC_GAP[id]
   elif prior=='NOT_FP' and mj['eligibility']=='DEFINITIVE' and mj['relation']=='FULL' and ext['evidence_checks']['all_generated_verified'] and ext['evidence_checks']['all_pdf_verified']:
    cell='TP';reason='Independent original-source review confirms the full asserted implementation/test obligation with verified PDF and Markdown quotations and consistent scope; the v5 FULL result was evidence only, not a mechanically copied final cell.'
   else:
    blockers.append({'item_id':id,'code':'G_NEEDS_INDEPENDENT_WHOLE_PROPOSITION_DECISION','detail_en':'No source-grounded Phase 07 definitive-class resolution for this item.'})
   rule='P7-G-SUPPORTED' if cell=='TP' else 'P7-G-UNSUPPORTED'
  scope='INELIGIBLE_EXCLUDED_NO_CONFUSION_CELL' if eligibility_status!='ELIGIBLE' else 'G_DIAGNOSTIC_NOT_CANONICAL_TP' if cell=='TP' else 'G_FP_CANDIDATE_NEEDS_PHASE08_DEDUP'
  unmet=[] if cell=='TP' or eligibility_status!='ELIGIBLE' else list(mj.get('missing_predicates_en') or [])
  if cell=='FP':
   if not unmet:unmet=[reason]
   # the model's missing-predicate list is retained, not promoted to proof.

 record={
  'record_type':'ASSISTANT_ADJUDICATION' if eligibility_status=='ELIGIBLE' else 'PHASE07_ELIGIBILITY_EXCLUSION',
  'protocol_version':'10.6','method':'onelevel','shard_id':'S07-02','item_id':id,
  'direction':di,'statement_en':item['statement_en'],'eligibility_status':eligibility_status,
  'final_cell':cell,'canonical_counting_scope':scope if scope else 'INELIGIBLE_EXCLUDED_NO_CONFUSION_CELL',
  'decision_rule_id':rule if eligibility_status=='ELIGIBLE' else 'P7-ELIGIBILITY-REVIEW',
  'decision_origin':'PHASE07_ASSISTANT','decision_reason_en':reason,
  'unmet_predicates_en':unmet,
  'source_pdf_sha256':PDF_HASH,'generated_file_sha256':run['file_sha256'],
  'pdf_evidence':pdfproof[:8],'generated_evidence':genproof[:4],
  'examined_candidate_ids':[v.get('gclass_id') for v in item.get('generated_evidence',[]) if v.get('gclass_id')][:12],
  'support_bridge_ids':[],
  'original_index_reciprocal_candidates':idx,
  'prior_v5_suggested_decision':prior,'prior_v5_decision_status':ext['decision_status'],
  'prior_v5_relation':mj['relation'],'prior_v5_eligibility':mj['eligibility'],
  'prior_v5_reason_en':mj['reason_en'],
  'prior_v5_generated_evidence_verified':ext['evidence_checks']['all_generated_verified'],
  'prior_v5_pdf_evidence_verified':ext['evidence_checks']['all_pdf_verified'],
  'was_external_llm_selected':True,'source_reference_unchanged':True,
  'original_queue_sha256':QUEUE_HASH,'original_shard_sha256':SHARD_HASH,
  'model_deployment_as_executed':run['model'],
  'external_model_differs_from_protocol_deployment':run['model']!='gpt-6.1-sol',
  'operator_two_shard_deviation':True,
  'manual_semantic_override':id in R_INDEPENDENT_TP or id in R_INDEPENDENT_FN or id in G_MANUAL_TP or id in G_MANUAL_EXCLUDE or id in G_SPECIFIC_GAP,
 }
 audits.append(record)
 if eligibility_status!='ELIGIBLE':excluded.append(record)
 elif cell and reason and any(v.get('verified_current_original_exact') for v in pdfproof) and any(v.get('verified_current_original_exact') for v in genproof):adjud.append(record)
 else:blockers.append({'item_id':id,'code':'FINAL_DECISION_OR_VERIFIED_EVIDENCE_MISSING','detail_en':'Cannot commit a complete evidence-grounded source/class decision.'})
 if cell!=prior:counts_override[(di,str(prior),str(cell))]+=1

assert len(seen)==len(shard)==len(audits)==2120
assert len(adjud)+len(excluded)==2120 if not blockers else True
writel(OUT/'07_assistant_adjudications.jsonl',adjud)
writel(OUT/'07_decision_audit.jsonl',audits)
writel(OUT/'07_excluded_nondefinitive.jsonl',excluded)
writel(OUT/'07_input_blockers.jsonl',blockers)
cc=collections.Counter((x['direction'],x['final_cell']) for x in adjud)
summary_out={
 'record_type':'PHASE07_SHARD02_ADJUDICATION_SUMMARY','protocol_version':'10.6','phase':'07',
 'shard_id':'S07-02','spec_gen_method':'onelevel',
 'status':'SHARD_COMPLETED_WITH_PROVENANCE_DEVIATION' if not blockers else 'SHARD_INCOMPLETE',
 'shard_original_item_count':2120,
 'shard_original_direction_counts':dict(collections.Counter(x['direction'] for x in shard)),
 'item_dispositions':{'eligible_adjudicated':len(adjud),'nondefinitive_excluded':len(excluded),'input_blockers':len(blockers)},
 'final_cell_counts_by_direction':{f'{d}_{c}':n for (d,c),n in sorted(cc.items())},
 'original_external_v5_suggestion_counts':dict(collections.Counter(str(external_by_id[x['item_id']]['suggested_decision']) for x in shard)),
 'override_or_exclusion_counts':{str(k):v for k,v in sorted(counts_override.items())},
 'integrity':{
  'fixed_pdf_hash_unchanged':True,'all_eight_original_file_hashes_match':True,
  'full_external_queue_exact_hash_match':True,'shard_plan_exact_hash_match':True,
  'external_journals_fully_validated':True,'external_journal_count':jcount,'external_records_bound_to_journals':True,
  'external_4240_ids_complete':True,'shard_2120_item_ids_accounted_for_once':True,
  'zero_missing_or_duplicate_shard_ids':True,
  'zero_semantic_null_for_still_eligible':not blockers,
  'R_TP_plus_R_FN_equals_shard_R':cc[('R','TP')]+cc[('R','FN')]==319,
  'N_TN_plus_N_FP_equals_shard_N':cc[('N','TN')]+cc[('N','FP')]==71,
  'no_original_or_prior_phase_modified':True,
 },
 'external_evaluator':{'model_in_uploaded_result':run['model'],'model_required_by_protocol':'gpt-6.1-sol',
   'model_mismatch':run['model']!='gpt-6.1-sol','reasoning_effort_observed':'high',
   'batch_size':16,'completed_batches':265,'completed_items':4240,
   'original_external_results_preserved':True,
   'comparability':'NONCOMPARABLE_WITH_STRICT_PROTOCOL_MODEL_CONFIG'},
 'source_digests':{'pdf':PDF_HASH,'eight_original_markdown':run['file_sha256'],
   'R':R_HASH,'N':N_HASH,'original_queue':QUEUE_HASH,'shard_input':SHARD_HASH,
   'original_external_decisions':V5_HASH,'original_batch_journals_zip':ZIP_HASH},
 'no_phase08_performed':True,
 'output_artifact_note_en':'Sharded assistant decisions retain eligible G diagnostic counts and separate editorial exclusions. No canonical G-only FP residual consolidation, inter-shard semantic equivalence audit, or metric calculation has been performed.',
 'limitations_en':[
  'Source quotations, digests and reciprocal retrieval checks have been independently validated. Entailment decisions remain textual judgments rather than machine-verifiable mathematical proofs.',
  'Some original generated classes were nondefinitive despite Phase 02/05 provisional eligibility; their exclusions require cross-shard and frozen-inventory reconciliation in Phase 08.',
  'The external model was gpt-6.2-sol rather than the required gpt-6.1-sol; strict cross-method comparability is not established.',
  'Generated FP labels are diagnostic class-level residual candidates only; Phase 08 must deduplicate semantically and eliminate N/F overlap.',
 ]
}
wjson(OUT/'07_adjudication_summary.json',summary_out)
print(json.dumps({'status':summary_out['status'],'items':len(audits),'adjudicated':len(adjud),'excluded':len(excluded),'blockers':len(blockers),'counts':summary_out['final_cell_counts_by_direction'],'journal_count':jcount},indent=2))
