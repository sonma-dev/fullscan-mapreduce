# Phase 07 — Shard 02: Evidence-grounded adjudication report

Protocol: 10.6. Method: onelevel. Generation reasoning effort: low. External evaluator reasoning effort: high.

## Input verification and execution

The 90-physical-page original PDF and eight original Markdown specifications, frozen positive and negative source inventories, immutable Phase 06 4,240-item queue, Shard 02 2,120-item selection, Version 5.0 original model output and all 265 external 16-item batch journals were checked by SHA-256, original line/page references and batch ordering. All Shard 02 IDs exist once in the original queue and v5 output. Previous phase files, original documents, and Shard 01 outputs have not been modified.

## Shard 02 adjudication results

| Direction | Supported/negative control pass | Uncovered/unsupported | Nondefinitive exclusions | Original items |
|---|---:|---:|---:|---:|
| R | TP 299 | FN 20 | 0 | 319 |
| N | TN 71 | FP 0 | 0 | 71 |
| G diagnostic | Supported 1435 | Unsupported candidate 46 | 249 | 1,730 |

Eligible decisions: 1,871; nondefinitive G exclusions: 249; input blockers: zero. No eligible item remains semantically UNRESOLVED or null. Exactly 2,120 source queue IDs are accounted for.

The initial v5 suggestion count for this shard was {'EXCLUDED_NONDEFINITIVE': 242, 'FN': 1, 'NOT_FP': 1341, 'None': 238, 'TN': 1, 'TP': 297}. All 22 R items without accepted TP suggestions received item-specific PDF/Markdown comparison: two TP corrections and twenty FN. All 147 G v5 abstentions received individually selected support, unsupported-residual or nondefinitive dispositions, not a blind PARTIAL-to-FP/UNRESOLVED-to-negative conversion.

## Evidence and limitations

- Verified 4,393 original Markdown quotations at their exact original line ranges and 10,455 PDF quotations against physical page text. 2 reciprocal PDF excerpts serve as inspected context, not independent proof of entailment.
- The assistant gave separate claim-specific explanations for the unaccepted R results and G unsupported residuals; model suggestions remain immutable and are cited only as prior evidence.
- The generated prediction extraction contains 249 Shard 02 classes whose source text is an open decision, editorial statement, example or nondefinitive qualification. Phase 08 must reconcile these with the originally frozen GO/GC membership rather than changing older records.
- A diagnostic `G:TP` does not create another canonical R true positive. The 46 Shard 02 G unsupported candidates are **not** the final canonical FP count; Phase 08 must merge semantically equivalent residuals and remove overlaps with affirmative N controls.
- The cross-shard similarity screen identified 24 potential FP-versus-supported semantic comparisons and 7 potential unsupported-residual duplicate pairs. These are *review prompts*, not actual inconsistencies or automatic merges. Genuine contradictions require explicit Phase 07 superseding decisions.
- Entailment judgments remain interpretable and may require later contradiction correction. Mechanical quotation checks prove the cited text exists, not the conclusion by themselves.

## External-evaluator comparability deviation

The uploaded run used gpt-6.2-sol, whereas protocol Version 10.6 specifies gpt-6.1-sol. The original model responses are preserved without modification. The two-Shard arrangement was authorized by the operator, but the external model change is not thereby accepted as cross-method comparable. Do not claim strict method comparability without consistent configurations or an approved protocol amendment.

## Completion gate

Shard 02 is completed with documented provenance deviation. Both Shards cover all 4,240 original Phase 06 IDs once; their item-level R/N binary judgments are complete. Phase 08 semantic reconciliation and Phase 09 metric calculation have **not** been executed. The two-shard aggregate is available only as a handoff diagnostic.
