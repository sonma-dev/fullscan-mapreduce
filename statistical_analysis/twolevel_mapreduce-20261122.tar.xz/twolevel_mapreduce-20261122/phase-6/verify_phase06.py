#!/usr/bin/env python3
"""Independent integrity verification and review-candidate discovery, not semantic verdicts."""
import sys,json,hashlib,re,math,collections
from pathlib import Path
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import linear_kernel
P=Path('/mnt/data/oriondesk_twolevel_v10_6'); B=P/'phase06'
def r(fn):return [json.loads(x) for x in open(fn,encoding='utf-8') if x.strip()]
def h(fn):return hashlib.sha256(Path(fn).read_bytes()).hexdigest()
def save(fn, arr):
 with open(B/fn,'w',encoding='utf-8') as f:
  for e in arr:f.write(json.dumps(e,sort_keys=True,ensure_ascii=False)+'\n')
q=r(B/'06_llm_queue_v10.6.jsonl'); sel=json.loads((B/'06_queue_selection.json').read_text())
frozen_r=r('/mnt/data/common_atomic_reqs(3).jsonl');frozen_n=r('/mnt/data/common_negative_controls(3).jsonl')
cls=r(P/'phase05/05_generated_claim_validity.jsonl'); rec=r(P/'phase05/05_recovered_atoms.jsonl')
active_g=[{'id':x['class_id'],'s':x['complete_claim_en'],'file':x['original_source_file'],'line':x['original_line_start']} for x in cls]+[
 {'id':x['class_id'],'s':x['complete_claim_en'],'file':x['source_file'],'line':x['line_start']} for x in rec if not x['merged_into_original_GC']]
assert len(active_g)==2183
expected={x['requirement_id'] for x in frozen_r}|{x['control_id'] for x in frozen_n}|{x['id'] for x in active_g}
qids=[x['item_id'] for x in q];assert len(qids)==len(expected)==len(set(qids))==2963;assert set(qids)==expected
assert qids[:638]==[x['requirement_id'] for x in frozen_r]
assert qids[638:780]==[x['control_id'] for x in frozen_n]
assert qids[780:]==[x['id'] for x in sorted(active_g,key=lambda x:(int(x['file'][:2]),x['line'],x['line'],x['id']))]
assert all(x['record_type']=='UNRELIABLE_ITEM' and x['unreliable'] is True for x in q)
assert {x['direction'] for x in q}=={'R','N','G'}
assert collections.Counter(x['direction'] for x in q)=={'R':638,'N':142,'G':2183}
assert h(B/'06_llm_queue_v10.6.jsonl')==sel['queue_sha256']
assert len(sel['batch_boundaries'])==371
assert [len(x) for x in [q[i:i+8] for i in range(0,2963,8)]][-1]==3
for block in sel['batch_boundaries']:
 ids=[x['item_id'] for x in q[block['queue_start_index']:block['queue_end_index_exclusive']]]
 assert ids==block['item_ids']; assert len(ids)==block['batch_size']
# independently verify model attribution snippets exact original lines
source=json.loads((P/'phase01/01_source_reference_manifest.json').read_text())
lines={x['actual_filename']:Path(x['original_path']).read_text(encoding='utf-8-sig').splitlines() for x in source['source_roles']}
dig={x['actual_filename']:x['sha256'] for x in source['source_roles']}
verified=0
for item in q:
 for ev in item.get('generated_evidence',[]):
  fn=ev['file']; lo,hi=ev['line_start'],ev['line_end']
  assert fn in lines and 1<=lo<=hi<=len(lines[fn])
  assert h('/mnt/data/'+fn)==dig[fn]==ev['source_sha256']
  import unicodedata
  norm=lambda s:' '.join(unicodedata.normalize('NFKC',s).split()).casefold()
  assert norm(ev['quote_en']) in norm('\n'.join(lines[fn][lo-1:hi])),(item['item_id'],ev['file'])
  verified+=1
# near duplicate candidate discovery across effective G (no automatic semantic merge)
corpus=[x['s'] for x in active_g]
v=TfidfVectorizer(analyzer='char',ngram_range=(3,5),min_df=1,sublinear_tf=True)
mat=v.fit_transform(corpus)
# sparse matrices overlap and candidate cutoff 0.92 before any source-grounded semantic evaluation
scores=(mat@mat.T).tocsr()
sim=[]
for i in range(len(active_g)):
 start,end=scores.indptr[i],scores.indptr[i+1]
 for j,s in zip(scores.indices[start:end],scores.data[start:end]):
  if j<=i or s<.92:continue
  x,y=active_g[i],active_g[j]
  sim.append({'record_type':'POTENTIAL_NEAR_DUPLICATE','class_a':x['id'],'class_b':y['id'],
   'claim_a_en':x['s'],'claim_b_en':y['s'],'lexical_similarity_diagnostic':round(float(s),6),
   'same_file':x['file']==y['file'],'mutual_entailment_verified':False,
   'unsupportedness_verified':False,'merge_authorized':False})
sim.sort(key=lambda x:(-x['lexical_similarity_diagnostic'],x['class_a'],x['class_b']))
save('06_semantic_near_duplicate_candidates.jsonl',sim)
# frozen N/G possible overlaps, not N affirmed and not generated-only FP.
controls=r(B/'06_fp_controls.jsonl');all_pairs=[]
for c in controls:
 for g in c['top_candidates']:
  if g['lexical_similarity_diagnostic']>=.25:
   all_pairs.append({'record_type':'CANDIDATE_N_G_OVERLAP','negative_control_id':c['control_id'],
    'class_id':g['class_id'],'counterfactual_en':c['counterfactual_en'],
    'claim_en':g['generated_statement_en'],'lexical_similarity_diagnostic':g['lexical_similarity_diagnostic'],
    'is_forbidden_affirmation':'PENDING_ADJUDICATION','semantically_same_residual':'PENDING_ADJUDICATION',
    'FP_counted':False})
save('06_N_G_overlap_candidates.jsonl',all_pairs)
vr={ 'record_type':'PHASE06_INDEPENDENT_VERIFICATION','protocol_version':'10.6','method':'twolevel',
 'queue_ids_match_full_R_N_effective_GC':True,'queue_R':638,'queue_N':142,'queue_G':2183,
 'K_equals_C':len(q)==sel['pending_population_C']==sel['queued_K'],
 'zero_omitted_due_to_numeric_limits':True,'queue_sha256_matches_selection':True,
 'batch_boundaries_valid':True,'original_generated_evidence_quotes_verified':verified,
 'near_duplicate_candidate_pairs_gt_0_92':len(sim),'N_G_possible_overlaps_gt_0_25':len(all_pairs),
 'semantic_truth_or_final_fp_counts_inferred_from_similarity':False,
 'final_semantic_decisions_written':0,'actual_external_submissions':0,
 'phase06_status':'INCOMPLETE_EXTERNAL_POLICY_AND_INPUT_BLOCKER'}
(B/'06_independent_verification.json').write_text(json.dumps(vr,indent=2)+'\n')
print(json.dumps(vr,indent=2))
