#!/usr/bin/env bash
# External Azure execution handoff. This script does not run without the required
# Azure environment variables and it does not change the uploaded Python script.
set -euo pipefail
: "${AZURE_OPENAI_API_KEY:?Set AZURE_OPENAI_API_KEY in the Azure execution environment}"
: "${AZURE_OPENAI_ENDPOINT:?Set AZURE_OPENAI_ENDPOINT in the Azure execution environment}"
python "/mnt/data/oriondesk_twolevel_v10_6/phase06/correction_updated_evaluator/semantic_decision_evaluator(3).py" \
  --pdf "/mnt/data/OrionDesk_AI_Detailed_Design_Specification(3).pdf" \
  --spec-dir "/mnt/data" \
  --source-lock "/mnt/data/oriondesk_twolevel_v10_6/phase06/06_evaluator_source_lock.json" \
  --queue "/mnt/data/oriondesk_twolevel_v10_6/phase06/06_llm_queue_v10.6.jsonl" \
  --out-dir "/mnt/data/oriondesk_twolevel_v10_6/phase06/correction_updated_evaluator/azure_execution_results" \
  --batch-size 8 --concurrency 4 --batch-retries 3 \
  --confidence-threshold 0.90
