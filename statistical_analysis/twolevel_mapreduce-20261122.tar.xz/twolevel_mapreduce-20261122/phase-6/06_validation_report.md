# Phase 06 — Negative Controls, Residual Review, and Exhaustive External Handoff

**Protocol:** v10.6  
**Generation method:** `twolevel`  
**Phase status:** `INCOMPLETE`  
**Scored confusion matrix:** not produced  
**External paid API calls:** 0

## Completed offline work

- Verified all eight frozen original Markdown files, the 90-page PDF, and the unchanged R/N reference digests against Phase 01.
- Examined all **142 frozen negative controls** against the full inventory of **2,183 generated-class candidates** using bidirectional retrieval for evidence candidates. The 142 controls remain *semantically pending*; lexical overlap is not proof that a counterfactual is affirmatively asserted.
- Reconciled **638 R**, **142 N**, and **2,183 G** IDs into an exhaustive unique queue: **K=C=2,963**. All 128 Phase 05 tentative nondefinitive classes are included for independent eligibility determination rather than excluded on unconfirmed heuristic grounds.
- Created **371 deterministic batches of 8** (last batch contains 3), with no total-item, total-batch, or total-request cap imposed on the selection.
- Validated original generated quotations: **4,523** original-file/line quotations; validated PDF baseline source evidence in source preparation.
- Independently checked full ID equality, item order, all boundaries, and queue SHA-256. The v10.6 evaluator's `read_queue()` accepted every row in offline `--dry-run`.
- Executed **24 filename-alias regression assertions**, all passing: exact source names, two alias directions, multiline quote, invalid line/quote, incorrect role, path rejection, ambiguous role, conflicting alias digest and changed original bytes.
- Generated **10 near-duplicate candidate pairs** and **219 N/G overlap candidate pairs** for source-grounded semantic adjudication. These are not confirmed residual FP units and no speculative semantic consolidation was counted.

## Mandatory pre-handoff issues

1. **Exact original v5 evaluator unavailable.** The accessible v5.0 script's `RESULT_SCHEMA` includes `predicate_checks`; the accessible v10.6 derivative omits it. `suggest()` AST matches exactly. `SYSTEM_PROMPT` has a batch-transport wording change, so byte-identical preservation cannot be certified. The exact named `semantic_decision_evaluator(3).py` was not available in the supplied or located materials. Under the v10.6 source-integrity rule, halt before paid handoff.
2. **Reasoning-effort disagreement.** The operator requested `low`, but v10.6 requires `medium` for external comparative evaluation. No model request was sent at either effort.
3. **Azure external execution unavailable.** `AZURE_OPENAI_API_KEY` and `AZURE_OPENAI_ENDPOINT` are absent. No batch journal or model suggestion may be invented.
4. **Source-lock structural mismatch remediated for dry-run only.** The execution derivative could not read the prior Phase 01 lock directly. A source-byte-verified `06_evaluator_source_lock.json` maps the same eight digest values and PDF identity into the executable's supported layout. Neither Phase 01 nor any source file was altered.

## Not committed and phase boundary

- No final TP, FN, FP or TN. No unsupported-generated-only residual was established as canonical FP merely by lack of lexical match; no raw GC unit was added to TP/FP.
- Identity-like and N/G overlap candidates have not been certified as semantic equivalences; they remain pending. Phase 08 must eliminate overlap only after evidence-grounded Phase 07 decisions.
- The external v5 output files `semantic_decisions.jsonl`, `semantic_summary.json`, batch journals and `run_state.json` **do not exist** for this run. A successful dry-run cannot replace them.
- Per the Phase 06 completion gate, this phase is **INCOMPLETE** until baseline evaluator incompatibility is resolved. Phase 07 was not started.

## Artifacts

| File | Description |
|---|---|
| `06_fp_controls.jsonl` | All 142 controls with original PDF evidence and strongest generated candidates; no invented FP/TN cells |
| `06_generated_residual_review.jsonl` | 2,183 generated class pending records |
| `06_residual_consolidation_candidates.jsonl` | Exact-identity residual candidate clusters; none met the strict text identity criterion |
| `06_semantic_near_duplicate_candidates.jsonl` | 10 candidate semantic duplicates, not automatically merged |
| `06_N_G_overlap_candidates.jsonl` | 219 candidate N/G overlaps, polarity unresolved |
| `06_llm_queue_v10.6.jsonl` | 2,963 original-item pending v5-compatible rows |
| `06_queue_selection.json` | Full ordered population, SHA-256, 371 fixed batch boundaries, configuration |
| `06_alias_regression_result.json` | 24 test assertions; all pass |
| `06_evaluator_policy_audit.json` | Confirmed v5.0 versus v10.6 policy/transport differences |
| `06_evaluator_source_lock.json` | Derived unchanged-source input digest adapter |
| `06_dry_run.log` | Successful offline evaluator queue parsing/batching |
| `06_independent_verification.json` | Independent ID, line, batch and candidate verification |
| `06_phase_status.json` | Explicit blockers and incomplete status |
| `prepare_phase06.py`, `verify_phase06.py`, `test_alias_regression.py` | Reproducibility scripts |

### Handoff command (not executed against Azure)

```bash
python reference_scripts/semantic_decision_evaluator_v10.6_unlimited.py \
  --pdf '/mnt/data/OrionDesk_AI_Detailed_Design_Specification(3).pdf' \
  --spec-dir /mnt/data \
  --source-lock '/mnt/data/oriondesk_twolevel_v10_6/phase06/06_evaluator_source_lock.json' \
  --queue '/mnt/data/oriondesk_twolevel_v10_6/phase06/06_llm_queue_v10.6.jsonl' \
  --out-dir '/mnt/data/oriondesk_twolevel_v10_6/phase06/06_external_run' \
  --batch-size 8 --concurrency 4 --batch-retries 3
```

**Do not run this paid command until the original evaluator contract and effort discrepancy have been resolved, and endpoint/credentials are available.** The operational code is an unmodified materialized library copy, not a claimed replacement for the specific unavailable v5 `(3)` original.
