#!/usr/bin/env python3
"""Prepare a conservative, exhaustive Phase 06 v10.6 queue without fabricating semantic verdicts.
Reads phase01..phase05 immutable records; creates source-locked R/N/G pending queue, N
reciprocal candidate audit, and provisional residual identity/overlap review inventory.
No API calls, final verdicts, or source mutation.
"""
import json, hashlib, re, math, unicodedata, collections, itertools, importlib.util
from pathlib import Path
import pymupdf
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import linear_kernel
ROOT=Path('/mnt/data')
BASE=ROOT/'oriondesk_twolevel_v10_6'
OUT=BASE/'phase06'
OUT.mkdir(exist_ok=True)
P=BASE/'phase01'/'01_source_reference_manifest.json'
METHOD='twolevel'; VERSION='10.6'; BATCH=8

def digest(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def rows(path):
    with open(path,encoding='utf-8-sig') as f:
        for line in f:
            if line.strip():yield json.loads(line)
def store(name,records):
    path=OUT/name
    with open(path,'w',encoding='utf-8') as f:
        for x in records:f.write(json.dumps(x,ensure_ascii=False,sort_keys=True)+'\n')
    return {'path':str(path),'sha256':digest(path),'size_bytes':path.stat().st_size}
def js(name,obj):
    p=OUT/name;p.write_text(json.dumps(obj,indent=2,ensure_ascii=False,sort_keys=True)+'\n',encoding='utf-8');return digest(p)
def normal(s):return ' '.join(unicodedata.normalize('NFKC',str(s)).split()).casefold()
def verified_quote(s,quote):return bool(normal(quote)) and normal(quote) in normal(s)
def canonical(s):return re.sub(r'[^a-z0-9_<>]+',' ',normal(s)).strip()

def run():
 m=json.loads(P.read_text()); manifest=m['source_roles']; paths={x['actual_filename']:ROOT/x['actual_filename'] for x in manifest}
 assert len(paths)==8
 for x in manifest:assert digest(ROOT/x['actual_filename'])==x['sha256']
 pdf=ROOT/m['authoritative_pdf']['actual_filename'];assert digest(pdf)==m['authoritative_pdf']['sha256']
 rpath=ROOT/m['frozen_positive_ledger']['actual_filename'];npath=ROOT/m['frozen_negative_ledger']['actual_filename']
 assert digest(rpath)==m['frozen_positive_ledger']['sha256']
 assert digest(npath)==m['frozen_negative_ledger']['sha256']
 with pymupdf.open(pdf) as d:
  assert len(d)==90
  pages=[p.get_text(sort=False)+'\n'+p.get_text(sort=True) for p in d]
 R=list(rows(rpath));N=list(rows(npath)); assert len(R)==638 and len(N)==142
 Rids=[x['requirement_id'] for x in R];Nids=[x['control_id'] for x in N]; assert len(set(Rids))==638 and len(set(Nids))==142
 for name,a in [('R',R),('N',N)]:
  for x in a:
   assert x['source_pdf_sha256']==digest(pdf)
   for ev in x['pdf_evidence']:
    p=ev['physical_page']; assert isinstance(p,int) and 1<=p<=90
    if ev.get('pdf_verification')=='PDF_VISUAL_INSPECTED':continue
    assert verified_quote(pages[p-1],ev['quote']), (name,x.get('requirement_id') or x.get('control_id'),p,ev['quote'][:40])
 G=list(rows(BASE/'phase05/05_generated_claim_validity.jsonl'))
 REC=list(rows(BASE/'phase05/05_recovered_atoms.jsonl'))
 GA=list(rows(BASE/'phase02/02_generated_atoms_final.jsonl'))
 GC=list(rows(BASE/'phase02/02_generated_classes_final.jsonl'))
 assert len(G)==len(GC)==2178 and len(GA)==2349 and len(REC)==7
 r_gid={x['class_id'] for x in REC if not x['merged_into_original_GC']}
 assert len(r_gid)==5 and not r_gid.intersection({x['class_id'] for x in G})
 source_lines={fn:path.read_text(encoding='utf-8-sig').splitlines() for fn,path in paths.items()}
 for g in G:
  fn=g['original_source_file']; lo=g['original_line_start'];hi=g['original_line_end']
  assert 1<=lo<=hi<=len(source_lines[fn]); assert g['original_source_sha256']==digest(paths[fn]); assert verified_quote('\n'.join(source_lines[fn][lo-1:hi]),g['original_line_quote_en'])
 for g in REC:
  fn=g['source_file']; lo=g['line_start'];hi=g['line_end']
  assert 1<=lo<=hi<=len(source_lines[fn]); assert g['source_sha256']==digest(paths[fn]);assert verified_quote('\n'.join(source_lines[fn][lo-1:hi]),g['original_full_line_en'])
 active=[]
 for g in G:
  active.append({'class_id':g['class_id'],'statement_en':g['complete_claim_en'],'file':g['original_source_file'],
  'line_start':g['original_line_start'],'line_end':g['original_line_end'],
  'quote_en':g['original_line_quote_en'],'sha256':g['original_source_sha256'],
  'eligibility_prior':g['eligibility_reassessment'],'linked_R_candidates':g.get('linked_R_candidates',[]),
  'pdf_hints':g.get('pdf_evidence_candidates',[]),'original_class_count':g['class_occurrences'],
  'representative_gen_id':g['representative_gen_id']})
 for g in REC:
  if g['merged_into_original_GC']:continue
  active.append({'class_id':g['class_id'],'statement_en':g['complete_claim_en'],'file':g['source_file'],
  'line_start':g['line_start'],'line_end':g['line_end'],'quote_en':g['original_full_line_en'],
  'sha256':g['source_sha256'],'eligibility_prior':g['eligibility'],
  'linked_R_candidates':[], 'pdf_hints':g.get('pdf_evidence_candidates',[]),
  'original_class_count':1,'representative_gen_id':g['gen_id']})
 assert len(active)==2183 and len({x['class_id'] for x in active})==2183
 # Unique deterministic file/line order for effective GC; class-ID breaks ties.
 rank={x['actual_filename']:x['ordinal'] for x in manifest}
 active.sort(key=lambda x:(rank[x['file']],x['line_start'],x['line_end'],x['class_id']))

 # Every N is examined against every generated class; TF-IDF is candidate retrieval only.
 # A generated prohibition of a control is NOT an affirmation of the forbidden statement.
 docs=[x['statement_en'] for x in active]
 n_docs=[x['counterfactual_en'] for x in N]
 v=TfidfVectorizer(lowercase=True,stop_words='english',ngram_range=(1,2),min_df=1,sublinear_tf=True)
 mat=v.fit_transform(docs+n_docs)
 match=linear_kernel(mat[len(docs):],mat[:len(docs)]).astype('float32')
 fp_controls=[]
 for i,n in enumerate(N):
  idx=sorted(range(len(active)), key=lambda j:(-float(match[i,j]),j))[:8]
  negator=re.compile(r'\b(?:no|not|never|cannot|must not|prohibit(?:ed|s|ion)?|exclude(?:d|s)?|defer(?:red)?)\b',re.I)
  cand=[]
  for j in idx:
   g=active[j]
   cand.append({'class_id':g['class_id'],'generated_statement_en':g['statement_en'],
    'filename':g['file'],'line_start':g['line_start'],'line_end':g['line_end'],
    'generated_quote_en':g['quote_en'],'generated_sha256':g['sha256'],
    'lexical_similarity_diagnostic':round(float(match[i,j]),6),
    'polarity_risk':'NEGATION_PRESENT_CHECK_AFFIRMATION' if negator.search(g['statement_en']) else 'POLARITY_NOT_RESOLVED',
    'is_semantic_affirmation':'NOT_ADJUDICATED'})
  fp_controls.append({'record_type':'NEGATIVE_CONTROL_RECIPROCAL_REVIEW', 'protocol_version':VERSION,
   'method':METHOD, 'control_id':n['control_id'],'counterfactual_en':n['counterfactual_en'],
   'source_pdf_sha256':n['source_pdf_sha256'], 'pdf_evidence':n['pdf_evidence'],
   'all_effective_generated_classes_searched':len(active), 'top_candidates':cand,
   'affirmative_counterfactual_final':'NOT_COMMITTED_PENDING_EXTERNAL_AND_PHASE07',
   'conclusion_rule_en':'Only a definitive affirmative assertion of the prohibited counterfactual is FP; prohibition is not assertion. Lexical matches are not semantic judgments.'})
 saved_controls=store('06_fp_controls.jsonl',fp_controls)

 # No unsupported-only class has source-grounded FP evidence yet. Deduplicate
 # provisional candidate strings by identity only; no FP is counted.
 grouped=collections.defaultdict(list)
 for x in active:grouped[canonical(x['statement_en'])].append(x)
 multi=[c for c in grouped.values() if len(c)>1]
 candidate_dedup=[]
 for g in multi:
  candidate_dedup.append({'record_type':'POTENTIAL_IDENTITY_RESIDUAL_DUPLICATE','class_ids':[x['class_id'] for x in g],
   'statements_en':[x['statement_en'] for x in g],
   'identity_normalization_only':True,'final_pdf_unsupportedness':'NOT_ADJUDICATED',
   'merge_for_canonical_FP':'PENDING_PHASE07_08_SEMANTIC_REVIEW'})
 saved_dupes=store('06_residual_consolidation_candidates.jsonl',candidate_dedup)
 pending_candidates=[]
 for x in active:
  pending_candidates.append({'record_type':'GENERATED_RESIDUAL_REVIEW','class_id':x['class_id'],
   'original_filename':x['file'],'line_start':x['line_start'],'line_end':x['line_end'],
   'complete_claim_en':x['statement_en'],'previous_eligibility_assessment':x['eligibility_prior'],
   'candidate_pdf_support_count':len(x['pdf_hints']),
   'candidate_R_links':x['linked_R_candidates'],
   'pdf_entailment':'PENDING','unsupported_residual':'PENDING','overlaps_frozen_N':'PENDING',
   'canonical_FP_counted':False})
 saved_residual=store('06_generated_residual_review.jsonl',pending_candidates)

 audits={x['requirement_id']:x for x in rows(BASE/'phase04/04_coverage_audit.jsonl')}
 assert set(audits)==set(Rids)
 queue=[]
 for x in R:
  a=audits[x['requirement_id']]; ged=[]
  for c in a.get('verified_phase03_candidate_quotes',[])[:3]:
   o=c.get('original') or {}
   if o.get('literal_quote_verified'):
    ged.append({'file':o['actual_file'],'line_start':o['line_start'],
     'line_end':o['line_end'],'quote_en':o['original_line_quote_en'],
     'source_sha256':o['original_sha256'],'evidence_kind':'SEARCH_CANDIDATE_NOT_PROOF'})
  for b in a.get('verified_contextual_bridge_audits',[])[:2]:
   # Provenance already separately available by source ID; avoid invented quotes.
   pass
  queue.append({'record_type':'UNRELIABLE_ITEM','item_id':x['requirement_id'],'direction':'R',
   'current_cell':'FN','statement_en':x['statement_en'],'spec_name':'All eight original generated specifications',
   'unreliable':True,'pdf_evidence_hints':[{'physical_page':q['physical_page'],'quote_en':q.get('quote') or q.get('visible_text') or q.get('visual_locator',''), 'verification':q.get('pdf_verification','PDF_TEXT_EXACT')} for q in x['pdf_evidence']],
   'generated_evidence':ged,'phase04_provisional_grade':a['phase04_evidence_grade'],
   'source_pdf_sha256':x['source_pdf_sha256'],'reason_pending_en':'Phase04 evidence grade is provisional, not an accepted final TP/FN.'})
 for i,x in enumerate(N):
  ev=fp_controls[i]['top_candidates']
  queue.append({'record_type':'UNRELIABLE_ITEM','item_id':x['control_id'],'direction':'N',
   'current_cell':'TN','statement_en':x['counterfactual_en'],'spec_name':'All eight original generated specifications',
   'unreliable':True,'pdf_evidence_hints':[{'physical_page':q['physical_page'],'quote_en':q.get('quote') or q.get('visible_text') or q.get('visual_locator',''), 'verification':q.get('pdf_verification','PDF_TEXT_EXACT')} for q in x['pdf_evidence']],
   'generated_evidence':[{'file':c['filename'],'line_start':c['line_start'],'line_end':c['line_end'],
   'quote_en':c['generated_quote_en'],'source_sha256':c['generated_sha256'],
   'evidence_kind':'POSSIBLE_ASSERTION_CHECK_POLARITY'} for c in ev[:3]],
   'source_pdf_sha256':x['source_pdf_sha256'],'reason_pending_en':'No final affirmative-counterfactual decision independently accepted.'})
 for x in active:
  hints=[]
  for q in x['pdf_hints'][:3]:
   if q.get('pdf_quote_verified') or q.get('pdf_match_not_entailment'):
    hints.append({'physical_page':q.get('physical_page'), 'quote_en':q.get('quote_en')})
  queue.append({'record_type':'UNRELIABLE_ITEM','item_id':x['class_id'],'direction':'G',
   'current_cell':'FP','statement_en':x['statement_en'],'spec_name':x['file'],'unreliable':True,
   'pdf_evidence_hints':hints,'generated_evidence':[{'file':x['file'],'line_start':x['line_start'],'line_end':x['line_end'],
    'quote_en':x['quote_en'],'source_sha256':x['sha256'],'evidence_kind':'ORIGINAL_CLAIM'}],
   'phase05_previous_eligibility':x['eligibility_prior'],
   'reason_pending_en':'Both claim eligibility and PDF entailment are not independently finalized; no provisional FP is scored.'})
 assert len(queue)==638+142+2183
 assert len({q['item_id'] for q in queue})==len(queue)
 saved_queue=store('06_llm_queue_v10.6.jsonl',queue)
 batch_bounds=[]
 for i in range(0,len(queue),BATCH):
  block=queue[i:i+BATCH]
  batch_bounds.append({'batch_id':f'B10.6-{i//BATCH+1:05d}','batch_index':i//BATCH,
     'queue_start_index':i,'queue_end_index_exclusive':i+len(block),'batch_size':len(block),
     'first_item_id':block[0]['item_id'],'last_item_id':block[-1]['item_id'],
     'item_ids':[x['item_id'] for x in block]})
 assert len(batch_bounds)==math.ceil(len(queue)/BATCH)
 assert all(x['batch_size']==BATCH for x in batch_bounds[:-1])
 hist=dict(collections.Counter(x['eligibility_prior'] for x in active))
 selection={'record_type':'PHASE_06_QUEUE_SELECTION','protocol_version':VERSION,'method':METHOD,
  'phase':'06','status':'HANDOFF_PREPARED_EXTERNAL_EXECUTION_NOT_PERFORMED',
  'source_pdf_sha256':digest(pdf),'positive_ledger_sha256':digest(rpath),
  'negative_ledger_sha256':digest(npath),'source_lock_sha256':digest(BASE/'phase01/01_reference_lock.json'),
  'queue_sha256':saved_queue['sha256'],'R_total':len(R),'N_total':len(N),
  'GO_original':len(GA),'GO_recovered':len(REC),'GC_original':len(GC),
  'GC_recovered_distinct':len(r_gid),'GC_effective_pending_eligibility_and_validity':len(active),
  'pre_phase07_resolved_ids_count':0,
  'pending_population_C':len(queue),'queued_K':len(queue),'assert_K_equals_C':True,
  'queue_includes_128_prior_nondefinitive_classifications_for_independent_eligibility_check':True,
  'G_prior_eligibility_histogram':hist,
  'ordered_item_ids':[x['item_id'] for x in queue],
  'omitted_due_to_numerical_limit':0,'selected_batch_size':BATCH,
  'batch_count':len(batch_bounds),'batch_boundaries':batch_bounds,
  'protocol_external_model':'gpt-6.1-sol','protocol_external_reasoning_effort':'medium',
  'operator_requested_reasoning_effort':'low','effort_policy_discrepancy':'UNRESOLVED_FOR_CROSS_METHOD_COMPARABILITY',
  'concurrency':4,'additional_batch_retries':3,'actual_external_submissions':0,
  'external_execution_completed':False,'estimated_maximum_submissions_if_all_retried':4*len(batch_bounds),
  'source_roles':[{'role':x['role'],'file':x['actual_filename'],'sha256':x['sha256']} for x in manifest],
  'notes_en':['All R/N and every original or distinct recovered GC are queued because no Phase07-quality accepted final semantic cell exists.',
   '128 previously tagged nondefinitive generated classes remain queued to avoid excluding possibly eligible claims without independent verification.',
   'Conservative identity-similarity residual clusters are diagnostics, not accepted FP or a semantic deduplication proof.',
   'Offline evaluator dry-run and alias unit testing are separate required checks.']}
 sel_hash=js('06_queue_selection.json',selection)
 artifacts={'06_fp_controls.jsonl':saved_controls,'06_residual_consolidation_candidates.jsonl':saved_dupes,
  '06_generated_residual_review.jsonl':saved_residual,'06_llm_queue_v10.6.jsonl':saved_queue,
  '06_queue_selection.json':{'sha256':sel_hash}}
 validation={'record_type':'PHASE_06_POPULATION_VALIDATION','protocol_version':VERSION,'method':METHOD,
  'immutable_inputs_verified':True,'R_count':len(R),'N_count':len(N),'GO_original':len(GA),
  'GO_recovered':len(REC),'GC_effective':len(active),'N_rows_audited':len(fp_controls),
  'every_N_scanned_against_all_GC':True,'unadjudicated_n_affirmations':len(N),
  'G_previous_eligibility_histogram':hist,'identity_duplicate_candidate_clusters':len(multi),
  'identity_duplicate_candidate_class_mentions':sum(len(x) for x in multi),
  'verified_pdf_R_N_quotes':True,'verified_original_generated_quotes':True,
  'canonical_FP_claims_finalized':0,'FP_count':'NOT_COMMITTED',
  'queue_total':len(queue),'batch_size':BATCH,'batch_count':len(batch_bounds),
  'K_equals_C':True,'no_numerical_truncation':True,
  'artifacts':artifacts}
 js('06_population_validation.json',validation)
 print(json.dumps({k:v for k,v in validation.items() if k not in ('artifacts','G_previous_eligibility_histogram')},indent=2))
if __name__=='__main__':run()
