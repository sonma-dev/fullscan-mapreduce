# Phase 07 — Shard 2 (Twolevel, v10.6)

**Status: SHARD2_COMPLETED (not whole Phase07).**

## Split contract

The original 2,963 external item IDs are stratified by `R`, `N` and `G` in original frozen order. One-based odd positions go to Shard1, even positions to Shard2. This creates **1,481** Shard2 items (319 R + 71 N + 1,091 G), with **1,482** previously assigned to Shard1. No ID overlaps or disappears. Full 90-page PDF and all eight Markdown originals were accessible for each shard review; source bytes and v5 Azure journal files were not changed.

## Shard2 item results

| Category | Count |
|---|---:|
| R TP | 292 |
| R FN | 27 |
| N FP | 0 |
| N TN | 71 |
| G PDF supported (diagnostic TP) | 916 |
| G PDF unsupported (diagnostic FP) | 26 |
| G nondefinitive excluded | 149 |
| Eligible semantic null | 0 |

**Existing external unresolved proposals in Shard2:** 151 (R=31, N=71, G=49). These have Shard2 source-grounded dispositions; the old v5 statuses remain immutable.

## Evidence procedures

- Original PDF sha256: `b71541e74564559d2cc0a84e9827086946998fbc6c627488fb9e7a7f9b0137c3`; original 90 physical pages reopened and examined through PyMuPDF text locators.
- All eight original Markdown roles SHA-256 verified against the external evaluation run; every carried source citation was checked against the original file and exact line span.
- 186 of 186 committed external batch journals confirmed with recorded payload SHA-256 and item identity.
- PDF nonempty exact quotation checks: 2956; generated original line quotation checks: 3501; visual-only PDF locators: 7.
- Full original Markdown line inventory was indexed for reciprocal top-candidate inspection on each of the 1,481 items. Retrieval scores were not accepted as semantic decisions.
- Frozen R/N and the source PDF were not altered; four prior Phase07 supersessions are preserved as historical evidence.

## Review provenance and limits

The Phase07 Shard2 source/quote verification and reciprocal line inspection were run anew on all 1,481 items. Prior gpt-6.2-sol `high` v5 results and the older assistant Phase07 determinations were consulted as **historical candidate evidence**, and this reliance is disclosed item by item. No second Azure call was made, no model response was fabricated, and no claim of a completely independent second-model audit is made. Decisions were not auto-generated from v5 low confidence or `UNRESOLVED` alone.

This shard does NOT provide a final full-population TP/FP/FN/TN score. Shard1 has already run separately against the full originals. Phase07 merged outcome needs a cross-shard semantic equivalence/contradiction check before Phase08 or Phase09 computations.
