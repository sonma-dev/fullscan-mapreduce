#!/usr/bin/env python3
"""Independent structural and provenance validation for Phase 07 Shard 2.

Does not claim independent new LLM semantic judgments or run Phase 08/09.
Checks the entire original PDF and eight original Markdown texts, cross-shard
assignment, immutable external record, and every Shard 2 original quote.
"""
from pathlib import Path
from collections import Counter
import hashlib,json,unicodedata
import fitz
ROOT=Path('/mnt/data')
D2=ROOT/'OrionDesk_twolevel_v10.6_Phase07_Shard2'
D1=ROOT/'OrionDesk_twolevel_v10.6_Phase07_Shard1'
PDF=ROOT/'OrionDesk_AI_Detailed_Design_Specification(3).pdf'
FILES=['01_screen_functions(3).md','02_api(3).md','03_data(3).md','04_batch_functions(4).md','05_business_rules(3).md','06_exception_handling(5).md','07_processing_flows(5).md','08_architecture_decision(4).md']
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def norm(s):return ' '.join(unicodedata.normalize('NFKC',str(s)).split()).casefold()
def rows(p):return [json.loads(s) for s in Path(p).open(encoding='utf-8-sig') if s.strip()]
def yes(cond,msg):
 if not cond:raise AssertionError(msg)
s=json.loads((D2/'07_shard2_summary.json').read_text());manifest=json.loads((D2/'07_shard2_manifest.json').read_text())
assign=rows(D2/'07_shard2_assignments.jsonl')
d2=rows(D2/'07_shard2_adjudications.jsonl')
audit=rows(D2/'07_shard2_decision_audit.jsonl')
ext=rows(ROOT/'semantic_decisions.jsonl')
d1=rows(D1/'07_shard1_adjudications.jsonl')
a1=rows(D1/'07_shard1_assignments.jsonl')
yes(len(assign)==2963 and len(ext)==2963,'Whole queue assignment count invalid')
yes(len(d2)==len(audit)==1481,'Shard2 output count invalid')
yes(len(d1)==1482,'Shard1 earlier output count invalid')
yes(assign==a1,'Shard1/Shard2 assignments do not agree')
yes([x['item_id'] for x in assign]==[x['item_id'] for x in ext],'External result/assignment order differs')
yes(len({x['item_id'] for x in assign})==2963,'Duplicate assigned item ID')
D2_ids={x['item_id'] for x in d2};D1_ids={x['item_id'] for x in d1}
yes(len(D1_ids)==1482 and len(D2_ids)==1481 and not D1_ids & D2_ids,'Shard overlap or intra-shard duplicate')
yes(D1_ids|D2_ids=={x['item_id'] for x in ext},'Shard coverage incomplete')
selected=[x for x in assign if x['shard_id']=='S2']
yes([x['item_id'] for x in selected]==[x['item_id'] for x in d2]==[x['item_id'] for x in audit],'Shard2 order mismatched')
for direction in ('R','N','G'):
 items=[x for x in assign if x['direction']==direction]
 for pos,x in enumerate(items,1):
  yes(x['position_within_direction_one_based']==pos,'Changed within-direction position')
  yes(x['shard_id']==('S1' if pos%2==1 else 'S2'),'Incorrect parity partition')
with fitz.open(PDF) as doc:
 yes(len(doc)==90,'Incorrect PDF page count')
 pages=[p.get_text(sort=False)+'\n'+p.get_text(sort=True) for p in doc]
files={f:{'lines':(ROOT/f).read_text(encoding='utf-8-sig').splitlines(),'sha256':sha(ROOT/f)} for f in FILES}
yes(s['pdf_sha256']==sha(PDF),'Original PDF identity changed')
yes(s['source_markdown_role_sha256']=={f:files[f]['sha256'] for f in FILES},'Original Markdown SHA values changed')
yes(s['external_semantic_decisions_sha256']==sha(ROOT/'semantic_decisions.jsonl'),'External result SHA mismatch')
yes(s['batch_journals_sha256']==sha(ROOT/'batch_journals.zip'),'External batch archive SHA mismatch')
yes(s['shard1_results_sha256']==sha(D1/'07_shard1_adjudications.jsonl'),'Shard1 file changed')
yes(s['historical_phase07_active_sha256']==sha(ROOT/'recovered_prior/07_active_adjudications_after_supersession.jsonl'),'Historical source changed')
yes(s['R_sha256']==sha(ROOT/'common_atomic_reqs(3).jsonl') and s['N_sha256']==sha(ROOT/'common_negative_controls(3).jsonl'),'Frozen R/N altered')
yes(all(sha(D2/name)==meta['sha256'] for name,meta in manifest['files'].items()),'Manifest disagrees with Shard2 data')
ext_by_id={x['item_id']:x for x in ext}
historical={x['item_id']:x for x in rows(ROOT/'recovered_prior/07_active_adjudications_after_supersession.jsonl')}
yes(len(historical)==2963,'Historical active decision count invalid')
checks=Counter();C=Counter();reason_count=Counter();changed=0;unresolved=Counter()
for item,a in zip(d2,audit):
 id=item['item_id'];direction=item['direction'];cell=item['final_cell']
 yes(a['item_id']==id and a['direction']==direction,'Decision/audit mismatch')
 yes(item['record_type']=='ASSISTANT_ADJUDICATION' and item['shard_id']=='S2','Invalid Shard2 record type/ID')
 yes(item['decision_origin']=='PHASE07_SHARD2_ASSISTANT' and item['method']=='twolevel','Wrong method or decision origin')
 yes(item['external_evaluation_model']=='gpt-6.2-sol' and item['external_evaluation_reasoning_effort']=='high','Incorrect external evaluation model or effort')
 yes(item['protocol_version']=='10.6' and item['source_reference_unchanged'] is True,'Protocol or reference changed')
 yes(item['original_pdf_sha256']==sha(PDF),'Per-item source PDF hash wrong')
 yes(item['original_markdown_sha256']==s['source_markdown_role_sha256'],'Per-item spec hashes differ')
 yes(item['external_queue_sha256']==s['external_queue_sha256'],'Per-item queue identity changed')
 yes(item['prior_v5_suggested_decision']==ext_by_id[id]['suggested_decision'],'v5 suggestion corrupted')
 yes(item['prior_v5_decision_status']==ext_by_id[id]['decision_status'],'v5 uncertainty status corrupted')
 yes(bool(item['decision_reason_en']) and bool(item['source_statement_en']),'Missing statement or reason')
 yes(item['pdf_evidence'] and item['generated_evidence'] and item['examined_original_line_candidates'],'Missing original source and reciprocal evidence')
 if direction=='R':yes(item['eligible'] and cell in ('TP','FN'),'Invalid R result')
 elif direction=='N':yes(item['eligible'] and cell in ('FP','TN'),'Invalid N result')
 else:
  if item['eligible']:yes(cell in ('TP','FP'),'Invalid eligible G label')
  else:yes(cell is None and item['canonical_counting_scope']=='NOT_ELIGIBLE_EXCLUDED','Invalid excluded G label')
 if item['eligible'] and cell in ('FN','FP') and direction in ('R','G'):
  yes(bool(item['unmet_predicates_en']),'No unmet-predicate explanation')
 old=historical[id]
 yes(old['direction']==direction and old['final_cell']==item['historical_pre_shard_cell'],'Historical item not faithfully linked')
 yes(item['historical_pre_shard_row_sha256']==hashlib.sha256(json.dumps(old,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest(),'Historical item digest mismatch')
 if cell!=item['historical_pre_shard_cell']:changed+=1
 for e in item['pdf_evidence']:
  pg=e['physical_page'];yes(type(pg) is int and 1<=pg<=90,'Bad PDF page')
  yes(e['source_pdf_sha256']==s['pdf_sha256'],'PDF quote source digest mismatch')
  if e['quote_en']:
   yes(norm(e['quote_en']) in norm(pages[pg-1]),'False source PDF quote '+id)
   checks['PDF_EXACT']+=1
  else:
   yes(e['visual_locator_only'],'Unverified non-visual PDF locator')
   checks['PDF_VISUAL_ONLY']+=1
 for e in item['generated_evidence']:
  f=e['file']; lo=e['line_start']; hi=e['line_end']
  yes(f in files and 1<=lo<=hi<=len(files[f]['lines']),'Wrong original Markdown line')
  yes(e['source_sha256']==files[f]['sha256'],'Wrong original Markdown SHA')
  yes(norm(e['quote_en']) in norm('\n'.join(files[f]['lines'][lo-1:hi])),'Fabricated original Markdown quote '+id)
  checks['MARKDOWN_EXACT']+=1
 for e in item['examined_original_line_candidates']:
  f=e['source_file'];lo=e['line_start']; hi=e['line_end']
  yes(f in files and 1<=lo<=hi<=len(files[f]['lines']),'Invalid reciprocal candidate source')
  yes(e['original_source_sha256']==files[f]['sha256'],'Wrong reciprocal candidate source SHA')
  yes(norm(e['source_quote_en']) in norm('\n'.join(files[f]['lines'][lo-1:hi])),'Fabricated reciprocal original quote '+id)
  checks['RECIPROCAL_ORIGINAL_LINES']+=1
 C[(direction,str(cell))]+=1;reason_count[item['adjudication_basis']]+=1
 if ext_by_id[id]['decision_status']=='UNRESOLVED':unresolved[direction]+=1
yes(C==Counter({('R','TP'):292,('R','FN'):27,('N','TN'):71,('G','TP'):916,('G','FP'):26,('G','None'):149}),'Unexpected category results')
yes(changed==s['shard2_decisions_differing_from_historical_count']==0,'Shards diverged from disclosed historical reuse')
yes(sum(unresolved.values())==s['external_unresolved_selected']==151,'Missing formerly unresolved input')
yes(dict(unresolved)==s['external_unresolved_by_direction'],'Unresolved direction counts incorrect')
yes(not (D2/'07_shard2_input_blockers.jsonl').read_text().strip(),'Undisclosed blocking errors exist')
yes(s['eligible_null_count']==0,'Eligible unresolved item remains')
yes(s['original_pdf_exact_quote_checks']==checks['PDF_EXACT'] and s['original_markdown_exact_quote_checks']==checks['MARKDOWN_EXACT'],'Summary original source checks inconsistent')
yes(s['visual_only_locators']==checks['PDF_VISUAL_ONLY'],'Visual evidence count inconsistent')
result={'record_type':'PHASE07_SHARD2_INDEPENDENT_STRUCTURAL_VALIDATION','status':'PASS','shard_id':'S2',
 'evaluated_items':len(d2),'assigned_global_items':len(assign),'other_shard_items_completed':len(d1),
 'shard_id_overlap_count':len(D1_ids&D2_ids),'shard_unassigned_item_count':2963-len(D1_ids|D2_ids),
 'external_previously_unresolved_reviewed':sum(unresolved.values()),'evidence_rechecks':dict(checks),
 'shard_cells':{f'{k[0]}:{k[1]}':n for k,n in sorted(C.items())},'decision_basis_counts':dict(reason_count),
 'historical_labels_changed':changed,'all_shard2_eligible_decisions_classified':True,
 'semantic_entailment_beyond_original_quote_verification':'Not mechanically certifiable. Historical Phase07 item classifications were used as recorded candidate decisions and no new independent Azure inference took place.',
 'original_phase07_unchanged':True,'original_shard1_unchanged':True,
 'global_cross_shard_semantic_reconciliation_not_executed':True,
 'phase08_not_executed':True,'phase09_metrics_not_computed':True}
(D2/'07_shard2_independent_validation.json').write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
print(json.dumps(result,indent=2,ensure_ascii=False))
