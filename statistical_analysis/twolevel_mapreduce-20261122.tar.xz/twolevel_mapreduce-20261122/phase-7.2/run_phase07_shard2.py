#!/usr/bin/env python3
"""Phase07 Shard 2, twolevel v10.6, high-effort gpt-6.2-sol external record.

The full 90-page PDF and eight original Markdown sources are checked independently;
external v5 judgments and previously recorded assistant adjudication are immutable
historical evidence, never newly invented calls.  Partition: every odd-position
item within each ordered R/N/G population, with one-based indices.
No Shard1 results are changed.  No Phase08/09 scores are computed.
"""
import collections
import hashlib
import json
import os
import re
import sys
import unicodedata
import zipfile
from datetime import datetime, timezone
from pathlib import Path

import fitz
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import linear_kernel

ROOT=Path('/mnt/data')
INPUT=ROOT/'recovered_prior'
OUT=ROOT/'OrionDesk_twolevel_v10.6_Phase07_Shard2'
FILES=[
 '01_screen_functions(3).md','02_api(3).md','03_data(3).md','04_batch_functions(4).md',
 '05_business_rules(3).md','06_exception_handling(5).md','07_processing_flows(5).md','08_architecture_decision(4).md']
PDF=ROOT/'OrionDesk_AI_Detailed_Design_Specification(3).pdf'
ORIG=INPUT/'07_assistant_adjudications.jsonl'
ACTIVE=INPUT/'07_active_adjudications_after_supersession.jsonl'
SUP=INPUT/'07_superseding_adjudications.jsonl'
EXTERNAL=ROOT/'semantic_decisions.jsonl'
STATE=ROOT/'run_state.json'
SUMMARY=ROOT/'semantic_summary.json'
JOURNALS=ROOT/'batch_journals.zip'
RFILE=ROOT/'common_atomic_reqs(3).jsonl'
NFILE=ROOT/'common_negative_controls(3).jsonl'
FREEZE=ROOT/'reference_freeze(3).json'
CODES={'R':{'TP':'P7-R-TP','FN':'P7-R-FN'},'N':{'TN':'P7-N-TN','FP':'P7-N-FP'},'G':{'TP':'P7-G-SUPPORTED','FP':'P7-G-UNSUPPORTED'}}
SHARD_ID='S2'; METHOD='twolevel'; PROTOCOL='10.6'; MODEL='gpt-6.2-sol'; EFFORT='high'


def sha(path):
 h=hashlib.sha256()
 with Path(path).open('rb') as f:
  for blk in iter(lambda:f.read(1<<20),b''):h.update(blk)
 return h.hexdigest()

def rows(path):
 with Path(path).open(encoding='utf-8-sig') as f: return [json.loads(x) for x in f if x.strip()]

def norm(s):return ' '.join(unicodedata.normalize('NFKC',str(s)).split()).casefold()

def canonical(x):return json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':'))

def jhash(x):return hashlib.sha256(canonical(x).encode()).hexdigest()

def write_json(path,x):Path(path).write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n',encoding='utf8')

def write_jsonl(path,x):
 with Path(path).open('w',encoding='utf-8') as f:
  for item in x:f.write(canonical(item)+'\n')

def check(v,reason):
 if not v:raise ValueError(reason)

def role_file(value):
 value=Path(value).name
 for fn in FILES:
  base=re.sub(r'\(\d+\)(?=\.md$)','',fn)
  if re.fullmatch(re.escape(base[:-3])+r'(?:\([1-9]\d*\))?\.md',value):return fn
 return None


def main():
 OUT.mkdir(exist_ok=True)
 pdf_hash=sha(PDF)
 active_hash=sha(ACTIVE)
 src=json.loads(FREEZE.read_text()); st=json.loads(STATE.read_text());su=json.loads(SUMMARY.read_text())
 check(st['protocol_version']=='10.6' and su['status']=='COMPLETE' and su['remaining_items']==0,'External evaluation incomplete')
 check(st['model']==MODEL and st['item_count']==2963 and st['batch_size']==16,'External model/queue mismatch')
 check(pdf_hash==src['source_document']['sha256']==st['pdf_sha256'],'Frozen PDF sha changed')
 check(sha(RFILE)==src['output_artifacts_sha256']['common_atomic_reqs.jsonl'],'Frozen R changed')
 check(sha(NFILE)==src['output_artifacts_sha256']['common_negative_controls.jsonl'],'Frozen N changed')
 spec={fn:{'lines':(ROOT/fn).read_text(encoding='utf-8-sig').splitlines(),'sha256':sha(ROOT/fn)} for fn in FILES}
 actual_sha={re.sub(r'\(\d+\)(?=\.md$)','',fn):spec[fn]['sha256'] for fn in FILES}
 check(all(st['file_sha256'].get(k)==v for k,v in actual_sha.items()),'Original Markdown role hash mismatch')
 with fitz.open(PDF) as doc:
  check(len(doc)==90,'PDF page count mismatch')
  pages=[p.get_text(sort=False)+'\n'+p.get_text(sort=True) for p in doc]
 D=rows(EXTERNAL);R=rows(RFILE);N=rows(NFILE)
 check(len(R)==638 and len(N)==142 and len(D)==2963,'Population count mismatch')
 original=rows(ORIG);active=rows(ACTIVE);supersessions=rows(SUP)
 check(len(original)==len(active)==len(D)==2963,'Historical record count mismatch')
 hist={x['item_id']:x for x in active}
 check(len(hist)==2963,'Historical adjudication duplicate IDs')
 original_map={x['item_id']:x for x in original}
 check(set(hist)==set(original_map)=={x['item_id'] for x in D},'Historical/queue ID population differs')
 check(len(supersessions)==4 and sha(ORIG)=='24e624d8e122b5c0283c3032716ea4d0711c271548997608884042afd4369718','Historic Phase07 supersession identity incompatible')
 refR={x['requirement_id']:x for x in R};refN={x['control_id']:x for x in N}
 check(len(refR)==638 and len(refN)==142,'Frozen R/N duplicate ids')
 by_dir={k:[x for x in D if x['direction']==k] for k in ('R','N','G')}
 check([x['item_id'] for x in by_dir['R']]==list(refR),'R order not frozen ledger order')
 check([x['item_id'] for x in by_dir['N']]==list(refN),'N order not frozen ledger order')
 for dir,groups in by_dir.items():check(len({x['item_id'] for x in groups})==len(groups),'Duplicate '+dir)
 queue_positions={x['item_id']:i+1 for i,x in enumerate(D)}
 assignments=[];sel=[];remaining=[]
 for direction in ('R','N','G'):
  for idx,item in enumerate(by_dir[direction]):
   assignment={'record_type':'PHASE07_TWO_SHARD_ASSIGNMENT','protocol_version':PROTOCOL,
    'method':METHOD,'item_id':item['item_id'],'direction':direction,
    'position_within_direction_one_based':idx+1,
    'shard_id':('S1' if idx%2==0 else 'S2'),'original_queue_position_one_based':queue_positions[item['item_id']]}
   assignments.append(assignment)
   (sel if idx%2==1 else remaining).append(item)
 check(len(sel)==1481 and len(remaining)==1482,'Invalid two-shard split')

 prior_dir=ROOT/'OrionDesk_twolevel_v10.6_Phase07_Shard1'
 prior_summary=json.loads((prior_dir/'07_shard1_summary.json').read_text())
 prior_validation=json.loads((prior_dir/'07_shard1_independent_validation.json').read_text())
 prior_assignments=rows(prior_dir/'07_shard1_assignments.jsonl')
 prior_ids={x['item_id'] for x in rows(prior_dir/'07_shard1_adjudications.jsonl')}
 check(prior_summary['status']=='SHARD1_COMPLETED' and prior_validation['status']=='PASS','Previous Shard1 not verified as complete')
 check(prior_summary['source_R']==638 and prior_summary['source_N']==142 and prior_summary['source_G_candidates']==2183,'Previous shard reference differs')
 check(prior_summary['pdf_sha256']==pdf_hash and prior_summary['historical_phase07_active_sha256']==active_hash,'Previous shard original reference differs')
 check(prior_assignments==assignments,'Shard 1/2 assignment drift')
 check(prior_ids=={x['item_id'] for x in remaining} and not prior_ids.intersection(x['item_id'] for x in sel),'Shard1/Shard2 overlap or gap')
 prior_manifest=json.loads((prior_dir/'07_shard1_manifest.json').read_text())
 for name,meta in prior_manifest['files'].items():
  check(sha(prior_dir/name)==meta['sha256'],'Previous Shard1 artifact changed: '+name)

 check(collections.Counter(x['direction'] for x in sel)=={'R':319,'N':71,'G':1091},'Shard2 stratum counts mismatch')
 check(not {x['item_id'] for x in sel}&{x['item_id'] for x in remaining},'Shard overlap')
 check(set(x['item_id'] for x in sel)|set(x['item_id'] for x in remaining)==set(hist),'Missing shard IDs')
 # Validate all 186 committed journals: their identities and content hashes. Never
 # generate synthetic model results or replay a request.
 journals=0
 with zipfile.ZipFile(JOURNALS) as z:
  check(z.testzip() is None,'ZIP journal corrupted')
  journal_names=[x for x in z.namelist() if re.fullmatch(r'batch_journals/B10\.6-\d{5}\.json',x)]
  check(len(journal_names)==186,'Unexpected batch journal count')
  for b in range(186):
   name=f'batch_journals/B10.6-{b+1:05d}.json'
   check(name in journal_names,'Missing journal '+name)
   j=json.loads(z.read(name))
   chunk=D[b*16:(b+1)*16]
   check(j['batch_id']==f'B10.6-{b+1:05d}' and j['batch_size']==len(chunk),'Journal batch mismatch')
   check(j['pdf_sha256']==pdf_hash and j['queue_sha256']==st['queue_sha256'],'Journal source/queue hash mismatch')
   check(j['content_sha256']==jhash({'raw_model_json':j['raw_model_json'],'item_records':j['item_records']}),'Journal content digest mismatch')
   check([q['item_id'] for q in j['item_records']]==[q['item_id'] for q in chunk],'Journal IDs mismatch')
   for ref,rec in zip(chunk,j['item_records']):check(ref==rec,'External LLM decision altered after commit')
   journals+=1
 # Full-corpus candidate retrieval over original Markdown lines, not just model
 # snippets. This supplies explicit reciprocal challenges on absence decisions.
 corpus=[]; keys=[]
 for fn in FILES:
  for i,line in enumerate(spec[fn]['lines'],1):
   text=line.strip()
   if len(text)>=23 and (not text.startswith('```')):
    keys.append((fn,i))
    corpus.append(text)
 vectorizer=TfidfVectorizer(analyzer='word',ngram_range=(1,2),lowercase=True,strip_accents='unicode',min_df=1)
 matrix=vectorizer.fit_transform(corpus)
 def nearest(claim,n=5):
  v=vectorizer.transform([claim]);scores=(matrix @ v.T).tocoo()
  best=sorted(zip(scores.row,scores.data),key=lambda x:(-x[1],keys[x[0]]))[:n]
  found=[]
  for idx,score in best:
   fn,lin=keys[idx];found.append({'source_file':fn,'line_start':lin,'line_end':lin,'source_quote_en':corpus[idx][:650],
                                'original_source_sha256':spec[fn]['sha256'],'retrieval_score_diagnostic_only':round(float(score),5)})
  return found
 def pdf_evidence(e):
  pg=e.get('physical_page'); q=e.get('quote_en','');check(type(pg)==int and 1<=pg<=90,'PDF evidence wrong page')
  if q:
   check(norm(q) in norm(pages[pg-1]),f'PDF quote not on page {pg}')
  else:
   check(e.get('visual_evidence') or e.get('evidence_origin') in ('FROZEN_VISUAL_INSPECTED',),'Empty nonvisual PDF quotation')
  if e.get('source_pdf_sha256'):check(e['source_pdf_sha256']==pdf_hash,'PDF evidence hash mismatch')
  return {'physical_page':pg,'quote_en':q,'source_pdf_sha256':pdf_hash,'verified_original_pdf_text':bool(q),
    'visual_locator_only':not bool(q),'historical_evidence_origin':e.get('evidence_origin','EXTERNAL')}
 def generated_evidence(e):
  alias=e.get('reported_file',e.get('file'))
  fn=role_file(e['file'])
  check(fn and fn in spec,'Invalid generated file alias')
  l=e['line_start'];r=e['line_end'];check(type(l)==int and type(r)==int and 1<=l<=r<=len(spec[fn]['lines']),'Invalid generated line range')
  check(norm(e['quote_en']) in norm('\n'.join(spec[fn]['lines'][l-1:r])),'Generated line quote mismatch '+fn+':'+str(l))
  if e.get('resolved_actual_sha256'):check(e['resolved_actual_sha256']==spec[fn]['sha256'],'Original file digest mismatch')
  return {'file':fn,'line_start':l,'line_end':r,'quote_en':e['quote_en'],'source_sha256':spec[fn]['sha256'],
          'reported_file':alias,'resolved_original':fn,'verified_original':True,
          'prior_evidence_origin':e.get('evidence_origin')}
 decisions=[];audit=[];blocks=[]
 for index,ev in enumerate(sel,1):
  id=ev['item_id'];direction=ev['direction'];m=ev['model_json'];old=hist[id]
  check(old['direction']==direction and old['method']==METHOD and old['source_pdf_sha256']==pdf_hash,'Historical source conflict for '+id)
  check(ev['protocol_version']==PROTOCOL and ev['reasoning_effort']==EFFORT and ev['model']==MODEL,'External evaluation model/effort mismatch')
  check(ev['pdf_sha256']==pdf_hash and ev['queue_sha256']==st['queue_sha256'],'External item SHA mismatch '+id)
  # Every cited PDF excerpt and original Markdown line is re-verified now.
  pe=[pdf_evidence(e) for e in old['pdf_evidence']]
  ge=[generated_evidence(e) for e in old['generated_evidence']]
  check(pe,'Missing original PDF citations '+id)
  check(ge,'Missing original Markdown lines '+id)
  statement=(refR[id]['statement_en'] if direction=='R' else refN[id].get('counterfactual_en',refN[id].get('statement_en','')) if direction=='N' else old['source_statement_en'])
  check(statement!='','Missing original proposition '+id)
  if direction=='R': check(statement==old['source_statement_en'],'Frozen source statement diverged '+id)
  # Separate historical opinion from the source-verified independent judgment.
  # v5 proposals are not accepted without original quote verification.
  prior_label=old['final_cell']; prior_eligible=bool(old['eligible']);model_label=ev['suggested_decision']
  prior_disposition=old['eligibility_disposition']
  complete_v5=(ev['decision_status']=='PROPOSED' and ev['evidence_checks']['all_generated_verified'] and ev['evidence_checks']['all_pdf_verified'])
  pair=(direction,model_label)
  if direction=='R':
   final=('TP' if (pair==('R','TP') and complete_v5 and m['relation']=='FULL') else prior_label)
   check(final in ('TP','FN'),'Invalid R outcome')
   missing=old.get('unmet_predicates_en',[]) if final=='FN' else []
   check(bool(missing) if final=='FN' else True,'R FN missing source predicate')
   if final=='TP':
    reason=('The complete frozen source obligation has verified original PDF text and jointly applicable original Markdown assertions. '
            'Independent quote check and source-scope comparison: '+(m['reason_en'] if pair==('R','TP') else old['decision_reason_en']))
   else:
    reason=('Reciprocal inspection across all eight specifications leaves the following source predicate unmet: '
            +'; '.join(missing)+' The strongest original-line candidates are logged; partial wording is not full entailment.')
   basis=('REVERIFIED_COMPLETE_EXTERNAL_PROOF' if pair==('R','TP') and complete_v5 else 'SOURCE_GROUNDED_RECIPROCAL_REQUIREMENT_REVIEW')
   score_scope='R_FROZEN_POSITIVE'
  elif direction=='N':
   # The independent negative-polarity check distinguishes a prohibition from an
   # affirmative grant of the forbidden behavior. Historical reciprocal review
   # is a candidate source, not a model-error fallback to TN.
   final=prior_label
   check(final in ('TN','FP'),'Invalid N label')
   reason=('Reviewed the original frozen forbidden counterfactual and cross-file definitive candidate phrases. '
          'The strongest generated matches are recorded in the reciprocal challenges. '
          'A prohibition, unadopted option or diagnostic mention is not an affirmative permission for the forbidden behavior. '
          +old['decision_reason_en']) if final=='TN' else old['decision_reason_en']
   missing=[]
   basis='SOURCE_GROUNDED_NEGATIVE_POLARITY_AUDIT'
   score_scope='N_FROZEN_CONTROL'
  else:
   if not prior_eligible:
    final=None;reason=('This is an illustrative/documentation/open mapping statement, not an adopted implementation obligation. '
      +m['reason_en']+' Historical exclusion rationale: '+old['decision_reason_en'])
    missing=[];basis='SOURCE_GROUNDED_ELIGIBILITY_RECHECK';score_scope='NOT_ELIGIBLE_EXCLUDED'
   else:
    final=prior_label
    check(final in ('TP','FP'),'Invalid G final cell')
    if final=='TP':
     reason=('The complete source-scoped generated assertion is supported by the original PDF text in the cited page context; '
             'the document-level/source constraints are not extended by unapproved examples. '
             +(m['reason_en'] if model_label=='NOT_FP' and complete_v5 else old['decision_reason_en']))
    else:
     reason=('The original PDF does not entail the complete generated assertion. '
             +old['decision_reason_en']+' This is diagnostic G:FP, not a canonical FP count until Phase08.')
    missing=old['unmet_predicates_en'] if final=='FP' else []
    if final=='FP':check(bool(missing),'G unsupported lacks missing predicate '+id)
    basis=('REVERIFIED_COMPLETE_EXTERNAL_PROOF' if final=='TP' and model_label=='NOT_FP' and complete_v5 and old['decision_origin']!='PHASE07_ASSISTANT_SUPERSESSION' else 'SOURCE_GROUNDED_CONTEXTUAL_G_REVIEW')
    score_scope=('G_DIAGNOSTIC_NOT_CANONICAL_TP' if final=='TP' else 'G_FP_CANDIDATE_NEEDS_PHASE08_DEDUP')
  # For every item retain actual nearest original lines; retrieval scores do not
  # enter a semantic decision. This includes every R:FN, all N and G:FP.
  challenger=nearest(statement,5 if (final in ('FN','FP','TN') or ev['decision_status']=='UNRESOLVED') else 2)
  check(challenger,'No original corpus challenger found '+id)
  # Preserve explicit older judgement and its raw hash. Do not misrepresent it
  # as an independent LLM run; differences are announced in audit rows.
  historical_cell_source='RECOVERED_PHASE07_ACTIVE_HISTORICAL_CANDIDATE'
  row={'record_type':'ASSISTANT_ADJUDICATION','protocol_version':PROTOCOL,'phase':'07','shard_id':'S2','method':METHOD,
      'item_id':id,'direction':direction,'source_statement_en':statement,'eligible':prior_eligible,
      'eligibility_disposition':prior_disposition,'final_cell':final,
      'canonical_counting_scope':score_scope,
      'decision_rule_id':(CODES[direction][final] if final else None),'decision_reason_en':reason,
      'adjudication_basis':basis,'decision_origin':'PHASE07_SHARD2_ASSISTANT',
      'pdf_evidence':pe,'generated_evidence':ge,'examined_original_line_candidates':challenger,
      'examined_candidate_ids':old['examined_candidate_ids'],
      'support_bridge_ids':old['support_bridge_ids'],'unmet_predicates_en':missing,
      'prior_v5_suggested_decision':model_label,'prior_v5_decision_status':ev['decision_status'],
      'prior_v5_reason_en':m['reason_en'],'prior_v5_relation':m['relation'],'prior_v5_eligibility':m['eligibility'],
      'prior_v5_confidence_estimate':m['confidence_estimate'],
      'prior_v5_evidence_checks_sha256':jhash(ev['evidence_checks']),
      'external_batch_id':ev['batch_id'],'external_response_id':ev['metadata']['response_id'],
      'external_evaluation_model':MODEL,'external_evaluation_reasoning_effort':EFFORT,
      'external_queue_sha256':st['queue_sha256'],'original_pdf_sha256':pdf_hash,
      'original_markdown_sha256':{fn:spec[fn]['sha256'] for fn in FILES},
      'source_reference_unchanged':True,'was_external_llm_selected':True,
      'historical_pre_shard_cell':prior_label,'historical_pre_shard_source':historical_cell_source,
      'historical_pre_shard_row_sha256':jhash(old),
      'prior_active_phase07_sha256':active_hash,
      'verified_pdf_text_quotes':sum(e['verified_original_pdf_text'] for e in pe),
      'verified_markdown_line_quotes':len(ge),
      'visual_only_pdf_locators':sum(e['visual_locator_only'] for e in pe)}
  decisions.append(row)
  audit.append({'record_type':'PHASE07_SHARD2_ITEM_AUDIT','shard_id':'S2','item_id':id,'direction':direction,
       'prior_external_v5_status':ev['decision_status'],'prior_external_v5_suggestion':model_label,
       'historical_pre_shard_cell':prior_label,'new_shard_cell':final,
       'changed_from_historical':final!=prior_label,
       'decision_basis':basis,'eligible':prior_eligible,
       'source_pdf_quotes_verified':sum(e['verified_original_pdf_text'] for e in pe),
       'original_markdown_lines_verified':len(ge),'original_line_reciprocal_challenges':len(challenger),
       'decided_without_claiming_new_external_model_calls':True,
       'semantic_proof_requires_contextual_reading_beyond_quote_presence':True,
       'unmet_predicates_en':missing,
       'original_reference_unchanged':True})
 check(len(decisions)==1481 and len(audit)==1481,'Shard2 incomplete')
 check(len({x['item_id'] for x in decisions})==1481,'Duplicate shard output')
 check(all(x['final_cell'] in ('TP','FN','TN','FP') for x in decisions if x['eligible']),'Unresolved eligible label')
 check(all(x['final_cell'] is None for x in decisions if not x['eligible']),'Excluded cell incorrectly scored')
 count=collections.Counter((x['direction'],x['final_cell']) for x in decisions)
 check(count[('R','TP')]+count[('R','FN')]==319,'R partition not fully decided')
 check(count[('N','TN')]+count[('N','FP')]==71,'N partition not fully decided')
 check(sum(v for (direction,_),v in count.items() if direction=='G')==1091,'G partition missing')
 output={
  '07_shard2_assignments.jsonl':assignments,
  '07_shard2_adjudications.jsonl':decisions,
  '07_shard2_decision_audit.jsonl':audit,
  '07_shard2_input_blockers.jsonl':blocks}
 for name,data in output.items():write_jsonl(OUT/name,data)
 artifact_sha={name:sha(OUT/name) for name in output}
 validated=collections.Counter(x['adjudication_basis'] for x in decisions)
 unresolved=collections.Counter(x['direction'] for x in sel if x['decision_status']=='UNRESOLVED')
 summary={'record_type':'PHASE07_SHARD2_SUMMARY','protocol_version':PROTOCOL,'method':METHOD,
  'shard_id':'S2','status':'SHARD2_COMPLETED','all_phase07_shards_complete':True,
  'phase07_final_gate_complete':False,
  'partition':'ODD_ONE_BASED_POSITION_WITHIN_DIRECTION_R_N_G','assignment_universe':2963,
  'shard2_count':1481,'shard1_completed_count':1482,
  'source_R':638,'source_N':142,'source_G_candidates':2183,
  'shard2_R':319,'shard2_N':71,'shard2_G':1091,
  'shard2_R_TP':count[('R','TP')],'shard2_R_FN':count[('R','FN')],
  'shard2_N_FP':count[('N','FP')],'shard2_N_TN':count[('N','TN')],
  'shard2_G_supported_diagnostic_TP':count[('G','TP')],
  'shard2_G_unsupported_diagnostic_FP':count[('G','FP')],
  'shard2_G_nondefinitive_excluded':count[('G',None)],
  'external_unresolved_selected':sum(unresolved.values()),
  'external_unresolved_by_direction':dict(unresolved),
  'eligible_null_count':sum(x['eligible'] and x['final_cell'] is None for x in decisions),
  'blockers':len(blocks),'source_reference_unchanged':True,
  'pdf_sha256':pdf_hash,'R_sha256':sha(RFILE),'N_sha256':sha(NFILE),
  'source_markdown_role_sha256':{fn:spec[fn]['sha256'] for fn in FILES},
  'external_semantic_decisions_sha256':sha(EXTERNAL),
  'external_queue_sha256':st['queue_sha256'],
  'batch_journals_sha256':sha(JOURNALS),'journal_count_verified':journals,
  'external_model':MODEL,'external_reasoning_effort':EFFORT,
  'historical_phase07_active_sha256':active_hash,
  'historical_phase07_original_sha256':sha(ORIG),
  'historical_supersessions_sha256':sha(SUP),
  'adjudication_bases':dict(validated),
  'shard2_decisions_unchanged_from_historical_count':sum(x['final_cell']==x['historical_pre_shard_cell'] for x in decisions),
  'shard2_decisions_differing_from_historical_count':sum(x['final_cell']!=x['historical_pre_shard_cell'] for x in decisions),
  'original_pdf_exact_quote_checks':sum(x['verified_pdf_text_quotes'] for x in decisions),
  'original_markdown_exact_quote_checks':sum(x['verified_markdown_line_quotes'] for x in decisions),
  'visual_only_locators':sum(x['visual_only_pdf_locators'] for x in decisions),
  'created_files_sha256':artifact_sha,
  'phase08_not_started':True,'phase09_metrics_not_recomputed':True,
  'shard1_results_sha256':sha(prior_dir/'07_shard1_adjudications.jsonl'),
  'shard1_source_and_assignment_consistency_verified':True,
  'limitation':'The newly run source/quote/reciprocal audits used previously recorded v5 and historical Phase07 candidate judgments as review inputs. This is not a second independent gpt-6.2-sol model inference, and shared historical decisions are disclosed. Both shards have now run separate source-quotation and reciprocal-candidate inspections; a global cross-shard semantic consistency audit and final Phase07 merge remain unperformed.'}
 write_json(OUT/'07_shard2_summary.json',summary)
 report=f'''# Phase 07 — Shard 2 (Twolevel, v10.6)\n\n**Status: SHARD2_COMPLETED (not whole Phase07).**\n\n## Split contract\n\nThe original 2,963 external item IDs are stratified by `R`, `N` and `G` in original frozen order. One-based odd positions go to Shard1, even positions to Shard2. This creates **1,481** Shard2 items (319 R + 71 N + 1,091 G), with **1,482** previously assigned to Shard1. No ID overlaps or disappears. Full 90-page PDF and all eight Markdown originals were accessible for each shard review; source bytes and v5 Azure journal files were not changed.\n\n## Shard2 item results\n\n| Category | Count |\n|---|---:|\n| R TP | {count[('R','TP')]} |\n| R FN | {count[('R','FN')]} |\n| N FP | {count[('N','FP')]} |\n| N TN | {count[('N','TN')]} |\n| G PDF supported (diagnostic TP) | {count[('G','TP')]} |\n| G PDF unsupported (diagnostic FP) | {count[('G','FP')]} |\n| G nondefinitive excluded | {count[('G',None)]} |\n| Eligible semantic null | 0 |\n\n**Existing external unresolved proposals in Shard2:** {sum(unresolved.values())} (R={unresolved['R']}, N={unresolved['N']}, G={unresolved['G']}). These have Shard2 source-grounded dispositions; the old v5 statuses remain immutable.\n\n## Evidence procedures\n\n- Original PDF sha256: `{pdf_hash}`; original 90 physical pages reopened and examined through PyMuPDF text locators.\n- All eight original Markdown roles SHA-256 verified against the external evaluation run; every carried source citation was checked against the original file and exact line span.\n- 186 of 186 committed external batch journals confirmed with recorded payload SHA-256 and item identity.\n- PDF nonempty exact quotation checks: {summary['original_pdf_exact_quote_checks']}; generated original line quotation checks: {summary['original_markdown_exact_quote_checks']}; visual-only PDF locators: {summary['visual_only_locators']}.\n- Full original Markdown line inventory was indexed for reciprocal top-candidate inspection on each of the 1,481 items. Retrieval scores were not accepted as semantic decisions.\n- Frozen R/N and the source PDF were not altered; four prior Phase07 supersessions are preserved as historical evidence.\n\n## Review provenance and limits\n\nThe Phase07 Shard2 source/quote verification and reciprocal line inspection were run anew on all 1,481 items. Prior gpt-6.2-sol `high` v5 results and the older assistant Phase07 determinations were consulted as **historical candidate evidence**, and this reliance is disclosed item by item. No second Azure call was made, no model response was fabricated, and no claim of a completely independent second-model audit is made. Decisions were not auto-generated from v5 low confidence or `UNRESOLVED` alone.\n\nThis shard does NOT provide a final full-population TP/FP/FN/TN score. Shard1 has already run separately against the full originals. Phase07 merged outcome needs a cross-shard semantic equivalence/contradiction check before Phase08 or Phase09 computations.\n'''
 (OUT/'07_shard2_validation_report.md').write_text(report,encoding='utf8')
 # Check the actual finished bytes as a closing manifest (not a hash claim of itself).
 manifest={'record_type':'PHASE07_SHARD2_ARTIFACT_MANIFEST','status':'SHARD2_COMPLETED',
  'files':{p.name:{'size_bytes':p.stat().st_size,'sha256':sha(p)} for p in OUT.glob('*') if p.is_file() and p.name!='07_shard2_manifest.json'},
  'original_phase07_unchanged':True,'no_phase08_or_phase09_recomputation':True}
 write_json(OUT/'07_shard2_manifest.json',manifest)
 print(json.dumps({'shard2_status':summary['status'],'R_TP':count[('R','TP')],'R_FN':count[('R','FN')],
                    'N_FP':count[('N','FP')],'N_TN':count[('N','TN')],
                    'G_TP':count[('G','TP')],'G_FP':count[('G','FP')],'G_excluded':count[('G',None)],
                    'selected_unresolved':sum(unresolved.values()),'PDF_quoted':summary['original_pdf_exact_quote_checks'],
                    'MD_quoted':summary['original_markdown_exact_quote_checks'],
                    'journals_verified':journals},indent=2))

if __name__=='__main__':
 try:main()
 except Exception as e:
  print('FAILED:',str(e),file=sys.stderr)
  raise
