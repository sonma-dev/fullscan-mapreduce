#!/usr/bin/env python3
"""Conservative, source-locked extraction of generated assertion occurrences.

Protocol 10.6, phase 02 only. The script never modifies source/reference inputs.
The deduplication pass accepts only demonstrable literal/near-literal proposition
identity with unchanged modality, identifiers and quantitative constraints.
Broader semantic transfers are reserved for source-grounded later-phase audit.
"""
import json, re, hashlib, math, collections, unicodedata, itertools
from pathlib import Path
from difflib import SequenceMatcher
from datetime import datetime, timezone
from rapidfuzz import fuzz

ROOT=Path('/mnt/data/oriondesk_twolevel_v10_6')
OUT=ROOT/'phase02'
LOCK=json.loads((ROOT/'phase01/01_reference_lock.json').read_text())
MANIFEST=json.loads((ROOT/'phase01/01_source_reference_manifest.json').read_text())
assert LOCK['phase_status']=='COMPLETE' and LOCK['protocol_version']=='10.6'
assert MANIFEST['source_role_count']==8 and MANIFEST['method']=='twolevel'
assert LOCK['reference']['positive_count']==638 and LOCK['reference']['negative_count']==142

for row in MANIFEST['source_roles']:
 p=Path(row['original_path']); data=p.read_bytes()
 assert hashlib.sha256(data).hexdigest()==row['sha256'], f'changed original: {p}'
 assert len(data.decode('utf-8').splitlines())==row['line_count']
for label, filename, sha in [
 ('pdf','/mnt/data/OrionDesk_AI_Detailed_Design_Specification(3).pdf','pdf_sha256'),
 ('positive','/mnt/data/common_atomic_reqs(3).jsonl','positive_sha256'),
 ('negative','/mnt/data/common_negative_controls(3).jsonl','negative_sha256'),
 ('freeze','/mnt/data/reference_freeze(3).json','freeze_sha256')]:
 assert hashlib.sha256(Path(filename).read_bytes()).hexdigest()==LOCK['reference'][sha],label

CITE_RE=re.compile(r'\s*\[(?:Source:|Sources:|PDF\s|Current PDF\s|pp?\.\d|Representative source:|Additional source:|Source findings|Register evidence:|Inventory evidence:)[^\n]*?\]\s*$',re.I)
INLINE_CITE_RE=re.compile(r'\[(?:Source:|Sources:|PDF pp?|Current PDF pp?|pp?\.\d)[^\]]*\]',re.I)
REF_TAG_RE=re.compile(r'`(?:screen_functions|api|data|batch_functions|business_rules|exception_handling|processing_flows):r\d+:c\d+:f\d+`(?:\s*[–-]\s*`?\w[^` ]+`?)?')
LINK_RE=re.compile(r'\[([^\]]+)\]\(([^)]+)\)')
BOLD_RE=re.compile(r'(?<!\\)(?:\*\*|__)(.+?)(?:\*\*|__)',re.S)

# Transparent, deliberately conservative classification policy.
OPEN_RE=re.compile(r'(?i)\b(?:needs confirmation|tbd|unadopted proposal|proposal\b|to be defined|remains? (?:unresolved|unknown|open|unselected)|not supplied|not specified|unconfirmed|open question|unknown|unresolved|pending decision|not (?:yet )?(?:established|selected|provided)|future confirmation|must be confirmed|confirmation required|no (?:complete|approved) (?:contract|mapping)|missing (?:contract|schema)|is open)\b')
META_RE=re.compile(r'(?i)^(?:\*\*)?(?:this (?:specification|register|stage|file|document)|all citations|references? to |source (?:citations|findings)|the source states|these (?:links|resolutions|rows)|the original PDF|the following (?:keys|tables|rows)|no (?:new|additional) (?:proposal|screen|endpoint)|all numbers|figures? (?:are|illustrate)|citations? refer|\[?(?:Source:|PDF pp?\.|Current PDF pp?\.|pp?\.\d)|\*\*Confirmed\.\*\* This|\*\*For every inventory row|\*\*For every exception|the candidate (?:is|remains) provisional|no previous specification|see )')
DONT_INFER_RE=re.compile(r'(?i)(?:do not (?:infer|assume|silently|promote|treat|interpret|manufacture|invent|copy|equate)|does not (?:establish|prove|imply|automatically|authorize)|not (?:automatically|independently) (?:establish|prove|authorize)|is not (?:automatically|necessarily|a proof)|not a (?:complete|full|universal|selected|new) (?:contract|schema|requirement)|are not (?:automatically|necessarily) )')
DEFINITE_RE=re.compile(r'(?i)(?:\b(?:must|shall|require[sd]?|enforc(?:e|es|ed)|reject[sd]?|validat(?:e|es|ed)|preserv(?:e|es|ed)|record[sd]?|return[sd]?|produce[sd]?|emit[sd]?|check[sd]?|bind[sd]?|apply|applies|authorize[sd]?|forbid[sd]?|prohibit[sd]?|support[sd]?|allow[sd]?|deny|denied|quarantin(?:e|ed)|publish(?:es|ed)?|search(?:es|ed)?|draft(?:s|ed)?|ingest(?:s|ed)?|store[sd]?|rotate[sd]?|sign[sd]?|create[sd]?|open[sd]?|use[sd]?|route[sd]?|commit[sd]?|disable[sd]?|remain[sd]?|retain[sd]?|include[sd]?|exclude[sd]?|recomput(?:e|es)|revalidat(?:e|es)|trace[sd]?|fail[sd]?|block[sd]?|suspend[sd]?|restore[sd]?|replay(?:s|ed)?|calculate[sd]?|derive[sd]?|advance[sd]?|reassign[sd]?|escalate[sd]?|report[sd]?|monitor[sd]?|resum(?:e|es)|filter[sd]?|strip[sd]?|retry|retri(?:es|ed)|annotat(?:e|es)|implement[sd]?|index(?:es|ed)?|encrypt(?:s|ed)?|snapshots?|lock[sd]?|audit(?:s|ed)?|baseline|threshold|scope|state|immutable|versioned|read-only|append-only|atomic|ACID|RLS|PKCE|MCP|A2A|\d{3}|GET|POST|PATCH|PUT|DELETE|\b(?:NEW|TRIAGED|FAILED|PUBLISHED|INTERNAL|PUBLIC|CONFIDENTIAL|RESTRICTED)\b)\b|→|\ble\b|<=|>=|≥|≤)')

# Identifiers and literal numeric values must never be dropped during dedup.
CODE_RE=re.compile(r'`([^`]+)`')
NUM_RE=re.compile(r'(?<![a-zA-Z])\d+(?:[.,]\d+)?(?:\s?[%a-zA-Z]+)?')
STOP_WORDS=set('the a an to by for of and in on with from is are be been being at as it its this that these those all any every each same only before after under between through whether or if then when where which while into during also some not no may must shall can should do does did will would one they their his her plus vs versus'.split())


def clean_text(s):
 s=LINK_RE.sub(lambda m:m.group(1),s)
 s=BOLD_RE.sub(r'\1',s)
 s=INLINE_CITE_RE.sub('',s)
 s=REF_TAG_RE.sub('',s)
 s=re.sub(r'\[Source:[^\n]*$', '',s,flags=re.I)
 s=re.sub(r'\s+',' ',s).strip()
 return s.strip(' \t;,:–-')

def split_cells(line):
 raw=line.strip()
 if not raw.startswith('|'): return []
 raw=raw.strip('|')
 return [x.replace(r'\|','|').strip() for x in re.split(r'(?<!\\)\|',raw)]

def is_separator(cells):
 return bool(cells) and all(re.fullmatch(r':?-{2,}:?',x.strip()) for x in cells)

def make_fragments(raw, max_length=380):
 """Split independent sentences and semicolon-separated duties; retain test predicates.
    Long enumerated field bundles are kept together to avoid false atomization.
 """
 raw=clean_text(raw)
 if not raw:return []
 raw=re.sub(r'^\s*\d+(?:\.\d+)*[.)]\s*','',raw)
 # Do not split inside braces/backticks or common abbreviated units.
 chunks=[]; current=''; tick=False; brace=0; square=0
 for idx,ch in enumerate(raw):
  if ch=='`': tick=not tick
  elif not tick and ch in '{(':brace+=1
  elif not tick and ch in '})':brace=max(0,brace-1)
  elif not tick and ch=='[':square+=1
  elif not tick and ch==']':square=max(0,square-1)
  if ch==';' and not tick and brace==square==0:
   if current.strip():chunks.append(current.strip())
   current='';continue
  current+=ch
 if current.strip():chunks.append(current.strip())
 out=[]
 for chunk in chunks:
  # Only split conventional sentence breaks, not abbreviations or decimals.
  parts=re.split(r'(?<=[.!?])\s+(?=(?:[A-Z`*]|\d+\.|\*\*))',chunk)
  for part in parts:
   part=part.strip();
   if not part: continue
   m_two=re.match(r'^(Each|Every)(?: (.+?))? must have (one primary action) and (a clear status summary)\.?$',part,re.I)
   if m_two:
    out.extend([f'{m_two.group(1)} {m_two.group(2) or "screen"} must have {m_two.group(3)}', f'{m_two.group(1)} {m_two.group(2) or "screen"} must have {m_two.group(4)}']);continue
   # Independent shared-subject action clauses (not simple lists of nouns).
   shared_subject=re.match(r'(?i)^(The platform|The service|The gateway|The application|The browser|The system|Each request|Every request|Workers|The worker|The orchestrator)\s+(.+)$',part)
   if shared_subject and re.search(r',\s+(?=(?:searches|drafts|applies|routes|publishes|preserves|rejects|enforces|validates|stores|records|binds|checks|dispatches|creates|returns|emits|verifies|retrieves|retains|converts|protects|restores)\b)',part,re.I):
    subject,body=shared_subject.groups()
    divided=re.split(r',\s+(?=(?:searches|drafts|applies|routes|publishes|preserves|rejects|enforces|validates|stores|records|binds|checks|dispatches|creates|returns|emits|verifies|retrieves|retains|converts|protects|restores)\b)',body,flags=re.I)
    if len(divided)>1:
     for x in divided:
      extra=re.split(r',?\s+and\s+(?=(?:searches|drafts|applies|routes|publishes|preserves|rejects|validates|stores|records|creates|returns|emits|verifies)\b)',x,flags=re.I)
      out.extend(subject+' '+part2.strip() for part2 in extra if part2.strip())
     continue
   # Split long compound duties joined by explicit normative-conjunction predicates.
   if len(part)>max_length and re.search(r'(?i)\b(?:and|but|while)\s+(?:must|shall|require[sd]?|reject[sd]?|preserv(?:e|es)|record[sd]?|do not|never|cannot|return[sd]?|block[sd]?|enforc(?:e|es)|validate[sd]?|apply|remain[sd]?)\b',part):
    sub=re.split(r'(?i)(?:,\s*|\s+)and\s+(?=(?:must|shall|require[sd]?|reject[sd]?|preserv(?:e|es)|record[sd]?|do not|never|cannot|return[sd]?|block[sd]?|enforc(?:e|es)|validate[sd]?|apply|remain[sd]?))',part)
    out.extend(x.strip() for x in sub if x.strip())
   else:out.append(part)
 return out

def classify_fragment(s, heading, role, col=''):
 """Return eligible vs excluded with traceable reason; leave potential controls for Phase 05.
 """
 t=s.strip(); low=t.lower(); h=heading.lower(); c=col.lower()
 if not t:return 'excluded','EMPTY'
 if re.search(r'(?i)^source name$',c) and re.search(r'\bSCR-\d+\b',str(col)+' '+str(heading)):
  return 'eligible','FORMAL_SCREEN_NAME_CONTRACT'
 if re.search(r'(?i)^source name$',c):return 'eligible','FORMAL_SOURCE_NAME_CONTRACT'
 if re.search(r'(?i)^(?:trigger|test trigger|test fixture|scenario / test|input fixture)$',c) and re.search(r'(?i)(?:acceptance criteria|failure acceptance|verification|test)',h):
  return 'excluded','TEST_TRIGGER_IS_CONTEXT_NOT_ASSERTION'
 if re.search(r'(?i)^(?:visible main title|selected sidebar|suggested columns|visual inventory)',c) and not re.search(r'(?i)\b(?:must|shall|cannot|never|prohibited|require)\b',t):return 'excluded','NONNORMATIVE_VISUAL_COLUMN'
 if re.search(r'(?i)^(?:detection and occurrence|category / affected scope|earlier implementation mappings|open implementation|original location)',c):return 'excluded','CONDITION_OR_MAPPING_CONTEXT'
 if re.search(r'(?i)(?:needs confirmation|unresolved|open (?:contract|implementation|field|mapping|attributes|details|recovery|source|predicate)|missing (?:contract|fields|schema)|unconfirmed|not selected|open details|open questions)',c):
  if not re.search(r'(?i)\b(?:must|shall|never|cannot|prohibited|required|is mandatory|do not|not allowed)\b',t):
   return 'excluded','OPEN_TABLE_COLUMN'
 if re.search(r'(?i)^(?:no confirmed|no selected|not (?:a|an) (?:confirmed|selected|established)|unselected|unknown|needs confirmation|open mapping|open status)',t) or re.search(r'(?i)\bopen\s*[.,]?$|\b(?:unknown|unresolved|unconfirmed)\s*$',t):
  return 'excluded','UNCONFIRMED_ABSENCE_OR_UNSELECTED'
 if re.fullmatch(r'\s*(?:p{1,2}\.?\s*\d+|\d+|[A-Z]{1,5}-\d+|[A-Z][A-Z0-9_\-/]+)\s*',t):return 'excluded','LABEL_ONLY'
 if META_RE.search(t):return 'excluded','DOCUMENTATION_META'
 if re.search(r'(?i)(?:representative console sidebar|mockup|fictional values|example (?:only|case|row)|sample fixture|depicted sidebar|figure excerpt|visual depiction|representative figures)',t) and not re.search(r'(?i)\b(?:must|shall|required|mandatory|prohibited|cannot|never)\b',t):
  return 'excluded','NONNORMATIVE_FIGURE_OR_EXAMPLE'
 if re.search(r'(?i)^(?:purposes below|the same restriction applies|the source names|the source states|figures|the candidate remains|source-specific)',t):return 'excluded','DOCUMENTATION_META'
 if re.search(r'(?i)(?:specification-assigned|traceability identifier|reference identif|source identifier|no independent evidence|not a source namespace|this file|earlier file|stage\s*\d|PDF original names|all citations|labelled separately|does not (?:independently )?(?:establish|prove)|not a requirement|not automatically infer|not a new screen)',t):
  if not re.search(r'(?i)\b(?:must not|shall not|is prohibited|cannot publish|must reject)\b',t):return 'excluded','METADATA_OR_INTERPRETIVE_SAFEGUARD'
 if re.search(r'(?i)(?:source|original location|related specifications and requirement ids|file and section contexts|source finding|original source|earlier implementation mappings)',c):
  if len(t)<220 and not re.search(r'(?i)(?<!not )\bmust\b|\bshall\b',t):return 'excluded','PROVENANCE_OR_MAPPING'
 if role=='08_architecture_decision':
  # An unresolved decision register is not an independent adopted design.
  if 'unresolved items' in h or 'cross-specification conflicts' in h or 'missing evidence' in h or 'dependency-implied' in h:
   return 'excluded','UNSELECTED_ARCHITECTURE_DECISION'
 if re.search(r'(?i)(?:consistency and open questions|required clarifications|remaining implementation decisions|open implementation questions|prior.stage amendment notes|outstanding contracts|missing evidence|further confirmation)',h):
  if not re.search(r'(?i)^\s*(?:must|shall|enforce|never|do not|no |only |a |every )',t):return 'excluded','OPEN_QUESTION_CONTEXT'
 if re.search(r'(?i)(?:\bis (?:a )?(?:TBD|unselected|needs confirmation)\b|\bremain(?:s)?(?:\s+\w+){0,2}\s+(?:unresolved|open)\b|\b(?:needs confirmation|tbd|to be confirmed)\b)',t) and not re.search(r'(?i)\b(?:must|shall|never|cannot|prohibited|required|enforce|reject|preserve|cannot|do not)\b',t):
  return 'excluded','UNRESOLVED_OR_OPTIONAL'
 if re.search(r'(?i)^(?:Define |Which |What |How |Is |Are |Should |Whether |Confirm |Needs confirmation|Open:|Question |No complete |Missing |TBD\b|Unknown\b)',t): return 'excluded','REQUEST_FOR_CONFIRMATION'
 if re.search(r'(?i)(?:\b(?:unconfirmed|not specified|not defined|no supplied|pending|unresolved|TBD|needs confirmation)\b|(?:is|are|remain|remains)\s+open\b|\bopen\s+(?:contract|mapping|implementation|details|question|status|predicate|configuration)\b)',t) and not re.search(r'(?i)\b(?:must|shall|cannot|never|is prohibited|required|do not|not allowed)\b',t):
  return 'excluded','OPEN_IMPLEMENTATION_DETAIL'
 if re.search(r'(?i)(?:illustrative|fictional example|depicted|mockup|demonstrat(?:ed|ion)|sample (?:only|console|case|row)|example only|unselected|may be issued|if selected|if used|if optional|proposal|not adopted)',t):
  if not re.search(r'(?i)(?:\b(?:must|shall|never|cannot|prohibited|required|do not|not allowed|shall not|is mandatory)\b)',t):return 'excluded','ILLUSTRATIVE_OR_OPTIONAL'
 if re.search(r'(?i)(?:not a (?:browser|screen|source|new|complete|full|selected|universal)|not (?:an approved|independently proven)|do not (?:infer|assume|silently|manufacture|invent|promote|equate)|does not (?:prove|establish)|remain\w* open|needs confirmation|is open|are open)',t):
  if not re.search(r'(?i)(?:\b(?:must|shall|never|cannot|prohibited|required|enforce|reject|preserve)\b)',t): return 'excluded','INTERPRETIVE_OR_UNCONFIRMED'
 if re.search(r'(?i)^(?:\[|\*?\*?Source:|Source findings|Register evidence|Additional source|\(PDF|pp?\.\s?\d|This (?:file|document|section|table)|The figures)',t):return 'excluded','CITATION_OR_METADATA'
 if re.search(r'(?i)^(?:\w+\-OQ|AD-\d+|RES-\d+)$',t):return 'excluded','IDENTIFIER_ONLY'
 # Bare object/role definitions that imply a testable contract are definitive.
 if re.search(r'(?i)^No\s+(?:implicit approval|business mutation|forbidden evidence|safety bypass|blocked action|credential|token|publication|publish|index|retry|equivalent.tool|deletion bypass|second business|leak)',t):return 'eligible','EXPLICIT_NEGATIVE_TEST_OUTCOME'
 if re.search(r'(?i)\b(?:cannot|never|must not|shall not|not allowed|prohibited|is forbidden)\b',t):return 'eligible','EXPLICIT_NEGATIVE_IMPLEMENTATION_DUTY'
 if re.search(r'(?i)^(?:Persist |Checkpoint |Scan |Validate |Authorize |Verify |Compare |Enforce |Compute |Detect |Inspect |Reconcile |Run |Open |Provide |Maintain |Restore |Rotate |Protect |Record |Create |Build |Switch |Return |Report |Emit |Count |Display |Bind |Reserve |Send |Terminate |Disable |Enable |Reject |Index |Handle )',t):return 'eligible','EXPLICIT_OPERATIONAL_IMPERATIVE'
 if re.search(r'(?i)\b(?:persists?|persisted|checkpoints?|checked|scans?|scanned|verif(?:y|ies|ied)|occurs|happens|happen|take[s]? place|before (?:transaction|parsing|dispatch|publication|approval|enforcement|promotion)|after (?:transaction|permission|approval|completion)|is opaque|are opaque|immutable tenant identity|independent)\b',t):return 'eligible','EXPLICIT_PERSISTENCE_OR_VERIFICATION_DUTY'
 if DEFINITE_RE.search(t):return 'eligible','DEFINITIVE_IMPLEMENTATION_OR_TEST_CLAIM'
 if re.search(r'(?i)\b(?:accepted|synchronous|asynchronous|authoritative|authenticated|read-only|source|policy|manual|async|scheduled|immutable|guarded|terminal|monotonic|not permitted|out of scope|deferred)\b',t):return 'eligible','DEFINITIVE_ENTITY_OR_SCOPE_CLAIM'
 return 'excluded','DESCRIPTIVE_OR_INCOMPLETE'

INDEX=[]; UNITS=[]; EXCLUDED=[]; GO=[]
gid=0; uid=0; eid=0

def put_go(unit, fragment, context, col, row_label, norm_reason, inherited=None):
 global gid
 statement=fragment.strip().rstrip(' .')
 if not statement:return None
 # Always keep the column and row label as independent context, not as a fabricated source quote.
 gid+=1
 atom={'record_type':'GENERATED_ATOM_OCCURRENCE','protocol_version':'10.6','method':'twolevel',
       'gen_id':f'GEN-{gid:07d}', 'source_unit_id':unit['unit_id'],
       'source_role':unit['source_role'],'source_file':unit['source_file'],
       'source_sha256':unit['source_sha256'],'line_start':unit['line_start'],'line_end':unit['line_end'],
       'source_kind':unit['kind'],'heading_path':unit['heading_path'],
       'table_column':col or None, 'table_row_label':row_label or None,
       'table_row_number':unit.get('table_row_number'), 'table_cell_index':unit.get('table_cell_index'),
       'literal_fragment_en':statement, 'statement_en':f"{row_label}: {statement}" if row_label and row_label.lower() not in statement.lower() else statement,
       'inherited_context_en':inherited if inherited is not None else context,
       'complete_claim_en': f"For {row_label}: {statement}" if row_label and row_label.lower() not in statement.lower() else statement,
       'extraction_basis':norm_reason,'eligibility':'DEFINITIVE','phase02_semantic_support':'NOT_YET_EVALUATED',
       'class_id':None, 'evidence_line_sha256': hashlib.sha256(unit['raw_text'].encode()).hexdigest()}
 GO.append(atom);return atom['gen_id']

def put_excl(unit, frag, reason, col=''):
 global eid
 if not frag.strip():return None
 eid+=1
 rec={'record_type':'EXCLUDED_OR_CONTEXT_FRAGMENT','protocol_version':'10.6','method':'twolevel',
      'exclusion_id':f'EXCL-{eid:07d}','source_unit_id':unit['unit_id'],
      'source_role':unit['source_role'],'source_file':unit['source_file'],'source_sha256':unit['source_sha256'],
      'line_start':unit['line_start'],'line_end':unit['line_end'],'heading_path':unit['heading_path'],
      'table_column':col or None,'raw_fragment_en':frag,'exclusion_reason':reason,
      'reassess_in_phase05': reason not in ('CITATION_OR_METADATA','LABEL_ONLY','EMPTY','TABLE_SOURCE_REFERENCE','SOURCE_ONLY','CODE_EXAMPLE','HEADING_OR_STRUCTURE','TABLE_HEADER')}
 EXCLUDED.append(rec);return rec['exclusion_id']

def parse_md(role):
 global uid
 path=Path(role['original_path']); lines=path.read_text().splitlines(); level={}; table_header=[]; row_num=0
 in_code=False; code_lang=''; in_table=False
 line_to_units=collections.defaultdict(list)
 def new_unit(kind,start,end,raw,heading,**kwargs):
  nonlocal role
  global uid
  uid+=1
  u={'unit_id':f'UNIT-{uid:06d}','source_role':role['role'],'source_file':path.name,'source_sha256':role['sha256'],
     'line_start':start,'line_end':end,'kind':kind,'heading_path':heading,'raw_text':raw,**kwargs,
     'gen_ids':[],'exclusion_ids':[]}
  UNITS.append(u)
  for ln in range(start,end+1):line_to_units[ln].append(u)
  return u
 def process_text(u, text, col='', label='', context=''):
  for frag in make_fragments(text):
   decision,reason=classify_fragment(frag,u['heading_path'],role['role'],col)
   if decision=='eligible':u['gen_ids'].append(put_go(u,frag,context,col,label,reason))
   else:u['exclusion_ids'].append(put_excl(u,frag,reason,col))
 i=0
 while i<len(lines):
  ln=i+1; s=lines[i].strip(); heading=' > '.join(level.values())
  if not s: i+=1;continue
  if s.startswith('```') or s.startswith('~~~'):
   if not in_code:in_code=True;code_lang=s.lstrip('`~').strip()
   else:in_code=False
   u=new_unit('code_fence',ln,ln,lines[i],heading)
   u['exclusion_ids'].append(put_excl(u,s,'CODE_FENCE'))
   i+=1;continue
  if in_code:
   u=new_unit('code_example',ln,ln,lines[i],heading)
   u['exclusion_ids'].append(put_excl(u,s,'CODE_EXAMPLE'))
   i+=1;continue
  m=re.match(r'^(#{1,6})\s+(.*)$',s)
  if m:
   depth=len(m.group(1));level={k:v for k,v in level.items() if k<depth};level[depth]=m.group(2).strip()
   heading=' > '.join(level.values());table_header=[];in_table=False;row_num=0
   u=new_unit('heading',ln,ln,lines[i],heading)
   u['exclusion_ids'].append(put_excl(u,s,'HEADING_OR_STRUCTURE'))
   i+=1;continue
  if s.startswith('|'):
   cells=split_cells(s)
   if is_separator(cells):
    u=new_unit('table_separator',ln,ln,lines[i],heading)
    u['exclusion_ids'].append(put_excl(u,s,'HEADING_OR_STRUCTURE'))
    in_table=True;i+=1;continue
   if not in_table or not table_header:
    table_header=cells;in_table=False;row_num=0
    u=new_unit('table_header',ln,ln,lines[i],heading)
    u['exclusion_ids'].append(put_excl(u,s,'TABLE_HEADER'))
    i+=1;continue
   row_num+=1
   u=new_unit('table_row',ln,ln,lines[i],heading,table_row_number=row_num)
   label=clean_text(cells[0])[:190] if cells else ''
   labels=[x.strip() for x in label.split(';') if x.strip()] if label.count(';')<=5 else [label]
   if not labels:labels=[label]
   all_columns=list(itertools.zip_longest(table_header,cells,fillvalue=''))
   # First column acts as subject; it may contain definitive domain labels and verbs.
   for ci,(col,cell) in enumerate(all_columns):
    col=clean_text(col); cell=cell.strip()
    if not cell:continue
    if ci==0 and len(cells)>1:
     # Absorb key into inherited context; also scan compound operative cells.
     if re.search(r'(?i)(?:\b(?:must|shall|require|reject|prevent|prohibit|return|apply|when|cannot|never|no |before|after)\b|→)',cell):
      process_text(u,cell,col,label,heading)
     else:
      u['exclusion_ids'].append(put_excl(u,cell,'TABLE_ROW_KEY_CONTEXT',col))
     continue
    if col.strip().lower()!='source name' and re.search(r'(?i)^(?:source|source and|source findings|related |earlier |original |mapping|references?|related specifications|source/page|citation)',col) and not re.search(r'(?i)\b(?:must|shall|required|cannot|never)\b',cell):
     u['exclusion_ids'].append(put_excl(u,cell,'TABLE_SOURCE_REFERENCE',col));continue
    # Avoid misinterpreting pure cross-document requirement mappings as product obligations.
    if re.fullmatch(r'(?:[A-Z]{1,5}(?:[-/ ]\d+(?:[a-z]|[–-]\d+)?)?[,;\s]*){2,}',cell):
     u['exclusion_ids'].append(put_excl(u,cell,'REFERENCE_MAPPING',col));continue
    for effective_label in labels:process_text(u,cell,col,effective_label,heading)
   if not u['gen_ids'] and not u['exclusion_ids']:
    u['exclusion_ids'].append(put_excl(u,s,'DESCRIPTIVE_OR_INCOMPLETE'))
   i+=1;continue
  in_table=False;table_header=[]
  # Paragraphs may wrap physically across lines; group adjacent nonstructural lines.
  start=i;block=[lines[i]]
  kind='paragraph'
  if re.match(r'^(?:[-*+]\s+|\d+(?:\.\d+)*[.)]\s+)',s):kind='list_item'
  elif s.startswith('>'):kind='blockquote'
  elif re.match(r'^\[?(?:Source|Additional source|Inventory evidence|Register evidence):',s,re.I):kind='citation_only'
  i+=1
  while i<len(lines):
   nxt=lines[i].strip()
   if not nxt or nxt.startswith(('|','#','```','~~~')) or re.match(r'^(?:[-*+]\s+|\d+(?:\.\d+)*[.)]\s+)',nxt):break
   if kind!='paragraph':break
   if nxt.startswith('>'):break
   block.append(lines[i]);i+=1
  raw='\n'.join(block)
  u=new_unit(kind,start+1,i,raw,heading)
  if kind=='citation_only' or (re.fullmatch(r'\[(?:Source:|Sources:|PDF pp?|Current PDF pp?|pp?\.).*',s,re.I) and len(block)==1):
   u['exclusion_ids'].append(put_excl(u,raw,'SOURCE_ONLY'));continue
  process_text(u, ' '.join(x.strip().lstrip('> ') for x in block), context=heading)
  if not u['gen_ids'] and not u['exclusion_ids']:
   u['exclusion_ids'].append(put_excl(u,raw,'DESCRIPTIVE_OR_INCOMPLETE'))
 # Per-original-line index: every nonempty line has exactly one unit classification.
 for num,line in enumerate(lines,1):
  if not line.strip():continue
  us=line_to_units.get(num,[])
  assert len(us)==1,(role['role'],num,us)
  u=us[0]
  INDEX.append({'record_type':'ORIGINAL_TEXT_LINE','protocol_version':'10.6','method':'twolevel',
       'source_role':role['role'],'source_file':path.name,'source_sha256':role['sha256'],
       'physical_line':num,'original_text_en':line,'unit_id':u['unit_id'],'kind':u['kind'],
       'heading_path':u['heading_path'],'gen_ids':u['gen_ids'],'exclusion_ids':u['exclusion_ids'],
       'accounting':'MIXED' if u['gen_ids'] and u['exclusion_ids'] else ('ELIGIBLE' if u['gen_ids'] else 'EXCLUDED_OR_CONTEXT')})

for role in MANIFEST['source_roles']:
 parse_md(role)

# Dedup: source/role context is retained; occurrence propositions may be equivalent
# only when full action/condition polarity, resource identities and parameters align.
def canon(s):
 s=unicodedata.normalize('NFKC',s).lower()
 s=re.sub(r'\b(?:shall|must|is required to|are required to|needs to)\b',' must ',s)
 s=re.sub(r'\b(?:cannot|must not|shall not|never|is prohibited from|are prohibited from)\b',' must not ',s)
 s=re.sub(r'\b(?:records|recorded)\b',' record ',s)
 s=re.sub(r'\b(?:checks|checking|checked)\b',' check ',s)
 s=re.sub(r'\b(?:validates|validated|validating)\b',' validate ',s)
 s=re.sub(r'\b(?:requires|required)\b',' require ',s)
 s=re.sub(r'\b(?:preserves|preserved|preserving)\b',' preserve ',s)
 s=re.sub(r'\b(?:rejects|rejected|rejecting)\b',' reject ',s)
 s=re.sub(r'\b(?:includes|included|including)\b',' include ',s)
 s=re.sub(r'\b(?:returns|returned|returning)\b',' return ',s)
 s=re.sub(r'\b(?:only|exclusively)\b',' only ',s)
 s=re.sub(r'\s+',' ',s)
 s=re.sub(r'^[\w\-\.\/` ]{1,25}:\s+(?=\b(?:must|require|enforce)\b)','',s)
 s=s.strip(' \t.;,:*`')
 return s

def signature(s):
 # Retain literals that tend to break bidirectional entailment across near copies.
 st=unicodedata.normalize('NFKC',s)
 code=[x.lower() for x in CODE_RE.findall(st) if len(x)<140]
 ids=sorted(set(x.lower() for x in re.findall(r'(?<!\w)(?:GET|POST|PATCH|PUT|DELETE)\s+/[\w/{}/?-]+|/[a-zA-Z][a-zA-Z0-9_/{}/-]+|(?:CASE_VERSION_CONFLICT|IDEMPOTENCY_CONFLICT|CONNECTOR_REAUTH_REQUIRED|NO_SUPPORTED_EVIDENCE|MODEL_OUTPUT_INVALID)|(?:\b\d{3}\b)|\b(?:\d{1,2}\.\d+|\d+\s?(?:MB|GB|ms|min|hours?|days?|years?|tokens?|dimensions?|%)|\d+(?:,\d{3})+)\b',st)))
 polarity= tuple(bool(re.search(p,st,re.I)) for p in [r'\b(?:not|no|never|cannot|without|prohibit|deny|reject|forbid)\b',r'\b(?:may|optional|can|permitted)\b',r'\b(?:must|shall|required|mandatory)\b'])
 return (tuple(ids),polarity)

# Fuzzy candidates get an independent conservative audit with one-to-one constraints.
def bag(s):
 t=re.findall(r'[a-z0-9_]+',canon(s))
 return set(w for w in t if len(w)>1 and w not in STOP_WORDS)

canon_groups=collections.defaultdict(list)
for atom in GO:
 atom['_canon']=canon(atom['statement_en'])
 atom['_signature']=signature(atom['statement_en'])
 canon_groups[(atom['_canon'],atom['_signature'])].append(atom)

CLASSES=[]; DUP=[]; class_counter=0
atom_by_id={a['gen_id']:a for a in GO}
for key,atoms in sorted(canon_groups.items(),key=lambda kv: min(int(a['gen_id'][4:]) for a in kv[1])):
 class_counter+=1
 rep=atoms[0]; cid=f'GCLASS-{class_counter:07d}'
 for a in atoms:a['class_id']=cid
 cls={'record_type':'GENERATED_SEMANTIC_CLASS','protocol_version':'10.6','method':'twolevel',
   'class_id':cid,'representative_gen_id':rep['gen_id'],'representative_statement_en':rep['complete_claim_en'],
   'source_role':rep['source_role'],'source_file':rep['source_file'],'line_start':rep['line_start'],
   'heading_path':rep['heading_path'],'member_gen_ids':[a['gen_id'] for a in atoms],
   'member_count':len(atoms),'files':sorted(set(a['source_file'] for a in atoms)),
   'equivalence_audit':'EXACT_CANONICAL_CLAIM_WITH_MATCHING_POLARITY_AND_CONSTRAINTS',
   'equivalence_scope':'COMPLETE_PROPOSITION', 'pdf_validity':'NOT_YET_ADJUDICATED',
   'scope_review_phase':'05','canon':key[0], '_signature':key[1]}
 CLASSES.append(cls)

# Near-exact matches: require high char/bag similarity, exact quantitative/route,
# and compatible context: no unbounded transitive chains, no unverified synonyms.
# We avoid agglomerating conditions based only on topical overlap.
by_sig=collections.defaultdict(list)
for c in CLASSES:by_sig[c['_signature']].append(c)
candidate_audits=[]
for sig,group in by_sig.items():
 if len(group)<2:continue
 # Inverted rare anchor terms to avoid all-pairs scans on large groups.
 index=collections.defaultdict(list)
 for c in group:
  b=bag(c['canon']); c['_bag']=b
  anchors=sorted((x for x in b if len(x)>5),key=lambda x:(-len(x),x))[:5]
  c['_anchors']=anchors
  for k in anchors:index[k].append(c)
 checked=set()
 for c in group:
  potential={x['class_id']:x for anchor in c['_anchors'] for x in index[anchor]}
  for other in potential.values():
   if other['class_id']==c['class_id']:continue
   pair=tuple(sorted([c['class_id'],other['class_id']]))
   if pair in checked:continue
   checked.add(pair)
   a,b=c['canon'],other['canon']
   if abs(len(a)-len(b))>min(len(a),len(b))*.12:continue
   ba,bb=c['_bag'],other['_bag']
   jac=len(ba&bb)/max(1,len(ba|bb))
   if jac<.91:continue
   ratio=fuzz.ratio(a,b)/100
   if ratio<.956:continue
   # Very strict punctuation/paraphrase admission, with comparable heading scope.
   same_scope= not (('exception' in c['heading_path'].lower()) ^ ('exception' in other['heading_path'].lower()))
   if not same_scope:continue
   candidate_audits.append((max(ratio,jac),c,other,ratio,jac))
# only merge trivial spelling differences where exact substring + benign punctuation;
# otherwise preserve separate classes and save the candidate as a later audit.
merge_candidates=[]; flagged=[]
for score,c,d,ratio,jac in sorted(candidate_audits,key=lambda x:-x[0]):
 a,b=c['canon'],d['canon']
 # If equal after punctuation/whitespace (word order stable) merge, otherwise audit pending.
 lexical_a=re.sub(r'[^a-z0-9]+',' ',a).strip()
 lexical_b=re.sub(r'[^a-z0-9]+',' ',b).strip()
 if lexical_a==lexical_b:
  merge_candidates.append((c,d,ratio,jac))
 else:
  flagged.append({'candidate_class_ids':[c['class_id'],d['class_id']], 'lexical_ratio':round(ratio,6),
    'token_jaccard':round(jac,6),'audit_status':'NOT_MERGED_SEMANTIC_ENTAILMENT_NOT_INDEPENDENTLY_PROVEN'})
# Source-informed near-literal audit: remove cross-document traceability references
# (not operational IDs/HTTP paths) while keeping every substantive token.
# High text identity can be merged only with positive explicit checks.
from sklearn.feature_extraction.text import TfidfVectorizer

def semantic_text(st):
 st=unicodedata.normalize('NFKC',st.lower()).replace('`','')
 st=re.sub(r'\b(?:gen|scr|sf|api|dat|bat|br|err|flow|ad|res|oq|ac|tst)-\d+(?:\.\d+)?\b:?', ' ', st)
 st=re.sub(r'\b(?:the|a|an|is|are|and|for|of)\b',' ',st)
 st=re.sub(r'[^a-z0-9]+',' ',st)
 return ' '.join(st.split())

def semantic_constraints(st):
 st=unicodedata.normalize('NFKC',st.lower())
 # Crosswalk test names are retained, but traceability section label aliases can differ.
 tests=tuple(sorted(set(re.findall(r'\b(?:tst-\d+|t-\d+|sec-\d+)\b',st))))
 paths=tuple(sorted(set(re.findall(r'(?:get|post|put|patch|delete)\s+/[^\s,;()]+',st))))
 values=tuple(sorted(set(re.findall(r'\b(?:case_version_conflict|idempotency_conflict|model_output_invalid|no_supported_evidence|connector_reauth_required|auto_allow|human_review|request_more_evidence)\b',st))))
 numeric=tuple(sorted(set(re.findall(r'(?<!\w)\d+(?:\.\d+)?(?:\s?%|\s?(?:mb|ms|days?|hours?|years?|tokens?|dimensions?))?(?!\w)', re.sub(r'\b(?:gen|scr|sf|api|dat|bat|br|err|flow|ad|res|oq|ac|tst)-\d+(?:\.\d+)?\b','',st)))))
 polarity=(bool(re.search(r'\b(?:not|no|never|cannot|without|deny|denied|reject|prohibit)\b',st)),
           bool(re.search(r'\b(?:may|optional|unselected|can)\b',st)))
 return tests,paths,values,numeric,polarity

# High-scoring pairs can still be false semantic duplicates. Use exclusion
# and substantive-term equality, not cosine similarity by itself.
if len(CLASSES)>1:
 vec=TfidfVectorizer(ngram_range=(1,2),sublinear_tf=True,min_df=1)
 semantic_contents=[semantic_text(c['representative_statement_en']) for c in CLASSES]
 matrix=vec.fit_transform(semantic_contents)
 similarities=(matrix @ matrix.T).tocsr()
 for i,c in enumerate(CLASSES):
  row=similarities.getrow(i)
  for j,score in zip(row.indices,row.data):
   if j<=i or score<.90:continue
   other=CLASSES[j]
   if c['source_role']==other['source_role'] and c['source_file']==other['source_file']:continue
   if semantic_constraints(c['representative_statement_en']) != semantic_constraints(other['representative_statement_en']): continue
   src1,src2=semantic_contents[i],semantic_contents[j]
   ta,tb=set(src1.split()),set(src2.split())
   jac=len(ta&tb)/max(1,len(ta|tb))
   # Full token overlap plus a near-identical word sequence; or an explicitly
   # audited very high match with no missing constraint/condition word.
   score=float(score)
   qualifies=(score>=.992 and jac>=.92) or (score>=.955 and jac>=.97)
   if qualifies:
    merge_candidates.append((c,other,score,jac))
   elif score>=.90:
    flagged.append({'candidate_class_ids':[c['class_id'],other['class_id']],
                   'lexical_ratio':round(score,6),'token_jaccard':round(jac,6),
                   'audit_status':'NOT_MERGED_SEMANTIC_ENTAILMENT_NOT_INDEPENDENTLY_PROVEN'})

# Explicit within-turn semantic review of the highest-scoring otherwise-unmerged
# candidates, comparing full asserted predicates, not merely their search scores.
# Classes omitted below either differ materially or lack independent proof.
manual_positive={
 ('GCLASS-0000176','GCLASS-0000549'): 'Same connector capability advertisement: list/fetch/delta cursor/ACL/delete.',
 ('GCLASS-0000539','GCLASS-0001918'): 'Same content-fingerprint and pipeline-version derivative identity; wording only.',
 ('GCLASS-0000559','GCLASS-0001911'): 'The same source ACL change invalidates affected cache before new results.',
 ('GCLASS-0000652','GCLASS-0002074'): 'The same incident documentation fields; only a flow-step label differs.',
 ('GCLASS-0000829','GCLASS-0001726'): 'Tenant in every storage predicate; identity is the same tenant scope.',
 ('GCLASS-0000848','GCLASS-0002165'): 'Same prohibition on treating whole job records as immutable, copied into a resolved-decision record.',
 ('GCLASS-0000932','GCLASS-0001494'): 'The same append-only batch-hash audit and independently controlled retention obligation.',
 ('GCLASS-0001010','GCLASS-0002109'): 'Same TST-004/T-08 in-flight revocation coverage; only FLOW-AC reference differs.',
 ('GCLASS-0001020','GCLASS-0002111'): 'Same TST-015/T-04 scan/sandbox/bounded parse/quarantine/no-index result.',
 ('GCLASS-0001163','GCLASS-0001940'): 'Same complete bounded DAG plan: depth 8, tool calls 16, dependencies, replayable checkpoints.',
 ('GCLASS-0001217','GCLASS-0002068'): 'Same delayed-index diagnostic inputs; only flow-stage label differs.',
 ('GCLASS-0001423','GCLASS-0001659'): 'Same insufficient confidence OR quality decision and NO_SUPPORTED_EVIDENCE/non-fabrication effect.',
 ('GCLASS-0001873','GCLASS-0002164'): 'Same signed background-job envelope with immutable tenant identity.',
}
manual_rejected={
 ('GCLASS-0000316','GCLASS-0001026'): 'Nondefinitive mapping-absence claim; avoid using it as equivalence proof.',
 ('GCLASS-0000190','GCLASS-0001181'): 'Determinism is an additional predicate; retain separate class.',
 ('GCLASS-0000190','GCLASS-0000817'): 'Policy scope and rule semantics require an additional proof; retain separate.',
 ('GCLASS-0000562','GCLASS-0001522'): 'Historic readiness is narrower than generic readiness; scopes not proven mutual.',
 ('GCLASS-0000654','GCLASS-0001529'): 'A negative test merely required differs from a required passing result.',
 ('GCLASS-0000751','GCLASS-0002141'): 'Evaluation corpus scope is not proven solely by stripped local phrasing.',
 ('GCLASS-0001241','GCLASS-0001543'): 'Verifying identity is weaker than verifying the allowed-build-identity digest.',
}
manual_positive={tuple(sorted(pair)):reason for pair,reason in manual_positive.items()}
manual_rejected={tuple(sorted(pair)):reason for pair,reason in manual_rejected.items()}
existing_pairs={tuple(sorted((c['class_id'],d['class_id']))) for _,c,d,_,_ in candidate_audits}
existing_pairs.update(tuple(sorted((c['class_id'],d['class_id']))) for c,d,_,_ in merge_candidates)
manual_records=[]
for pair,reason in itertools.chain(manual_positive.items(),manual_rejected.items()):
 c=next((v for v in CLASSES if v['class_id']==pair[0]),None)
 d=next((v for v in CLASSES if v['class_id']==pair[1]),None)
 if not c or not d:continue
 status='APPROVED_COMPLETE_EQUIVALENCE' if pair in manual_positive else 'NOT_EQUIVALENT_OR_PROOF_INCOMPLETE'
 manual_records.append({'record_type':'DUPLICATE_EQUIVALENCE_REVIEW','protocol_version':'10.6',
                        'candidate_class_ids':list(pair),'review_decision':status,
                        'basis_en':reason,'first_quote_en':c['representative_statement_en'],
                        'first_file':c['source_file'],'first_line':c['line_start'],
                        'second_quote_en':d['representative_statement_en'],
                        'second_file':d['source_file'],'second_line':d['line_start']})
 if pair in manual_positive:
  merge_candidates.append((c,d,1.0,1.0))

# Merge classes without changing original IDs: keep lower representative ID and retire old ID in audit.
retired={}
by_id={c['class_id']:c for c in CLASSES}
for c,d,ratio,jac in merge_candidates:
 a=by_id[c['class_id']];b=by_id[d['class_id']]
 while a['class_id'] in retired:a=by_id[retired[a['class_id']]]
 while b['class_id'] in retired:b=by_id[retired[b['class_id']]]
 if a['class_id']==b['class_id']:continue
 if int(a['representative_gen_id'].split('-')[-1])>int(b['representative_gen_id'].split('-')[-1]):a,b=b,a
 a['member_gen_ids'].extend(b['member_gen_ids']);a['member_gen_ids'].sort(key=lambda x:int(x.split('-')[-1]));
 a['files']=sorted(set(a['files']+b['files']));a['member_count']=len(a['member_gen_ids'])
 a['equivalence_audit']='EXACT_OR_INDEPENDENTLY_AUDITED_NEAR_LITERAL_COMPLETE_CLAIM_WITH_CONSTRAINT_GUARDS'
 retired[b['class_id']]=a['class_id']
 for gid in b['member_gen_ids']:atom_by_id[gid]['class_id']=a['class_id']
CLASSES=[c for c in CLASSES if c['class_id'] not in retired]
# Filter similarity leads superseded by an accepted class merge; never label
# accepted semantic duplicates as still unmerged candidates.
flagged=[x for x in flagged if not any(k in retired for k in x['candidate_class_ids'])]
# Track same semantic class repeated across files and within file, without multiplying counts.
for c in CLASSES:
 if c['member_count']<2:continue
 members=[atom_by_id[g] for g in c['member_gen_ids']]
 members.sort(key=lambda a:(next(r['ordinal'] for r in MANIFEST['source_roles'] if r['role']==a['source_role']),a['line_start'],a.get('table_cell_index') or 0,a['gen_id']))
 rep=members[0]; seen_files={rep['source_file']}
 dup_members=[]
 for m in members[1:]:
  category='within_file' if m['source_file'] in seen_files else 'across_file'
  seen_files.add(m['source_file'])
  dup_members.append({'gen_id':m['gen_id'],'duplicate_type':category,'file':m['source_file'],'line':m['line_start'],
                      'semantic_equivalence_basis':c['equivalence_audit'],
                      'reuse_intent':'UNDECIDED_EXPECTED_REUSE_OR_REDUNDANT'})
 DUP.append({'record_type':'DUPLICATED_SEMANTIC_CLASS','protocol_version':'10.6','method':'twolevel',
             'class_id':c['class_id'],'representative_gen_id':rep['gen_id'],'members':c['member_gen_ids'],
             'member_count':c['member_count'],'excess_occurrences':len(dup_members),
             'within_file_excess':sum(x['duplicate_type']=='within_file' for x in dup_members),
             'across_file_excess':sum(x['duplicate_type']=='across_file' for x in dup_members),
             'cross_file_repeated':len(set(a['source_file'] for a in members))>1,
             'member_locations':[{'gen_id':a['gen_id'],'source_file':a['source_file'],'line_start':a['line_start'],'table_column':a['table_column']} for a in members],
             'duplicate_members':dup_members,
             'equivalence_audit':c['equivalence_audit'],
             'reuse_intent':'UNDECIDED_EXPECTED_REUSE_OR_REDUNDANT'})

# Remove internal keys and serialize with stable order.
for a in GO:
 del a['_canon'];del a['_signature']
for c in CLASSES:
 for k in ('canon','_signature','_bag','_anchors'):c.pop(k,None)
assert all(x['class_id'] in set(c['class_id'] for c in CLASSES) for x in GO)
assert sum(c['member_count'] for c in CLASSES)==len(GO)
assert len(set(a['gen_id'] for a in GO))==len(GO)
assert len(set(a['class_id'] for a in GO))==len(CLASSES)
assert sum(d['excess_occurrences'] for d in DUP)==len(GO)-len(CLASSES)
assert sum(d['within_file_excess']+d['across_file_excess'] for d in DUP)==len(GO)-len(CLASSES)
assert len(set(i['source_role'] for i in INDEX))==8
assert len(set(x['unit_id'] for x in UNITS))==len(UNITS)
assert all(u['gen_ids'] or u['exclusion_ids'] for u in UNITS)
assert len(INDEX)==sum(sum(bool(s.strip()) for s in Path(x['original_path']).read_text().splitlines()) for x in MANIFEST['source_roles'])

# Stable JSONL inputs for subsequent phases. No PDF comparison or TP/FN classification in Phase02.
def write_jsonl(filename,items):
 with (OUT/filename).open('w',encoding='utf8',newline='\n') as f:
  for d in items:f.write(json.dumps(d,ensure_ascii=False,sort_keys=True)+'\n')
write_jsonl('02_generated_atoms_final.jsonl',GO)
write_jsonl('02_generated_classes_final.jsonl',CLASSES)
write_jsonl('02_excluded_units.jsonl',EXCLUDED)
write_jsonl('02_duplicate_classes.jsonl',DUP)
write_jsonl('02_original_text_index.jsonl',INDEX)
# Source coverage + deduction audit. These are support artifacts, not score estimates.
write_jsonl('02_near_duplicate_candidates.jsonl',flagged)
write_jsonl('02_semantic_duplicate_review.jsonl',manual_records)
role_summaries=[]
for r in MANIFEST['source_roles']:
 ri=[x for x in INDEX if x['source_role']==r['role']]
 role_summaries.append({'role':r['role'],'actual_filename':r['actual_filename'],'original_sha256':r['sha256'],
 'nonblank_original_lines':len(ri),'eligible_occurrences':sum(a['source_role']==r['role'] for a in GO),
 'excluded_fragments':sum(a['source_role']==r['role'] for a in EXCLUDED),
 'unaccounted_nonblank_lines':0,
 'generated_scored_scope':'yes' if r['ordinal']<8 else 'register_confirmed_only'})
report={'record_type':'PHASE_02_AUDIT','protocol_version':'10.6','method':'twolevel','phase':'02','phase_status':'COMPLETE',
 'reasoning_effort_requested':'low','scope':'All eight SHA-locked Markdown originals',
 'positive_reference_count_unchanged':LOCK['reference']['positive_count'],
 'negative_reference_count_unchanged':LOCK['reference']['negative_count'],
 'input_sha256_map':{r['actual_filename']:r['sha256'] for r in MANIFEST['source_roles']},
 'source_lock_sha256':hashlib.sha256((ROOT/'phase01/01_reference_lock.json').read_bytes()).hexdigest(),
 'eligible_generated_occurrences_GO':len(GO),'effective_generated_classes_GC':len(CLASSES),
 'excluded_or_context_fragments':len(EXCLUDED),'original_index_lines':len(INDEX),
 'original_scanned_units':len(UNITS), 'unaccounted_substantive_units':0,
 'duplicated_class_count':len(DUP),'duplicated_excess_occurrences':len(GO)-len(CLASSES),
 'raw_duplicate_ratio': (len(GO)-len(CLASSES))/len(GO) if GO else None,
 'within_file_excess':sum(d['within_file_excess'] for d in DUP),
 'across_file_excess':sum(d['across_file_excess'] for d in DUP),
 'cross_file_repeated_class_count':sum(d['cross_file_repeated'] for d in DUP),
 'near_duplicate_unmerged_review_candidates':len(flagged),
 'manual_semantic_pair_reviews':len(manual_records),
 'manually_accepted_equivalence_pairs':sum(r['review_decision']=='APPROVED_COMPLETE_EQUIVALENCE' for r in manual_records),
 'phase05_exclusions_pending_reassessment':sum(e['reassess_in_phase05'] for e in EXCLUDED),
 'grouping_policy_en':'Conservative identity-equivalence, including punctuation and small inflection, with matching explicit numeric/code constraints and polarity. Similar topical statements not proven mutually entailed remain separate pending contextual review; equivalence is not inferred from shared citations alone.',
 'limitations_en':['Phase 02 builds generated-only inventories; source coverage and PDF validity are not decided in this phase.',
 'The automatic atomizer conservatively retains multi-predicate statements when splitting risks losing scope. Independently testable subclauses and all excluded fragments are indexed for Phase 05 recovery and human audit.',
 'Near-duplicate pairs that require material semantic inference are not merged mechanically. Any later proof-based consolidation must preserve these immutable original Phase02 files and record supersessions.',
 'The PDF-positive/negative reference files are immutable and contain provisional benchmark completeness exceptions from Phase01.',
 'The operator requested low effort, while Phase06 external evaluator protocol requires medium; this does not change Phase02 extraction.'],
 'per_role':role_summaries,
 'outputs':{f:hashlib.sha256((OUT/f).read_bytes()).hexdigest() for f in ('02_generated_atoms_final.jsonl','02_generated_classes_final.jsonl','02_excluded_units.jsonl','02_duplicate_classes.jsonl','02_original_text_index.jsonl','02_near_duplicate_candidates.jsonl','02_semantic_duplicate_review.jsonl')}}
(OUT/'02_extraction_validation.json').write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n')
md=f'''# Phase 02 — GO/GC Extraction Validation\n\n**Status:** COMPLETE (Protocol 10.6; method `twolevel`).\n\n- All eight immutable source files passed SHA-256 verification against Phase 01.\n- Scanned original units: **{len(UNITS):,}**; indexed nonblank lines: **{len(INDEX):,}**.\n- Eligible generated assertion occurrences (GO): **{len(GO):,}**.\n- Effective generated semantic classes (GC): **{len(CLASSES):,}**.\n- Excluded or inherited-context fragments: **{len(EXCLUDED):,}**.\n- Repeated classes: **{len(DUP):,}**, with **{len(GO)-len(CLASSES):,}** excess occurrences.\n- Within-file excess: **{sum(d['within_file_excess'] for d in DUP):,}**; across-file excess: **{sum(d['across_file_excess'] for d in DUP):,}**.\n- Near-duplicate audit candidates: **{len(flagged):,}**; manually reviewed pairs: **{len(manual_records):,}**. Unproven semantic equivalence remains open for Phase 05.\n- Missing coverage of scanned original nonblank lines: **0**.\n\n## Reproducibility and scope\n\nEvery GO retains its source SHA-256, original line range, inherited heading and table context, and a stable GEN identifier. Each eligible occurrence is assigned to exactly one effective GCLASS identifier. Full text and nondefinitive exclusions are preserved separately for Phase 05 reinspection.\n\nSemantic grouping is deliberately conservative: only complete near-literal propositions whose constraints and polarity agree are consolidated. A mere common topic, section citation, lexical similarity, partial predicate match or requirement-ID mapping never establishes a merge. Unproven paraphrase candidates stay separate and are enumerated in `02_near_duplicate_candidates.jsonl` for subsequent semantic review.\n\nNo PDF entailment, generated-only FP residual, N/F overlap, R coverage, TP/FN/TN/FP or Precision/Recall/F1 was decided or calculated in Phase 02. The reference's 638 R and 142 N records remain unchanged.\n\nThe operator supplied `reasoning_effort=low`. External Phase 06 comparability requires the protocol-fixed `medium`; this discrepancy remains documented and does not invalidate the Phase 02 source inventory.\n\n## Machine validation\n\nChecks passed: original hashes, original line counts, exactly eight roles, unique GO/GC IDs, one GC per GO, every nonblank source line indexed, every source unit accounted for by eligible or excluded fragments, duplicate arithmetic, and aggregate class membership conservation.\n'''
(OUT/'02_validation_report.md').write_text(md,encoding='utf-8')
print(json.dumps({k:report[k] for k in ['phase_status','eligible_generated_occurrences_GO','effective_generated_classes_GC','excluded_or_context_fragments','original_index_lines','duplicated_class_count','duplicated_excess_occurrences','near_duplicate_unmerged_review_candidates','within_file_excess','across_file_excess','phase05_exclusions_pending_reassessment']},indent=2))
