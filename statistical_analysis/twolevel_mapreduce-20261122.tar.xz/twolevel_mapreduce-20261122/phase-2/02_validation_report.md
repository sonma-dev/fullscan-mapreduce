# Phase 02 — GO/GC Extraction Validation

**Status:** COMPLETE (Protocol 10.6; method `twolevel`).

- All eight immutable source files passed SHA-256 verification against Phase 01.
- Scanned original units: **2,219**; indexed nonblank lines: **2,219**.
- Eligible generated assertion occurrences (GO): **2,349**.
- Effective generated semantic classes (GC): **2,178**.
- Excluded or inherited-context fragments: **5,833**.
- Repeated classes: **131**, with **171** excess occurrences.
- Within-file excess: **2**; across-file excess: **169**.
- Near-duplicate audit candidates: **7**; manually reviewed pairs: **20**. Unproven semantic equivalence remains open for Phase 05.
- Missing coverage of scanned original nonblank lines: **0**.

## Reproducibility and scope

Every GO retains its source SHA-256, original line range, inherited heading and table context, and a stable GEN identifier. Each eligible occurrence is assigned to exactly one effective GCLASS identifier. Full text and nondefinitive exclusions are preserved separately for Phase 05 reinspection.

Semantic grouping is deliberately conservative: only complete near-literal propositions whose constraints and polarity agree are consolidated. A mere common topic, section citation, lexical similarity, partial predicate match or requirement-ID mapping never establishes a merge. Unproven paraphrase candidates stay separate and are enumerated in `02_near_duplicate_candidates.jsonl` for subsequent semantic review.

No PDF entailment, generated-only FP residual, N/F overlap, R coverage, TP/FN/TN/FP or Precision/Recall/F1 was decided or calculated in Phase 02. The reference's 638 R and 142 N records remain unchanged.

The operator supplied `reasoning_effort=low`. External Phase 06 comparability requires the protocol-fixed `medium`; this discrepancy remains documented and does not invalidate the Phase 02 source inventory.

## Machine validation

Checks passed: original hashes, original line counts, exactly eight roles, unique GO/GC IDs, one GC per GO, every nonblank source line indexed, every source unit accounted for by eligible or excluded fragments, duplicate arithmetic, and aggregate class membership conservation.
