#!/usr/bin/env python3
"""Independent Phase09 accounting after two-shard Phase07 and Phase08 reconciliation.

Protocol: OrionDesk v10.6; generation method: twolevel; external evaluator:
gpt-6.2-sol with reasoning effort high. This script does not infer missing
external queue bytes nor absent excluded GO IDs. All results are explicitly
qualified by directly tested evidence and missing-provenance constraints.
"""
from __future__ import annotations
import collections, hashlib, importlib.util, json, math, re, unicodedata, zipfile
from fractions import Fraction
from pathlib import Path
from datetime import datetime, timezone
import pymupdf

P=Path('/mnt/data')
P7=P/'OrionDesk_twolevel_v10.6_Phase07_Merged'
S1=P/'OrionDesk_twolevel_v10.6_Phase07_Shard1'
S2=P/'OrionDesk_twolevel_v10.6_Phase07_Shard2'
P8=P/'OrionDesk_twolevel_v10.6_Phase08_After_Shards'
OUT=P/'OrionDesk_twolevel_v10.6_Phase09_After_Shards'
SOURCES=['01_screen_functions(3).md','02_api(3).md','03_data(3).md','04_batch_functions(4).md','05_business_rules(3).md','06_exception_handling(5).md','07_processing_flows(5).md','08_architecture_decision(4).md']
PDF=P/'OrionDesk_AI_Detailed_Design_Specification(3).pdf'
RFILE=P/'common_atomic_reqs(3).jsonl';NFILE=P/'common_negative_controls(3).jsonl';FREEZE=P/'reference_freeze(3).json'
PDF_ROLE='OrionDesk_AI_Detailed_Design_Specification.pdf'

def sha(p):
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()

def readj(p):return json.loads(p.read_text(encoding='utf-8'))
def readl(p):return [json.loads(x) for x in p.open(encoding='utf-8-sig') if x.strip()]
def canon(x):return json.dumps(x,ensure_ascii=False,separators=(',',':'),sort_keys=True)
def objhash(x):return hashlib.sha256(canon(x).encode('utf-8')).hexdigest()
def norm(s):return ' '.join(unicodedata.normalize('NFKC',str(s)).split()).casefold()
def must(pred,reason):
    if not pred:raise RuntimeError(reason)
def pc(f):return float(f*100)
def pr(f):return f'{float(f*100):.2f}%'
def savej(name,obj): (OUT/name).write_text(json.dumps(obj,ensure_ascii=False,indent=2,sort_keys=True)+'\n',encoding='utf-8')
def write_report(name,s): (OUT/name).write_text(s,encoding='utf-8')

def compute():
    OUT.mkdir(parents=True,exist_ok=True)
    m7=readj(P7/'07_adjudication_summary.json');v7=readj(P7/'07_independent_validation.json')
    counts8=readj(P8/'08_binary_counts.json');v8=readj(P8/'08_independent_validation.json');m8=readj(P8/'08_artifact_manifest.json')
    freeze=readj(FREEZE);state=readj(P/'run_state.json');summary=readj(P/'semantic_summary.json')
    s1=readj(S1/'07_shard1_summary.json');s2=readj(S2/'07_shard2_summary.json')
    must(m7['status']=='PHASE07_TWO_SHARD_MERGE_COMPLETED' and v7['status']=='PASS','Merged Phase07 not validated')
    must(counts8['phase_status']=='PHASE_COMPLETED' and v8['status']=='PASS_CANONICAL_WITH_DOCUMENTED_INPUT_LIMITATIONS' and m8['status']=='PHASE_COMPLETED','Phase08 not validated')
    must(counts8['protocol_version']==m7['protocol_version']=='10.6' and counts8['method']==m7['method']=='twolevel','Wrong method/protocol')
    must(s1['status']=='SHARD1_COMPLETED' and s2['status']=='SHARD2_COMPLETED','Shard statuses incomplete')
    must(m7['shard1_total']==1482 and m7['shard2_total']==1481 and s1['shard1_count']==1482 and s2['shard2_count']==1481,'Shard sizes mismatch')
    must(m7['partition_rule']=='ODD_ONE_BASED_POSITION_WITHIN_DIRECTION_R_N_G','Unexpected shard partition rule')
    # Immutable original and freeze checks.
    pdf_sha=sha(PDF)
    must(pdf_sha==m7['source_pdf_sha256']==counts8['source_pdf_sha256']==state['pdf_sha256']==summary['pdf_sha256']==freeze['source_document']['sha256'],'Frozen PDF identity mismatch')
    with pymupdf.open(PDF) as doc:
        must(doc.page_count==freeze['source_document']['physical_pages']==90,'Original PDF page count mismatch')
        pdftext=[norm(page.get_text(sort=False)+'\n'+page.get_text(sort=True)) for page in doc]
    must(sha(RFILE)==counts8['reference_R_sha256']==m7['source_reference_R_sha256']==freeze['output_artifacts_sha256']['common_atomic_reqs.jsonl'],'Frozen R checksum mismatch')
    must(sha(NFILE)==counts8['reference_N_sha256']==m7['source_reference_N_sha256']==freeze['output_artifacts_sha256']['common_negative_controls.jsonl'],'Frozen N checksum mismatch')
    must(sha(FREEZE)==m7['source_reference_freeze_sha256'],'Frozen manifest SHA mismatch')
    roles={}
    for k,f in enumerate(SOURCES):
        real=sha(P/f);canonical_name=re.sub(r'\(\d+\)(?=\.md$)','',f)
        must(real==counts8['method_original_source_hashes'][f]==m7['generated_originals_sha256'][f]==summary['source_file_sha256'][canonical_name]==state['file_sha256'][canonical_name],'Source original hash mismatch: '+f)
        roles[f]=dict(sha256=real,original_lines=(P/f).read_text(encoding='utf-8-sig').splitlines())
    # Phase07 and Phase08 results: original item identity, source quotes and decisions.
    merged_path=P7/'07_assistant_adjudications.jsonl';ledger_path=P8/'08_final_ledger.jsonl'
    must(sha(merged_path)==counts8['phase07_merged_adjudications_sha256']==m8['authoritative_current_phase07_merged_sha256'],'Merged Phase07 SHA mismatch')
    for file,details in m8['files'].items():
        p=P8/file
        must(p.is_file() and p.stat().st_size==details['size_bytes'] and sha(p)==details['sha256'],'Phase08 artifact mismatch: '+file)
    r=readl(RFILE);n=readl(NFILE);p7=readl(merged_path); ledger=readl(ledger_path)
    must(len(r)==638 and len(n)==142 and len(p7)==2963 and len(ledger)==2707,'Input population wrong')
    Rids=[x['requirement_id'] for x in r];Nids=[x['control_id'] for x in n]
    must(len(set(Rids))==638 and len(set(Nids))==142 and set(Rids).isdisjoint(set(Nids)),'Frozen R/N IDs invalid')
    p7ids=[x['item_id'] for x in p7];m7ids=m7['final_R_ids']+m7['final_N_ids']+m7['final_G_ids']
    must(p7ids==m7ids and len(set(p7ids))==len(p7ids),'Phase07 final IDs missing/duplicated/out of order')
    must(p7ids[:638]==Rids and p7ids[638:780]==Nids,'Frozen R/N order differs')
    d7={x['item_id']:x for x in p7}
    for k in ('R','N','G'):
        subset=[x for x in p7 if x['direction']==k]
        assert len(subset)=={'R':638,'N':142,'G':2183}[k]
        must(all(x['eligible'] and x['final_cell'] in ('TP','FN') for x in subset) if k=='R' else (all(x['eligible'] and x['final_cell'] in ('TN','FP') for x in subset) if k=='N' else all((x['eligible'] and x['final_cell'] in ('TP','FP')) or (not x['eligible'] and x['final_cell'] is None) for x in subset)), 'Undecided/wrong direction Phase07 cell: '+k)
    must(sha(S1/'07_shard1_adjudications.jsonl')==s1['created_files_sha256']['07_shard1_adjudications.jsonl'],'Shard1 bytes changed')
    must(sha(S2/'07_shard2_adjudications.jsonl')==s2['created_files_sha256']['07_shard2_adjudications.jsonl'],'Shard2 bytes changed')
    s1rows=readl(S1/'07_shard1_adjudications.jsonl');s2rows=readl(S2/'07_shard2_adjudications.jsonl')
    must(len(s1rows)==1482 and len(s2rows)==1481 and len({x['item_id'] for x in s1rows+s2rows})==2963,'Shard coverage invalid')
    for direction in ('R','N','G'):
        all_dir=[x for x in p7 if x['direction']==direction]
        expected1={x['item_id'] for i,x in enumerate(all_dir) if i%2==0}
        expected2={x['item_id'] for i,x in enumerate(all_dir) if i%2==1}
        must(expected1=={x['item_id'] for x in s1rows if x['direction']==direction} and expected2=={x['item_id'] for x in s2rows if x['direction']==direction}, 'Shard odd/even partition disagrees for '+direction)
    must(all(d7[x['item_id']]['final_cell']==x['final_cell'] for x in s1rows+s2rows),'Shard verdicts differ from merged verdicts')
    # PDF text quotations and source line quotations: literal exact, visual marked separately.
    quote_count=collections.Counter()
    for item in p7:
        must(item['decision_reason_en'],'Phase07 missing reason: '+item['item_id'])
        for e in item['pdf_evidence']:
            pg=e['physical_page'];must(type(pg)==int and 1<=pg<=90,'Invalid PDF page for '+item['item_id'])
            txt=e.get('quote_en','')
            if txt:
                must(norm(txt) in pdftext[pg-1],'PDF quote not on physical page: '+item['item_id'])
                quote_count['pdf_exact']+=1
            else:
                must(e.get('visual_evidence') or e.get('visual_locator_only'),'Nonvisual empty PDF quotation: '+item['item_id'])
                quote_count['pdf_visual_only']+=1
        for e in item['generated_evidence']:
            f=e['file'];lo=e['line_start'];hi=e['line_end']
            must(f in roles and type(lo)==int and type(hi)==int and 1<=lo<=hi<=len(roles[f]['original_lines']),'Invalid Markdown locator: '+item['item_id'])
            must(norm(e['quote_en']) in norm('\n'.join(roles[f]['original_lines'][lo-1:hi])),'Original MD quote mismatch: '+item['item_id'])
            quote_count['markdown_exact']+=1
    must(quote_count==collections.Counter({'pdf_exact':5901,'pdf_visual_only':10,'markdown_exact':6988}),'Quote count mismatch: '+str(quote_count))
    bytype=collections.defaultdict(list)
    for x in ledger:bytype[x['record_type']].append(x)
    must({k:len(v) for k,v in bytype.items()}=={'FINAL_SOURCE':638,'FINAL_CONTROL':142,'FINAL_CLASS':1888,'FINAL_RESIDUAL':39},'Final ledger row types invalid')
    src={x['source_id']:x for x in bytype['FINAL_SOURCE']};ctrl={x['control_id']:x for x in bytype['FINAL_CONTROL']};cl={x['class_id']:x for x in bytype['FINAL_CLASS']}
    must(set(src)==set(Rids) and set(ctrl)==set(Nids),'Final source/control ID coverage invalid')
    must(all(src[x]['scoring_cell']==d7[x]['final_cell'] for x in src),'Phase08 R changes P7')
    must(all(ctrl[x]['scoring_cell']==d7[x]['final_cell'] for x in ctrl),'Phase08 N changes P7')
    must(all(cl[x]['diagnostic_cell']==d7[x]['final_cell'] for x in cl),'Phase08 G changes P7')
    excluded=readl(P8/'08_excluded_class_crosswalk.jsonl');excset={x['class_id'] for x in excluded}
    must(len(excset)==len(excluded)==295 and len(cl)==1888 and not set(cl)&excset,'Excluded/eligible overlap or duplication')
    g7={x['item_id'] for x in p7 if x['direction']=='G'}
    must(set(cl)|excset==g7,'GC inventory incomplete')
    must(all(not d7[x]['eligible'] for x in excset),'Excluded G accidentally eligible')
    eligible_go=readl(P8/'08_eligible_go_gc_crosswalk.jsonl');gids=[x['gen_id'] for x in eligible_go]
    must(len(gids)==len(set(gids))==2057 and all(x['class_id'] in cl and x['eligible'] for x in eligible_go),'Eligible GO identity/mapping invalid')
    must({x['class_id'] for x in eligible_go}==set(cl),'Some GC lacks an eligible GO class link')
    for x in eligible_go:
        cls=cl[x['class_id']]
        must(x['diagnostic_G_cell']==cls['diagnostic_cell'],'Eligible GO label differs from GC')
    grouped=collections.defaultdict(list)
    for x in eligible_go:grouped[x['class_id']].append(x['gen_id'])
    for key,x in cl.items():
        must(len(grouped[key])==x['original_occurrence_count']==len(x['occurrence_ids']) and set(grouped[key])==set(x['occurrence_ids']),'Eligible GO class occurrence size mismatch: '+key)
    residual=bytype['FINAL_RESIDUAL'];ids={x['residual_id'] for x in residual}
    must(len(residual)==len(ids)==39,'Residual IDs duplicate/missing')
    unsupported={id for id,x in cl.items() if x['diagnostic_cell']=='FP'}
    supported={id for id,x in cl.items() if x['diagnostic_cell']=='TP'}
    must(len(unsupported)==56 and len(supported)==1832,'GC diagnostic cell count inconsistent')
    member_list=[]
    for x in residual:
        must(x['canonical_fp_units']==1 and x['scoring_cell']=='FP' and not x['N_overlap_asserted_control_ids'],'Incorrect residual canonical units')
        must(x['representative_class_id'] in x['member_class_ids'] and len(x['member_class_ids'])==x['member_G_count'],'Residual member list invalid')
        member_list.extend(x['member_class_ids'])
    must(len(member_list)==56 and len(set(member_list))==56 and set(member_list)==unsupported,'Residual FP G class coverage incomplete')
    byres={x['residual_id']:x for x in residual}
    must(all(cl[id]['canonical_FP_residual_id'] in byres and id in byres[cl[id]['canonical_FP_residual_id']]['member_class_ids'] for id in unsupported),'FP class residual mapping wrong')
    must(all(cl[id]['canonical_FP_residual_id'] is None and cl[id]['canonical_TP_increment']==0 for id in supported),'Supported G contributes inappropriate canonical TP')
    t=sum(v['scoring_cell']=='TP' for v in src.values());f=sum(v['scoring_cell']=='FN' for v in src.values());npass=sum(v['scoring_cell']=='TN' for v in ctrl.values());nfp=sum(v['scoring_cell']=='FP' for v in ctrl.values())
    F=len(residual);fp=nfp+F;universe=t+f+npass+fp
    must((t,f,npass,nfp,F,fp,universe)==(585,53,142,0,39,39,819),'Canonical count identities differ')
    for k,v in {'TP':t,'FN':f,'TN':npass,'FP_N':nfp,'FP_F':F,'FP':fp,'canonical_scoring_universe':universe,'GC_total':2183,'GC_eligible':1888,'GC_excluded':295,'G_supported_diagnostic_TP':1832,'G_unsupported_diagnostic_FP':56}.items():
        must(counts8[k]==v,'Independent ledger count diverges: '+k)
    audit8=readl(P8/'08_reconciliation_audit.jsonl')
    must(sum(x['record_type']=='RESIDUAL_EQUIVALENCE_RECONCILIATION' for x in audit8)==39 and sum(x['record_type']=='N_G_OVERLAP_AUDIT' for x in audit8)==219,'Reconciliation audit row types not complete')
    # External: ensure 186 immutable committed responses reproduce every result. Frozen full queue itself is not in this session.
    state_hash=sha(P/'run_state.json');ext_hash=sha(P/'semantic_decisions.jsonl');zip_hash=sha(P/'batch_journals.zip')
    must(summary['status']=='COMPLETE' and summary['completed_items']==summary['requested_items']==2963 and summary['completed_batches']==summary['expected_batches']==186 and summary['remaining_items']==summary['failed_batches']==0,'External run incomplete')
    must(summary['queue_sha256']==state['queue_sha256']==m7['original_queue_sha256_reported_by_execution']==counts8['external_queue_sha256_reported_by_run_state'],'Run queue declaration mismatch')
    must(state['item_count']==2963 and state['batch_size']==16 and summary['batch_size']==16 and state['limit']==0,'External setting incompatible')
    must(summary['protocol_version']==state['protocol_version']=='10.6' and state['model']=='gpt-6.2-sol','External model/protocol mismatch')
    must(ext_hash==m7['original_external_result_sha256'],'External original semantic result SHA mismatch')
    must(zip_hash==s1['batch_journals_sha256']==s2['batch_journals_sha256'],'External batch ZIP SHA mismatch')
    must(all(s['external_evaluation_model']=='gpt-6.2-sol' and s['external_evaluation_reasoning_effort']=='high' for s in p7),'Shard evaluation metadata inconsistent')
    module_path=P/'semantic_decision_evaluator(3).py';spec=importlib.util.spec_from_file_location('oriondesk_uploaded_evaluator',str(module_path));mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
    must(mod.PROTOCOL_VERSION==mod.EXECUTION_VERSION=='10.6' and mod.DEFAULT_MODEL=='gpt-6.2-sol','Executor version/deployment mismatch')
    must(hashlib.sha256(mod.SYSTEM_PROMPT.encode()).hexdigest()==state['prompt_sha256'],'Prompt digest changed')
    must(objhash(mod.RESULT_SCHEMA)==state['result_schema_sha256'],'Result schema digest changed')
    must(len(mod.RESULT_SCHEMA['required'])==12 and 'predicate_checks' not in mod.RESULT_SCHEMA['properties'],'v5 schema unexpectedly changed')
    external=readl(P/'semantic_decisions.jsonl')
    must(len(external)==2963 and [x['item_id'] for x in external]==p7ids and len(set(x['item_id'] for x in external))==2963,'External record IDs/order do not match merged Phase07')
    must(all(x['model']=='gpt-6.2-sol' and x['reasoning_effort']=='high' and x['all_nine_source_files_attached'] for x in external),'External evaluation model/effort/attachments inconsistent')
    must(all(x['final_cell_not_committed'] and x['queue_sha256']==state['queue_sha256'] for x in external),'External result suggests a fabricated canonical cell or wrong queue')
    with zipfile.ZipFile(P/'batch_journals.zip') as z:
        must(z.testzip() is None,'Bad ZIP CRC in journal archive')
        names=[n for n in z.namelist() if re.fullmatch(r'batch_journals/B10\.6-\d{5}\.json',n)]
        must(len(names)==186,'Journal file count mismatch')
        v5_counts=collections.Counter();total=0
        for bi in range(186):
            name=f'batch_journals/B10.6-{bi+1:05d}.json'
            must(name in names,'Missing batch '+name)
            j=json.loads(z.read(name));b=external[16*bi:16*(bi+1)]
            must(j['batch_id']==f'B10.6-{bi+1:05d}' and j['batch_index']==bi and j['batch_size']==len(b),'Journal envelope mismatch')
            must(j['queue_sha256']==state['queue_sha256'] and j['pdf_sha256']==pdf_sha,'Journal hash declaration mismatch')
            must(j['content_sha256']==objhash({'raw_model_json':j['raw_model_json'],'item_records':j['item_records']}),'Journal content digest mismatch')
            must(len(j['item_records'])==len(b)==len(j['raw_model_json']['results']),'Journal item count mismatch')
            must(j['response_metadata'].get('response_id'),'External model response_id missing')
            for item,rec,ext in zip(j['raw_model_json']['results'],j['item_records'],b):
                must(item==rec['model_json']==ext['model_json'] and rec==ext,'Model results differ from committed immutable external journal')
                must(set(item)==set(mod.RESULT_SCHEMA['required']),'Original v5 response schema mismatch')
                # v5 suggestion may be verified using the original supplied model schema, checks, and direction.
                pitem={'direction':ext['direction']}
                suggestion,unresolved,reason=mod.suggest(pitem,item,ext['evidence_checks'],0.9,True)
                must(ext['suggested_decision']==suggestion and ext['review_reason_code']==reason and ext['decision_status']==('UNRESOLVED' if unresolved else 'PROPOSED'),'Original v5 suggestion mismatch')
                v5_counts[(ext['direction'],ext['decision_status'],str(ext['suggested_decision']))]+=1
                total+=1
        must(total==2963,'Model result missing in committed external journals')
    attempts=state['attempts'];must(len(attempts)==188 and summary['attempts']==188,'Attempt ledger mismatch')
    statuses=collections.Counter(a['status'] for a in attempts)
    must(statuses['COMPLETED']==186 and statuses['FAILED']==2,'Executed/failed attempt history inconsistent')
    must(max(collections.Counter(a['batch_id'] for a in attempts).values())<=4,'Per-batch retry cap exceeded')
    must(len({a['batch_id'] for a in attempts})==186,'Attempt batch coverage incomplete')
    # Explicit provenance limits: queue original bytes and excluded GO IDs truly unavailable.
    known_queue=P/'recovered_prior'/'06_llm_queue_v10.6.jsonl'
    present_but_wrong=known_queue.is_file() and (sum(1 for _ in known_queue.open())!=2963 or sha(known_queue)!=state['queue_sha256'])
    full_queue_rehashed=False
    # GO total is only inherited from historical validated Phase08 evidence, not reconstructed.
    go_total_reported=counts8['all_GO_total_inherited_from_historical_phase08']
    go_excluded_reported=counts8['GO_excluded_count_inherited_from_prior_validated_phase08']
    must(go_total_reported==2356 and go_excluded_reported==299 and go_total_reported==2057+go_excluded_reported,'Inherited GO totals inconsistent')
    dup_raw=Fraction(2356-2183,2356)
    dup_eligible=Fraction(2057-1888,2057)
    prec=Fraction(t,t+fp); recall=Fraction(t,t+f); f1=Fraction(2*t,2*t+fp+f)
    validity=Fraction(len(supported),len(cl))
    n_pass=Fraction(npass,npass+nfp)
    # Deliberate status boundary: arithmetic complete, full v10.6 source/queue/GO gate not independently reproducible here.
    strict_blockers=[
       'ORIGINAL_PHASE06_QUEUE_BYTES_UNAVAILABLE: the 2,963-row original queue and per-batch input digests cannot be independently SHA-256-recomputed; a same-named 2,438-row artifact is not accepted.',
       'ORIGINAL_PHASE02_GO_LEDGER_UNAVAILABLE: 299 excluded original GO IDs and lines cannot be reconstructed; raw GO and duplicate rate are inherited, not independently observed.'
    ]
    result={
       'record_type':'PHASE09_SHARDED_INDEPENDENT_METRICS','method':'twolevel','protocol_version':'10.6','phase':'09',
       'status':'METRICS_COMPUTED_WITH_DOCUMENTED_SOURCE_LIMITATIONS','strict_protocol_completion_status':'FINAL_INCOMPLETE',
       'metric_values_are_arithmetically_verified':True,'strict_blockers':strict_blockers,
       'counts':{'R':638,'N':142,'TP':t,'FN':f,'TN':npass,'FP_N':nfp,'FP_F':F,'FP':fp,'canonical_universe':universe},
       'metrics':{'precision':float(prec),'recall':float(recall),'f1':float(f1),'negative_control_pass_rate':float(n_pass),'gc_validity':float(validity),'duplicate_rate_raw_inherited':float(dup_raw),'duplicate_rate_eligible_diagnostic':float(dup_eligible)},
       'metrics_exact_rational':{'precision':f'{prec.numerator}/{prec.denominator}','recall':f'{recall.numerator}/{recall.denominator}','f1':f'{f1.numerator}/{f1.denominator}','duplicate_rate_raw_inherited':f'{dup_raw.numerator}/{dup_raw.denominator}','duplicate_rate_eligible_diagnostic':f'{dup_eligible.numerator}/{dup_eligible.denominator}','gc_validity':f'{validity.numerator}/{validity.denominator}'},
       'metrics_percent_2dp':{'precision':pr(prec),'recall':pr(recall),'f1':pr(f1),'duplicate_rate_raw_inherited':pr(dup_raw),'duplicate_rate_eligible_diagnostic':pr(dup_eligible),'gc_validity':pr(validity),'negative_control_pass_rate':pr(n_pass)},
       'generated_inventory':{'GC_all':2183,'GC_eligible':1888,'GC_excluded':295,'GC_supported':1832,'GC_unsupported':56,'unsupported_gc_to_unique_fp_reduction':17,'unique_fp_residuals':39,'GO_eligible_verified_unique_IDs':2057,'GO_all_inherited':2356,'GO_excluded_inherited':299,'raw_GO_duplicate_excess_inherited':173,'eligible_GO_duplicate_excess_verified':169},
       'phase07_sharded_validation':{'shard1_count':len(s1rows),'shard2_count':len(s2rows),'merged_count':len(p7),'zero_missing_ids':True,'zero_duplicate_ids':True,'zero_unresolved_eligible':True,'past_phase07_judgments_reused':True,'independent_new_gpt_6_2_sol_shard_inference':False},
       'external_evaluation':{'model':'gpt-6.2-sol','reasoning_effort':'high','batch_size':16,'external_results_committed':2963,'journal_count_sha_checked':186,'submission_attempts':188,'recovered_failed_attempts':2,'original_v5_suggestions_recomputed':2963,'source_file_sha256':{f:roles[f]['sha256'] for f in roles},'queue_sha256_reported_only':state['queue_sha256'],'queue_original_bytes_independently_rehashed':False,'same_named_different_queue_detected':bool(present_but_wrong),'attempts_per_batch_max_4':True,'v5_prompt_sha256':state['prompt_sha256'],'v5_schema_sha256':state['result_schema_sha256']},
       'original_source_quote_verification':dict(quote_count),
       'integrity_checks':{'source_pdf_original_hash_verified':True,'source_frozen_R_N_verified':True,'source_original_markdown_8_hash_verified':True,'phase07_partition_and_verdicts_verified':True,'phase08_full_final_ledger_recounted':True,'unsupported_GC_each_in_one_residual':True,'external_journals_recomputed_content_sha256':True,'v5_suggestions_independently_reproduced':True,'cross_method_comparability_verified':False,'all_go_original_ids_verified':False,'external_queue_input_digests_recomputed':False},
       'external_original_sha256':{'PDF':pdf_sha,'R':sha(RFILE),'N':sha(NFILE),'phase07_merged':sha(merged_path),'phase08_final_ledger':sha(ledger_path),'phase08_final_counts':sha(P8/'08_binary_counts.json'),'external_decisions':ext_hash,'batch_journals':zip_hash},
       'limitations':[
         'The original 2,963-row Phase06 queue is absent. Immutable committed per-item journal results and hashes are valid, but original input_digest values cannot be independently recalculated from missing queue bytes.',
         'All 2,057 eligible GO IDs were checked against GC classes. The 299 excluded GO IDs are not accessible and GO_all=2356 is a historical inherited total; the raw duplicate rate is flagged as inherited.',
         'Two Phase07 shards and their merge re-used existing Phase07 judgments as review inputs. This is not a new independent gpt-6.2-sol evaluation; no additional model submissions occurred during Phase09.',
         'The uploaded v10.6 text continues to mention gpt-6.1-sol/medium; the actual run and uploaded evaluator prove gpt-6.2-sol/high. The three-method invariance gate remains unverified.',
         'The original frozen R/N benchmark is a provisional atomization reference. This score measures agreement with that fixed reference only.'
       ]
    }
    savej('09_metrics.json',result)
    audit={'record_type':'PHASE09_INDEPENDENT_INTEGRITY_AUDIT','status':'PASS_AVAILABLE_INPUTS_WITH_TWO_SPECIFIED_SOURCE_GAPS',
           'strict_protocol_completion_status':'FINAL_INCOMPLETE',
           'canonical_recount':result['counts'],'source_quotations_verified':dict(quote_count),
           'shard_partition':result['phase07_sharded_validation'],'external_verified':result['external_evaluation'],
           'mandatory_unverified_inputs':strict_blockers,'source_artifacts':result['external_original_sha256']}
    savej('09_independent_validation.json',audit)
    rep=f'''# Phase 09 — Independent Metric Computation After Two-Shard Phase 07\n\n**Method:** twolevel | **Protocol:** 10.6 | **External model:** gpt-6.2-sol (reasoning effort high, 16-item batches)\n\n**Metric computation:** COMPLETE and independently reconciled against the final Phase08 ledger.  \n**Strict protocol verification:** FINAL_INCOMPLETE (two original artifacts unavailable; no data invented).\n\n## Canonical confusion matrix\n\n| Cell | Count |\n|---|---:|\n| TP | {t} |\n| FN | {f} |\n| FP from N | {nfp} |\n| FP from unique generated-only residuals | {F} |\n| Total FP | {fp} |\n| TN | {npass} |\n| Scoring universe R + N + F | {universe} |\n\n## Calculated metrics\n\n| Metric | Exact equation | Result |\n|---|---|---:|\n| Precision | {t} / ({t} + {fp}) | **{pr(prec)}** |\n| Recall | {t} / ({t} + {f}) | **{pr(recall)}** |\n| F1 | (2 × {t}) / (2 × {t} + {fp} + {f}) | **{pr(f1)}** |\n| Negative-control pass rate | {npass} / {npass+nfp} | **{pr(n_pass)}** |\n| Eligible-GC PDF validity | {len(supported)} / {len(cl)} | **{pr(validity)}** |\n| Raw duplicate (historically inherited GO total) | (2356 − 2183) / 2356 | **{pr(dup_raw)}** |\n| Eligible-only duplicate (diagnostic) | (2057 − 1888) / 2057 | **{pr(dup_eligible)}** |\n\nThe same canonical counts and metric values were reported before Shard partitioning. Because the shard adjudications reused historical Phase07 cells, this is a consistency result, **not** evidence of a second independent GPT judgment.\n\n## Reconciliation checks\n\n- R=638: TP + FN = {t} + {f} = 638.\n- N=142: TN + FP_N = {npass} + {nfp} = 142.\n- G=2,183 classes: eligible 1,888; supported 1,832; unsupported 56; excluded 295.\n- All 56 unsupported eligible G class IDs appear in exactly one of 39 distinct unsupported-residual groups, with 17 excess class-appearances merged. No asserted negative-control overlap remains.\n- Full merged Phase07: 2,963 unique IDs, Shard 1 1,482, Shard 2 1,481, no missing or unclassified eligible item.\n- Original PDF 90 physical pages, frozen R/N SHA-256, eight SHA-256-verified Markdown originals; original text quoted {quote_count['pdf_exact']} PDF times and {quote_count['markdown_exact']} Markdown times; {quote_count['pdf_visual_only']} figure-only locators preserved as such.\n- External gpt-6.2-sol/high v5 evaluator: 186 committed batch journals; 2,963 output records, 188 historical submissions (186 success, 2 failed attempts recovered); all journal content SHA-256 values and suggestions recomputed.\n\n## Strict source-provenance limitations\n\n1. The exact original 2,963-row Phase06 **queue file** is unavailable. The archive preserves each committed journal's original `input_digest`, but those digests cannot be independently rehashed from the missing queue. A recovered 2,438-row same-name file is not substituted.\n2. The original Phase02 **complete GO ledger** is unavailable. The 2,057 eligible GO IDs are traced, but 299 excluded GO IDs and their original source ranges were not reconstructed. Therefore the 2,356-GO raw duplicate-rate denominator is explicitly inherited, not independently re-derived.\n\nThese limitations prevent claiming the strict v10.6 Phase09 *full source-integrity gate*. They do **not** undermine the verified arithmetic of the canonical 2,707-row Phase08 ledger. Original external data, Phase07/08 judgments and files were not changed.\n'''
    write_report('09_report.md',rep)
    limits='''# Phase 09 — Coverage and Limitations\n\nNo metric unit has been fabricated. The report states exactly what was measured, what was recovered and what remains unavailable.\n\n- The frozen PDF and R/N inputs, all eight original Markdown role files, both Shard 1 and Shard 2, their merged 2,963-item decision inventory, the committed external v5 results, all 186 batch journals, and the 2,707-row Phase08 final ledger were inspected and cross-checked.\n- A frozen queue SHA-256 is recorded in run_state and every committed journal, but the original full queue file is not present. Therefore external queue completeness is supported by results/journal/ID reconciliation, NOT by independent original-queue content-byte hashing.\n- Original per-GO excluded occurrence IDs and source locators are unavailable. Do not equate the 2,057 eligible verified GO with the historical 2,356 all-GO total, and do not call the raw duplicate fraction independently reconstructed.\n- Shards used previously recorded Phase07 adjudication decisions as references and preserved their labels. Neither new independent gpt-6.2-sol model inference nor an unrelated human expert review took place.\n- The source reference Gold Set remains frozen and provisionally audited; 638 R and 142 N are not presented as exhaustive ontology coverage for all possible design requirements.\n- The attached v10.6 textual protocol's earlier deployment/effort differs from actual gpt-6.2-sol/high execution; source scripts, run_state, and individual model records establish the actual setting. Three-method comparability requires separate fullload/onelevel run evidence and policy invariance validation.\n- Same-source quotation matches establish exact textual provenance and do not by themselves prove all semantic entailments or all-pairs semantic equivalence.\n\nStrict protocol completion status is FINAL_INCOMPLETE pending restoration and independent validation of the original 2,963-row Phase06 queue and complete Phase02 GO ledger. The canonical metrics were nevertheless computed exactly without assumptions about absent item decisions.\n'''
    write_report('09_coverage_and_limitations.md',limits)
    manifest={'record_type':'PHASE09_METRIC_ARTIFACT_MANIFEST','phase':'09','method':'twolevel','protocol_version':'10.6',
       'status':result['status'],'strict_protocol_completion_status':result['strict_protocol_completion_status'],
       'created_at_utc':datetime.now(timezone.utc).isoformat(),
       'files_sha256':{name:sha(OUT/name) for name in ['compute_metrics.py','09_metrics.json','09_report.md','09_coverage_and_limitations.md','09_independent_validation.json']},
       'prior_phase_files_unchanged':True,'source_hashes':result['external_original_sha256']}
    savej('09_artifact_manifest.json',manifest)
    print(json.dumps({'status':result['status'],'strict_protocol_completion_status':result['strict_protocol_completion_status'],'counts':result['counts'],'metrics_percent':result['metrics_percent_2dp'],'quotes':dict(quote_count),'external_journals_verified':186,'queue_original_independently_rehashed':False,'excluded_GOs_original_ids_available':False},indent=2))

if __name__=='__main__':compute()
