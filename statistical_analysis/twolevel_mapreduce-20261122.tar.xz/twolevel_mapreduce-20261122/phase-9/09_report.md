# Phase 09 — Independent Metric Computation After Two-Shard Phase 07

**Method:** twolevel | **Protocol:** 10.6 | **External model:** gpt-6.2-sol (reasoning effort high, 16-item batches)

**Metric computation:** COMPLETE and independently reconciled against the final Phase08 ledger.  
**Strict protocol verification:** FINAL_INCOMPLETE (two original artifacts unavailable; no data invented).

## Canonical confusion matrix

| Cell | Count |
|---|---:|
| TP | 585 |
| FN | 53 |
| FP from N | 0 |
| FP from unique generated-only residuals | 39 |
| Total FP | 39 |
| TN | 142 |
| Scoring universe R + N + F | 819 |

## Calculated metrics

| Metric | Exact equation | Result |
|---|---|---:|
| Precision | 585 / (585 + 39) | **93.75%** |
| Recall | 585 / (585 + 53) | **91.69%** |
| F1 | (2 × 585) / (2 × 585 + 39 + 53) | **92.71%** |
| Negative-control pass rate | 142 / 142 | **100.00%** |
| Eligible-GC PDF validity | 1832 / 1888 | **97.03%** |
| Raw duplicate (historically inherited GO total) | (2356 − 2183) / 2356 | **7.34%** |
| Eligible-only duplicate (diagnostic) | (2057 − 1888) / 2057 | **8.22%** |

The same canonical counts and metric values were reported before Shard partitioning. Because the shard adjudications reused historical Phase07 cells, this is a consistency result, **not** evidence of a second independent GPT judgment.

## Reconciliation checks

- R=638: TP + FN = 585 + 53 = 638.
- N=142: TN + FP_N = 142 + 0 = 142.
- G=2,183 classes: eligible 1,888; supported 1,832; unsupported 56; excluded 295.
- All 56 unsupported eligible G class IDs appear in exactly one of 39 distinct unsupported-residual groups, with 17 excess class-appearances merged. No asserted negative-control overlap remains.
- Full merged Phase07: 2,963 unique IDs, Shard 1 1,482, Shard 2 1,481, no missing or unclassified eligible item.
- Original PDF 90 physical pages, frozen R/N SHA-256, eight SHA-256-verified Markdown originals; original text quoted 5901 PDF times and 6988 Markdown times; 10 figure-only locators preserved as such.
- External gpt-6.2-sol/high v5 evaluator: 186 committed batch journals; 2,963 output records, 188 historical submissions (186 success, 2 failed attempts recovered); all journal content SHA-256 values and suggestions recomputed.

## Strict source-provenance limitations

1. The exact original 2,963-row Phase06 **queue file** is unavailable. The archive preserves each committed journal's original `input_digest`, but those digests cannot be independently rehashed from the missing queue. A recovered 2,438-row same-name file is not substituted.
2. The original Phase02 **complete GO ledger** is unavailable. The 2,057 eligible GO IDs are traced, but 299 excluded GO IDs and their original source ranges were not reconstructed. Therefore the 2,356-GO raw duplicate-rate denominator is explicitly inherited, not independently re-derived.

These limitations prevent claiming the strict v10.6 Phase09 *full source-integrity gate*. They do **not** undermine the verified arithmetic of the canonical 2,707-row Phase08 ledger. Original external data, Phase07/08 judgments and files were not changed.
