# Phase 09 — Coverage and Limitations

No metric unit has been fabricated. The report states exactly what was measured, what was recovered and what remains unavailable.

- The frozen PDF and R/N inputs, all eight original Markdown role files, both Shard 1 and Shard 2, their merged 2,963-item decision inventory, the committed external v5 results, all 186 batch journals, and the 2,707-row Phase08 final ledger were inspected and cross-checked.
- A frozen queue SHA-256 is recorded in run_state and every committed journal, but the original full queue file is not present. Therefore external queue completeness is supported by results/journal/ID reconciliation, NOT by independent original-queue content-byte hashing.
- Original per-GO excluded occurrence IDs and source locators are unavailable. Do not equate the 2,057 eligible verified GO with the historical 2,356 all-GO total, and do not call the raw duplicate fraction independently reconstructed.
- Shards used previously recorded Phase07 adjudication decisions as references and preserved their labels. Neither new independent gpt-6.2-sol model inference nor an unrelated human expert review took place.
- The source reference Gold Set remains frozen and provisionally audited; 638 R and 142 N are not presented as exhaustive ontology coverage for all possible design requirements.
- The attached v10.6 textual protocol's earlier deployment/effort differs from actual gpt-6.2-sol/high execution; source scripts, run_state, and individual model records establish the actual setting. Three-method comparability requires separate fullload/onelevel run evidence and policy invariance validation.
- Same-source quotation matches establish exact textual provenance and do not by themselves prove all semantic entailments or all-pairs semantic equivalence.

Strict protocol completion status is FINAL_INCOMPLETE pending restoration and independent validation of the original 2,963-row Phase06 queue and complete Phase02 GO ledger. The canonical metrics were nevertheless computed exactly without assumptions about absent item decisions.
