#!/usr/bin/env python3
"""Second independent Phase09 arithmetic/provenance checker.

Uses Decimal arithmetic and independently enumerates Phase08 ledger rows,
compares the authored output and its source hashes, detects unsupported
claims of verified original queue / excluded GO reconstruction.
"""
import json,hashlib,collections
from decimal import Decimal,getcontext,ROUND_HALF_UP
from pathlib import Path

P=Path('/mnt/data');O=P/'OrionDesk_twolevel_v10.6_Phase09_After_Shards';B=P/'OrionDesk_twolevel_v10.6_Phase08_After_Shards';M=P/'OrionDesk_twolevel_v10.6_Phase07_Merged'
getcontext().prec=50
R=lambda p:[json.loads(line) for line in p.open(encoding='utf8') if line.strip()]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
metric=json.loads((O/'09_metrics.json').read_text());counts=json.loads((B/'08_binary_counts.json').read_text());ledger=R(B/'08_final_ledger.jsonl');p7=R(M/'07_assistant_adjudications.jsonl')
by=collections.defaultdict(list)
for x in ledger:by[x['record_type']].append(x)
a={typ:len(vals) for typ,vals in by.items()};assert a=={'FINAL_SOURCE':638,'FINAL_CONTROL':142,'FINAL_CLASS':1888,'FINAL_RESIDUAL':39},a
cell_R=collections.Counter(x['scoring_cell'] for x in by['FINAL_SOURCE']);cell_N=collections.Counter(x['scoring_cell'] for x in by['FINAL_CONTROL']);cell_G=collections.Counter(x['diagnostic_cell'] for x in by['FINAL_CLASS'])
tp,fn,tn,np,fpF=cell_R['TP'],cell_R['FN'],cell_N['TN'],cell_N['FP'],len(by['FINAL_RESIDUAL'])
fp=np+fpF
assert (tp,fn,tn,np,fpF,fp)==(585,53,142,0,39,39)
assert metric['counts']=={'R':638,'N':142,'TP':tp,'FN':fn,'TN':tn,'FP_N':np,'FP_F':fpF,'FP':fp,'canonical_universe':819}
assert (cell_G['TP'],cell_G['FP'])==(1832,56)
assert len({x['residual_id'] for x in by['FINAL_RESIDUAL']})==39
members=[y for x in by['FINAL_RESIDUAL'] for y in x['member_class_ids']]
assert len(members)==56 and len(set(members))==56
fpids={x['class_id'] for x in by['FINAL_CLASS'] if x['diagnostic_cell']=='FP'}
assert set(members)==fpids
assert all(not x['N_overlap_asserted_control_ids'] for x in by['FINAL_RESIDUAL'])
perc=lambda numerator,denominator: (Decimal(numerator)*Decimal(100)/Decimal(denominator)).quantize(Decimal('.01'),rounding=ROUND_HALF_UP)
expected={
 'precision':perc(tp,tp+fp), 'recall':perc(tp,tp+fn),
 'f1':perc(2*tp,2*tp+fp+fn),
 'duplicate_rate_raw_inherited':perc(173,2356),
 'duplicate_rate_eligible_diagnostic':perc(169,2057),
 'gc_validity':perc(cell_G['TP'],len(by['FINAL_CLASS'])),
 'negative_control_pass_rate':perc(tn,tn+np),
}
for k,v in expected.items():
 assert metric['metrics_percent_2dp'][k]==f'{v:.2f}%',(k,v)
assert metric['status']=='METRICS_COMPUTED_WITH_DOCUMENTED_SOURCE_LIMITATIONS' and metric['strict_protocol_completion_status']=='FINAL_INCOMPLETE'
assert metric['integrity_checks']['all_go_original_ids_verified'] is False and metric['integrity_checks']['external_queue_input_digests_recomputed'] is False
assert counts['original_phase02_twolevel_atomization_ledger_unavailable'] and counts['live_external_queue_full_bytes_unavailable']
assert metric['external_original_sha256']['phase08_final_ledger']==sha(B/'08_final_ledger.jsonl')
assert metric['external_original_sha256']['phase07_merged']==sha(M/'07_assistant_adjudications.jsonl')
manifest=json.loads((O/'09_artifact_manifest.json').read_text())
for name,digest in manifest['files_sha256'].items():
 assert (O/name).is_file() and sha(O/name)==digest,name
assert '93.75%' in (O/'09_report.md').read_text() and '91.69%' in (O/'09_report.md').read_text() and '92.71%' in (O/'09_report.md').read_text()
assert len(p7)==2963 and len({x['item_id'] for x in p7})==2963
assert len(R(B/'08_eligible_go_gc_crosswalk.jsonl'))==2057
assert len(R(B/'08_excluded_class_crosswalk.jsonl'))==295
out={'record_type':'PHASE09_SECOND_INDEPENDENT_VALIDATOR','status':'PASS_ARITHMETIC_AND_AVAILABLE_SOURCE_INTEGRITY',
 'strict_protocol_status':'FINAL_INCOMPLETE',
 'derived_counts':metric['counts'],
 'derived_percentages_2dp':{k:f'{v:.2f}%' for k,v in expected.items()},
 'all_39_residuals_cover_56_FP_G_classes_exactly_once':True,
 'all_638_R_and_142_N_ledger_rows_accounted_for':True,
 'all_2963_merged_Phase07_IDs_unique':True,
 'unavailable_phase06_original_queue_and_excluded_phase02_GO_explicitly_flagged':True,
 'authored_metric_manifest_SHA256_values_rechecked':True,
 'phase09_report_agrees':True,
 'source_phase07_08_bytes_untouched':True}
(O/'09_second_independent_validation.json').write_text(json.dumps(out,indent=2,ensure_ascii=False)+'\n')
print(json.dumps(out,indent=2,ensure_ascii=False))
