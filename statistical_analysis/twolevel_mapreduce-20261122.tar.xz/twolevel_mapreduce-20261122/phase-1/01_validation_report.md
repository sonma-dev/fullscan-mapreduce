# Phase 01 — Reference Lock Verification Report

**Phase result:** COMPLETE  
**Protocol:** 10.6  
**Generation method:** `twolevel` (explicit operator input)  
**Requested reasoning effort:** `low`  
**Original PDF:** `OrionDesk_AI_Detailed_Design_Specification(3).pdf` (90 physical pages)  
**PDF SHA-256:** `b71541e74564559d2cc0a84e9827086946998fbc6c627488fb9e7a7f9b0137c3`  

## Frozen inputs

- R positives: **638**; SHA-256 `072ffe9c50001a0a9605f1ce00aef97c30f329e25e0c16c540a59dbc0eafc427` (matches freeze).
- N controls: **142**; SHA-256 `0d2481530218ae6a8ebd010bf259233a56f141a03a3562dfca50ada5a024524e` (matches freeze).
- R + N canonical source population: **780** records; original IDs, labels, and bytes preserved.
- Reference manifest SHA-256: `35b206a87838adc78c83c9ebec86ecd1c2652cd24db075b55299fa6711a1143f`; frozen status `REFERENCE_FROZEN_PROVISIONAL`.
- Original PDF's filename in the supplied manifest differs by upload-copy suffix, but **the complete PDF SHA-256 matches exactly**.
- Exactly eight generated Markdown source roles are uniquely mapped and SHA-256 locked in `01_source_reference_manifest.json`.

## Validation

- Passed: **46**; failed: **0**.
- Verified **2142** literal PDF text evidence quotations against their stated physical pages, using the document's original reading order and normalized whitespace.
- Independently visually checked **18** cited figure assertions on PDF physical pages 57, 61, 64, 68, 78. These cover the visible cross-cutting runtime assertions in Figures 16.1, 17.1, 18.1, 19.1, and 22.1.
- Evidence mismatches: **0**.
- Nonfatal inherited reference exceptions: **60** (4 frozen-manifest limitations plus 56 flagged reference items). The frozen manifest discloses a bounded semantic audit, imperfect shard independence, negative-control review limitations, and provisional semantic completeness; these caveats are preserved without changing scoring units.

## Reasoning-effort configuration discrepancy

The operator explicitly requested `reasoning_effort=low`. Protocol 10.6 explicitly specifies `reasoning_effort=medium` for the Phase 06 external v5-compatible evaluator. **No choice or silent override has been made.** Phase 01 source locking is complete, but a future Phase 06 run at `low` would violate the protocol-defined comparable-run configuration. This is a future execution/comparability blocker, not a missing Phase 01 input.

## Phase boundary

No generated assertion was classified; no GO/GC, R->generated coverage, negative-control semantic decision, confusion-matrix count, or metric was produced. Phase 02 has not started. No input bytes or frozen reference records were modified.
