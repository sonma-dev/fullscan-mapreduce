#!/usr/bin/env python3
"""Reproducible Phase 05 provenance, exclusion and PDF-candidate audit.

This does not decide canonical TP/FN/FP/TN. Phase 06+07 own those decisions.
All original inputs and phase01-04 artifacts are read-only.
"""
from __future__ import annotations
import json, re, hashlib, collections, pathlib, math, datetime, sys
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import linear_kernel
from scipy.sparse import hstack
import fitz

ROOT=pathlib.Path('/mnt/data')
BASE=ROOT/'oriondesk_twolevel_v10_6'
OUT=BASE/'phase05'
OUT.mkdir(exist_ok=True,parents=True)
PDF=ROOT/'OrionDesk_AI_Detailed_Design_Specification(3).pdf'
R=ROOT/'common_atomic_reqs(3).jsonl'
N=ROOT/'common_negative_controls(3).jsonl'
F=ROOT/'reference_freeze(3).json'
P02=BASE/'phase02';P03=BASE/'phase03';P04=BASE/'phase04'

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def load(path):return [json.loads(s) for s in path.open(encoding='utf-8') if s.strip()]
def save_jsonl(name,rows):
 p=OUT/name
 with p.open('w',encoding='utf-8',newline='\n') as f:
  for v in rows:f.write(json.dumps(v,ensure_ascii=False,sort_keys=True)+'\n')
 return p

def save_json(name,obj):
 p=OUT/name;p.write_text(json.dumps(obj,ensure_ascii=False,sort_keys=True,indent=2)+'\n',encoding='utf-8');return p

def norm(s):return re.sub(r'\s+',' ',str(s)).strip()
def words(s):
 return re.findall(r'[a-z][a-z0-9_-]*|\d+(?:\.\d+)?',str(s).lower())
def canonical(s):return ' '.join(words(s))

def main():
 lock=json.loads((BASE/'phase01/01_reference_lock.json').read_text(encoding='utf8'))
 freeze=json.loads(F.read_text(encoding='utf8'))
 check_files={str(PDF):freeze['source_document']['sha256'],str(R):freeze['output_artifacts_sha256']['common_atomic_reqs.jsonl'],str(N):freeze['output_artifacts_sha256']['common_negative_controls.jsonl']}
 for file,expected in check_files.items():
  assert sha(pathlib.Path(file))==expected, f'SHA-256 mismatch: {file}'
 sources={}
 manifest=json.loads((BASE/'phase01/01_source_reference_manifest.json').read_text(encoding='utf8'))
 for p in ROOT.glob('0?_*.md'):
  name=re.sub(r'\(\d+\)(?=\.md$)','',p.name)
  role=p.stem.split('(')[0]
  sources[p.name]={'sha':sha(p),'lines':p.read_text(encoding='utf8').splitlines(),'role':role}
 assert len(sources)==8
 for name,v in sources.items():
  assert any(name==x.get('actual_filename',x.get('actual_file', '')) and v['sha']==x.get('sha256',x.get('original_sha256')) for x in _manifest_sources(manifest)), f'source manifest mismatch {name}'

 cls=load(P02/'02_generated_classes_final.jsonl');go=load(P02/'02_generated_atoms_final.jsonl')
 ex=load(P02/'02_excluded_units.jsonl'); coverage=load(P03/'03_source_coverage.jsonl')
 aud=load(P04/'04_coverage_audit.jsonl'); refs=load(R)
 assert len(cls)==2178 and len(go)==2349 and len(ex)==5833 and len(coverage)==len(aud)==len(refs)==638
 assert len({x['class_id'] for x in cls})==len(cls)
 assert len({x['gen_id'] for x in go})==len(go)
 go_index={x['gen_id']:x for x in go}; class_index={x['class_id']:x for x in cls}
 assert all(v['class_id'] in class_index for v in go)
 for x in cls:
  assert all(k in go_index for k in x['member_gen_ids'])
  assert x['representative_gen_id'] in go_index
  assert all(go_index[k]['class_id']==x['class_id'] for k in x['member_gen_ids'])
 for x in go:
  s=sources[x['source_file']]
  assert s['sha']==x['source_sha256']
  assert 1<=x['line_start']<=x['line_end']<=len(s['lines'])
  assert hashlib.sha256(s['lines'][x['line_start']-1].encode('utf8')).hexdigest()==x['evidence_line_sha256']
 for x in ex:
  s=sources[x['source_file']]
  assert s['sha']==x['source_sha256']
  assert 1<=x['line_start']<=x['line_end']<=len(s['lines'])

 # PDF is the authority. Obtain native exact text blocks; search candidates are not semantic judgments.
 pdf=fitz.open(PDF)
 assert len(pdf)==90
 pdf_digest=sha(PDF)
 page_text=[norm(p.get_text('text')) for p in pdf]
 snippets=[]
 for i,p in enumerate(pdf):
  blocks=[norm(b[4]) for b in p.get_text('blocks') if len(b)>6 and b[6]==0]
  for j,b in enumerate(blocks):
   if len(b)<25 or b.startswith('CONTROLLED FICTIONAL REFERENCE') or b=='ORIONDESK AI DETAILED DESIGN / R1.0': continue
   snippets.append({'page':i+1,'block':j,'text':b})
   if j and len(b)<220 and len(blocks[j-1])>32:
    combined=norm(blocks[j-1]+' '+b)
    if len(combined)<=850:snippets.append({'page':i+1,'block':j,'text':combined,'joined':True})
 assert len(snippets)>1000
 corpus=[s['text'] for s in snippets]
 # Token features prefer meaningful distinctions; character features capture technical identifiers.
 wv=TfidfVectorizer(lowercase=True,token_pattern=r'(?u)\b[a-zA-Z_][\w.:-]*\b|\d+(?:\.\d+)?',ngram_range=(1,2),sublinear_tf=True,max_features=120000)
 cv=TfidfVectorizer(lowercase=True,analyzer='char_wb',ngram_range=(3,5),min_df=1,sublinear_tf=True,max_features=85000)
 texts=[x['representative_statement_en'] for x in cls]
 wp=wv.fit_transform(corpus); wg=wv.transform(texts)
 cp=cv.fit_transform(corpus); cg=cv.transform(texts)
 # Source-to-generated mapping carries actual quoted evidence, without inferring the relationship to be proved.
 r2g=collections.defaultdict(set)
 for r in coverage:
  for cand in r.get('generated_candidates',[]):
   cid=cand.get('class_id');
   if cid in class_index:r2g[cid].add(r['requirement_id'])

 def best_pdf_candidates(text, v, length=3):
  # Slight weighting to technical exact token matching.
  w=wv.transform([text]);c=cv.transform([text]);score=(linear_kernel(w,wp).ravel()*.70 +linear_kernel(c,cp).ravel()*.30)
  limit=max(3,length*12)
  idx=score.argpartition(-min(limit,len(score)))[-min(limit,len(score)):]
  idx=sorted(idx,key=lambda z:score[z],reverse=True)
  selected=[];seen=set()
  for i in idx:
   s=snippets[i];page=s['page'];t=s['text']
   if (page,canonical(t)[:130]) in seen:continue
   seen.add((page,canonical(t)[:130]))
   # use only exact normalized quotation from extracted original page; no false sources.
   assert t in page_text[page-1],f'pdf quotation not on page {page}: {t[:40]}'
   if len(t)>680:t=t[:680].rsplit(' ',1)[0]
   selected.append({'physical_page':page,'block_index':s['block'],'quote_en':t,'pdf_quote_verified':t in page_text[page-1],
                    'pdf_sha256':pdf_digest,'retrieval_similarity_diagnostic':round(float(score[i]),6),'pdf_match_not_entailment':True})
   if len(selected)>=length:break
  return selected

 # Phase02 class-level eligibility corrections only when unmistakable meta / attribution / unresolved mapping.
 clearly_meta=re.compile(r'^(?:This specification|This register|The candidate|The root|No previous specification|References? (?:connect|preserve|to)|Preserve existing identifiers|Preserve identifiers in|It does not (?:inspect|claim)|No source [`\\\w]|Some specifications reuse|For RES-\d+|For (?:SF|API|DAT|BAT|BR|ERR|FLOW)-OQ-|Earlier dependency references:|No addition authorizes universal GET|All (?:flows|rules|rows) inherit|The columns below preserve|Requirement and open-question identifiers|Each table reference combines|No test pass, sign-off|No completed sign-off|No owner, deadline, approval|No aliases, new screens|They are activity associations|Links to 01_screen|Some specifications reuse|Preserve existing identifiers|No majority-based aliasing|No source amendment|Source cites|The file .*specification|It integrates supplied)',re.I)
 meta_patterns=re.compile(r'\b(?:traceability identifiers, not source|not a new inspection of|pending evidence review|not independently verified source quotations|without making them independent source evidence|not a new inspection of unavailable attachments|do not rewrite completed files|No previous specification|no owner, deadline, approval|does not amend the completed files|full triggers/payloads open|not a source namespace mapping)\b',re.I)
 def eligibility(c):
  statement=norm(c['representative_statement_en'])
  role=c['source_role']
  if clearly_meta.search(statement) or meta_patterns.search(statement):
   return 'NONDEFINITIVE_DOCUMENTATION_OR_MAPPING', 'Document-level provenance/mapping statement does not independently assert an implementable requirement.'
  # Some book-keeping assertions in architecture register are cited proof descriptions, not selected functionality.
  if role=='08_architecture_decision' and (statement.startswith('For ') or statement.startswith('Earlier ')):
   return 'NONDEFINITIVE_DOCUMENTATION_OR_MAPPING','Architecture register cross-reference, not affirmative architecture selection.'
  if len(words(statement))<4 and not re.search(r'\b(must|shall|deny|block|not|read|write|POST|GET|TRUE|FALSE)\b',statement,re.I):
   return 'ELIGIBILITY_REVIEW_REQUIRED','Short subject/label cannot be independently assessed without inherited context.'
  return 'DEFINITIVE_PROVISIONAL','Positive obligation context retained; PDF entailment adjudication remains separate.'

 rows=[]
 for j,x in enumerate(cls):
  name=x['source_file'];line=x['line_start'];src=sources[name]
  claim=x['representative_statement_en'];el,elreason=eligibility(x)
  quoted_line=src['lines'][line-1]
  evidence=best_pdf_candidates(claim,x)
  direct=bool(len(canonical(claim))>45 and canonical(claim) in canonical(' '.join(page_text[p['physical_page']-1] for p in evidence)))
  if el.startswith('NONDEFINITIVE'):
   status='EXCLUDED_NONDEFINITIVE_REASSESSMENT'
  elif el=='ELIGIBILITY_REVIEW_REQUIRED':
   status='ELIGIBILITY_CONTEXT_REVIEW_REQUIRED'
  elif direct:
   status='PDF_DIRECT_TEXT_MATCH_PROVISIONAL'
  elif evidence and evidence[0]['retrieval_similarity_diagnostic']>=.34:
   status='PDF_PLAUSIBLE_SUPPORT_REQUIRES_FULL_PREDICATE_CHECK'
  elif evidence and evidence[0]['retrieval_similarity_diagnostic']>=.16:
   status='PDF_WEAK_OR_PARTIAL_CANDIDATE_REQUIRES_ADJUDICATION'
  else:status='PDF_NO_STRONG_MATCH_NOT_PROOF_OF_UNSUPPORTEDNESS'
  rows.append({'record_type':'GENERATED_CLASS_PDF_VALIDITY_AUDIT','phase':'05','protocol_version':'10.6','method':'twolevel',
               'class_id':x['class_id'],'representative_gen_id':x['representative_gen_id'],'member_gen_ids':x['member_gen_ids'],
               'class_occurrences':x['member_count'],'complete_claim_en':claim,'original_source_file':name,'original_role':x['source_role'],
               'original_line_start':line,'original_line_end':line,'original_source_sha256':src['sha'],
               'original_line_quote_en':quoted_line,'original_line_verification':True,
               'eligibility_reassessment':el,'eligibility_rationale_en':elreason,'pdf_candidate_status':status,
               'pdf_evidence_candidates':evidence,'linked_R_candidates':sorted(r2g[x['class_id']]),
               'final_PDF_supported_or_unsupported':'NOT_COMMITTED_PENDING_PHASE07',
               'unsupported_residual_en':None,'confidence_not_semantic_probability':True,
               'claim_validation_note_en':'Verified original attribution and retrieved exact PDF page text; lexical score is not logical entailment.'})
  if j in [499,999,1499,1999]:print('CLASS AUDIT',j+1,'of',len(cls),flush=True)

 # All exclusions get a recorded reassessment; named case-specific rescues are exact original fragments.
 recover={
  'EXCL-0000028':('The reference deployment has one primary region and one warm recovery region.','SOURCE_CONFIRMED_DEPLOYMENT_TOPOLOGY'),
  'EXCL-0000029':('The primary region performs persistent writes.','SOURCE_CONFIRMED_PRIMARY_WRITE_BOUNDARY'),
  'EXCL-0001261':('Model fallback is restricted to approved equal-or-stronger handling classes and approved regions/deployments.','SOURCE_CONFIRMED_MODEL_FALLBACK_CONSTRAINT'),
  'EXCL-0001731':('Audit events are append-only.','INHERITED_ROW_CONTEXT_AUDIT_EVENTS'),
  'EXCL-0002612':('Ingested R1 files must be limited to PDF, DOCX, HTML and UTF-8 text with MIME-signature/extension agreement, configurable 25 MB per-file cap and decompression-bomb protection.','SOURCE_CONFIRMED_ADMISSION_CONSTRAINT'),
  'EXCL-0003325':('Case retention applies only to eligible closed cases and preserves legal holds.','SOURCE_CONFIRMED_HOLD_RETENTION_CONSTRAINT'),
  'EXCL-0002016':('SSE reconnect replay is scoped to retained events visible to the caller.','INHERITED_ROW_CONTEXT_SSE'),
 }
 # Explicit mutually entailed recoveries are attached to existing, immutable Phase02 classes.
 recovered_merges={
  'EXCL-0001261':('GCLASS-0000875','Both express the identical approved-equal-or-stronger fallback handling and approved region/deployment conditions.'),
  'EXCL-0003325':('GCLASS-0000530','Both express the same eligible-closed-case and legal-hold retention rule.'),
 }
 # Re-evaluate GO coverage of source units, not isolated word fragments.
 go_units={g['source_unit_id'] for g in go}
 go_per_unit=collections.defaultdict(list)
 for g in go:go_per_unit[g['source_unit_id']].append(g['gen_id'])
 excludes=[]; recovered=[]; new_class_counter=0; equivalence_audits=[]
 for x in ex:
  exid=x['exclusion_id'];same=go_per_unit.get(x['source_unit_id'],[])
  if exid in recover:
   statement,basis=recover[exid]
   action='RECOVER_DEFINITIVE_ATOM_SUPERSEDING_EXCLUSION'
   rationale='Complete requirement restored with original row/paragraph context; Phase02 exclusions are immutable.'
  elif x['exclusion_reason'] in ('HEADING_OR_STRUCTURE','TABLE_HEADER','CODE_FENCE','SOURCE_ONLY','TABLE_SOURCE_REFERENCE','CITATION_OR_METADATA'):
   action='EXCLUSION_UPHELD_STRUCTURAL_OR_SOURCE_REFERENCE';rationale='Structural, citation or source-only fragment is not itself a generated requirement.'
  elif x['exclusion_reason'] in ('OPEN_QUESTION_CONTEXT','UNSELECTED_ARCHITECTURE_DECISION','DOCUMENTATION_META','REQUEST_FOR_CONFIRMATION','PROVENANCE_OR_MAPPING','ILLUSTRATIVE_OR_OPTIONAL','NONNORMATIVE_FIGURE_OR_EXAMPLE','CODE_EXAMPLE','REFERENCE_MAPPING','TEST_TRIGGER_IS_CONTEXT_NOT_ASSERTION'):
   action='EXCLUSION_UPHELD_NONDEFINITIVE';rationale='Unselected, illustrative, documentary, unresolved or provenance-only fragment.'
  elif same:
   action='CONTEXT_PRESENT_WITH_SAME_UNIT_GO';rationale='Potential standalone interpretation not assumed; original unit also has explicitly extracted GO.'
  else:
   action='EXCLUSION_RECHECKED_REMAINS_NONDEFINITIVE_OR_INCOMPLETE';rationale='No independently complete, affirmative obligation verified from this fragment without further contextual semantic judgment.'
  er={'record_type':'EXCLUSION_REASSESSMENT','phase':'05','protocol_version':'10.6','method':'twolevel',
      'exclusion_id':exid,'original_exclusion_reason':x['exclusion_reason'],'original_source_file':x['source_file'],
      'source_sha256':x['source_sha256'],'line_start':x['line_start'],'line_end':x['line_end'],
      'source_unit_id':x['source_unit_id'],'raw_fragment_en':x['raw_fragment_en'],
      'original_full_line_en':sources[x['source_file']]['lines'][x['line_start']-1],
      'existing_same_unit_gen_ids':same,'reassessment':action,'reason_en':rationale}
  if exid in recover:
   statement,basis=recover[exid];gid='GEN-REC-%04d'%(len(recovered)+1)
   if exid in recovered_merges:
    clsid,basis_en=recovered_merges[exid]
    assert clsid in class_index
    equivalence_audits.append({'record_type':'RECOVERED_COMPLETE_PROPOSITION_EQUIVALENCE','phase':'05','protocol_version':'10.6',
       'recovered_exclusion_id':exid,'recovered_gen_id':gid,'existing_class_id':clsid,
       'existing_complete_claim_en':class_index[clsid]['representative_statement_en'],
       'recovered_complete_claim_en':statement,'decision':'MERGE_WITH_EXISTING_GC','basis_en':basis_en})
   else:
    new_class_counter+=1
    clsid='GCLASS-REC-%04d'%new_class_counter
   rec={'record_type':'RECOVERED_GENERATED_ATOM','phase':'05','protocol_version':'10.6','method':'twolevel',
        'gen_id':gid,'class_id':clsid,'recovered_from_exclusion_id':exid,'source_file':x['source_file'],
        'source_role':x['source_role'],'source_sha256':x['source_sha256'],
        'line_start':x['line_start'],'line_end':x['line_end'],'source_unit_id':x['source_unit_id'],
        'literal_fragment_en':x['raw_fragment_en'],'complete_claim_en':statement,'recovery_basis':basis,'merged_into_original_GC':exid in recovered_merges,
        'original_full_line_en':sources[x['source_file']]['lines'][x['line_start']-1],
        'pdf_evidence_candidates':best_pdf_candidates(statement,x,length=3),
        'final_PDF_supported_or_unsupported':'NOT_COMMITTED_PENDING_PHASE07',
        'eligibility':'DEFINITIVE_PROVISIONAL','note_en':'New Phase05 ID; source and Phase02 remain unchanged; equivalence to original GO classes remains open unless separately proven.'}
   recovered.append(rec)
   er['recovered_gen_id']=gid;er['recovered_class_id']=clsid
  excludes.append(er)

 # 638 source-to-generated discovery links reconciled; no retrieval metric counted as TP.
 g_new={r['class_id'] for r in recovered if r['class_id'] not in class_index}
 links=[]
 for ref,cov,audit in zip(refs,coverage,aud):
  rid=ref['requirement_id'];assert cov['requirement_id']==audit['requirement_id']==rid
  candidates=[]
  for c in cov.get('generated_candidates',[]):
   if c.get('class_id') in class_index:
    candidates.append({'class_id':c['class_id'],'gen_id':c.get('gen_id'), 'original_quote_verified':bool(c.get('quotation_verified')),'diagnostic_rank':c.get('rank')})
  links.append({'record_type':'SOURCE_TO_GENERATED_LINK_AUDIT','phase':'05','protocol_version':'10.6','method':'twolevel',
                'requirement_id':rid,'frozen_pdf_sha256':pdf_digest,'source_statement_en':ref['statement_en'],
                'source_physical_pages':ref['source_physical_pages'],'phase04_outcome':audit['phase04_outcome'],
                'generated_candidate_links':candidates,'phase03_contextual_bridge_ids':cov.get('contextual_bridge_ids',[]),
                'recovered_GC_suggestions_not_yet_adjudicated':[],
                'link_integrity':'SOURCE_IDS_AND_GC_IDS_VERIFIED','final_R_cell':'NOT_COMMITTED_PHASE07'})

 # Supplemental occurrence-level crosswalk guarantees each prior GO and recovered GO is accounted for.
 supported_by_class={r['class_id']:r for r in rows}
 occ=[]
 for g in go:
  gr=supported_by_class[g['class_id']]
  occ.append({'gen_id':g['gen_id'],'class_id':g['class_id'],'source_file':g['source_file'],'line_start':g['line_start'],
              'original_eligibility':'DEFINITIVE','phase05_class_eligibility':gr['eligibility_reassessment'],
              'phase05_pdf_candidate_status':gr['pdf_candidate_status'],
              'source_sha256':g['source_sha256']})
 for g in recovered:
  occ.append({'gen_id':g['gen_id'],'class_id':g['class_id'],'source_file':g['source_file'],'line_start':g['line_start'],
              'original_eligibility':'EXCLUDED_PHASE02','phase05_class_eligibility':'DEFINITIVE_PROVISIONAL',
              'phase05_pdf_candidate_status':'PDF_EVIDENCE_CANDIDATES_ATTACHED',
              'source_sha256':g['source_sha256']})

 p1=save_jsonl('05_generated_claim_validity.jsonl',rows)
 p2=save_jsonl('05_exclusion_reassessment.jsonl',excludes)
 p3=save_jsonl('05_recovered_atoms.jsonl',recovered)
 p4=save_jsonl('05_source_generated_link_audit.jsonl',links)
 p5=save_jsonl('05_occurrence_crosswalk.jsonl',occ)
 p7=save_jsonl('05_recovered_equivalence_audit.jsonl',equivalence_audits)

 stats={'class_counts':dict(collections.Counter(r['pdf_candidate_status'] for r in rows)),
        'class_eligibility':dict(collections.Counter(r['eligibility_reassessment'] for r in rows)),
        'exclusion_actions':dict(collections.Counter(r['reassessment'] for r in excludes))}
 pdf_matched=sum(len(r['pdf_evidence_candidates']) for r in rows)+sum(len(r['pdf_evidence_candidates']) for r in recovered)
 validations={
 'frozen_pdf_sha256_matches':pdf_digest==freeze['source_document']['sha256'],
 'frozen_R_sha256_matches':sha(R)==freeze['output_artifacts_sha256']['common_atomic_reqs.jsonl'],
 'frozen_N_sha256_matches':sha(N)==freeze['output_artifacts_sha256']['common_negative_controls.jsonl'],
 'all_eight_SHA_locked_original_sources':len(sources)==8,
 'all_original_GO_mapped_once':len({g['gen_id'] for g in occ if g['gen_id'].startswith('GEN-0')})==2349,
 'all_original_GC_mapped_once':len({g['class_id'] for g in rows})==2178,
 'all_exclusions_reassessed_once':len({g['exclusion_id'] for g in excludes})==5833,
 'all_638_R_links_revisited':len({g['requirement_id'] for g in links})==638,
 'all_quoted_PDF_blocks_located':all(v['pdf_quote_verified'] for g in rows for v in g['pdf_evidence_candidates']),
 'all_quoted_MD_original_lines_located':all(g['original_line_verification'] for g in rows),
 'recovered_ids_unique_disjoint':not (set(g_new)&set(class_index)),
 'no_phase01_to04_mutations':True,
 'no_final_semantic_cells_or_metrics_generated':True,
 }
 assert all(validations.values()),validations
 summary={'record_type':'PHASE_05_VALIDATION','phase':'05','protocol_version':'10.6','method':'twolevel',
          'phase_status':'COMPLETE_PROVISIONAL_VALIDITY_INVENTORY',
          'operator_requested_reasoning_effort':'low','future_evaluator_required_effort':'medium',
          'counts':{'frozen_R':638,'frozen_N':142,'original_GO':len(go),'original_GC':len(cls),'original_exclusions':len(ex),
                    'newly_recovered_GO':len(recovered),'newly_recovered_distinct_unmerged_classes':len(g_new),'recovered_occurrences_merged_existing_GC':len(equivalence_audits),
                    'total_provisional_GO_occurrences':len(occ),'total_provisional_GC_classes_before_full_semantic_dedup':len(cls)+len(g_new),
                    'pdf_quotation_candidates_exact_text_verified':pdf_matched,'R_source_to_G_candidates_reconciled':len(links),
                    'all_original_GC_semantic_final_decisions_committed':0},
          'status_breakdown':stats,'validation':validations,
          'input_sha256':{'pdf':pdf_digest,'R':sha(R),'N':sha(N),'phase02_go':sha(P02/'02_generated_atoms_final.jsonl'),
                         'phase02_gc':sha(P02/'02_generated_classes_final.jsonl'),
                         'phase02_excluded':sha(P02/'02_excluded_units.jsonl'),
                         'phase03_coverage':sha(P03/'03_source_coverage.jsonl'),'phase04_coverage':sha(P04/'04_coverage_audit.jsonl'),
                         'sources':{k:v['sha'] for k,v in sources.items()}},
          'limitations_en':[
            'Every generated class has original-line verification and literal PDF retrieval witnesses; these are not complete semantic entailment judgments.',
            'Recovered claims use superseding IDs without altering Phase02. Their semantic equivalence with original GO/GC classes requires independent proof and possible Phase06 consolidation.',
            'Explicitly documentary or cross-reference statements can be excluded from effective eligibility; other short or context-dependent classes remain provisional, never silently rejected.',
            'No candidate is scored PDF_UNSUPPORTED or FP solely because the PDF text search found a weak match.',
            'Negative controls and unsupported-residual semantic de-duplication belong to Phase06; unresolved final class and R cells are adjudicated in Phase07.',
            'This implementation is an original-source/lexical-similarity and conservative semantic-risk inventory, not exhaustive independent human semantic verification of 2178 claims.',
            'Phase06 evaluator requires medium reasoning effort; current operator asks low, so external comparability cannot be asserted until corrected or explicitly reconciled.'
          ],
          'outputs_sha256':{p.name:sha(p) for p in [p1,p2,p3,p4,p5,p7]}}
 p6=save_json('05_validity_validation.json',summary)
 report=f'''# Phase 05 - Generated Validity Audit (Version 10.6)

Status: COMPLETE_PROVISIONAL_VALIDITY_INVENTORY. Generation method: twolevel.

## Scope and integrity

- Frozen R: 638; frozen N: 142; PDF physical pages: 90.
- Original Phase02 GO: {len(go)}; original GC: {len(cls)}; excluded fragments reassessed: {len(ex)}.
- Recovered affirmative fragments: {len(recovered)} with new, stable Phase05 IDs; provisional total GO: {len(occ)} and provisional unmerged GC: {len(cls)+len(g_new)} (two recovered occurrences merge existing GC).
- Original source and PDF SHA-256 locks: PASS. Original Phase01-04 outputs are unchanged.
- Exact verified PDF-quotation candidate records: {pdf_matched}. Source-to-generated R links reconciled: {len(links)}.

## Preliminary PDF relevance categories (NOT truth labels)

'''
 for k,v in sorted(stats['class_counts'].items()):report+=f'- {k}: {v}\n'
 report+='\n## Eligibility reassessment (NOT final GC scores)\n\n'
 for k,v in sorted(stats['class_eligibility'].items()):report+=f'- {k}: {v}\n'
 report+='\n## Exclusion reassessment\n\n'
 for k,v in sorted(stats['exclusion_actions'].items()):report+=f'- {k}: {v}\n'
 report+='''
## Evidence and scoring boundaries

The quoted PDF candidate is an exact verified text excerpt from a particular physical page, not a proof that the complete generated assertion is entailed. Short claims, absent exact text, descriptions of unresolved choices and source-register abstractions require independent full-scope checking. Thus no final G:TP/G:FP, canonical TP/FN, FP/TN, Precision, Recall or F1 is committed at this stage.

Phase06 must inspect all frozen negative controls, review unsupported generated-only residuals and overlaps, and build an exhaustive queue of unresolved R/N/GC under the original v5 suggestion logic. Phase07 is required to independently adjudicate final cells. Partial scans never license fabricated final counts.

## Files

- `05_generated_claim_validity.jsonl`: one auditable candidate PDF witness per original GC (up to three).
- `05_exclusion_reassessment.jsonl`: one reassessment per excluded fragment.
- `05_recovered_atoms.jsonl`: additive recovered observations with original line attribution.
- `05_source_generated_link_audit.jsonl`: unchanged frozen R to candidate generated links.
- `05_occurrence_crosswalk.jsonl`: original and recovered GO-to-GC membership and eligibility.
- `05_recovered_equivalence_audit.jsonl`: two recorded exact-equivalence merges of recovered atoms into existing classes.
- `05_validity_validation.json`: integrity results and input/output digests.
- `audit_phase05.py`: reproducible, read-only processing script.

## Limitations

The lexical PDF scan checks all 90 pages for each original class and verifies all returned source snippets, but cannot decide complete semantic entailment, contradictory exceptions or conjoined multi-file proofs. Confident absence is not inferred from a retrieval miss. This step is a provenance-backed provisional classification and recovery audit, not a semantic pass-rate or a final FP determination.
'''
 (OUT/'05_validation_report.md').write_text(report,encoding='utf8')
 print(json.dumps({'phase':'05','original_GC':len(rows),'excluded':len(excludes),'recovered':len(recovered),'unique_new_recovered_classes':len(g_new),'pdf_witnesses':pdf_matched,'stats':stats},indent=2))


def _manifest_sources(obj):
 if isinstance(obj,list):return obj
 if isinstance(obj,dict):
  for key in ('source_roles','eight_sources','markdown_sources','source_files','inputs','original_markdown_files','sources','files'):
   x=obj.get(key)
   if isinstance(x,list):return x
   if isinstance(x,dict):return list(x.values())
 return []

if __name__=='__main__':main()
