# Phase 05 - Generated Validity Audit (Version 10.6)

Status: COMPLETE_PROVISIONAL_VALIDITY_INVENTORY. Generation method: twolevel.

## Scope and integrity

- Frozen R: 638; frozen N: 142; PDF physical pages: 90.
- Original Phase02 GO: 2349; original GC: 2178; excluded fragments reassessed: 5833.
- Recovered affirmative fragments: 7 with new, stable Phase05 IDs; provisional total GO: 2356 and provisional unmerged GC: 2183 (two recovered occurrences merge existing GC).
- Original source and PDF SHA-256 locks: PASS. Original Phase01-04 outputs are unchanged.
- Exact verified PDF-quotation candidate records: 6555. Source-to-generated R links reconciled: 638.

## Preliminary PDF relevance categories (NOT truth labels)

- ELIGIBILITY_CONTEXT_REVIEW_REQUIRED: 51
- EXCLUDED_NONDEFINITIVE_REASSESSMENT: 128
- PDF_DIRECT_TEXT_MATCH_PROVISIONAL: 9
- PDF_NO_STRONG_MATCH_NOT_PROOF_OF_UNSUPPORTEDNESS: 52
- PDF_PLAUSIBLE_SUPPORT_REQUIRES_FULL_PREDICATE_CHECK: 1155
- PDF_WEAK_OR_PARTIAL_CANDIDATE_REQUIRES_ADJUDICATION: 783

## Eligibility reassessment (NOT final GC scores)

- DEFINITIVE_PROVISIONAL: 1999
- ELIGIBILITY_REVIEW_REQUIRED: 51
- NONDEFINITIVE_DOCUMENTATION_OR_MAPPING: 128

## Exclusion reassessment

- CONTEXT_PRESENT_WITH_SAME_UNIT_GO: 2320
- EXCLUSION_RECHECKED_REMAINS_NONDEFINITIVE_OR_INCOMPLETE: 1383
- EXCLUSION_UPHELD_NONDEFINITIVE: 1423
- EXCLUSION_UPHELD_STRUCTURAL_OR_SOURCE_REFERENCE: 700
- RECOVER_DEFINITIVE_ATOM_SUPERSEDING_EXCLUSION: 7

## Evidence and scoring boundaries

The quoted PDF candidate is an exact verified text excerpt from a particular physical page, not a proof that the complete generated assertion is entailed. Short claims, absent exact text, descriptions of unresolved choices and source-register abstractions require independent full-scope checking. Thus no final G:TP/G:FP, canonical TP/FN, FP/TN, Precision, Recall or F1 is committed at this stage.

Phase06 must inspect all frozen negative controls, review unsupported generated-only residuals and overlaps, and build an exhaustive queue of unresolved R/N/GC under the original v5 suggestion logic. Phase07 is required to independently adjudicate final cells. Partial scans never license fabricated final counts.

## Files

- `05_generated_claim_validity.jsonl`: one auditable candidate PDF witness per original GC (up to three).
- `05_exclusion_reassessment.jsonl`: one reassessment per excluded fragment.
- `05_recovered_atoms.jsonl`: additive recovered observations with original line attribution.
- `05_source_generated_link_audit.jsonl`: unchanged frozen R to candidate generated links.
- `05_occurrence_crosswalk.jsonl`: original and recovered GO-to-GC membership and eligibility.
- `05_recovered_equivalence_audit.jsonl`: two recorded exact-equivalence merges of recovered atoms into existing classes.
- `05_validity_validation.json`: integrity results and input/output digests.
- `audit_phase05.py`: reproducible, read-only processing script.

## Limitations

The lexical PDF scan checks all 90 pages for each original class and verifies all returned source snippets, but cannot decide complete semantic entailment, contradictory exceptions or conjoined multi-file proofs. Confident absence is not inferred from a retrieval miss. This step is a provenance-backed provisional classification and recovery audit, not a semantic pass-rate or a final FP determination.
