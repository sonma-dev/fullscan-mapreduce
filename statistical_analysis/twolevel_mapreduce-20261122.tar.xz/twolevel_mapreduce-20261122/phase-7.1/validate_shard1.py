#!/usr/bin/env python3
"""Independent structural/source verification for the twolevel Phase07 Shard1 artifacts.

Checks complete partition, original citations, SHA, external suggestions, and
explicit non-scoring exclusions. Does not pretend that quote presence alone
constitutes semantic entailment.
"""
import collections, hashlib, json, re, unicodedata
from pathlib import Path
import fitz
BASE=Path('/mnt/data');DIR=BASE/'OrionDesk_twolevel_v10.6_Phase07_Shard1'
PDF=BASE/'OrionDesk_AI_Detailed_Design_Specification(3).pdf'
FILES=['01_screen_functions(3).md','02_api(3).md','03_data(3).md','04_batch_functions(4).md','05_business_rules(3).md','06_exception_handling(5).md','07_processing_flows(5).md','08_architecture_decision(4).md']
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
norm=lambda s:' '.join(unicodedata.normalize('NFKC',str(s)).split()).casefold()
read=lambda p:[json.loads(s) for s in Path(p).open() if s.strip()]
s= json.loads((DIR/'07_shard1_summary.json').read_text());assign=read(DIR/'07_shard1_assignments.jsonl');d=read(DIR/'07_shard1_adjudications.jsonl');a=read(DIR/'07_shard1_decision_audit.jsonl');ext=read(BASE/'semantic_decisions.jsonl')
assert len(assign)==len(ext)==2963 and len(d)==len(a)==1482
assert len({x['item_id'] for x in assign})==2963
assert len({x['item_id'] for x in d})==1482
selected=[x for x in assign if x['shard_id']=='S1'];other=[x for x in assign if x['shard_id']=='S2']
assert len(selected)==1482 and len(other)==1481
assert [x['item_id'] for x in selected]==[x['item_id'] for x in d]==[x['item_id'] for x in a]
for direction in ['R','N','G']:
 sub=[x for x in assign if x['direction']==direction]
 assert all(x['position_within_direction_one_based']==i+1 and x['shard_id']==('S1' if i%2==0 else 'S2') for i,x in enumerate(sub))
assert all(ext[x['original_queue_position_one_based']-1]['item_id']==x['item_id'] for x in assign)
with fitz.open(PDF) as doc: pages=[p.get_text(sort=False)+'\n'+p.get_text(sort=True) for p in doc]
assert len(pages)==90
spec={f:(BASE/f).read_text(encoding='utf-8-sig').splitlines() for f in FILES}
assert sha(PDF)==s['pdf_sha256']
assert all(sha(BASE/f)==s['source_markdown_role_sha256'][f] for f in FILES)
assert s['external_semantic_decisions_sha256']==sha(BASE/'semantic_decisions.jsonl')
assert s['batch_journals_sha256']==sha(BASE/'batch_journals.zip')
checks=collections.Counter();c=collections.Counter()
for i,(x,z) in enumerate(zip(d,a)):
 assert x['record_type']=='ASSISTANT_ADJUDICATION' and x['decision_origin']=='PHASE07_SHARD1_ASSISTANT'
 assert x['shard_id']=='S1' and x['method']=='twolevel' and x['source_reference_unchanged']
 assert x['item_id']==z['item_id'] and x['direction']==z['direction']
 assert x['external_evaluation_model']=='gpt-6.2-sol' and x['external_evaluation_reasoning_effort']=='high'
 assert x['prior_v5_suggested_decision']==ext[[q['item_id'] for q in ext].index(x['item_id'])]['suggested_decision']
 if x['direction']=='R':assert x['final_cell'] in ('TP','FN')
 elif x['direction']=='N':assert x['final_cell'] in ('TN','FP')
 else:
  if x['eligible']:assert x['final_cell'] in ('TP','FP')
  else:assert x['final_cell'] is None and x['canonical_counting_scope']=='NOT_ELIGIBLE_EXCLUDED'
 assert x['decision_reason_en'] and x['pdf_evidence'] and x['generated_evidence'] and x['examined_original_line_candidates']
 if x['eligible'] and x['final_cell'] in ('FN','FP'): assert x['unmet_predicates_en'] if x['direction'] in ('R','G') else True
 for e in x['pdf_evidence']:
  pg=e['physical_page'];assert 1<=pg<=90 and e['source_pdf_sha256']==s['pdf_sha256']
  if e['quote_en']:
   assert norm(e['quote_en']) in norm(pages[pg-1]);checks['PDF_EXACT']+=1
  else:
   assert e['visual_locator_only'];checks['PDF_VISUAL_ONLY']+=1
 for e in x['generated_evidence']:
  fn=e['file'];l=e['line_start'];h=e['line_end']
  assert fn in spec and 1<=l<=h<=len(spec[fn]);assert sha(BASE/fn)==e['source_sha256']
  assert norm(e['quote_en']) in norm('\n'.join(spec[fn][l-1:h]));checks['MARKDOWN_EXACT']+=1
 for candidate in x['examined_original_line_candidates']:
  fn=candidate['source_file'];ln=candidate['line_start'];assert fn in spec
  assert candidate['original_source_sha256']==sha(BASE/fn)
  assert norm(candidate['source_quote_en']) in norm(spec[fn][ln-1]);checks['RECIPROCAL_ORIGINAL_LINES']+=1
 c[(x['direction'],str(x['final_cell']))]+=1
assert c==collections.Counter({('R','TP'):293,('R','FN'):26,('N','TN'):71,('G','TP'):916,('G','FP'):30,('G','None'):146})
assert not (DIR/'07_shard1_input_blockers.jsonl').read_text().strip()
assert s['external_unresolved_selected']==144
assert s['eligible_null_count']==0
assert s['original_pdf_exact_quote_checks']==checks['PDF_EXACT']
assert s['original_markdown_exact_quote_checks']==checks['MARKDOWN_EXACT']
assert s['visual_only_locators']==checks['PDF_VISUAL_ONLY']
manifest=json.loads((DIR/'07_shard1_manifest.json').read_text())
for name,val in manifest['files'].items():assert sha(DIR/name)==val['sha256']
result={'record_type':'PHASE07_SHARD1_INDEPENDENT_STRUCTURAL_VALIDATION','status':'PASS','shard_id':'S1',
 'evaluated_items':len(d),'assigned_global_items':len(assign),'other_shard_items_reserved':len(other),
 'external_previously_unresolved_reviewed':144,'evidence_rechecks':dict(checks),
 'shard_cells':{f'{k}:{v}':n for (k,v),n in c.items()},
 'semantic_entailment_beyond_quotation_checks':'Not mechanically certifiable; preserved source-grounded reasons and historical candidate provenance.',
 'original_phase07_file_unchanged':True,'shard2_not_executed':True,
 'phase08_not_started':True,'phase09_not_started':True}
(DIR/'07_shard1_independent_validation.json').write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n')
print(json.dumps(result,indent=2,ensure_ascii=False))
