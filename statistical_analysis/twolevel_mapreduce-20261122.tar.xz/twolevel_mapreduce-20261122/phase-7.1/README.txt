OrionDesk AI: Twolevel v10.6, Phase 07 Shard 1

Contents:
- 07_shard1_assignments.jsonl: deterministic full-population assignment of all 2,963 external item IDs. S1=odd one-based position per R/N/G, S2=even.
- 07_shard1_adjudications.jsonl: 1,482 Shard1 item dispositions, source evidence, external v5 history and historical Phase07 linkage.
- 07_shard1_decision_audit.jsonl: per-item decision/evidence checks.
- 07_shard1_input_blockers.jsonl: empty.
- 07_shard1_summary.json: population, source digests, outcomes and limitations.
- 07_shard1_validation_report.md: human-readable scope, rationale, limitations.
- 07_shard1_independent_validation.json: independent mechanical source/provenance verification.
- run_phase07_shard1.py and validate_shard1.py: audit scripts.
- 07_shard1_manifest.json: SHA-256 of all package artifacts.

Authoritative source identity: PDF SHA-256 b71541e74564559d2cc0a84e9827086946998fbc6c627488fb9e7a7f9b0137c3.
External evaluator: Azure gpt-6.2-sol, high reasoning effort, 16-item batches, 2,963 results.

Important limitations:
This run reviewed original-source quotations and the strongest reciprocal Markdown candidates. The source-grounded judgments were reconciled with previously recorded Phase07 results. They are *not* a fresh second independent Azure/model adjudication; no new external response was manufactured. Each record identifies its historical decision. Structural verification validates quote existence and consistency, not the infallibility of semantic entailment.

Shard2 has not been executed. Final Phase07/08/09 scoring is deliberately not produced by this shard.
