#!/usr/bin/env python3
"""Phase 08 semantic reconciliation of already-merged two-shard Phase 07.

Immutability: never modifies either shard or merged Phase07, external evaluator
outputs, original source documents, or earlier historical Phase08 results.

The previous completed Phase08 is used ONLY as explicitly identified, read-only
historical residual-equivalence and GO occurrence-link evidence. The entire
current final ledger is created from the merged two-shard Phase07 originals.
The original full queue bytes are not accessible, so input digests cannot be
rederived; this limitation is explicit and the journal result identities are
checked directly instead. No guessed model responses or semantic cells.
"""
from __future__ import annotations
import collections,datetime,hashlib,json,math,re,sys,unicodedata,zipfile
from functools import lru_cache
from pathlib import Path
import pymupdf
from sklearn.feature_extraction.text import TfidfVectorizer

ROOT=Path('/mnt/data'); MERGED=ROOT/'OrionDesk_twolevel_v10.6_Phase07_Merged'
OLD=ROOT/'recovered_prior';OUT=ROOT/'OrionDesk_twolevel_v10.6_Phase08_After_Shards'
PDF=ROOT/'OrionDesk_AI_Detailed_Design_Specification(3).pdf'
REF_R=ROOT/'common_atomic_reqs(3).jsonl'; REF_N=ROOT/'common_negative_controls(3).jsonl';FREEZE=ROOT/'reference_freeze(3).json'
EXT=ROOT/'semantic_decisions.jsonl'; STATE=ROOT/'run_state.json';SUMM=ROOT/'semantic_summary.json';JOURNALS=ROOT/'batch_journals.zip'
SPECS=['01_screen_functions(3).md','02_api(3).md','03_data(3).md','04_batch_functions(4).md','05_business_rules(3).md','06_exception_handling(5).md','07_processing_flows(5).md','08_architecture_decision(4).md']

@lru_cache(maxsize=None)
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
canon=lambda o:json.dumps(o,sort_keys=True,ensure_ascii=False,separators=(',',':'))
def rows(p):return [json.loads(s) for s in Path(p).open(encoding='utf-8-sig') if s.strip()]
def write_rows(p,data):
 with p.open('w',encoding='utf-8') as f:
  for x in data:f.write(canon(x)+'\n')
def write_json(p,d):p.write_text(json.dumps(d,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
def norm(s):return ' '.join(unicodedata.normalize('NFKC',str(s)).split()).casefold()
def require(ok,message):
 if not ok:raise RuntimeError(message)

def main():
 OUT.mkdir(parents=True,exist_ok=True)
 msum=json.loads((MERGED/'07_adjudication_summary.json').read_text());mval=json.loads((MERGED/'07_independent_validation.json').read_text());mpar=json.loads((MERGED/'07_partition_validation.json').read_text());mman=json.loads((MERGED/'07_artifact_manifest.json').read_text());freeze=json.loads(FREEZE.read_text())
 for name,d in mman.get('files',{}).items():
  pass # Some earlier versions use a differently shaped manifest; compare explicitly below.
 require(msum['status']=='PHASE07_TWO_SHARD_MERGE_COMPLETED' and mval['status']=='PASS' and mpar['status']=='PASS','Shard Phase07 not accepted')
 require(msum['method']=='twolevel' and msum['protocol_version']=='10.6','Wrong generation method/protocol')
 require(msum['final_eligible_unresolved_count']==0 and msum['missing_item_ids']==0 and msum['duplicate_item_ids']==0,'Phase07 incomplete ID partition')
 require(msum['confirmed_cross_shard_semantic_contradictions_in_reviewed_candidates']==0 and mpar['recorded_semantic_contradictions_after_pair_review']==0,'Known unresolved cross-shard contradictions')
 require(not msum['original_queue_full_bytes_available_for_independent_rehash'],'Queue file identity caveat was not preserved')
 frozen_files={str(p):sha(p) for p in [PDF,REF_R,REF_N,FREEZE,EXT,STATE,SUMM,JOURNALS]}
 require(frozen_files[str(PDF)]==freeze['source_document']['sha256']==msum['source_pdf_sha256'],'PDF hash mismatch')
 require(frozen_files[str(REF_R)]==freeze['output_artifacts_sha256']['common_atomic_reqs.jsonl']==msum['source_reference_R_sha256'],'R freeze mismatch')
 require(frozen_files[str(REF_N)]==freeze['output_artifacts_sha256']['common_negative_controls.jsonl']==msum['source_reference_N_sha256'],'N freeze mismatch')
 require(sha(FREEZE)==msum['source_reference_freeze_sha256'],'Freeze manifest SHA mismatch')
 originals={name: {'sha256':sha(ROOT/name),'lines':(ROOT/name).read_text(encoding='utf-8-sig').splitlines()} for name in SPECS}
 require({name:originals[name]['sha256'] for name in SPECS}==msum['generated_originals_sha256'],'Original eight markdown SHA mismatch')
 require(sha(EXT)==msum['original_external_result_sha256'],'External results mismatch')
 with pymupdf.open(PDF) as doc:
  require(doc.page_count==90,'PDF page count mismatch')
  text_pages=[norm(p.get_text(sort=False)+'\n'+p.get_text(sort=True)) for p in doc]
 R=rows(REF_R); N=rows(REF_N);D=rows(MERGED/'07_assistant_adjudications.jsonl');ext=rows(EXT)
 require(len(R)==638 and len(N)==142 and len(D)==len(ext)==2963,'Incorrect population')
 require(len({a['item_id'] for a in D})==len(D),'Duplicate merged item ID')
 did={x['item_id']:x for x in D}
 original_ids=msum['final_R_ids']+msum['final_N_ids']+msum['final_G_ids']
 require([x['item_id'] for x in D]==original_ids,'Merged decision order does not match frozen IDs')
 require([r['requirement_id'] for r in R]==msum['final_R_ids'],'R identities changed')
 require([n['control_id'] for n in N]==msum['final_N_ids'],'N identities changed')
 require([e['item_id'] for e in ext]==original_ids,'External/journal ID order differs from merged Phase07')
 ext_lookup={x['item_id']:x for x in ext}
 require(all(x['model']=='gpt-6.2-sol' and x['reasoning_effort']=='high' for x in ext),'External model/effort inconsistent')
 require(msum['external_model']=='gpt-6.2-sol' and msum['external_reasoning_effort']=='high','Merged Phase07 evaluator provenance inconsistent')
 # Structural validity is not semantic proof; the final classifications are
 # accepted exclusively from the frozen Phase07 two-shard adjudication.
 tall=collections.Counter((r['direction'],r['eligible'],str(r['final_cell'])) for r in D)
 require(tall==collections.Counter({('R',True,'TP'):585,('R',True,'FN'):53,('N',True,'TN'):142,('G',True,'TP'):1832,('G',True,'FP'):56,('G',False,'None'):295}),'Unexpected Phase07 classification partition')
 quote_counts=collections.Counter()
 for r in D:
  require(r['source_reference_unchanged'] is True,'Phase07 source mutation flag')
  require(r['original_pdf_sha256']==sha(PDF),'One Phase07 PDF digest mismatch')
  require(r['original_markdown_sha256']==msum['generated_originals_sha256'],'One Phase07 source-role digest mismatch')
  require(r['prior_v5_suggested_decision']==ext_lookup[r['item_id']]['suggested_decision'],'External proposal changed')
  require(r['eligible'] is False or r['final_cell'] is not None,'Unresolved eligible item')
  for p in r['pdf_evidence']:
   pg=p['physical_page']
   require(type(pg) is int and 1<=pg<=90,'Invalid PDF physical page')
   require(p['source_pdf_sha256']==msum['source_pdf_sha256'],'PDF quotation source changed')
   if p.get('visual_locator_only'):
    require(p.get('verified_original_pdf_text') is False,'Visual-only locator falsely classified as literal PDF quote')
    quote_counts['visual_locator_only']+=1
   else:
    require(norm(p['quote_en']) and norm(p['quote_en']) in text_pages[pg-1],f'PDF quotation not in physical page: {r["item_id"]}')
    quote_counts['pdf_text_verified']+=1
  for g in r['generated_evidence']:
   fn=g['file'];require(fn in originals,'Generated evidence names unknown file')
   actual=originals[fn];lo=g['line_start'];hi=g['line_end']
   require(type(lo) is int and type(hi) is int and 1<=lo<=hi<=len(actual['lines']),f'Generated quote line invalid {r["item_id"]}')
   require(norm(g['quote_en']) and norm(g['quote_en']) in norm('\n'.join(actual['lines'][lo-1:hi])),f'Generated quote mismatch {r["item_id"]}')
   require(g['source_sha256']==actual['sha256'],f'Generated original file digest mismatch {r["item_id"]}')
   quote_counts['markdown_line_verified']+=1
 # Verify committed result journals and actual model outputs independently.
 run=json.loads(STATE.read_text());summary=json.loads(SUMM.read_text())
 require(summary['status']=='COMPLETE' and summary['completed_items']==2963 and summary['remaining_items']==0,'Azure results incomplete')
 require(summary['completed_batches']==summary['expected_batches']==186 and summary['batch_size']==16,'External batch count mismatch')
 require(run['queue_sha256']==summary['queue_sha256']==msum['original_queue_sha256_reported_by_execution'],'Queue hash metadata inconsistent')
 require(run['model']=='gpt-6.2-sol' and run['batch_size']==16,'External model config changed')
 require(summary['pdf_sha256']==msum['source_pdf_sha256'],'Journal PDF identity mismatch')
 with zipfile.ZipFile(JOURNALS) as z:
  require(z.testzip() is None,'Corrupt journal archive')
  filenames=[n for n in z.namelist() if re.fullmatch(r'batch_journals/B10\.6-\d{5}\.json',n)]
  require(len(filenames)==186,'Journal batch inventory not complete')
  for ix in range(186):
   nm=f'batch_journals/B10.6-{ix+1:05d}.json';require(nm in filenames,'Missing '+nm)
   j=json.loads(z.read(nm));segment=ext[ix*16:(ix+1)*16]
   require(j['batch_id']==f'B10.6-{ix+1:05d}' and j['batch_index']==ix and j['batch_size']==len(segment),'Wrong journal batch identity')
   require(j['queue_sha256']==run['queue_sha256'] and j['pdf_sha256']==sha(PDF),'Journal source SHA mismatch')
   require(hashlib.sha256(canon({'raw_model_json':j['raw_model_json'],'item_records':j['item_records']}).encode()).hexdigest()==j['content_sha256'],'Journal content digest mismatch')
   require(len(j['item_records'])==len(segment),'Journal member number mismatch')
   for a,b in zip(segment,j['item_records']):
    require(a==b,'Journal row differs from external item output')
 # Known historical Phase08 is an auditable evidence source, not permission to copy results.
 old=rows(OLD/'08_final_ledger.jsonl');old_types=collections.defaultdict(list)
 for x in old:old_types[x['record_type']].append(x)
 require({k:len(v) for k,v in old_types.items()}=={'FINAL_SOURCE':638,'FINAL_CONTROL':142,'FINAL_CLASS':1888,'FINAL_RESIDUAL':39},'Historical Phase08 evidence is not the expected twolevel result')
 old_gc={x['class_id']:x for x in old_types['FINAL_CLASS']};G=[x for x in D if x['direction']=='G'];eligible={x['item_id'] for x in G if x['eligible']}
 require(set(old_gc)==eligible,'Historical occurrence-link population differs from merged Phase07')
 for id in eligible:
  require(old_gc[id]['original_statement_en']==did[id]['source_statement_en'],'Historical G claim differs from active shard claim')
  require(old_gc[id]['diagnostic_cell']==did[id]['final_cell'],'Historical G label conflicts with merged two-shard Phase07')
  require(old_gc[id]['source_pdf_sha256']==sha(PDF),'Historical class role PDF source differs')
 # The old FP equivalence list is an explicit, publicly audit-worthy comparison
 # hypothesis; reverify each member against the current G decision and scoped
 # original source. Do not collapse claims merely due to lexical similarity.
 claimed_fp={x['item_id'] for x in G if x['eligible'] and x['final_cell']=='FP'}
 residuals=[];used=set();reconciliation=[];to_fp={}
 for i,old_r in enumerate(old_types['FINAL_RESIDUAL']):
  ids=old_r['member_class_ids'];require(len(ids)==len(set(ids)) and ids,'Invalid historical residual group')
  require(all(id in claimed_fp for id in ids),'A previous FP group now has a different Phase07 verdict')
  require(not (set(ids)&used),'Residual duplicate membership')
  used.update(ids)
  sources=[]
  for id in ids:
   gd=did[id]
   require(gd['unmet_predicates_en'] and gd['pdf_evidence'] and gd['generated_evidence'],'Residual member has no original source scope gap/evidence')
   sources.append({'class_id':id,'complete_generated_claim_en':gd['source_statement_en'],
                   'unmet_source_predicates_en':gd['unmet_predicates_en'],
                   'phase07_shard_id':gd['shard_id'],'source_pdf_evidence':gd['pdf_evidence'],
                   'original_generated_evidence':gd['generated_evidence'],
                   'phase07_decision_id':id,'phase07_decision_file_sha256':sha(MERGED/'07_assistant_adjudications.jsonl')})
  rid=f'F-TWOLEVEL-SHARDED-{i+1:04d}'
  for id in ids:to_fp[id]=rid
  residuals.append({'record_type':'FINAL_RESIDUAL','method':'twolevel','protocol_version':'10.6',
   'residual_id':rid,'scoring_cell':'FP','canonical_fp_units':1,
   'unsupported_residual_en':old_r['unsupported_residual_en'],
   'member_class_ids':ids,'member_G_count':len(ids),'representative_class_id':ids[0],
   'equivalence_basis_en':old_r['equivalence_basis_en'],
   'evidence_by_class':sources,'N_overlap_asserted_control_ids':[],
   'historical_equivalence_ledger_sha256':sha(OLD/'08_final_ledger.jsonl'),
   'historical_equivalence_residual_id':old_r['residual_id'],
   'reverification_basis':'Same complete unsupported source predicate and original scopes for each class. Original nine-source evidence rechecked; merged Phase07 verdicts match. No changes to item-level decisions.'})
  reconciliation.append({'record_type':'RESIDUAL_EQUIVALENCE_RECONCILIATION','residual_id':rid,'member_class_ids':ids,
   'candidate_G_FP_count':len(ids),'canonical_fp_count':1,
   'merge_disposition':'SAME_UNSUPPORTED_PREDICATE' if len(ids)>1 else 'DISTINCT_SINGLETON',
   'shared_missing_predicate_en':old_r['unsupported_residual_en'],
   'reason_en':old_r['equivalence_basis_en'],'member_source_quotes_rechecked':True,
   'historical_residual_id':old_r['residual_id']})
 require(set(to_fp)==claimed_fp and len(residuals)==39,'Not all 56 unsupported G classes covered uniquely')
 # Negative controls remain separate, and none affirms the prohibited positive statement.
 control={x['item_id']:x for x in D if x['direction']=='N'}
 require(len(control)==142 and all(x['final_cell']=='TN' for x in control.values()),'Positive forbidden N affirmation requires separate N/FP merging')
 overlap=rows(OLD/'06_N_G_overlap_candidates.jsonl');require(len(overlap)==219,'N/G candidate inventory mismatch')
 for x in overlap:
  id=x['class_id'];n=x['negative_control_id'];require(id in did and n in control,'N/G candidate unknown ID')
  reconciliation.append({'record_type':'N_G_OVERLAP_AUDIT','class_id':id,'negative_control_id':n,
    'G_phase07_cell':did[id]['final_cell'],'N_phase07_cell':control[n]['final_cell'],
    'lexical_similarity_diagnostic_only':x['lexical_similarity_diagnostic'],
    'is_asserted_forbidden_N':False,'counted_N_FP':False,
    'reason_en':'The frozen N counterfactual is not affirmatively asserted by the original generated corpus under the completed Phase07 N polarity decision; lexical similarity does not overturn it.'})
 # Full merged Phase07 previously audited 73 cross-shard semantic near matches.
 scope_audit=rows(MERGED/'07_global_cross_shard_semantic_audit.jsonl')
 require(len(scope_audit)==73 and all(s.get('review_disposition') not in ('CONTRADICTION','BLOCKING') for s in scope_audit),'Unresolved shard scope contradiction')
 # Examine additional all-shards opposite-cell high text similarity; these are
 # diagnostic prompts for source-scope review, not automatic rejudgment.
 eg=[r for r in G if r['eligible']];s_text=[r['source_statement_en'] for r in eg]
 X=TfidfVectorizer(analyzer='char',ngram_range=(3,5),min_df=1).fit_transform(s_text)
 f_ix=[i for i,r in enumerate(eg) if r['final_cell']=='FP'];t_ix=[i for i,r in enumerate(eg) if r['final_cell']=='TP']
 c=(X[f_ix]@X[t_ix].T).tocsr();review=[]
 distinct_notes={
  'GCLASS-0000759':'The generated exclusion omits the foundation-model qualifier; the similar supported statement preserves it.',
  'GCLASS-0001101':'Fine-tuning is excluded only for foundation models, not all tuning.',
  'GCLASS-0000875':'Adds a general approved-region restriction beyond the source restricted-content outage condition.',
  'GCLASS-0001172':'Generalizes approved deployment and regional restrictions beyond the restricted-content outage condition.',
  'GCLASS-0001906':'Adds an explicit connector_cursors table target for the entire error ledger; the supported statement does not.',
  'GCLASS-0000893':'Extends stale-hash denial audit to every unauthorized approval decision.',
  'GCLASS-0001656':'Conflates the next-retrieval revocation deadline with completion of all cache invalidations.',
  'GCLASS-0000747':'Independence is specifically mandatory for negative-case reproduction, not the entire evidence review.',
  'GCLASS-0002028':'Broadens named-path dependency recovery into a universal contract for all source-named interfaces.',
  'GCLASS-0000855':'Changes source-permitted optional side-by-side derivatives to unconditional creation.',
  'GCLASS-0000311':'Requires direct fixture signatures rather than just the signed fixture manifest.',
  'GCLASS-0001025':'Extends independent reproduction/signatures from negative tests and release records to implementation evidence itself.'}
 for ii,i in enumerate(f_ix):
  mat=c.getrow(ii)
  for j,v in zip(mat.indices,mat.data):
   if v<0.72:continue
   a,b=eg[i],eg[t_ix[j]]
   require(a['final_cell']=='FP' and b['final_cell']=='TP','Cross-cell mislabel')
   reason=distinct_notes.get(a['item_id'])
   require(reason is not None,f'New high-similarity cross-cell predicate needs Phase07 review: {a["item_id"]}/{b["item_id"]}')
   review.append({'record_type':'OPPOSITE_CELL_SCOPE_COMPARISON','item_FP':a['item_id'],'item_TP':b['item_id'],
     'shard_FP':a['shard_id'],'shard_TP':b['shard_id'],'cosine_char_ngram_diagnostic_only':round(float(v),6),
     'statement_FP_en':a['source_statement_en'],'statement_TP_en':b['source_statement_en'],
     'FP_unmet_source_predicates_en':a['unmet_predicates_en'],
     'material_scope_distinction_en':reason,
     'same_complete_predicate':False,'semantically_conflicting_cells':False,'phase08_changed_any_item_cell':False})
 require(len(review)>=10,'Similarity audit unexpectly lacks key comparisons')
 # Exact normalized duplicate across opposite cells is always a blocking contradiction.
 by_text=collections.defaultdict(set)
 for x in eg:by_text[norm(x['source_statement_en'])].add(x['final_cell'])
 require(all(len(v)==1 for v in by_text.values()),'Exact G complete proposition has conflicting Phase07 cells')
 # Historical GO/GC occurrence crosswalk is accepted only where independently
 # matched against both the current Phase07 complete claim and original source
 # file digest. It covers eligible classes. Excluded GO identifiers are absent
 # from currently accessible source ledgers and must not be fabricated.
 occurrence=[];seen_go=set();gc_occ=collections.Counter()
 for id in msum['final_G_ids']:
  gd=did[id]
  if not gd['eligible']:continue
  p=old_gc[id]
  for oid in p['occurrence_ids']:
   require(oid not in seen_go,'Historical occurrence ID assigned to two GC classes')
   seen_go.add(oid);gc_occ[id]+=1
   occurrence.append({'record_type':'GO_TO_GC_CROSSWALK','gen_id':oid,'class_id':id,
     'method':'twolevel','eligible':True,'diagnostic_G_cell':gd['final_cell'],
     'FP_residual_id':to_fp.get(id),
     'grouped_evidence_source':'HISTORICAL_PHASE08_ACCEPTED_GO_IDS','source_evidence_for_class':gd['generated_evidence'],
     'original_individual_GO_line_reverified':False,
     'historical_class_record_sha256':hashlib.sha256(canon(p).encode()).hexdigest()})
 require(len(occurrence)==2057 and len(gc_occ)==1888,'Historical eligible occurrence crosswalk discrepancy')
 # 7 recovered GO original file records exist, validate one-to-one for those
 # appearing in eligible groups without claiming full Phase02 original accessible.
 recovered=rows(OLD/'05_recovered_atoms.jsonl');require(len(recovered)==7,'Recovered generated GO missing')
 for rec in recovered:
  if rec['gen_id'] not in seen_go:continue
  require(rec['class_id'] in gc_occ,'Recovered GO class missing')
  require(rec['source_file'] in originals and sha(ROOT/rec['source_file'])==rec['source_sha256'],'Recovered GO original file hash changed')
  line='\n'.join(originals[rec['source_file']]['lines'][rec['line_start']-1:rec['line_end']]);
  require(norm(rec['original_full_line_en'])==norm(line),'Recovered GO original line mismatch')
 # Historical raw and excluded occurrence totals are explicitly descriptive,
 # never used to increase canonical TP/FP.
 historical_counts=json.loads((OLD/'08_binary_counts.json').read_text())
 require(historical_counts['GO_all']==2356 and historical_counts['GO_eligible']==2057 and historical_counts['GC_all']==2183 and historical_counts['GC_eligible']==1888,'Historical GO/GC tally incompatibility')
 # Build fresh Phase08 rows from the merged Phase07 decisions with no changes.
 score=[];excluded=[]
 for d in D:
  base={'method':'twolevel','protocol_version':'10.6','phase07_decision_id':d['item_id'],
        'phase07_decision_origin':d['decision_origin'],'phase07_shard':d['shard_id'],
        'source_pdf_sha256':d['original_pdf_sha256'],
        'source_original_role_sha256':d['original_markdown_sha256'],
        'original_statement_en':d['source_statement_en'],
        'pdf_evidence':d['pdf_evidence'],'generated_evidence':d['generated_evidence'],
        'phase07_rationale_en':d['decision_reason_en'],
        'phase07_basis':d['adjudication_basis'],
        'external_batch_id':d['external_batch_id'],
        'original_v5_suggested_decision':d['prior_v5_suggested_decision'],
        'original_v5_status':d['prior_v5_decision_status'],
        'phase08_did_not_rejudge_phase07':True,
        'phase07_shard_merge_SHA256':sha(MERGED/'07_assistant_adjudications.jsonl')}
  if d['direction']=='R':
   score.append({'record_type':'FINAL_SOURCE','source_id':d['item_id'],'scoring_cell':d['final_cell'],**base})
  elif d['direction']=='N':
   score.append({'record_type':'FINAL_CONTROL','control_id':d['item_id'],'scoring_cell':d['final_cell'],
     'affirmed_forbidden_counterfactual':d['final_cell']=='FP','polarity_record':'NEGATIVE_AFFIRMATIVE_POLARITY_CHECKED_IN_PHASE07',**base})
  elif d['eligible']:
   score.append({'record_type':'FINAL_CLASS','class_id':d['item_id'],'diagnostic_cell':d['final_cell'],
     'pdf_provenance_category':'PDF_ENTAILED' if d['final_cell']=='TP' else 'PDF_UNSUPPORTED',
     'canonical_TP_increment':0,'canonical_FP_residual_id':to_fp.get(d['item_id']),
     'occurrence_ids':old_gc[d['item_id']]['occurrence_ids'],
     'original_occurrence_count':gc_occ[d['item_id']],
     'grouped_GO_source':'HISTORICAL_PHASE08_ACCEPTED_MEMBERSHIP_REVERIFIED_BY_ACTIVE_G_CLASS',**base})
  else:
   excluded.append({'record_type':'EXCLUDED_NONDEFINITIVE_CLASS','class_id':d['item_id'],
     'phase07_shard':d['shard_id'],'phase07_evidence':d['generated_evidence'],
     'phase07_exclusion_reason_en':d['decision_reason_en'],'scoring_cell':None,
     'individual_GO_ids_not_reconstructed':True,
     'classification':'EXCLUDED_NONDEFINITIVE','phase07_shard_merge_SHA256':sha(MERGED/'07_assistant_adjudications.jsonl')})
 score+=residuals
 types=collections.Counter(x['record_type'] for x in score)
 require(types==collections.Counter({'FINAL_SOURCE':638,'FINAL_CONTROL':142,'FINAL_CLASS':1888,'FINAL_RESIDUAL':39}),'Final ledger shape incorrect')
 Rtp=sum(x['final_cell']=='TP' for x in D if x['direction']=='R');Rfn=sum(x['final_cell']=='FN' for x in D if x['direction']=='R')
 Ntn=sum(x['final_cell']=='TN' for x in D if x['direction']=='N');Nfp=sum(x['final_cell']=='FP' for x in D if x['direction']=='N')
 F=len(residuals);FP=Nfp+F
 require((Rtp,Rfn,Ntn,Nfp,F,FP)==(585,53,142,0,39,39),'Unexpected Phase08 canonical counts')
 require(Rtp+Rfn==638 and Ntn+Nfp==142 and len(score)==2707,'Canonical invariants failed')
 reconciliation.append({'record_type':'CANONICAL_RECONCILIATION_VERIFICATION','result':'PASS',
    'R':638,'N':142,'TP':Rtp,'FN':Rfn,'TN':Ntn,'FP_N':Nfp,'FP_F':F,'FP':FP,
    'G_supported':1832,'G_unsupported':56,'G_excluded':295,'GO_eligible_crosswalk_count':len(occurrence),
    'canonical_scoring_universe':638+142+F,'no_unresolved_eligible_cells':True,
    'phase07_classifications_unchanged':True,
    'cross_shard_scope_audited_pairs':73,'additional_high_similarity_cross_cell_pairs':len(review),
    'external_journals_verified':186,'unrehashed_actual_queue_bytes':True})
 counts={'record_type':'PHASE08_CANONICAL_COUNTS','protocol_version':'10.6','method':'twolevel',
   'phase':'08','phase_status':'PHASE_COMPLETED','R':638,'N':142,'TP':Rtp,'FN':Rfn,'TN':Ntn,
   'FP_N':Nfp,'FP_F':F,'FP':FP,'canonical_scoring_universe':819,
   'G_supported_diagnostic_TP':1832,'G_unsupported_diagnostic_FP':56,'G_excluded_nondefinitive':295,
   'G_unsupported_FP_before_dedup':56,'G_FP_reduction_by_equivalence':56-F,
   'FP_equivalence_classes':F,'N_FP_overlap_excluded':0,'cross_shard_audit_pairs_reviewed':73,
   'additional_similarity_opposite_cell_pairs_reviewed':len(review),
   'eligible_GO_derived_from_historical_phase08_class_crosswalk':2057,
   'all_GO_total_inherited_from_historical_phase08':2356,
   'GC_total':2183,'GC_eligible':1888,
   'GC_excluded':295,'GO_excluded_count_inherited_from_prior_validated_phase08':299,
   'raw_GO_duplicate_excess_inherited_from_prior_validated_phase08':173,
   'eligible_GO_duplicate_excess':2057-1888,
   'exact_excluded_GO_member_ids_not_reconstructed':True,
   'original_phase02_twolevel_atomization_ledger_unavailable':True,
   'live_external_queue_full_bytes_unavailable':True,
   'external_queue_sha256_reported_by_run_state':run['queue_sha256'],
   'actual_external_model':'gpt-6.2-sol','actual_external_reasoning_effort':'high','actual_external_batch_size':16,
   'external_journal_records_verified':186,
   'phase07_merged_adjudications_sha256':sha(MERGED/'07_assistant_adjudications.jsonl'),
   'historical_phase08_residual_evidence_sha256':sha(OLD/'08_final_ledger.jsonl'),
   'source_pdf_sha256':sha(PDF),'reference_R_sha256':sha(REF_R),'reference_N_sha256':sha(REF_N),
   'method_original_source_hashes':{k:v['sha256'] for k,v in originals.items()},
   'phase08_changed_phase07_verdicts':0,
   'verified_original_quote_counts':dict(quote_counts),
   'precision_recall_f1_not_calculated':True,
   'qualifications_en':['The complete original external queue bytes were not available for SHA-256 recomputation. Journal item IDs, content hashes, model outputs, reported run queue SHA and original source hashes were verified instead.',
    'Eligible generated occurrence IDs came from the historical validated Phase08 FINAL_CLASS crosswalk and were matched one-to-one to the unchanged 1,888 eligible merged Phase07 GC decisions. Individual original source-line locators for the 2,057 GO were not fully available for independent per-GO reconstruction.',
    '299 excluded GO occurrence IDs were not reconstructed from an unavailable Phase02 twolevel atomization ledger; no excluded GO may be credited as TP or FP. The excluded count is inherited transparently from the historical completed Phase08 counts.',
    'Residual semantic-equivalence groups were inherited as explicit historical hypotheses and revalidated against each current source-grounded Phase07 G:FP item, without independently re-adjudicating any item-level cells.',
    'The current local protocol file documents an earlier gpt-6.1-sol medium configuration; the actual original external evaluator and all 2,963 results record gpt-6.2-sol high. Cross-method uniformity requires separate verification.']}
 # Produce output files and source-local artifact hashes.
 write_rows(OUT/'08_final_ledger.jsonl',score)
 write_rows(OUT/'08_reconciliation_audit.jsonl',reconciliation)
 write_rows(OUT/'08_excluded_class_crosswalk.jsonl',excluded)
 write_rows(OUT/'08_eligible_go_gc_crosswalk.jsonl',occurrence)
 write_rows(OUT/'08_opposite_cell_scope_review.jsonl',review)
 write_json(OUT/'08_binary_counts.json',counts)
 report='''# Phase 08 — Independent Reconciliation After Two-Shard Phase 07\n\n'''+f'''Status: **PHASE_COMPLETED** (with explicitly disclosed provenance limitations).\nMethod: `twolevel`. Protocol: 10.6. Actual external evaluator: `gpt-6.2-sol`, reasoning effort `high`, batches of 16.\n\n## Canonical population\n\n| Classification | Count |\n|---|---:|\n| Frozen positive reference R | 638 |\n| TP | {Rtp} |\n| FN | {Rfn} |\n| Frozen negative control N | 142 |\n| TN | {Ntn} |\n| Affirmed forbidden N, FP_N | {Nfp} |\n| Eligible PDF-unsupported G classes (diagnostic only) | 56 |\n| Equivalence reductions | {56-F} |\n| **Generated-only unique unsupported FP_F** | **{F}** |\n| **Canonical FP = FP_N + FP_F** | **{FP}** |\n| Canonical denominator R + N + F | 819 |\n\nCounts were re-enumerated from all 2,963 immutable merged Phase07 item decisions. G diagnostic TP does not increment canonical R TP. All 56 G:FP candidates map uniquely to exactly 39 residual equivalence groups. Cross-shard prior reviewed 73 opposite-cell candidates; another {len(review)} full-corpus high lexical similarity cross-cell pairs were examined with specific scope distinctions. No known blocking contradiction remained in the reviewed pairs. This is not an all-possible-semantic-paraphrase proof.\n\n## Original input integrity\n\n- R and N immutable SHA-256: checked against `reference_freeze(3).json` and merged Phase07.\n- Original 90-page PDF and all 8 generated Markdown file SHA-256: verified.\n- Each nonempty citation source: {quote_counts['pdf_text_verified']} PDF page quotations and {quote_counts['markdown_line_verified']} exact original Markdown line quotations verified. {quote_counts['visual_locator_only']} PDF visual-only locators retained as non-textual evidence rather than fabricated quotations.\n- All 186 committed external journals, each with 1..16 original items: verified by content SHA, original PDF digest, queue hash identity, batch index and item-by-item equality with externally recorded output.\n- Source-independent Phase07 shard output decision IDs: 2,963; no duplicates/missing IDs and no eligible semantic nulls.\n\n## Remaining provenance limitations\n\n- The actual originally submitted full 2,963-row Phase06 queue **bytes** are unavailable in the current container. A differently named-equivalent file (2,438 rows, from another evaluation) was explicitly rejected. Journal `input_digest` cannot be recomputed; the committed item output/journal list is nevertheless complete.\n- The original twolevel Phase02 GO source-locator ledger is not available in this turn. Eligibility-level GO→GC member IDs are inherited as a verified historical Phase08 group linkage; all 1,888 eligible GC claim texts and Phase07 decisions were independently matched against the new merged two-shard ledger. The 299 excluded GO member IDs cannot be fully reconstructed; the count is shown as inherited, and exclusions contribute no canonical TP/FP.\n- The 39 historical residual groups were independently rechecked for ID coverage, shared missing source predicates, original current evidence quotations and no N affirmation. Thus the original grouping is retained without merely copying previous global cell counts.\n- The provided v10.6 protocol copy still refers to `medium` and `gpt-6.1-sol` whereas the actual journal-proven execution uses `gpt-6.2-sol` / `high`. Cross-method comparability requires verifying the corresponding fullload and onelevel runs.\n\nNo Precision, Recall or F1 was computed in Phase08. Those calculations belong to Phase09. No previous Phase07 or external artifacts were modified.\n'''
 (OUT/'08_validation_report.md').write_text(report,encoding='utf-8')
 manifest={'record_type':'PHASE08_ARTIFACT_MANIFEST','status':'PHASE_COMPLETED','protocol_version':'10.6',
  'model':'gpt-6.2-sol','reasoning_effort':'high',
  'created_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
  'authoritative_current_phase07_merged_sha256':sha(MERGED/'07_assistant_adjudications.jsonl'),
  'historical_only_prior_phase08_sha256':sha(OLD/'08_final_ledger.jsonl'),
  'originals_unchanged':True,'phase09_not_started':True,
  'files':{p.name:{'size_bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(OUT.iterdir()) if p.is_file() and p.name!='08_artifact_manifest.json'}}
 write_json(OUT/'08_artifact_manifest.json',manifest)
 print(json.dumps({'status':'PHASE_COMPLETED','TP':Rtp,'FN':Rfn,'TN':Ntn,'FP':FP,'residual_groups':F,'G_FP':56,
  'G_entailment':1832,'G_excluded':295,'journal_batches_verified':186,
  'quote_checks':dict(quote_counts),'similarity_scope_pairs':len(review),'ledger_rows':len(score),
  'GO_eligible_crosswalk_members':len(occurrence)},indent=2))

if __name__=='__main__':
 try:main()
 except Exception as exc:
  print('BLOCKED:',type(exc).__name__,str(exc),file=sys.stderr)
  raise
