# Phase 08 — Independent Reconciliation After Two-Shard Phase 07

Status: **PHASE_COMPLETED** (with explicitly disclosed provenance limitations).
Method: `twolevel`. Protocol: 10.6. Actual external evaluator: `gpt-6.2-sol`, reasoning effort `high`, batches of 16.

## Canonical population

| Classification | Count |
|---|---:|
| Frozen positive reference R | 638 |
| TP | 585 |
| FN | 53 |
| Frozen negative control N | 142 |
| TN | 142 |
| Affirmed forbidden N, FP_N | 0 |
| Eligible PDF-unsupported G classes (diagnostic only) | 56 |
| Equivalence reductions | 17 |
| **Generated-only unique unsupported FP_F** | **39** |
| **Canonical FP = FP_N + FP_F** | **39** |
| Canonical denominator R + N + F | 819 |

Counts were re-enumerated from all 2,963 immutable merged Phase07 item decisions. G diagnostic TP does not increment canonical R TP. All 56 G:FP candidates map uniquely to exactly 39 residual equivalence groups. Cross-shard prior reviewed 73 opposite-cell candidates; another 15 full-corpus high lexical similarity cross-cell pairs were examined with specific scope distinctions. No known blocking contradiction remained in the reviewed pairs. This is not an all-possible-semantic-paraphrase proof.

## Original input integrity

- R and N immutable SHA-256: checked against `reference_freeze(3).json` and merged Phase07.
- Original 90-page PDF and all 8 generated Markdown file SHA-256: verified.
- Each nonempty citation source: 5901 PDF page quotations and 6988 exact original Markdown line quotations verified. 10 PDF visual-only locators retained as non-textual evidence rather than fabricated quotations.
- All 186 committed external journals, each with 1..16 original items: verified by content SHA, original PDF digest, queue hash identity, batch index and item-by-item equality with externally recorded output.
- Source-independent Phase07 shard output decision IDs: 2,963; no duplicates/missing IDs and no eligible semantic nulls.

## Remaining provenance limitations

- The actual originally submitted full 2,963-row Phase06 queue **bytes** are unavailable in the current container. A differently named-equivalent file (2,438 rows, from another evaluation) was explicitly rejected. Journal `input_digest` cannot be recomputed; the committed item output/journal list is nevertheless complete.
- The original twolevel Phase02 GO source-locator ledger is not available in this turn. Eligibility-level GO→GC member IDs are inherited as a verified historical Phase08 group linkage; all 1,888 eligible GC claim texts and Phase07 decisions were independently matched against the new merged two-shard ledger. The 299 excluded GO member IDs cannot be fully reconstructed; the count is shown as inherited, and exclusions contribute no canonical TP/FP.
- The 39 historical residual groups were independently rechecked for ID coverage, shared missing source predicates, original current evidence quotations and no N affirmation. Thus the original grouping is retained without merely copying previous global cell counts.
- The provided v10.6 protocol copy still refers to `medium` and `gpt-6.1-sol` whereas the actual journal-proven execution uses `gpt-6.2-sol` / `high`. Cross-method comparability requires verifying the corresponding fullload and onelevel runs.

No Precision, Recall or F1 was computed in Phase08. Those calculations belong to Phase09. No previous Phase07 or external artifacts were modified.
