#!/usr/bin/env python3
"""Independent Phase08 arithmetic/inventory and immutable lineage validation.

Run separately from reconcile_phase08_sharded.py. Reports limitations rather than
claiming to reconstruct missing original 2,963-item queue or Phase02 excluded GO.
"""
from pathlib import Path
import json,hashlib,collections,zipfile,math
BASE=Path('/mnt/data'); M=BASE/'OrionDesk_twolevel_v10.6_Phase07_Merged'; O=BASE/'OrionDesk_twolevel_v10.6_Phase08_After_Shards'
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
rows=lambda f:[json.loads(s) for s in f.open(encoding='utf-8') if s.strip()]
L=rows(O/'08_final_ledger.jsonl'); D=rows(M/'07_assistant_adjudications.jsonl'); C=json.loads((O/'08_binary_counts.json').read_text())
Gex=rows(O/'08_excluded_class_crosswalk.jsonl');X=rows(O/'08_eligible_go_gc_crosswalk.jsonl');A=rows(O/'08_reconciliation_audit.jsonl');Q=rows(O/'08_opposite_cell_scope_review.jsonl')
Dmap={x['item_id']:x for x in D};assert len(Dmap)==2963==len(D)
assert len(L)==2707
kinds=collections.Counter(x['record_type'] for x in L)
assert kinds=={'FINAL_SOURCE':638,'FINAL_CONTROL':142,'FINAL_CLASS':1888,'FINAL_RESIDUAL':39}
positives={x['source_id']:x for x in L if x['record_type']=='FINAL_SOURCE'}
negatives={x['control_id']:x for x in L if x['record_type']=='FINAL_CONTROL'}
classes={x['class_id']:x for x in L if x['record_type']=='FINAL_CLASS'}
residuals={x['residual_id']:x for x in L if x['record_type']=='FINAL_RESIDUAL'}
assert len(positives)==638 and len(negatives)==142 and len(classes)==1888 and len(residuals)==39
assert set(positives)=={x['item_id'] for x in D if x['direction']=='R'}
assert set(negatives)=={x['item_id'] for x in D if x['direction']=='N'}
assert set(classes)=={x['item_id'] for x in D if x['direction']=='G' and x['eligible']}
assert {x['class_id'] for x in Gex}=={x['item_id'] for x in D if x['direction']=='G' and not x['eligible']}
assert len(Gex)==295
for x in L:
 if x['record_type']=='FINAL_SOURCE':assert x['scoring_cell']==Dmap[x['source_id']]['final_cell']
 if x['record_type']=='FINAL_CONTROL':assert x['scoring_cell']==Dmap[x['control_id']]['final_cell']
 if x['record_type']=='FINAL_CLASS':
  p=Dmap[x['class_id']];assert x['diagnostic_cell']==p['final_cell']
  assert x['phase07_shard']==p['shard_id'] and x['original_statement_en']==p['source_statement_en']
  assert x['phase08_did_not_rejudge_phase07'] is True
TP=sum(x['scoring_cell']=='TP' for x in positives.values());FN=sum(x['scoring_cell']=='FN' for x in positives.values())
TN=sum(x['scoring_cell']=='TN' for x in negatives.values());FP_N=sum(x['scoring_cell']=='FP' for x in negatives.values())
GTP=sum(x['diagnostic_cell']=='TP' for x in classes.values());GFP=sum(x['diagnostic_cell']=='FP' for x in classes.values())
ids=collections.Counter(id for r in residuals.values() for id in r['member_class_ids'])
assert len(ids)==GFP==56 and all(v==1 for v in ids.values())
assert set(ids)=={id for id,x in classes.items() if x['diagnostic_cell']=='FP'}
assert sum(x['member_G_count']-1 for x in residuals.values())==17
assert sum(x['member_G_count']>1 for x in residuals.values())==10
for id,x in classes.items():
 if x['diagnostic_cell']=='FP':assert x['canonical_FP_residual_id'] in residuals and id in residuals[x['canonical_FP_residual_id']]['member_class_ids']
 else:assert x['canonical_FP_residual_id'] is None and x['canonical_TP_increment']==0
assert C['TP']==TP==585 and C['FN']==FN==53
assert C['TN']==TN==142 and C['FP_N']==FP_N==0 and C['FP_F']==len(residuals)==39
assert C['FP']==FP_N+len(residuals)==39 and C['canonical_scoring_universe']==638+142+len(residuals)==819
assert TP+FN==638 and TN+FP_N==142
assert GTP==1832 and GFP==56 and C['G_excluded_nondefinitive']==295
assert len(X)==2057==len({x['gen_id'] for x in X})
assert len({x['class_id'] for x in X})==1888
assert all(x['class_id'] in classes and x['diagnostic_G_cell']==classes[x['class_id']]['diagnostic_cell'] for x in X)
assert all(x['FP_residual_id']==classes[x['class_id']]['canonical_FP_residual_id'] for x in X)
assert C['original_phase02_twolevel_atomization_ledger_unavailable'] is True
assert C['live_external_queue_full_bytes_unavailable'] is True
assert C['precision_recall_f1_not_calculated'] is True
assert sum(r['record_type']=='RESIDUAL_EQUIVALENCE_RECONCILIATION' for r in A)==39
assert sum(r['record_type']=='N_G_OVERLAP_AUDIT' for r in A)==219
assert sum(r['record_type']=='CANONICAL_RECONCILIATION_VERIFICATION' for r in A)==1
assert len(Q)==C['additional_similarity_opposite_cell_pairs_reviewed']==15
assert all(not x['semantically_conflicting_cells'] for x in Q)
assert C['phase07_merged_adjudications_sha256']==sha(M/'07_assistant_adjudications.jsonl')
assert C['source_pdf_sha256']==sha(BASE/'OrionDesk_AI_Detailed_Design_Specification(3).pdf')
assert C['reference_R_sha256']==sha(BASE/'common_atomic_reqs(3).jsonl')
assert C['reference_N_sha256']==sha(BASE/'common_negative_controls(3).jsonl')
for name,h in C['method_original_source_hashes'].items():assert sha(BASE/name)==h
with zipfile.ZipFile(BASE/'batch_journals.zip') as z:assert z.testzip() is None
assert sum(C['verified_original_quote_counts'][k] for k in ('pdf_text_verified','visual_locator_only'))==5911
assert C['verified_original_quote_counts']['markdown_line_verified']==6988
status={'record_type':'PHASE08_INDEPENDENT_VALIDATION','status':'PASS_CANONICAL_WITH_DOCUMENTED_INPUT_LIMITATIONS',
'phase':'08','method':'twolevel','protocol_version':'10.6','ledger_rows_checked':len(L),
'phase07_shard_merged_records_checked':len(D),'canonical_scoring_counts':{'TP':TP,'FN':FN,'TN':TN,'FP_N':FP_N,'FP_F':len(residuals),'FP':FP_N+len(residuals)},
'generated_class_counts':{'supported':GTP,'unsupported':GFP,'excluded':len(Gex)},
'fp_candidate_groups':len(residuals),'excess_fp_classes_collapsed':GFP-len(residuals),
'phase07_items_changed_by_phase08':0,'N_G_lexical_overlap_pairs':219,'additional_cross_cell_similarity_pairs':len(Q),
'exact_eligible_go_to_gc_ids_inherited_and_uniquely_checked':len(X),
'full_2_963_original_external_queue_rehash_unavailable':True,
'excluded_original_GO_id_reconstruction_unavailable':True,
'candidate_equivalence_groups_inherited_from_prior_authoritative_phase08':True,
'prior_phase08_provenance_used_and_disclosed':True,
'canonical_arithmetic_valid':True,'all_original_source_sha256_match':True,'phase09_not_started':True,
'limitations_en':['Structural validation and verbatim quotation evidence do not constitute an independent all-pairs semantic entailment proof.',
'Original Phase02 individual GO line ledger and original external 2,963-item queue were not accessible in this container session. Do not claim those hashes or excluded GO identities were re-derived.']}
(O/'08_independent_validation.json').write_text(json.dumps(status,indent=2,ensure_ascii=False)+'\n')
# Keep hash manifest complete after independent validation itself.
mani=O/'08_artifact_manifest.json';m=json.loads(mani.read_text());m['files']={p.name:{'size_bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(O.iterdir()) if p.is_file() and p!=mani};m['independent_validation_status']=status['status'];mani.write_text(json.dumps(m,indent=2)+'\n')
print(json.dumps(status,indent=2))
