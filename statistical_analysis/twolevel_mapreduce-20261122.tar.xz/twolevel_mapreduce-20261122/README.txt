OrionDesk AI — Twolevel Sharded Evaluation Artifact Bundle
Protocol reference: v10.6; external evaluation deployment: gpt-6.2-sol; reasoning effort: high.

DIRECTORY LAYOUT
phase-1/    Phase 01 Reference Lock (including inputs/ for reproducibility)
phase-2/    Phase 02 Generated Occurrences and Semantic Classes
phase-3/    Phase 03 Source Coverage Discovery
phase-4/    Phase 04 Reciprocal TP/FN Audit
phase-5/    Phase 05 Generated Claim Validity
phase-6/    Phase 06 Negative Controls and External Evaluation Handoff
            external_evaluation/ preserves run_state, semantic_decisions, semantic_summary and original batch journals
phase-7.1/  NEW Phase 07 Shard 1
phase-7.2/  NEW Phase 07 Shard 2
phase-7.3/  NEW Phase 07 Cross-Shard Merge and Semantic Consistency Audit
phase-8/    NEW Phase 08 Reconciliation After Shards
phase-9/    NEW Phase 09 Metrics After Shards

OLD PHASE 07/08/09 EXCLUDED
No Phase 07, Phase 08 or Phase 09 files from the original pre-sharding evaluation bundle are included. The current Phase 07 Shard 1/Shard 2/merge, current Phase 08 and current Phase 09 files are preserved unmodified.

FINAL NUMERICAL RESULT
TP=585; FN=53; FP=39; TN=142.
Precision=93.75%; Recall=91.69%; F1=92.71%.
The new Phase 09 records the strict protocol status and any remaining reproducibility limitations. This packaging step does not claim to cure these limitations or independently rerun semantic judgments.

INPUT INTEGRITY
The Phase 06 original full 2,963-item queue embedded in the original pre-sharding bundle matches the immutable external execution queue SHA-256. The source PDF, eight Markdown originals, frozen references, updated evaluator and source protocol are included under phase-1/inputs/.
