#!/usr/bin/env python3
"""Phase 04 reciprocal audit, OrionDesk protocol 10.6, method twolevel.

Audits all 638 frozen positive requirements against the eight SHA-locked
original Markdown files and the immutable Phase 02/03 inventories.  A
retrieval candidate is NEVER upgraded to a final TP/FN by similarity.
Contextual E2 proof families are checked structurally and still marked
provisional until the completed bidirectional adjudication.
"""
from __future__ import annotations
import collections, datetime, hashlib, json, math, re, unicodedata
from pathlib import Path
from rapidfuzz import fuzz

ROOT=Path('/mnt/data'); RUN=ROOT/'oriondesk_twolevel_v10_6'; OUT=RUN/'phase04'
REF=ROOT/'common_atomic_reqs(3).jsonl'
PDF=ROOT/'OrionDesk_AI_Detailed_Design_Specification(3).pdf'
PROTOCOL=ROOT/'OrionDesk_One_Pass_Atomic_Evaluation_Protocol(8).md'
GO=RUN/'phase02/02_generated_atoms_final.jsonl'
GC=RUN/'phase02/02_generated_classes_final.jsonl'
INDEX=RUN/'phase02/02_original_text_index.jsonl'
P3=RUN/'phase03/03_source_coverage.jsonl'
BR=RUN/'phase03/03_semantic_coverage_bridges.jsonl'
LOCK=RUN/'phase01/01_reference_lock.json'
MAN=RUN/'phase01/01_source_reference_manifest.json'

STOP=set('the a an of and or to for from by in on with at as into over across while if than that this these those which who whose is are be being been must shall should may can cannot not no do does did will use using used each every all any only one same what when where how however without within per this its their under above below through between before after instead it also then some such have has had rather but otherwise each'.split())
COND_TOKENS={'not','never','no','only','before','after','unless','if','cannot','without','at','least','maximum','minimum','must','shall','with','or','and'}
NONCOMMITTAL=('needs confirmation','tbd','not established','not confirmed','unselected','unadopted proposal','provisional pending','no confirmed','unresolved implementation','not a confirmed','no source','needs to confirm')

def sha(p):
 h=hashlib.sha256()
 with open(p,'rb') as f:
  for chunk in iter(lambda:f.read(1<<20),b''):h.update(chunk)
 return h.hexdigest()

def jlines(path):
 with open(path,encoding='utf8') as f:return [json.loads(x) for x in f if x.strip()]

def js(path,obj):
 path.write_text(json.dumps(obj,ensure_ascii=False,indent=2,sort_keys=True)+'\n',encoding='utf8')

def jdump(path,items):
 with open(path,'w',encoding='utf8',newline='\n') as f:
  for v in items:f.write(json.dumps(v,ensure_ascii=False,sort_keys=True)+'\n')

def normal(s):
 s=unicodedata.normalize('NFKC',str(s)).lower().replace('**','').replace('`','')
 return re.sub(r'\s+',' ',s).strip()

def tok(s):return re.findall(r'[a-z0-9]+(?:[.-][a-z0-9]+)*',normal(s))

def content_tokens(s):return [x for x in tok(s) if x not in STOP and (len(x)>=3 or x.isdigit())]

def ratio(s,t):
 aa=content_tokens(s);bb=content_tokens(t)
 if not aa:return 0.0
 b=set(bb);return len(set(aa)&b)/len(set(aa))

def select_context_match(premises,source_lines,by_file):
 for pr in premises:
  file=pr['actual_file'];idx=pr['line_start'];last=pr['line_end']
  if file not in by_file or pr['source_sha256']!=by_file[file]['sha256']:return False,'FILE_OR_DIGEST_MISMATCH'
  lines=source_lines[file]
  if not(isinstance(idx,int) and 1<=idx<=last<=len(lines)):return False,'INVALID_LINE_LOCATOR'
  literal='\n'.join(lines[idx-1:last])
  if pr['quote_en'] not in literal and normal(pr['quote_en']) not in normal(literal):return False,'QUOTATION_MISMATCH'
 return True,'ORIGINAL_LINES_VERIFIED'

def main():
 OUT.mkdir(parents=True,exist_ok=True)
 lock=json.loads(LOCK.read_text(encoding='utf8'))
 manifest=json.loads(MAN.read_text(encoding='utf8'))
 assert lock['protocol_version']=='10.6' and lock['operator_request']['value']=='twolevel'
 assert sha(PDF)==manifest['authoritative_pdf']['sha256']==lock['reference']['pdf_sha256']
 assert sha(REF)==manifest['frozen_positive_ledger']['sha256']==lock['reference']['positive_sha256']
 assert sha(ROOT/'common_negative_controls(3).jsonl')==lock['reference']['negative_sha256']
 sources=manifest['source_roles']; assert len(sources)==8
 by_file={s['actual_filename']:s for s in sources}
 lines={}
 for s in sources:
  p=Path(s['original_path']);assert p.exists() and sha(p)==s['sha256'],s['actual_filename']
  lines[s['actual_filename']]=p.read_text(encoding='utf8').splitlines()

 expected_phase02=json.loads((RUN/'phase02/02_extraction_validation.json').read_text(encoding='utf8'))
 expected_phase03=json.loads((RUN/'phase03/03_discovery_validation.json').read_text(encoding='utf8'))
 assert sha(GO)==expected_phase03['phase02_generated_atoms_sha256']
 assert sha(GC)==expected_phase03['phase02_generated_classes_sha256']
 assert sha(INDEX)==expected_phase03['phase02_original_index_sha256']
 assert sha(REF)==expected_phase03['reference_positive_sha256']
 assert sha(PDF)==expected_phase03['source_pdf_sha256']
 req=jlines(REF); go=jlines(GO); classes=jlines(GC); index=jlines(INDEX)
 phase3=jlines(P3); bridges=jlines(BR)
 assert len(req)==len(phase3)==638 and len(go)==2349 and len(classes)==2178 and len(bridges)==171
 assert [x['requirement_id'] for x in req]==[x['requirement_id'] for x in phase3]
 by_bridge=collections.defaultdict(list)
 for b in bridges:by_bridge[b['requirement_id']].append(b)
 by_go={g['gen_id']:g for g in go};by_class={g['class_id']:g for g in classes}
 for g in go:
  assert g['source_file'] in by_file and by_file[g['source_file']]['sha256']==g['source_sha256']
  assert 1<=g['line_start']<=g['line_end']<=len(lines[g['source_file']])
 for d in index:
  assert d['original_text_en']==lines[d['source_file']][d['physical_line']-1]

 # Independently index *all original nonheading content lines*, preserving each real locus.
 all_units=[]
 by_token=collections.defaultdict(set)
 for f,rows in lines.items():
  for n,s in enumerate(rows,1):
   if not s.strip() or s.strip().startswith(('# ','## ','### ','#### ','```')):continue
   if re.fullmatch(r'[-|:\s]{4,}',s):continue
   unit_id=len(all_units)
   all_units.append((f,n,s))
   for t in set(content_tokens(s)):by_token[t].add(unit_id)

 def evidence_for(file,n,claim=None):
  s=lines[file][n-1]
  return {'actual_file':file,'line_start':n,'line_end':n,'source_role':by_file[file]['role'],
          'original_sha256':by_file[file]['sha256'],'original_line_quote_en':s,
          'literal_quote_verified':True,'source_corpus':'ORIGINAL_MARKDOWN'}

 def second_pass_matches(statement,preds,avoid):
  # This is a reciprocal CHALLENGE search, not an entailment classifier.
  terms=[t for t in set(content_tokens(statement+' '+' '.join(preds))) if len(t)>3]
  counter=collections.Counter()
  for t in terms:
   for i in by_token.get(t,()):counter[i]+=1
  ranked=[]
  for i,cnt in counter.items():
   f,n,s=all_units[i]
   score=0.50*(cnt/max(1,len(terms))) +0.25*ratio(statement,s) +0.25*fuzz.token_set_ratio(normal(statement),normal(s))/100
   if (f,n) in avoid:score-=0.10
   ranked.append((score,f,n,s,cnt))
  ranked.sort(key=lambda e:(-e[0],sources.index(by_file[e[1]]),e[2]))
  winners=[];seen_file=set();seen=set()
  # Diverse cross-file alternatives, to challenge ranking misses.
  for score,f,n,s,cnt in ranked:
   if (f,n) in seen:continue
   if f in seen_file:continue
   winners.append({'score_diagnostic':round(score,5),'matched_content_tokens':cnt,
                   'statement_token_recall_diagnostic':round(ratio(statement,s),3),**evidence_for(f,n)})
   seen_file.add(f);seen.add((f,n))
   if len(winners)>=8:break
  return winners, len(counter)

 def predicate_checks(preds,original_candidates):
  checks=[]
  for pred in preds:
   p=normal(pred)
   exact=[]
   for f,n,s in all_units:
    if p and len(p)>3 and p in normal(s):
     exact.append((f,n,s))
   best=sorted(original_candidates,key=lambda x:ratio(pred,x['original_line_quote_en']),reverse=True)
   checks.append({'predicate_en':pred,'literal_occurrence_count_all_eight_files':len(exact),
                  'literal_quotation_witnesses':[evidence_for(f,n) for f,n,_ in exact[:3]],
                  'best_reciprocal_candidate':{'file':best[0]['actual_file'],'line':best[0]['line_start'],
                                              'token_recall_diagnostic':round(ratio(pred,best[0]['original_line_quote_en']),3)} if best else None,
                  'literal_absence_is_not_nonentailment':True})
  return checks

 # Deliberate, narrowly scoped full-predicate semantic reviews for earlier weak matches.
 # These are separately listed for independent verification; none changes Phase 03.
 manual_proofs={
  'PDF-0001':([('01_screen_functions(3).md',13),('02_api(3).md',11),('05_business_rules(3).md',167)],'Case intake, permitted retrieval, generation and deterministic publication gate are expressly distinct but integrated.'),
  'PDF-0146':([('05_business_rules(3).md',53),('02_api(3).md',241)],'Originating document ACL filtering applies before model text release; relevance is not permission.'),
  'PDF-0314':([('05_business_rules(3).md',158),('06_exception_handling(5).md',151)],'Configured-SLA expiry reassigns or escalates, records escalation and never silently approves.'),
  'PDF-0401':([('03_data(3).md',233),('06_exception_handling(5).md',56)],'Client validation is convenience only; multiple server boundary validations are necessary.'),
  'PDF-0611':([('03_data(3).md',116),('03_data(3).md',117),('03_data(3).md',118)],'The three adjacent source-qualified SQL lines form one complete RLS + tenant-scope policy expression.'),
  'PDF-0638':([('05_business_rules(3).md',389),('08_architecture_decision(4).md',209)],'All six specified implementation-lock architecture selections require a dated decision; no source-unspecified implementation choice is assumed.'),
 }
 manual_audit=[]
 coverage=[];tp=[];fn=[];checks=collections.Counter();source_counts=collections.Counter();detail_families=collections.Counter()
 for j,(r,dis) in enumerate(zip(req,phase3)):
  rid=r['requirement_id'];statement=r['statement_en'];preds=r.get('required_predicates',[])
  assert dis['source_pdf_sha256']==sha(PDF)
  assert dis['searched_all_eight_roles'] and len(dis['generated_candidates'])>0
  # Phase03 quotations were checked already; independently verify all top-rank audit citations.
  first=dis['generated_candidates'][:12]
  candidate_evidence=[];proposed_tp=[]
  for c in first:
   f=c['actual_file'];n=c['line_start'];e=c['line_end'];q=c['quote_en'];src=by_file[f]
   assert c['source_sha256']==src['sha256']
   assert 1<=n<=e<=len(lines[f])
   base='\n'.join(lines[f][n-1:e]);assert q in base or normal(q) in normal(base),(rid,f,n)
   # True original text is used for all reciprocal diagnostics.
   confs=[a for a in NONCOMMITTAL if a in normal(base)]
   claim_go=by_go.get(c.get('gen_id'))
   pred_best=ratio(statement,base)
   evidence={
     'original':evidence_for(f,n),'phase03_rank':c['rank'],'phase03_kind':c['candidate_kind'],
     'gen_id':c.get('gen_id'),'class_id':c.get('class_id'),
     'lexical_overlap_diagnostic':round(pred_best,3),
     'contains_unselected_or_nondefinitive_qualification':bool(confs),
     'qualification_markers':confs,'used_as_entailment_verdict':False
   }
   candidate_evidence.append(evidence)
   # A GO is a potentially definitive item, but one isolated phrase is not a full proof.
   if claim_go and not confs and pred_best>=0.74:
    proposed_tp.append(evidence)
  avoid={(c['actual_file'],c['line_start']) for c in first}
  alternatives,search_hits=second_pass_matches(statement,preds,avoid)
  altern_evidence=[x for x in alternatives]
  pchecks=predicate_checks(preds,[x['original'] for x in candidate_evidence]+altern_evidence)
  missing=[]
  for p in pchecks:
   bc=p['best_reciprocal_candidate']
   if p['literal_occurrence_count_all_eight_files']==0 and (not bc or bc['token_recall_diagnostic']<0.80):
    missing.append(p['predicate_en'])
  reviewed_bridges=[];valid_bridge=False
  for bridge in by_bridge[rid]:
   all_ok,verification=select_context_match(bridge['premises'],lines,by_file)
   assert all_ok,(rid,verification)
   # Structural bridge enforces subject and obligation through two distinct source lines.
   family=bridge['bridge_family']
   intro=bridge['premises'][0]['quote_en'];detail=bridge['premises'][-1]['quote_en']
   structural= all_ok and len(bridge['premises'])>=2 and ((bridge['premises'][0]['actual_file'],bridge['premises'][0]['line_start']) != (bridge['premises'][-1]['actual_file'],bridge['premises'][-1]['line_start']))
   if family=='COMPONENT_COLUMN_INHERITANCE':
    structural=structural and 'Owner aggregate' in intro and 'Immutable derivative' in intro and 'Policy-bound control' in intro and 'Operational ledger' in intro
   supplemental=[]
   if family=='ENDPOINT_REGISTER_INVARIANT':
    exact_register= ('O+I' in detail or 'S+B' in detail or 'OAuth audience' in detail or 'Schema contract' in detail)
    registered_appendix= ('API-' in detail and ('POST' in detail or 'GET' in detail or 'PATCH' in detail))
    # API-043's per-operation applicability note explicitly supplements A.2.
    appendix_general=lines[next(f for f in lines if f.startswith('02_api('))][93]
    if not exact_register and registered_appendix and 'Primary chapter operations not marked above' in appendix_general and 'Secondary run read and SSE' in appendix_general:
     api_file=next(f for f in lines if f.startswith('02_api('))
     # For A.2 routes with O+I or run-read/SSE S+B, the general paragraph supplies the category.
     a2_subject=normal(statement)
     if ('api surface' in a2_subject and 'oauth audience' in a2_subject) or ('secondary api' in a2_subject and ('get /v1/runs/' in a2_subject or 'get /v1/streams/runs/' in a2_subject)):
      supplemental.append(evidence_for(api_file,94))
      exact_register=True
    structural=structural and ('O+I' in intro and 'S+B' in intro) and exact_register
   if family=='EVENT_REGISTER_INHERITANCE':
    # Phase 03 legitimately lists the named event first and its inherited envelope constraint second.
    expected_event=re.search(r'Published event (\w+) Versioned envelope',statement)
    event_named=bool(expected_event and ('`'+expected_event.group(1)+'`') in intro)
    # Repair, without rewriting Phase 03, an adversarial near-name hit:
    # the 'DeploymentPromoted' row mentions 'Distinct from ReleasePromoted',
    # which is NOT the ReleasePromoted event's own declaration.
    if expected_event and not event_named:
     api_file=next(f for f in lines if f.startswith('02_api('))
     exact_names=[n for n,v in enumerate(lines[api_file],1) if v.startswith('| `'+expected_event.group(1)+'` |')]
     if len(exact_names)==1:
      supplemental.append(evidence_for(api_file,exact_names[0]))
      event_named=True
    universal=('All registered events use versioned envelope/outbox' in detail) or ('All published register events require' in detail)
    structural=structural and event_named and universal
   if family=='RELATIONAL_ENTITY_SELECTED_SCHEMA':
    structural=structural and ('Confirmed selected declarations' in intro or 'Selected physical names' in intro)
   reviewed_bridges.append({'bridge_id':bridge['bridge_id'],'bridge_family':family,
                            'full_original_sha_and_exact_line_quotes':verification,
                            'source_premise_misalignment_found':(family=='EVENT_REGISTER_INHERITANCE' and bool(supplemental)),
                            'source_correction_type':'PHASE04_ADD_CORRECT_EVENT_ROW_NO_PHASE03_MUTATION' if family=='EVENT_REGISTER_INHERITANCE' and supplemental else None,
                            'structural_applicability_rechecked':structural,
                            'original_premises':bridge['premises'],'supplemental_premises':supplemental,
                            'affirmative_obligation_context':'Reference-system logical/selected contract, not fabricated physical table or inferred wire schema',
                            'proof_grade_if_semantically_accepted':'E2',
                            'final_canonical_TP_FN_decision':'NOT_COMMITTED'})
   if structural:valid_bridge=True;detail_families[family]+=1
  # Strict direct-source quote acceptance is *provisional*, pending full scope/negative examination.
  pdf_quotes=[normal(ev.get('quote','')) for ev in r['pdf_evidence'] if ev.get('quote')]
  exact_matches=[]
  for ev in candidate_evidence:
   c=ev['original']['original_line_quote_en'];cn=normal(c)
   if ev['contains_unselected_or_nondefinitive_qualification']:continue
   for q in pdf_quotes:
    if q and len(q)>=38 and q in cn:
     exact_matches.append({'evidence':ev['original'],'matching_pdf_quote_en':q,
                           'proof_scope':'PDF_QUOTATION_INSIDE_GENERATED_STATEMENT; normative_context_still_REQUIRED'})
     break
  manual_record=None
  if rid in manual_proofs:
   loci,semantic_reason=manual_proofs[rid]
   manual_record={'record_type':'MANUAL_RECIPROCAL_SEMANTIC_REVIEW','requirement_id':rid,'statement_en':statement,
                  'semantic_complete_predicate_rationale_en':semantic_reason,
                  'verified_generated_original_premises':[evidence_for(f,n) for f,n in loci],
                  'review_status':'SOURCE_CONTEXTUALLY_SUPPORTED_PROVISIONAL_E2',
                  'independent_phase07_final_cell':'NOT_COMMITTED'}
   manual_audit.append(manual_record)
  if manual_record:
   outcome='E2_CONTEXTUAL_FULL_PROOF_PROVISIONAL';grade='E2';reason=manual_record['semantic_complete_predicate_rationale_en']
  elif valid_bridge:
   outcome='E2_CONTEXTUAL_FULL_PROOF_PROVISIONAL';grade='E2';reason='Verified source-named register row plus separately applicable universal category constraint. No extra physical/wire schema inferred.'
  elif exact_matches:
   outcome='E3_DIRECT_QUOTE_FULL_PROOF_PROVISIONAL';grade='E3';reason='Complete source quotation reproduced in a generated original line without an explicit open/proposal marker; context and full predicates still require independent adjudication.'
  elif missing:
   outcome='RECIPROCAL_SEARCH_NO_FULL_PROOF_YET';grade='EU';reason='After challenging source discovery with a separate full-eight-file reciprocal search, one or more source predicates lack a decisive source-text match; this is not a proved FN.'
  else:
   outcome='POSSIBLE_CONTEXTUAL_OR_PARTIAL_COVERAGE';grade='E1';reason='Multiple potentially relevant original passages found, but literal or similarity overlap is insufficient to certify complete conditional entailment.'
  if valid_bridge:
   assert reviewed_bridges and any(x['structural_applicability_rechecked'] for x in reviewed_bridges)
  if outcome.endswith('PROVISIONAL'):tp.append({'record_type':'TP_EVIDENCE_AUDIT','protocol_version':'10.6','method':'twolevel','phase':'04',
                                              'requirement_id':rid,'statement_en':statement,'evidence_grade':grade,
                                              'proof_family':'CONTEXTUAL_CONJUNCTION' if valid_bridge else 'DIRECT_QUOTE',
                                              'verified_bridges':reviewed_bridges,'direct_quotes':exact_matches,'manual_semantic_evidence':manual_record,
                                              'challenge_best_candidate':candidate_evidence[:3],
                                              'negative_challenge':'No exhaustive semantic contradiction clearance claimed; Phase 07 final independent classification.',
                                              'provisional_only':True,'final_tp_decision':'NOT_COMMITTED'})
  if outcome in ('RECIPROCAL_SEARCH_NO_FULL_PROOF_YET','POSSIBLE_CONTEXTUAL_OR_PARTIAL_COVERAGE'):
   root='NO_DIRECT_FULL_PREDICATE_EXPRESSION' if missing else 'CONTEXT_OR_CONDITIONAL_SCOPE_NOT_YET_PROVED'
   fn.append({'record_type':'FN_ROOT_CAUSE_AUDIT','protocol_version':'10.6','method':'twolevel','phase':'04',
              'requirement_id':rid,'statement_en':statement,'phase03_discovery_status':dis['discovery_status'],
              'root_cause_candidate':root,'missing_predicates_needing_review':missing,
              'cross_file_reciprocal_challengers':altern_evidence[:4],
              'possible_generation_inventory_miss':'Phase 05 must re-examine excluded/original lines and effective GO/GC before FN can be final.',
              'final_fn_decision':'NOT_COMMITTED','warning':'This is NOT a proven false negative.'})
  row={'record_type':'R_RECIPROCAL_COVERAGE_AUDIT','phase':'04','protocol_version':'10.6','method':'twolevel',
       'requirement_id':rid,'source_pdf_sha256':sha(PDF),'statement_en':statement,
       'source_scope_en':r.get('source_scope'),'source_physical_pages':r.get('source_physical_pages'),
       'source_pdf_quotation_evidence':dis['pdf_evidence_verified'],
       'required_predicates_en':preds,'discovery_status':dis['discovery_status'],
       'original_eight_roles_searched':True,'candidate_reinspection_count':len(candidate_evidence),
       'reciprocal_full_original_line_search_units':len(all_units),
       'reciprocal_index_candidate_hits':search_hits,
       'verified_phase03_candidate_quotes':candidate_evidence,
       'independent_cross_file_challengers':altern_evidence,
       'predicate_reciprocal_checks':pchecks,'apparently_unmet_predicates_en':missing,
       'verified_contextual_bridge_audits':reviewed_bridges,'manual_semantic_review':manual_record,
       'potential_direct_GO_covered_candidates':proposed_tp[:4],
       'exact_direct_pdf_quote_witnesses':exact_matches[:4],
       'phase04_evidence_grade':grade,'phase04_outcome':outcome,'reason_en':reason,
       'proposed_miss_challenged':True,'provisional_TP_full_predicate_challenged':True,
       'phase05_exclusion_recovery_required':bool(missing) or (not valid_bridge and manual_record is None),
       'negative_control_audit_deferred_to_phase06':True,
       'final_binary_cell':'NOT_COMMITTED',
       'guardrail':'Retrieval miss alone is never proof of FN; lexically close evidence alone is never proof of TP.'}
  coverage.append(row);checks[outcome]+=1;source_counts[dis['discovery_status']]+=1

 # Hard invariants and immutable inputs rechecked after processing.
 assert len(coverage)==len(req)==638
 assert {a['requirement_id'] for a in coverage}=={a['requirement_id'] for a in req}
 assert len(tp)+len(fn)==638
 assert all(x['final_binary_cell']=='NOT_COMMITTED' and x['original_eight_roles_searched'] for x in coverage)
 assert sha(PDF)==lock['reference']['pdf_sha256'] and sha(REF)==lock['reference']['positive_sha256']
 assert sha(GO)==expected_phase03['phase02_generated_atoms_sha256'] and sha(GC)==expected_phase03['phase02_generated_classes_sha256']
 assert all(x['proposed_miss_challenged'] and x['provisional_TP_full_predicate_challenged'] for x in coverage)
 out_names=('04_coverage_audit.jsonl','04_tp_evidence_audit.jsonl','04_fn_root_cause_audit.jsonl')
 for f,v in zip(out_names,[coverage,tp,fn]):jdump(OUT/f,v)
 jdump(OUT/'04_manual_semantic_review.jsonl',manual_audit)
 summary={'record_type':'PHASE_04_AUDIT_VALIDATION','phase':'04','protocol_version':'10.6',
          'specification_generation_method':'twolevel','operator_reasoning_effort':'low',
          'phase_status':'PHASE_COMPLETED_WITH_PROVISIONAL_SEMANTIC_DECISIONS',
          'input_identity':{'pdf_sha256':sha(PDF),'reference_sha256':sha(REF),
                           'go_sha256':sha(GO),'gc_sha256':sha(GC),'phase03_coverage_sha256':sha(P3),
                           'phase03_bridges_sha256':sha(BR),
                           'eight_sources':[{'actual_file':x['actual_filename'],'sha256':x['sha256']} for x in sources]},
          'counts':{'frozen_R':638,'frozen_N':142,'GO':2349,'GC':2178,
                    'audited_R':len(coverage),'fully_challenged_proposed_misses':len(coverage),
                    'full_predicate_tp_challenges':len(coverage),'original_content_lines_in_reciprocal_scan':len(all_units),
                    'contextual_bridge_proof_families_verified':sum(detail_families.values()),
                    'phase03_wrong_event_row_proof_repaired_without_input_mutation':sum(bool(x.get('source_premise_misalignment_found')) for y in coverage for x in y['verified_contextual_bridge_audits']),
                    'individual_manual_semantic_reviews':len(manual_audit),
                    'contextual_bridge_families_by_type':dict(detail_families),
                    'phase04_outcomes':dict(checks),'tp_evidence_audit_rows':len(tp),
                    'fn_root_cause_audit_rows':len(fn),
                    'canonical_TP_FN_scores_committed':0,'proven_FN_based_on_retrieval_only':0},
          'source_discovery_status_audited':dict(source_counts),
          'output_sha256':{name:sha(OUT/name) for name in (*out_names,'04_manual_semantic_review.jsonl')},
          'checks':{'R_ids_all_present':len(coverage)==638,
                    'all_eight_input_markdown_SHA_locked':True,
                    'immutable_R_N_GO_GC_preserved':True,
                    'no_retrieval_miss_coerced_to_FN':True,
                    'no_lexical_match_coerced_to_final_TP':True,
                    'contextual_premises_verified_original_line_by_line':True,
                    'phase04_no_final_metrics':True},
          'limitations_en':[
              'Phase 04 grades are evidence-audit assessments, not final canonical TP/FN cell commits. Phase 05 must re-assess excluded units and recover missed definitive claims.',
              'Structural E2 proofs cover explicitly recorded logical/selected register invariants, not invented physical tables, schemas, endpoint response bodies or event triggers.',
              'Exact reproduced PDF quotations are source-context candidates and do not prove an entire multi-condition obligation without contextual review.',
              'Automated full-corpus reciprocal searches are exhaustive for indexed original lines and literal terms, not an exhaustive human semantic judgment for each paraphrase.',
              'Phase 06 negative controls and Phase 07 mandatory item-level binary adjudications are pending; no precision/recall is reported.',
              'The operator requested low reasoning effort, whereas protocol Phase 06 externally mandates medium; comparability remains unresolved until that handoff.'
          ]}
 js(OUT/'04_audit_validation.json',summary)
 md='''# Phase 04 - TP/FN Reciprocal Audit\n\nStatus: **PHASE_COMPLETED_WITH_PROVISIONAL_SEMANTIC_DECISIONS**\n\n- Protocol: 10.6\n- Generation method: twolevel\n- Source and generated inputs: eight SHA-256-locked Markdown sources, 90-page original PDF, frozen 638 R / 142 N.\n- Earlier phase inputs: unchanged.\n\n## Audit counts\n\n'''
 md+='| Check | Count |\n|---|---:|\n'
 md+=f'| Source R obligations audited | {len(coverage)} |\n| Full original content lines independently searched | {len(all_units)} |\n| Contextual E2 bridge proofs structurally verified | {sum(detail_families.values())} |\n'
 for k,v in checks.items():md+=f'| {k} | {v} |\n'
 md+='''\n## Interpretation\n\nAll Phase 03 proposed low-match cases were challenged against the full eight-original-file reciprocal index, not judged absent because of retrieval score. Each provisional full proof was rechecked for its original quote, inherited table/column, applicability and qualifications. The output retains each original file, SHA-256 and line locator, the strongest alternative evidence, the source predicates, and apparent gaps.\n\n**No final canonical TP/FN labels or metrics are issued in Phase 04.** A lexical match cannot force TP; a retrieval miss cannot force FN. Contextual E2 and exact-quotation E3 evidence is provisional. Phase 05 must re-examine exclusions and class validity before Phase 06, and independent Phase 07 adjudication is mandatory for unresolved decisions.\n\n## Files\n\n- `04_coverage_audit.jsonl`: all R, original evidence and reciprocal challenges.\n- `04_tp_evidence_audit.jsonl`: provisional E2/E3 coverage proofs and adverse-check notes.\n- `04_fn_root_cause_audit.jsonl`: unproven missing predicates and strongest alternative witnesses; never an automatic FN.\n- `04_manual_semantic_review.jsonl`: targeted full-predicate semantic review of direct-matcher misses or partial quotation proofs.
- `04_audit_validation.json`: identities, invariants and exact outcome counts.\n- `04_validation_report.md`: this report.\n- `audit_phase04.py`: reproducible original-source reciprocal-audit code.\n\n## Material limitations\n\n- Semantic paraphrase entailment is not fully decided by lexical scanning.\n- The accepted register-family scope does not add unstated DB objects or UI controls.\n- Phase 03's ReleasePromoted bridge originally selected the DeploymentPromoted row merely because it said 'Distinct from ReleasePromoted'; Phase 04 preserved that source and appended the correct registered event line in an explicit superseding proof.
- The Phase 06 external evaluator mandates medium reasoning effort, whereas the operator requested low. The discrepancy remains documented.\n'''
 (OUT/'04_validation_report.md').write_text(md,encoding='utf8')
 print(json.dumps({'status':summary['phase_status'],'counts':summary['counts'],'outputs':summary['output_sha256']},indent=2))

if __name__=='__main__':main()
