# Phase 04 - TP/FN Reciprocal Audit

Status: **PHASE_COMPLETED_WITH_PROVISIONAL_SEMANTIC_DECISIONS**

- Protocol: 10.6
- Generation method: twolevel
- Source and generated inputs: eight SHA-256-locked Markdown sources, 90-page original PDF, frozen 638 R / 142 N.
- Earlier phase inputs: unchanged.

## Audit counts

| Check | Count |
|---|---:|
| Source R obligations audited | 638 |
| Full original content lines independently searched | 1914 |
| Contextual E2 bridge proofs structurally verified | 169 |
| E2_CONTEXTUAL_FULL_PROOF_PROVISIONAL | 175 |
| POSSIBLE_CONTEXTUAL_OR_PARTIAL_COVERAGE | 178 |
| E3_DIRECT_QUOTE_FULL_PROOF_PROVISIONAL | 8 |
| RECIPROCAL_SEARCH_NO_FULL_PROOF_YET | 277 |

## Interpretation

All Phase 03 proposed low-match cases were challenged against the full eight-original-file reciprocal index, not judged absent because of retrieval score. Each provisional full proof was rechecked for its original quote, inherited table/column, applicability and qualifications. The output retains each original file, SHA-256 and line locator, the strongest alternative evidence, the source predicates, and apparent gaps.

**No final canonical TP/FN labels or metrics are issued in Phase 04.** A lexical match cannot force TP; a retrieval miss cannot force FN. Contextual E2 and exact-quotation E3 evidence is provisional. Phase 05 must re-examine exclusions and class validity before Phase 06, and independent Phase 07 adjudication is mandatory for unresolved decisions.

## Files

- `04_coverage_audit.jsonl`: all R, original evidence and reciprocal challenges.
- `04_tp_evidence_audit.jsonl`: provisional E2/E3 coverage proofs and adverse-check notes.
- `04_fn_root_cause_audit.jsonl`: unproven missing predicates and strongest alternative witnesses; never an automatic FN.
- `04_manual_semantic_review.jsonl`: targeted full-predicate semantic review of direct-matcher misses or partial quotation proofs.
- `04_audit_validation.json`: identities, invariants and exact outcome counts.
- `04_validation_report.md`: this report.
- `audit_phase04.py`: reproducible original-source reciprocal-audit code.

## Material limitations

- Semantic paraphrase entailment is not fully decided by lexical scanning.
- The accepted register-family scope does not add unstated DB objects or UI controls.
- Phase 03's ReleasePromoted bridge originally selected the DeploymentPromoted row merely because it said 'Distinct from ReleasePromoted'; Phase 04 preserved that source and appended the correct registered event line in an explicit superseding proof.
- The Phase 06 external evaluator mandates medium reasoning effort, whereas the operator requested low. The discrepancy remains documented.
