#!/usr/bin/env python3
"""Independent source/historical-provenance-preserving merge for v10.6 twolevel Phase07 S1+S2.

This file only reads immutable original shard/external/source files and writes
new Phase07 merge outputs. Historical candidate verdicts are NOT independent
new gpt-6.2-sol results. This gate never calculates canonical FP or metrics.
"""
from __future__ import annotations
from collections import Counter, defaultdict
from datetime import datetime, timezone
import hashlib, json, math, re, unicodedata, zipfile
from pathlib import Path
import pymupdf
from sklearn.feature_extraction.text import TfidfVectorizer

BASE=Path('/mnt/data')
OUT=BASE/'OrionDesk_twolevel_v10.6_Phase07_Merged'
P=[BASE/f'OrionDesk_twolevel_v10.6_Phase07_Shard{i}' for i in (1,2)]
HIST=BASE/'recovered_prior'
PDF=BASE/'OrionDesk_AI_Detailed_Design_Specification(3).pdf'
RFILE=BASE/'common_atomic_reqs(3).jsonl'
NFILE=BASE/'common_negative_controls(3).jsonl'
FREEZE=BASE/'reference_freeze(3).json'
QUEUE=HIST/'06_llm_queue_v10.6.jsonl'
EXTERNAL=BASE/'semantic_decisions.jsonl'
STATE=BASE/'run_state.json'
SUM=BASE/'semantic_summary.json'
JOURNAL=BASE/'batch_journals.zip'
HIST_ACTIVE=HIST/'07_active_adjudications_after_supersession.jsonl'
HIST_INITIAL=HIST/'07_assistant_adjudications.jsonl'
HIST_SUP=HIST/'07_superseding_adjudications.jsonl'
SOURCE_NAMES=['01_screen_functions(3).md','02_api(3).md','03_data(3).md','04_batch_functions(4).md','05_business_rules(3).md','06_exception_handling(5).md','07_processing_flows(5).md','08_architecture_decision(4).md']


def sha(p):
  h=hashlib.sha256()
  with Path(p).open('rb') as f:
    for part in iter(lambda:f.read(1<<20),b''):h.update(part)
  return h.hexdigest()

def norm(s):return ' '.join(unicodedata.normalize('NFKC',str(s)).split()).casefold()
def canon(obj):return json.dumps(obj,ensure_ascii=False,sort_keys=True,separators=(',',':'))
def sha_obj(x):return hashlib.sha256(canon(x).encode('utf8')).hexdigest()
def jlist(path):return [json.loads(line) for line in Path(path).open(encoding='utf-8-sig') if line.strip()]
def jobj(path):return json.loads(Path(path).read_text(encoding='utf8'))
def require(condition,message):
  if not condition:raise AssertionError(message)
def write_rows(name,records):
  (OUT/name).write_text(''.join(canon(x)+'\n' for x in records),encoding='utf8')
def write_json(name,obj):
  (OUT/name).write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n',encoding='utf8')

def compare_reason(a,b):
  """Distinction recorded for human-reviewed high-similarity opposite-cell pairs.
  All comparisons also embed literal, reverified PDF and Markdown quotations.
  """
  if a['direction']=='R':
    x,y=a['source_statement_en'],b['source_statement_en']
    if a['item_id']=='PDF-0568' and b['item_id']=='PDF-0545':
      return 'An independent implementation test proving both approval checks is a distinct test obligation from enforcing the approval checks at runtime.'
    if a['item_id']=='PDF-0601' and b['item_id']=='PDF-0602':
      return 'The approval_tasks entity and approval_decisions entity have distinct fields, ownership and immutability rules; covering one is not proof of the other.'
    if a['item_id']=='PDF-0073' and b['item_id']=='PDF-0304':
      return 'Both cite the same run-start endpoint but impose different predicates: secondary schema/bounded errors versus OAuth audience and idempotency.'
    if a['item_id']=='PDF-0566' and b['item_id']=='PDF-0565':
      return 'The secondary workspace DELETE schema/bounded-error requirement differs from the export POST authorization/idempotency contract.'
    if a['item_id']=='PDF-0073' and b['item_id']=='PDF-0072':
      return 'The contracts apply to different routes: case-scoped run creation versus case creation.'
    paths_a=re.findall(r'(?:GET|POST|PATCH|PUT|DELETE)\s+/[\w{}./?=-]+',x)
    paths_b=re.findall(r'(?:GET|POST|PATCH|PUT|DELETE)\s+/[\w{}./?=-]+',y)
    if paths_a and paths_b and paths_a[0]!=paths_b[0]:
      return 'The source register attaches independent schema/contract obligations to distinct methods or resource paths: '+paths_a[0]+' versus '+paths_b[0]+'. Shared boilerplate is not a shared atom.'
    return 'The complete PDF-positive obligations differ in the actor, target, test duty or action; the evidence for one does not entail the complete other obligation.'
  gaps=a.get('unmet_predicates_en') or []
  asserted=b['source_statement_en']
  code=a['item_id']
  mapping={
   'GCLASS-0000759':'The unsupported assertion excludes all fine-tuning; the supported assertion explicitly limits exclusion to foundation-model fine-tuning (PDF p.9).',
   'GCLASS-0001101':'The unsupported assertion excludes generic model fine-tuning; the supported assertion names foundation-model fine-tuning (PDF p.9).',
   'GCLASS-0000875':'The unsupported assertion universally requires an approved region/deployment for every fallback; the supported clause states handling strength or preserves the RESTRICTED-content/outage condition (PDF p.37).',
   'GCLASS-0001172':'The unsupported assertion universally adds approved-region/deployment routing; the supported clause does not impose this on unrestricted classes outside the outage/restricted-content condition (PDF p.37).',
   'GCLASS-0000893':'A requirement to audit ALL unauthorized review denials is stronger than the specifically audited changed/wrong-hash/stale denial (PDF p.45 and TST-006).',
   'GCLASS-0000599':'A general audit requirement for every denied decision is stronger than the source-specific stale-hash denial audit (PDF p.45 and TST-006).',
   'GCLASS-0001656':'Revocation must take effect before the next retrieval, but cache invalidation is required before new RESULTS. The assertion wrongly combines these two distinct deadlines (PDF pp.27-28).',
   'GCLASS-0000747':'PDF p.88 assigns three different duties: review implementation evidence, independently reproduce NEGATIVE cases and sign the release record. Independence of reviewing evidence is an added scope.',
   'GCLASS-0000315':'PDF p.88 independently reproduces negative TEST cases, not every SEC implementation-evidence artifact; it signs the release record, not all evidence artifacts.',
   'GCLASS-0001025':'Independence is attached to reproducing negative cases and signing to the release record; the unsupported statement extends both to all implementation evidence (PDF pp.88-89).',
   'GCLASS-0001906':'The source records provider cursor/high-watermark/error ledger in a sync run but the partial connector_cursors DDL does not put the complete error ledger in that table (PDF pp.28,85).',
   'GCLASS-0000311':'Source T-12 signs the dataset MANIFEST, while the unsupported statement requires signing/versioning fixtures themselves (PDF p.88).',
   'GCLASS-0000736':'The dataset version and signed manifest are distinct; the unsupported class claims the dataset/fixtures themselves are signed (PDF pp.88-89).',
   'GCLASS-0001547':'The 1,200 frozen synthetic cases and the frozen SAFETY suite are not proven coextensive; metric thresholds alone are separately supported (PDF pp.75-76).',
   'GCLASS-0001827':'The benchmark metrics and safety-suite targets are source-supported, but the assertion additionally equates their evaluation populations (PDF pp.75-76).',
   'GCLASS-0001116':'Repeated dependency-failure contracts for specified interfaces do not establish unconditional coverage of EVERY named interface (PDF pp.9-56).',
   'GCLASS-0002028':'The universal ALL-named-interface claim is stronger than the local, source-named dependency branch shown for relevant interfaces (PDF pp.9-56).',
   'GCLASS-0000867':'PDF p.49 uses the outbox to repair broken LINKS, not to derive every fingerprint reconciliation input. The supported clause separates reconciliation from link repair.',
   'GCLASS-0001331':'Frozen/versioned/independently leakage-reviewed is expressly scoped to EVALUATION corpora, not all fixtures (PDF p.89).',
   'GCLASS-0000931':'PDF p.84 attaches the full exclusion list to ERROR objects; PDF p.54 separately excludes credentials from public responses. The assertion combines them universally.',
   'GCLASS-0001746':'The error envelope has exclusions beyond the source-wide public response credential ban; same list across all response categories is unsupported (PDF pp.54,84).',
   'GCLASS-0001881':'The retrieved-document/full-prompt/private-existence list is specified for error objects, not universally for every public success response (PDF pp.54,84).',
   'GCLASS-0000199':'Full-prompt/document/private-existence prohibitions in error objects do not automatically become required for every public success response (PDF pp.54,84).',
   'GCLASS-0001082':'A GET usage endpoint and daily aggregation are specified independently; the source does not prohibit GET from triggering any work. Attribution is a different duty (PDF pp.65,83).',
   'GCLASS-0000653':'A suspected ACL leak suspends affected search aliases and REVOKES cached evidence; suspension of the cache itself is a stronger, different control (PDF p.79).',
   'GCLASS-0001518':'Incident command conditions snapshot RESTORATION; the unsupported claim expands that prerequisite to ordinary primary-region WRITES (PDF pp.19,69).',
   'GCLASS-0001042':'Source outcomes are durably recorded after ingestion; the unsupported generated claim reverses causal order by saying source outcomes feed ingestion (PDF pp.27-28).',
   'GCLASS-0001314':'Arbitrary MCP tool invocation is denied before dispatch; recursive tool hints are governed by bounded planning/step controls, not an automatic shared predispatch DENY (PDF pp.41,88-89).',
   'GCLASS-0000476':'The manifest is required specifically for controlled EXPORT; legal-hold-safe DELETE has distinct checks and completion receipts (PDF pp.78-80).',
   'GCLASS-0001573':'Tenant guards and pool resets are separately supported controls; the claimed universal combined integration-test obligation is an additional requirement (PDF pp.85-89).',
  }
  if code in mapping:return mapping[code]
  require(gaps,'No documented unmet predicate for unsupported generated claim '+code)
  return 'Unsupported G claim has an explicit, unfulfilled additional predicate: '+ '; '.join(gaps)[:320]+'. The supported G candidate does not assert that same extra complete predicate.'


def candidates(rows, direction):
  pool=[r for r in rows if r['direction']==direction and r['eligible']]
  neg=[x for x in pool if x['final_cell'] in ('FP','FN')]
  pos=[x for x in pool if x['final_cell']=='TP']
  claims=[x['source_statement_en'] for x in neg+pos]
  sims={}
  for representation,minval in [('char',0.48),('word',0.4)]:
    v=TfidfVectorizer(analyzer=('char' if representation=='char' else 'word'),
                      ngram_range=(3,5) if representation=='char' else (1,2),
                      token_pattern=r'(?u)\b\w+\b',sublinear_tf=True)
    mx=v.fit_transform(claims)
    product=(mx[:len(neg)]@mx[len(neg):].T).tocsr()
    for i,n in enumerate(neg):
      for j,sim in zip(product.getrow(i).indices,product.getrow(i).data):
        p=pos[j]
        if n['shard_id']==p['shard_id'] or sim<minval:continue
        key=(n['item_id'],p['item_id'])
        sims.setdefault(key,{})[representation]=round(float(sim),6)
  # Complete direct string identity audit across opposing labels, independent of retrieval thresholds.
  normalized=defaultdict(list)
  for p in pos:normalized[norm(p['source_statement_en'])].append(p)
  for n in neg:
    for p in normalized[norm(n['source_statement_en'])]:
      if n['shard_id']!=p['shard_id']:sims.setdefault((n['item_id'],p['item_id']),{})['exact_normalized']=True
  ref={x['item_id']:x for x in pool}
  ranked=sorted(sims, key=lambda k:(-max(x for x in sims[k].values() if isinstance(x,float)) if any(isinstance(x,float) for x in sims[k].values()) else -1,k))
  return [(ref[a],ref[b],sims[(a,b)]) for a,b in ranked]


def main():
  OUT.mkdir(exist_ok=True)
  freeze=jobj(FREEZE); summary=jobj(SUM); state=jobj(STATE)
  pdf_sha=sha(PDF); hist_active_sha=sha(HIST_ACTIVE); ref_r_sha=sha(RFILE); ref_n_sha=sha(NFILE); ext_sha=sha(EXTERNAL); freeze_sha=sha(FREEZE)
  require(state['model']=='gpt-6.2-sol' and summary['status']=='COMPLETE','External model or state mismatch')
  require(state['batch_size']==16 and summary['expected_batches']==186 and summary['failed_batches']==0,'External batching invalid')
  require(pdf_sha==freeze['source_document']['sha256']==state['pdf_sha256'],'Frozen PDF SHA mismatch')
  require(ref_r_sha==freeze['output_artifacts_sha256']['common_atomic_reqs.jsonl'],'Frozen R SHA mismatch')
  require(ref_n_sha==freeze['output_artifacts_sha256']['common_negative_controls.jsonl'],'Frozen N SHA mismatch')
  # The separately retrievable historical file named 06_llm_queue_v10.6.jsonl is a DIFFERENT 2,438-item artifact.
  # Never assert that its bytes match this 2,963-item external execution. Use the
  # authoritative committed external-result order and the two identical assignment ledgers.
  require(state['queue_sha256']==summary['queue_sha256'],'Execution queue digest inconsistency')
  originals={fn:BASE/fn for fn in SOURCE_NAMES}
  source_sha={fn:sha(p) for fn,p in originals.items()}
  role_shas=dict(zip(['01','02','03','04','05','06','07','08'],source_sha.values()))
  for role,fn in zip(role_shas,SOURCE_NAMES):
    require(role_shas[role]==state['file_sha256'][fn.split('(')[0]+'.md'],'Original generated-file role mismatch: '+fn)
  sources={fn:p.read_text(encoding='utf-8-sig').splitlines() for fn,p in originals.items()}
  with pymupdf.open(PDF) as doc:
    require(len(doc)==90,'PDF is not the frozen 90 pages')
    pdftext=[norm(page.get_text(sort=False)+'\n'+page.get_text(sort=True)) for page in doc]
  rlist=jlist(RFILE); nlist=jlist(NFILE); external=jlist(EXTERNAL)
  q=[{'item_id':x['item_id'],'direction':x['direction']} for x in external]
  require(len(q)==len(external)==2963,'Invalid queue/external cardinality')
  ids=[r['item_id'] for r in q]
  require(len(set(ids))==2963 and all(x['queue_sha256']==state['queue_sha256'] for x in external),'Original item order/queue identity mismatch')
  require([x['item_id'] for x in q if x['direction']=='R']==[x['requirement_id'] for x in rlist],'Frozen R sequence changed')
  require([x['item_id'] for x in q if x['direction']=='N']==[x['control_id'] for x in nlist],'Frozen N sequence changed')
  require(Counter(r['direction'] for r in q)=={'R':638,'N':142,'G':2183},'Frozen queue direction count mismatch')
  require(all(r['reasoning_effort']=='high' and r['model']=='gpt-6.2-sol' for r in external),'Original external high-effort identity mismatch')
  require(ext_sha==jobj(P[0]/'07_shard1_summary.json')['external_semantic_decisions_sha256'],'External result SHA mismatch')
  require(sha(JOURNAL)==jobj(P[1]/'07_shard2_summary.json')['batch_journals_sha256'],'Journal zip SHA mismatch')
  prev=jlist(HIST_ACTIVE);prev_by_id={x['item_id']:x for x in prev}
  require(len(prev_by_id)==2963,'Historical comparison file incomplete')
  require(hist_active_sha==jobj(P[0]/'07_shard1_summary.json')['historical_phase07_active_sha256'],'Frozen historical Phase07 digest mismatch')
  require(sha(HIST_INITIAL)==jobj(P[0]/'07_shard1_summary.json')['historical_phase07_original_sha256'],'Original Phase07 source SHA mismatch')
  require(sha(HIST_SUP)==jobj(P[0]/'07_shard1_summary.json')['historical_supersessions_sha256'],'Historical supersessions SHA mismatch')
  assignments=[];shard_rows=[];audits=[];shardhashes={};artifactsha={}
  for s in [1,2]:
    d=P[s-1];name=f'07_shard{s}'
    manifest=jobj(d/(name+'_manifest.json'));sumry=jobj(d/(name+'_summary.json'));val=jobj(d/(name+'_independent_validation.json'))
    require(manifest['status']==sumry['status']==f'SHARD{s}_COMPLETED' and val['status']=='PASS','Shard not independently checked')
    for filename,info in manifest['files'].items():
      f=d/filename
      require(f.is_file() and sha(f)==info['sha256'] and f.stat().st_size==info['size_bytes'],'Shard manifest file hash/size mismatch '+str(f))
    ar=jlist(d/(name+'_assignments.jsonl'))
    if s==1:assignments=ar
    else:require(assignments==ar,'Shard assignment ledgers disagree')
    r=jlist(d/(name+'_adjudications.jsonl'))
    require(len(r)==(1482 if s==1 else 1481),'Shard population size mismatch')
    require(set(x['shard_id'] for x in r)=={f'S{s}'},'Shard ID assignment inconsistent')
    require(pdf_sha==sumry['pdf_sha256'],'Shard original PDF mismatch')
    require(sumry['external_model']=='gpt-6.2-sol' and sumry['external_reasoning_effort']=='high','Shard external model/effort mismatch')
    require(sumry['source_markdown_role_sha256']==source_sha,'Shard generated file SHA mismatch')
    require(sumry['R_sha256']==ref_r_sha and sumry['N_sha256']==ref_n_sha,'Shard frozen reference mismatch')
    require(sumry['external_queue_sha256']==state['queue_sha256'],'Shard external queue identity mismatch')
    require(sumry['eligible_null_count']==0 and (s==1 or val['all_shard2_eligible_decisions_classified']),'Incomplete shard eligible decisions')
    shard_rows+=r
    audits+=jlist(d/(name+'_decision_audit.jsonl'))
    shardhashes[f'S{s}']={'adjudications_sha256':sha(d/(name+'_adjudications.jsonl')),
                          'audit_sha256':sha(d/(name+'_decision_audit.jsonl')),
                          'summary_sha256':sha(d/(name+'_summary.json')),
                          'validation_sha256':sha(d/(name+'_independent_validation.json')),
                          'manifest_sha256':sha(d/(name+'_manifest.json'))}
  require(len(assignments)==2963 and [x['item_id'] for x in assignments]==ids,'Assignments cover wrong queue or order')
  across=Counter((x['direction'],x['shard_id']) for x in assignments)
  require(across=={('R','S1'):319,('R','S2'):319,('N','S1'):71,('N','S2'):71,('G','S1'):1092,('G','S2'):1091},'Shard partition counts wrong')
  dirposition=Counter();expected={}
  for i,x in enumerate(q,1):
    d=x['direction'];dirposition[d]+=1
    group='S1' if dirposition[d]%2 else 'S2'
    a=assignments[i-1]
    require(a['item_id']==x['item_id'] and a['direction']==d and a['shard_id']==group and a['position_within_direction_one_based']==dirposition[d], 'Shard assignment parity/order mismatch')
    expected[x['item_id']]=group
  by_id={x['item_id']:x for x in shard_rows}
  require(len(by_id)==2963 and set(by_id)==set(ids),'Missing or duplicate shard final decision')
  require(len(audits)==2963 and len({x['item_id'] for x in audits})==2963,'Shard audit coverage is incomplete')
  merged=[by_id[i] for i in ids]
  ext_map={x['item_id']:x for x in external}
  pdf_evidence=md_evidence=visual=near_evidence=0
  evidence_mismatches=[];hist_mismatches=[]
  for r in merged:
    ix=r['item_id'];x=ext_map[ix]; historic=prev_by_id[ix]
    require(r['shard_id']==expected[ix] and r['protocol_version']=='10.6' and r['method']=='twolevel','Merged item shard/method mismatch: '+ix)
    require(r['original_pdf_sha256']==pdf_sha,'Item original PDF digest differs')
    require(r['original_markdown_sha256']==source_sha,'Item original Markdown digest differs')
    require(r['prior_active_phase07_sha256']==hist_active_sha,'Original history linkage inconsistent')
    require(r['external_queue_sha256']==state['queue_sha256'] and r['prior_v5_evidence_checks_sha256']==sha_obj(x['evidence_checks']),'v5 decision provenance mismatch')
    require(r['prior_v5_decision_status']==x['decision_status'] and r['prior_v5_suggested_decision']==x['suggested_decision'],'v5 suggestions have been mutated')
    require(r['external_response_id']==x['metadata']['response_id'] and r['external_evaluation_reasoning_effort']=='high' and r['external_evaluation_model']=='gpt-6.2-sol','Model provenance differs')
    require(r['historical_pre_shard_cell']==historic['final_cell'] and r['historical_pre_shard_row_sha256']==sha_obj(historic),'Historical row/cell digest mismatch')
    if r['final_cell']!=historic['final_cell']:hist_mismatches.append(ix)
    require(r['source_reference_unchanged']==True,'Source reference unexpectedly changed')
    require(r['direction'] in ('R','N','G'),'Invalid direction')
    if r['direction']=='R':require(r['eligible'] and r['final_cell'] in ('TP','FN') and r['decision_rule_id']=='P7-R-'+r['final_cell'],'R incomplete')
    if r['direction']=='N':require(r['eligible'] and r['final_cell'] in ('TN','FP') and r['decision_rule_id']=='P7-N-'+r['final_cell'],'N incomplete')
    if r['direction']=='G':
      if r['eligible']:require(r['final_cell'] in ('TP','FP'),'Eligible G unclassified: '+ix)
      else:require(r['final_cell'] is None and r['eligibility_disposition']=='EXCLUDED_NONDEFINITIVE','Excluded G is mislabeled')
    require(bool(r['decision_reason_en']),'Missing item justification: '+ix)
    if r['direction'] in ('R','G') and r['eligible'] and r['final_cell'] in ('FN','FP'):
      require(bool(r['unmet_predicates_en']),'Absent unsupported/missing predicate at '+ix)
    ct=0; vt=0
    for ev in r['pdf_evidence']:
      page=ev['physical_page'];quote=ev['quote_en']
      require(type(page)==int and 1<=page<=90,'Invalid physical page for '+ix)
      if ev.get('visual_locator_only') and not quote:
        require(ev.get('verified_original_pdf_text') is False,'Visual locator misreported as text quote')
        visual+=1;vt+=1
      else:
        require(norm(quote) in pdftext[page-1] and bool(norm(quote)),'PDF quote mismatch at '+ix)
        pdf_evidence+=1;ct+=1
    require(r['verified_pdf_text_quotes']==ct and r['visual_only_pdf_locators']==vt,'PDF quoted item counter incorrect: '+ix)
    cg=0
    for ev in r['generated_evidence']:
      fn=ev['file'];lo=ev['line_start'];hi=ev['line_end'];quoted=ev['quote_en']
      require(fn in sources and 1<=lo<=hi<=len(sources[fn]),'Generated quote locator invalid: '+ix)
      require(norm(quoted) in norm('\n'.join(sources[fn][lo-1:hi])) and bool(norm(quoted)),'Generated quote mismatch: '+ix)
      require(ev['source_sha256']==source_sha[fn],'Generated quoted role SHA mismatch: '+ix)
      md_evidence+=1;cg+=1
    require(r['verified_markdown_line_quotes']==cg,'Generated quote count mismatch: '+ix)
    for ev in r['examined_original_line_candidates']:
      fn=ev['source_file'];lo=ev['line_start'];hi=ev['line_end'];quoted=ev['source_quote_en']
      require(fn in sources and 1<=lo<=hi<=len(sources[fn]) and norm(quoted) in norm('\n'.join(sources[fn][lo-1:hi])),'Reciprocal original line quote mismatch: '+ix)
      require(ev['original_source_sha256']==source_sha[fn],'Reciprocal quote file SHA differs: '+ix)
      near_evidence+=1
  require(not hist_mismatches,'Shard labels diverged from historical active Phase07 without explicit new supersession: '+str(hist_mismatches[:6]))
  require(pdf_evidence==2945+2956 and md_evidence==3487+3501 and near_evidence==3405+3418,'Combined original evidence counts do not match the shards')
  # All journal evidence retained; independently verify committed content vs immutable external outputs.
  journal_pass=0
  with zipfile.ZipFile(JOURNAL) as z:
    require(z.testzip() is None,'ZIP journal CRC failed')
    for idx in range(186):
      n=f'batch_journals/B10.6-{idx+1:05d}.json';j=json.loads(z.read(n))
      seg=q[idx*16:(idx+1)*16]; rec=external[idx*16:(idx+1)*16]
      require(j['batch_index']==idx and j['batch_size']==len(seg),'Journal segment structure mismatch')
      require(j['queue_sha256']==state['queue_sha256'] and j['pdf_sha256']==pdf_sha,'Journal source identity mismatch')
      # Original submitted JSONL payload bytes are not available for this run.
      # The journal input digest is immutable and nonempty but cannot be rederived
      # from the partial id/direction metadata reconstructed here.
      require(bool(re.fullmatch(r'[0-9a-f]{64}',j['input_digest'])) and j['content_sha256']==sha_obj({'raw_model_json':j['raw_model_json'],'item_records':j['item_records']}),'Journal content digest mismatch')
      require(j['item_records']==rec,'Journal committed original items differ')
      journal_pass+=1
  # Source-grounded cross-shard opposite-cell targeted semantic pair audit:
  # char ngram >=0.48 OR word 1-2 gram >=0.4 OR normalized exact duplicate.
  pair_records=[];pair_counts={}
  for direction in ['G','R']:
    pool=candidates(merged,direction);pair_counts[direction]=len(pool)
    for a,b,score in pool:
      require(a['shard_id']!=b['shard_id'] and a['final_cell'] in ('FP','FN') and b['final_cell']=='TP','Invalid opposite-cell candidate')
      reason=compare_reason(a,b)
      require(reason and len(reason)>35,'Unjustified cross-shard pair rejection: '+a['item_id'])
      # Retain exact PDF quotes as separately verified literal source evidence.
      p_evidence=[{'id':r['item_id'],'physical_page':e['physical_page'],'quote_en':e['quote_en'], 'original_quote_verified':e.get('original_quote_verified',False), 'visual_evidence':e.get('visual_evidence',False)} for r in (a,b) for e in r['pdf_evidence'][:2]]
      pair_records.append({'record_type':'CROSS_SHARD_OPPOSITE_CELL_SEMANTIC_AUDIT','protocol_version':'10.6',
       'direction':direction,'item_a':a['item_id'],'shard_a':a['shard_id'],'decision_a':a['final_cell'],
       'item_b':b['item_id'],'shard_b':b['shard_id'],'decision_b':b['final_cell'],
       'similarity_diagnostic_only':score,'claim_a_en':a['source_statement_en'],'claim_b_en':b['source_statement_en'],
       'actual_pdf_support':p_evidence,'original_generated_evidence_a':a['generated_evidence'][:1],
       'original_generated_evidence_b':b['generated_evidence'][:1],
       'item_a_unmet_predicates_en':a['unmet_predicates_en'],
       'semantic_distinction_en':reason,'review_disposition':'NO_CONFIRMED_CONTRADICTION_DIFFERENT_COMPLETE_PREDICATE',
       'pdf_authority_sha256':pdf_sha,'source_history_provenance':'SHARD_ORIGINALS_AND_PHASE07_HISTORICAL_CANDIDATES',
       'phase08_duplicate_unification_not_performed':True})
  # Cross-shard exact string-duplicate audit over every cross-shard pair regardless score.
  normgroups=defaultdict(list)
  for x in merged:
    if x['direction']=='G' and x['eligible']:
      normgroups[norm(x['source_statement_en'])].append(x)
  exact_opposite=[];exact_same=[]
  for items in normgroups.values():
    for i,a in enumerate(items):
      for b in items[i+1:]:
        if a['shard_id']==b['shard_id']:continue
        if a['final_cell']!=b['final_cell']:exact_opposite.append((a['item_id'],b['item_id']))
        else:exact_same.append((a['item_id'],b['item_id']))
  require(not exact_opposite,'Exact normalized generated claim has opposite cross-shard cells: '+str(exact_opposite[:5]))
  # Original source R/N exact ID non-overlap is independently checked before scoring.
  require(len(set(x['item_id'] for x in merged if x['direction']=='R'))==638,'R coverage inconsistent')
  require(len(set(x['item_id'] for x in merged if x['direction']=='N'))==142,'N coverage inconsistent')
  hist=Counter((r['direction'],r['final_cell']) for r in merged)
  require(hist=={('R','TP'):585,('R','FN'):53,('N','TN'):142,('G','TP'):1832,('G','FP'):56,('G',None):295},'Merged cells unexpected')
  require(all(x['eligible'] and x['final_cell'] is not None or x['direction']=='G' and not x['eligible'] and x['final_cell'] is None for x in merged),'Eligible item still null')
  require(hist[('R','TP')]+hist[('R','FN')]==638 and hist[('N','TN')]==142,'R/N partition mismatch')
  audit_by_id={a['item_id']:a for a in audits}
  combined_audit=[]
  for r in merged:
    original=audit_by_id[r['item_id']]
    require(original['new_shard_cell']==r['final_cell'] and original['shard_id']==r['shard_id'],'Shard audit disagrees with final cell')
    combined_audit.append({**original,'record_type':'PHASE07_COMBINED_DECISION_AUDIT',
      'original_shard_audit_sha256':shardhashes[r['shard_id']]['audit_sha256'],
      'final_phase07_item_id':r['item_id'],'integrated_direction_order':'R_N_G_FROZEN_QUEUE',
      'original_shard_item_sha256':sha_obj(r),'cross_shard_audit_performed':True})
  # Advisory, no Phase08/09 canonical residual reductions, no new external API calls.
  summary_out={
    'record_type':'PHASE07_SHARD_MERGE_SUMMARY','protocol_version':'10.6','method':'twolevel',
    'phase':'07','status':'PHASE07_TWO_SHARD_MERGE_COMPLETED',
    'partition_rule':'ODD_ONE_BASED_POSITION_WITHIN_DIRECTION_R_N_G',
    'source_pdf_sha256':pdf_sha,'source_pdf_physical_pages':90,
    'source_reference_R_sha256':ref_r_sha,'source_reference_N_sha256':ref_n_sha,
    'source_reference_freeze_sha256':freeze_sha,'generated_originals_sha256':source_sha,
    'external_model':'gpt-6.2-sol','external_reasoning_effort':'high','external_batch_size':16,
    'external_committed_items':len(external),'external_batches_verified':journal_pass,
    'original_external_result_sha256':ext_sha,'original_queue_sha256_reported_by_execution':state['queue_sha256'],
    'original_queue_full_bytes_available_for_independent_rehash':False,
    'original_queue_recovered_same_name_is_a_different_2438_item_artifact':True,
    'external_item_order_and_journals_verified_from_committed_records':True,
    'shard_artifact_lineage':shardhashes,
    'shard1_total':1482,'shard2_total':1481,'all_source_R':638,'all_source_N':142,'all_effective_G_candidates':2183,
    'R_TP':hist[('R','TP')],'R_FN':hist[('R','FN')],
    'N_FP':hist.get(('N','FP'),0),'N_TN':hist[('N','TN')],
    'G_supported_diagnostic_TP':hist[('G','TP')],'G_unsupported_diagnostic_FP':hist[('G','FP')],
    'G_nondefinitive_excluded':hist[('G',None)],
    'final_R_ids':[r['item_id'] for r in merged if r['direction']=='R'],
    'final_N_ids':[r['item_id'] for r in merged if r['direction']=='N'],
    'final_G_ids':[r['item_id'] for r in merged if r['direction']=='G'],
    'final_eligible_unresolved_count':0,'new_item_ids':0,'duplicate_item_ids':0,'missing_item_ids':0,
    'prior_external_unresolved_by_direction':{d:sum(x['direction']==d and x['decision_status']=='UNRESOLVED' for x in external) for d in ['R','N','G']},
    'prior_external_unresolved_total':sum(x['decision_status']=='UNRESOLVED' for x in external),
    'cross_shard_opposite_cell_candidate_counts':pair_counts,
    'cross_shard_opposite_cell_candidates_source_compared':len(pair_records),
    'confirmed_cross_shard_semantic_contradictions_in_reviewed_candidates':0,
    'cross_shard_exact_normalized_opposite_G_cells':len(exact_opposite),
    'cross_shard_exact_normalized_same_G_pairs':len(exact_same),
    'pdf_text_quotes_verified':pdf_evidence,'markdown_line_quotes_verified':md_evidence,
    'pdf_visual_only_locators_preserved':visual,'reciprocal_original_line_candidates_verified':near_evidence,
    'hist_original_phase07_active_sha256':hist_active_sha,'historical_item_labels_changed_by_shards':len(hist_mismatches),
    'semantic_audit_scope':'Every original shard item provenance, PDF and Markdown quotation; all cross-shard exact matching G statements; candidate opposite-cell pairs over declared char/word relevance thresholds. Below-threshold semantic equivalence is not formally excluded.',
    'independence_limitations_en':[
      'The shard adjudications used historical Phase07 cells as candidates. The merged result is NOT an independent second gpt-6.2-sol inference and cannot be claimed as a new statistically independent model evaluation.',
      'Textual quotations prove original-source existence, not semantic entailment. Opposite-cell pairs were adjudicated within an explicit lexical candidate screen and original source comparison; a zero contradiction finding for screened pairs is not an exhaustive all-pairs semantic proof.',
      'Phase08 residual/N/FP semantic deduplication and Phase09 metric calculation are not performed in this output.',
      'The locally supplied v10.6 protocol text specifies medium reasoning for the external evaluator, whereas the uploaded operator script and actual external journals show gpt-6.2-sol high. This is recorded rather than silently rewritten.',
      'The original 2963-item submitted queue JSONL is not retrievable in this session; the separate old 2438-item similarly named copy was rejected. The committed journal content and execution queue digest are checked, but submitted batch input digests cannot be recomputed.'
    ],
    'phase08_not_started':True,'phase09_metrics_not_recomputed':True,
  }
  write_rows('07_assistant_adjudications.jsonl',merged)
  write_rows('07_decision_audit.jsonl',combined_audit)
  write_rows('07_global_cross_shard_semantic_audit.jsonl',pair_records)
  write_rows('07_input_blockers.jsonl',[])
  write_json('07_adjudication_summary.json',summary_out)
  write_json('07_partition_validation.json',{
   'record_type':'PHASE07_TWO_SHARD_PARTITION_VALIDATION','status':'PASS',
   'expected_global_IDs':len(ids),'integrated_total':len(merged),'all_queue_IDs_covered_exactly_once':True,
   'ordered_by_original_frozen_queue':True,'R_total':638,'N_total':142,'G_total':2183,
   'sha256_original_PDF':pdf_sha,'execution_reported_external_queue_sha256':state['queue_sha256'],
   'submitted_external_queue_input_digest_recomputed':False,
   'sha256_original_external_results':ext_sha,'external_batch_journals_validated':journal_pass,
   'original_shard_files_unchanged':True,'intershard_exact_normalized_opposite_G_count':0,
   'cross_shard_semantic_screen_opposite_cell_candidates':len(pair_records),
   'recorded_semantic_contradictions_after_pair_review':0,
   'unresolved_eligible':0,'external_model':'gpt-6.2-sol','external_reasoning_effort':'high',
   'historical_independent_new_paid_calls':0,
  })
  (OUT/'07_validation_report.md').write_text(f'''# Phase 07 — Two-Shard Integration and Cross-Shard Consistency Review\n\n**Status:** PHASE07_TWO_SHARD_MERGE_COMPLETED  \n**Method:** twolevel  \n**Protocol:** 10.6 with explicitly user-authorized two-shard Phase07 deviation  \n**External judge:** gpt-6.2-sol, reasoning effort **high**, 16 items per batch.\n\n## Integrations and preservation\n\nMerged S1 (1,482 items) and S2 (1,481 items) into the original source queue order. All 2,963 items appear exactly once, including 638 frozen source requirements, 142 frozen negative controls and 2,183 generated semantic classes. No Shard1/Shard2 files, historical Phase07 cells, original nine reference documents, source/reference freeze, original external v5 results, or batch journals were edited.\n\n## Item-level Phase07 final decisions (not canonical final FP)\n\n| Cell | Count |\n|---|---:|\n| R:TP | {hist[('R','TP')]} |\n| R:FN | {hist[('R','FN')]} |\n| N:FP | {hist.get(('N','FP'),0)} |\n| N:TN | {hist[('N','TN')]} |\n| G:diagnostic TP / PDF-supported | {hist[('G','TP')]} |\n| G:diagnostic FP / PDF-unsupported | {hist[('G','FP')]} |\n| G:nondefinitive excluded, unscored | {hist[('G',None)]} |\n\nAll eligible Phase07 item decisions are classified. The frozen `R:TP+R:FN=638` and `N:FP+N:TN=142` identities hold.\n\n## Cross-shard semantic consistency review\n\nReviewed {len(pair_records)} opposite-cell cross-shard near-pairs (G={pair_counts['G']}, R={pair_counts['R']}), enumerated by char ngrams >=0.48 OR word ngrams >=0.40, plus cross-shard exact normalized G identity. Each selected pair is documented in `07_global_cross_shard_semantic_audit.jsonl` with source and generated quotations, both complete claims, the unsupported predicate for the negative side and a case-specific reason why the two claims differ. None of the screened pairs was adjudicated as an actual conflicting label for the same complete predicate. No cross-shard exact normalized G statements carry opposing cells.\n\nThis is a reproducible high-relevance cross-shard semantic screen and source review, **not** a mathematical proof against every lower-similarity paraphrase. Repeated same-cell generated requirements are handled by Phase08 and have NOT been counted as new canonical FP here.\n\n## Evidence and execution integrity\n\n- Frozen source PDF (90 pages), R/N ledgers, eight Markdown originals: SHA-256 matched.\n- External run-state queue SHA-256, item order and all {journal_pass} committed batch journal contents matched. **The original 2,963-item queue bytes were not available to rehash**: a separately retrievable same-name historical file has 2,438 items and was NOT accepted as equivalent. Journal `input_digest` values are preserved but cannot be recomputed without the actual submitted full JSONL queue bytes.\n- Original PDF textual quotations: {pdf_evidence}; exact Markdown original-line quotes: {md_evidence}; quoted reciprocal original-line candidates: {near_evidence}.\n- Figure/visual-only PDF locators preserved separately: {visual}, and never claimed to be verified text quotations.\n- No new gpt-6.2-sol API submission, new paid judge, or fabricated external result. Historical Phase07 decisions were candidate inputs to the shard reviews, so the merged output does not constitute a second statistically independent model run.\n\n## Workflow boundary\n\nOnly the Phase07 S1+S2 merge and cross-shard audit were completed. Phase08 (N/F semantic residual consolidation) and Phase09 (Precision/Recall/F1) were not executed. The initial Phase07 full-run historical scores are not treated as new scores from this merge.\n''',encoding='utf8')
  # Final immutable path digest manifest (SHA manifest self-excluded).
  artifacts={f.name:{'size_bytes':f.stat().st_size,'sha256':sha(f)} for f in OUT.iterdir() if f.is_file() and f.name!='07_artifact_manifest.json'}
  write_json('07_artifact_manifest.json',{'record_type':'PHASE07_TWO_SHARD_MERGE_ARTIFACT_MANIFEST','status':'COMPLETED','method':'twolevel','protocol_version':'10.6',
    'created_at_utc':datetime.now(timezone.utc).isoformat(),'artifacts':artifacts,
    'shard_origin_checksums':shardhashes,'source_reference_unchanged':True,'phase08_not_started':True,'phase09_not_started':True})
  print(json.dumps({k:v for k,v in summary_out.items() if k in ['status','R_TP','R_FN','N_FP','N_TN','G_supported_diagnostic_TP','G_unsupported_diagnostic_FP','G_nondefinitive_excluded','final_eligible_unresolved_count','cross_shard_opposite_cell_candidates_source_compared','confirmed_cross_shard_semantic_contradictions_in_reviewed_candidates','pdf_text_quotes_verified','markdown_line_quotes_verified','reciprocal_original_line_candidates_verified','pdf_visual_only_locators_preserved']},ensure_ascii=False,indent=2))

if __name__=='__main__':main()
