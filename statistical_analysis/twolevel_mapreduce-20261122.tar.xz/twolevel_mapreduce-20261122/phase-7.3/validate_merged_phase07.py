#!/usr/bin/env python3
"""Independent structural audit for Phase07 merged two-shard artifacts.
Does NOT invent or alter semantic cells, infer entailment from text similarity,
or validate the unavailable original 2963-line submitted queue bytes.
"""
from pathlib import Path
from collections import Counter,defaultdict
import hashlib,json,zipfile
P=Path('/mnt/data'); O=P/'OrionDesk_twolevel_v10.6_Phase07_Merged'
read=lambda f:[json.loads(l) for l in Path(f).open(encoding='utf-8') if l.strip()]
sha=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest()
merged=read(O/'07_assistant_adjudications.jsonl');audit=read(O/'07_decision_audit.jsonl');pairs=read(O/'07_global_cross_shard_semantic_audit.jsonl')
s=json.loads((O/'07_adjudication_summary.json').read_text())
p=json.loads((O/'07_partition_validation.json').read_text());assert p['status']=='PASS'
s1=read(P/'OrionDesk_twolevel_v10.6_Phase07_Shard1/07_shard1_adjudications.jsonl')
s2=read(P/'OrionDesk_twolevel_v10.6_Phase07_Shard2/07_shard2_adjudications.jsonl')
ext=read(P/'semantic_decisions.jsonl')
assert len(s1)==1482 and len(s2)==1481 and len(merged)==len(audit)==len(ext)==2963
assert len({r['item_id'] for r in merged})==2963
assert [r['item_id'] for r in merged]==[x['item_id'] for x in ext]
byid={x['item_id']:x for x in s1+s2}
assert len(byid)==2963 and all(x==byid[x['item_id']] for x in merged)
assert all(a['final_phase07_item_id']==m['item_id'] and a['original_shard_item_sha256']==hashlib.sha256(json.dumps(m,sort_keys=True,ensure_ascii=False,separators=(',',':')).encode()).hexdigest() for a,m in zip(audit,merged))
assert [x['item_id'] for x in merged if x['direction']=='R']==s['final_R_ids']
assert [x['item_id'] for x in merged if x['direction']=='N']==s['final_N_ids']
assert [x['item_id'] for x in merged if x['direction']=='G']==s['final_G_ids']
counts=Counter((r['direction'],r['final_cell']) for r in merged)
assert counts=={('R','TP'):585,('R','FN'):53,('N','TN'):142,('G','TP'):1832,('G','FP'):56,('G',None):295}
assert sum(x['eligible'] and x['final_cell'] is None for x in merged)==0
assert len(pairs)==73 and Counter(x['direction'] for x in pairs)=={'G':48,'R':25}
assert len({(x['item_a'],x['item_b']) for x in pairs})==73
for x in pairs:
 a=byid[x['item_a']];b=byid[x['item_b']]
 assert a['shard_id']!=b['shard_id'] and a['direction']==b['direction']==x['direction']
 assert a['source_statement_en']==x['claim_a_en'] and b['source_statement_en']==x['claim_b_en']
 assert a['final_cell']==x['decision_a'] and b['final_cell']==x['decision_b']
 assert x['semantic_distinction_en'] and x['review_disposition']=='NO_CONFIRMED_CONTRADICTION_DIFFERENT_COMPLETE_PREDICATE'
 assert x['actual_pdf_support'] and x['original_generated_evidence_a'] and x['original_generated_evidence_b']
assert sha(P/'OrionDesk_AI_Detailed_Design_Specification(3).pdf')==s['source_pdf_sha256']
assert sha(P/'common_atomic_reqs(3).jsonl')==s['source_reference_R_sha256']
assert sha(P/'common_negative_controls(3).jsonl')==s['source_reference_N_sha256']
assert sha(P/'semantic_decisions.jsonl')==s['original_external_result_sha256']
assert s['original_queue_full_bytes_available_for_independent_rehash'] is False
assert s['cross_shard_opposite_cell_candidates_source_compared']==73
assert s['pdf_text_quotes_verified']==5901 and s['markdown_line_quotes_verified']==6988
assert s['pdf_visual_only_locators_preserved']==10 and s['reciprocal_original_line_candidates_verified']==6823
assert s['phase08_not_started'] and s['phase09_metrics_not_recomputed']
assert not (O/'07_input_blockers.jsonl').read_text().strip()
with zipfile.ZipFile(P/'batch_journals.zip') as z:
 names=[n for n in z.namelist() if n.endswith('.json') and n.startswith('batch_journals/B10.6-')]
 assert len(names)==186 and z.testzip() is None
out={'record_type':'PHASE07_INDEPENDENT_MERGE_VALIDATION','status':'PASS','method':'twolevel',
 'queue_order_matched_external_committed_results':True,'submitted_queue_full_bytes_rehashed':False,
 'all_2963_shard_rows_preserved_exactly':True,'shard_ID_duplicate_count':0,'shard_ID_missing_count':0,
 'shard_assistant_reclassification_performed':False,'external_model':'gpt-6.2-sol','external_effort':'high',
 'pdf_sha256_matched':True,'negative_controls_sha256_matched':True,'frozen_R_sha256_matched':True,
 'eligible_pending_count':0,'G_opposite_cell_scope_pairs_checked':48,'R_opposite_cell_scope_pairs_checked':25,
 'screened_pairs_with_confirmed_contradiction':0,'unscored_G_excluded':295,'semantic_screen_not_all_pairs_proof':True,
 'journal_archive_count':186,'phase08_not_executed':True,'phase09_not_executed':True}
(O/'07_independent_validation.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(out,indent=2))
