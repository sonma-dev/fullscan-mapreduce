# Phase 07 — Two-Shard Integration and Cross-Shard Consistency Review

**Status:** PHASE07_TWO_SHARD_MERGE_COMPLETED  
**Method:** twolevel  
**Protocol:** 10.6 with explicitly user-authorized two-shard Phase07 deviation  
**External judge:** gpt-6.2-sol, reasoning effort **high**, 16 items per batch.

## Integrations and preservation

Merged S1 (1,482 items) and S2 (1,481 items) into the original source queue order. All 2,963 items appear exactly once, including 638 frozen source requirements, 142 frozen negative controls and 2,183 generated semantic classes. No Shard1/Shard2 files, historical Phase07 cells, original nine reference documents, source/reference freeze, original external v5 results, or batch journals were edited.

## Item-level Phase07 final decisions (not canonical final FP)

| Cell | Count |
|---|---:|
| R:TP | 585 |
| R:FN | 53 |
| N:FP | 0 |
| N:TN | 142 |
| G:diagnostic TP / PDF-supported | 1832 |
| G:diagnostic FP / PDF-unsupported | 56 |
| G:nondefinitive excluded, unscored | 295 |

All eligible Phase07 item decisions are classified. The frozen `R:TP+R:FN=638` and `N:FP+N:TN=142` identities hold.

## Cross-shard semantic consistency review

Reviewed 73 opposite-cell cross-shard near-pairs (G=48, R=25), enumerated by char ngrams >=0.48 OR word ngrams >=0.40, plus cross-shard exact normalized G identity. Each selected pair is documented in `07_global_cross_shard_semantic_audit.jsonl` with source and generated quotations, both complete claims, the unsupported predicate for the negative side and a case-specific reason why the two claims differ. None of the screened pairs was adjudicated as an actual conflicting label for the same complete predicate. No cross-shard exact normalized G statements carry opposing cells.

This is a reproducible high-relevance cross-shard semantic screen and source review, **not** a mathematical proof against every lower-similarity paraphrase. Repeated same-cell generated requirements are handled by Phase08 and have NOT been counted as new canonical FP here.

## Evidence and execution integrity

- Frozen source PDF (90 pages), R/N ledgers, eight Markdown originals: SHA-256 matched.
- External run-state queue SHA-256, item order and all 186 committed batch journal contents matched. **The original 2,963-item queue bytes were not available to rehash**: a separately retrievable same-name historical file has 2,438 items and was NOT accepted as equivalent. Journal `input_digest` values are preserved but cannot be recomputed without the actual submitted full JSONL queue bytes.
- Original PDF textual quotations: 5901; exact Markdown original-line quotes: 6988; quoted reciprocal original-line candidates: 6823.
- Figure/visual-only PDF locators preserved separately: 10, and never claimed to be verified text quotations.
- No new gpt-6.2-sol API submission, new paid judge, or fabricated external result. Historical Phase07 decisions were candidate inputs to the shard reviews, so the merged output does not constitute a second statistically independent model run.

## Workflow boundary

Only the Phase07 S1+S2 merge and cross-shard audit were completed. Phase08 (N/F semantic residual consolidation) and Phase09 (Precision/Recall/F1) were not executed. The initial Phase07 full-run historical scores are not treated as new scores from this merge.
