# Phase 03 — R Coverage Discovery Validation

Status: **PHASE_COMPLETED** (candidate discovery, not committed TP/FN scoring)

- Protocol: 10.6
- Method: twolevel
- Frozen R source obligations: 638
- Frozen negative controls (unchanged): 142
- Generated Phase 02 occurrences (GO): 2349
- Generated Phase 02 semantic classes (GC): 2178
- Search-indexed units (GO + original Markdown lines): 4263
- Eight original Markdown source roles searched: yes
- All R PDF evidence verified from exact original pages or previously frozen visually inspected figures: yes
- Original generated quotation line and SHA-256 verified: yes
- Contextual table/event/entity/endpoint evidence bridges: 171

## Discovery status (non-scoring)
- CONTEXTUAL_BRIDGE_CANDIDATE: 171
- LOW_MATCH_NEEDS_RECIPROCAL_AUDIT: 121
- POTENTIAL_PARTIAL_OR_DIRECT_CANDIDATE: 238
- STRONG_LEXICAL_GO_CANDIDATE: 108

## Registry and contextual traceability
- component_bridge_success: 88
- component_expected: 88
- endpoint_bridge_success: 43
- endpoint_expected: 43
- entity_bridge_success: 18
- entity_expected: 18
- event_bridge_success: 22
- event_expected: 22

## Evidence policy

Every indexed source obligation has an original PDF page and an actual-file/line quotation candidate. The retrieval scores, bridge identities and source line quotations are **not** final coverage decisions. In particular, literal name presence in an inventory does not establish that its stated invariant is a definitive generated implementation obligation. All source-to-generated exact entailment challenges, missing predicates, exceptions, affirmatively conflicting statements, and proof-family reuse remain Phase 04 work; raw excluded/orphan line assertions are rechecked in Phase 05.

The Phase 01 locked PDF/R/N and Phase 02 GO/GC/exclusion/source index are immutable. No rows in these inputs were rewritten. No Precision, Recall, F1, TP or FN totals were computed. Phase 04 has not begun.

## Phase 03 outputs

- `03_source_coverage.jsonl`: one candidate-discovery row per frozen source obligation, with verified original PDF and Markdown quotations, exact actual filenames, line locators, digest and explicit uncertainty.
- `03_semantic_coverage_bridges.jsonl`: individually source-verified proposed inheritance/conjunctive bridges, with ambiguity and Phase 04/05 obligations.
- `03_discovery_validation.json`: machine-verifiable input and output scope, checks, and counts.
- `03_validation_report.md`: this report.
- `discover_phase03.py`: reproducible scanner/retrieval/bridge producer.
