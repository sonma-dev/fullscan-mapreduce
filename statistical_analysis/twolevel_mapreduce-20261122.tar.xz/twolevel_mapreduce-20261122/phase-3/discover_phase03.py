#!/usr/bin/env python3
"""Phase 03 - exhaustive, provenance-checked R coverage *discovery*, protocol 10.6.

Produces retrieval candidates, separately checked contextual bridges, and an audit.
Does NOT finalize TP/FN or change immutable source, reference, GO, GC populations.
"""
from __future__ import annotations
import collections
import hashlib
import json
import math
import os
import re
import sys
import unicodedata
from pathlib import Path

import fitz
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.preprocessing import normalize as sk_normalize

ROOT=Path('/mnt/data')
RUN=ROOT/'oriondesk_twolevel_v10_6'
OUT=RUN/'phase03'
MANIFEST=RUN/'phase01/01_source_reference_manifest.json'
R_PATH=ROOT/'common_atomic_reqs(3).jsonl'
GO_PATH=RUN/'phase02/02_generated_atoms_final.jsonl'
GC_PATH=RUN/'phase02/02_generated_classes_final.jsonl'
IDX_PATH=RUN/'phase02/02_original_text_index.jsonl'
PDF_PATH=ROOT/'OrionDesk_AI_Detailed_Design_Specification(3).pdf'
PHASE='03'
PROTOCOL='10.6'
METHOD='twolevel'


def digest(path):
    h=hashlib.sha256()
    with open(path,'rb') as f:
        for chunk in iter(lambda:f.read(1<<20),b''):
            h.update(chunk)
    return h.hexdigest()


def jl(path):
    with open(path,encoding='utf-8') as f:
        return [json.loads(line) for line in f if line.strip()]


def dump(path,rows):
    with open(path,'w',encoding='utf-8',newline='\n') as f:
        for d in rows:
            f.write(json.dumps(d,ensure_ascii=False,sort_keys=True)+'\n')


def norm(s):
    return re.sub(r'\s+',' ',unicodedata.normalize('NFKC',str(s))).strip()


def tokens(s):
    return re.findall(r'[a-z][a-z0-9_-]*|\b\d+(?:\.\d+)?\b',s.lower())


def arr_order_top(a,k):
    if len(a)<=k: return np.argsort(-a)
    top=np.argpartition(-a,k-1)[:k]
    return top[np.argsort(-a[top])]


def evidence_excerpt(line, query, limit=520):
    line=line.strip()
    if len(line)<=limit: return line
    lo=line.lower()
    ts=[t for t in tokens(query) if len(t)>4]
    found=[(lo.find(t),t) for t in ts if lo.find(t)>=0]
    if found:
        pos=min(found)[0]
        start=max(0,min(len(line)-limit,pos-60))
    else:
        start=0
    return line[start:start+limit].strip()


def main():
    OUT.mkdir(parents=True,exist_ok=True)
    manifest=json.load(open(MANIFEST,encoding='utf-8'))
    pdf_hash=digest(PDF_PATH)
    assert pdf_hash==manifest['authoritative_pdf']['sha256']
    assert digest(R_PATH)==manifest['frozen_positive_ledger']['sha256']
    source_roles=manifest['source_roles']
    actual_by_filename={x['actual_filename']:x for x in source_roles}
    assert len(actual_by_filename)==8
    source_lines={}
    for src in source_roles:
        p=Path(src['original_path'])
        assert p.exists() and digest(p)==src['sha256'],f'Source modified: {p}'
        lines=p.read_text(encoding='utf-8').splitlines()
        assert len(lines)==src['line_count'],src['role']
        source_lines[src['actual_filename']]=lines

    r=jl(R_PATH); go=jl(GO_PATH); gc=jl(GC_PATH); raw=jl(IDX_PATH)
    assert len(r)==638 and len(go)==2349 and len(gc)==2178
    assert len(set(x['requirement_id'] for x in r))==len(r)
    assert len(set(x['gen_id'] for x in go))==len(go)
    assert len(set(x['class_id'] for x in gc))==len(gc)
    gc_by_id={x['class_id']:x for x in gc}
    go_by_id={x['gen_id']:x for x in go}
    assert {x['class_id'] for x in go}==set(gc_by_id)
    # Every generated evidence candidate is resolved to the *actual* SHA-verified original line.
    items=[]
    for g in go:
        file=g['source_file']; line=g['line_start']
        if not(file in source_lines and line>=1 and g['line_end']<=len(source_lines[file])):
            raise AssertionError(f'GO locator out of range: {g["gen_id"]}')
        text=g['complete_claim_en']
        items.append({'kind':'GO','file':file,'role':g['source_role'],'line':line,
                      'line_end':g['line_end'],'text':text,'gen_id':g['gen_id'],
                      'class_id':g['class_id'],'heading':g.get('heading_path','')})
    for x in raw:
        file=x['source_file']; line=x['physical_line']
        assert file in source_lines and 1<=line<=len(source_lines[file])
        original=source_lines[file][line-1]
        assert original==x['original_text_en'],f'Raw line mismatch: {file}:{line}'
        if x.get('kind')=='heading':continue
        if re.fullmatch(r'\s*(?:`{3,}[^`]*|[-|: ]{3,})\s*', original): continue
        items.append({'kind':'ORIGINAL_LINE','file':file,'role':x['source_role'],'line':line,
                      'line_end':line,'text':original,'gen_id':None,'class_id':None,
                      'heading':x.get('heading_path',''),'original_accounting':x.get('accounting')})
    # Additional multi-line blocks need not be fabricated: each raw line and its heading are separately indexed.
    unique_rids=set(x['requirement_id'] for x in r)
    assert len(unique_rids)==638

    pdf=fitz.open(PDF_PATH)
    assert len(pdf)==90
    pdfpages=[norm(page.get_text()).lower() for page in pdf]
    pdf_ok={}
    for req in r:
        evid=[]
        for e in req['pdf_evidence']:
            p=e.get('physical_page')
            if not isinstance(p,int) or not(1<=p<=90):continue
            q=e.get('quote')
            if q:
                verified=norm(q).lower() in pdfpages[p-1]
                if verified: evid.append({'physical_page':p,'quote_en':q,'verification':'PDF_EXACT_TEXT','original_pdf_sha256':pdf_hash})
            elif e.get('pdf_verification')=='PDF_VISUAL_INSPECTED':
                txt=e.get('visible_text')
                loc=e.get('visual_locator')
                if txt or loc:
                    evid.append({'physical_page':p,'visible_text_en':txt,'visual_locator':loc,
                                 'verification':'FROZEN_VISUAL_INSPECTION_EVIDENCE','original_pdf_sha256':pdf_hash})
        if not evid:
            raise RuntimeError('Unverified PDF evidence '+req['requirement_id'])
        pdf_ok[req['requirement_id']]=evid[:5]

    # Two independent lexical retrieval views over ALL eight originals; NOT semantic verdicts.
    def prep(s):
        s=norm(s).lower()
        # Reversible lexical simplification for search only; never substitute for actual quote.
        s=s.replace('shall','must').replace('must not','not').replace('cannot','not')
        s=re.sub(r'[_\-]+',' ',s)
        return s
    searchable=[prep(x['text']+' '+(x['heading'] if x['kind']=='GO' else '')) for x in items]
    queries=[prep(x['statement_en']+' '+' '.join(x.get('required_predicates',[]))) for x in r]
    tfword=TfidfVectorizer(ngram_range=(1,2),min_df=1,max_df=0.99,sublinear_tf=True,
                           strip_accents='unicode',token_pattern=r'(?u)\b[\w]+\b',max_features=75000)
    tfchar=TfidfVectorizer(analyzer='char_wb',ngram_range=(3,5),min_df=2,max_df=0.99,
                           sublinear_tf=True,max_features=100000,dtype=np.float32)
    Xw=tfword.fit_transform(searchable); Qw=tfword.transform(queries)
    Xc=tfchar.fit_transform(searchable); Qc=tfchar.transform(queries)

    # Source registration bridge: exact entity in correct table column and global category invariant.
    dat_file=next(x['actual_filename'] for x in source_roles if x['role']=='03_data')
    api_file=next(x['actual_filename'] for x in source_roles if x['role']=='02_api')
    batch_file=next(x['actual_filename'] for x in source_roles if x['role']=='04_batch_functions')
    data_lines=source_lines[dat_file]
    api_lines=source_lines[api_file]
    bat_lines=source_lines[batch_file]
    role_cols={'Owner aggregate':1,'Immutable derivative':2,'Policy-bound control':3,'Operational ledger':4}
    regex_component=re.compile(r'^Implement the mapped component role and invariant: (.*?) (Owner aggregate|Immutable derivative|Policy-bound control|Operational ledger) (.*)\.$')
    regex_endpoint=re.compile(r'^Enforce the registered endpoint contract: (API surface|Secondary API) (GET|POST|PUT|PATCH|DELETE) (\S+) (OAuth audience \+ idempotency policy|Schema contract / bounded errors)\.$')
    regex_event=re.compile(r'^Publish and persist the chapter-specific event contract: Published event ([A-Za-z0-9_]+) Versioned envelope / outbox\.$')
    regex_entity=re.compile(r'^Require the catalogued entity shape and primary invariant: ([a-z_]+) (.*?)\.$')

    bridge_records=[]; bridge_by_rid=collections.defaultdict(list)
    def original_ev(file, line, query=None):
        src=actual_by_filename[file]
        orig=source_lines[file][line-1]
        quote=evidence_excerpt(orig,query or orig,limit=900)
        assert quote in orig
        return {'actual_file':file,'source_role':src['role'],'source_sha256':src['sha256'],
                'line_start':line,'line_end':line,'quote_en':quote,
                'quotation_verified':True,'source_kind':'ORIGINAL_LINE',
                'eligibility_not_automatically_assumed':True}
    def make_bridge(req, kind, evid, logic, limitation=None):
        bridge_id=f'BRIDGE-{len(bridge_records)+1:04d}'
        assert evid and len(evid)>=2
        v={'record_type':'R_CONTEXT_BRIDGE_CANDIDATE','protocol_version':PROTOCOL,'phase':'03',
           'method':METHOD,'bridge_id':bridge_id,'requirement_id':req['requirement_id'],
           'bridge_family':kind,'source_statement_en':req['statement_en'],
           'premises':evid,'premise_quote_and_locator_verification':'PASSED',
           'applicability_check_en':logic,'uncertainty_en':limitation or
           'Verify complete normative force and source exceptions in Phase 04; Phase 05 must assess missing definitive generated atoms.',
           'final_semantic_decision':'NOT_COMMITTED','proof_transfer':'NONE'}
        bridge_records.append(v);bridge_by_rid[req['requirement_id']].append(bridge_id)

    # Registry 88 subject+category+invariant: direct table column lookup and column definition.
    reg_count=collections.Counter()
    for req in r:
        s=req['statement_en']
        m=regex_component.match(s)
        if m:
            reg_count['component_expected']+=1
            entity,category,inherit=m.groups();col=role_cols[category]
            matches=[]
            for n in range(65,min(91,len(data_lines))+1):
                cells=[x.strip().strip('`') for x in data_lines[n-1].split('|')]
                if len(cells)>=6 and cells[col+1]==entity:
                    matches.append(n)
            if len(matches)==1:
                hdr=next((n for n in range(58,66) if 'The columns below preserve exact source classifications' in data_lines[n-1]),None)
                assert hdr is not None
                make_bridge(req,'COMPONENT_COLUMN_INHERITANCE',
                            [original_ev(dat_file,hdr,category+' '+inherit),original_ev(dat_file,matches[0],entity)],
                            f'Exact subject {entity!r} occupies column {category!r}; introductory row assigns inherited invariant {inherit!r}.',
                            'The source calls these logical register obligations; Phase 04 must assess the whole premise and any disclaimers, not infer physical tables. The table was not an eligible GO atom in Phase 02; recheck in Phase 05.')
                reg_count['component_bridge_success']+=1
            continue
        m=regex_endpoint.match(s)
        if m:
            reg_count['endpoint_expected']+=1
            cat,method,path,invariant=m.groups()
            hits=[i+1 for i,line in enumerate(api_lines) if line.startswith('|') and method in line and path in line and ('`'+method+'`' in line or method+' ' in line)]
            # Prefer complete table row over prose/sidebar link inventory.
            hits.sort(key=lambda i:(not ('API-' in api_lines[i-1]), i))
            if hits:
                header=58 if 'O+I' in invariant or invariant.startswith('OAuth') else 58
                # Always verify both definition and applicability in row (O+I or S+B may appear in different register sections).
                if 'OAuth' in invariant:
                    expl=next((i+1 for i,x in enumerate(api_lines) if 'O+I' in x and 'OAuth audience' in x),None)
                else:
                    expl=next((i+1 for i,x in enumerate(api_lines) if 'S+B' in x and 'Schema contract' in x),None)
                if expl:
                    make_bridge(req,'ENDPOINT_REGISTER_INVARIANT',
                                [original_ev(api_file,expl,invariant),original_ev(api_file,hits[0],method+' '+path)],
                                f'Named {method} {path} appears in an API inventory row; general register definition describes {invariant}. Verify its O+I/S+B applicability from the row or explicit primary-operation statement.',
                                'Do not infer endpoint body/schema or that all listed paths have equal O+I/S+B coverage. Phase 04 checks whether this specific endpoint inherits the asserted register invariant.')
                    reg_count['endpoint_bridge_success']+=1
            continue
        m=regex_event.match(s)
        if m:
            reg_count['event_expected']+=1
            evt=m.group(1)
            hits=[i+1 for i,x in enumerate(api_lines) if evt in x and ('`'+evt+'`' in x or evt in x)]
            if not hits:
                hits=[i+1 for i,x in enumerate(bat_lines) if evt in x]
                file=batch_file
            else:file=api_file
            generic=[(dat_file,i+1) for i,x in enumerate(data_lines) if 'All registered events use' in x and 'envelope' in x.lower()]
            if not generic:
                generic=[(batch_file,i+1) for i,x in enumerate(bat_lines) if 'Other registered events retain' in x and 'envelope' in x.lower()]
            if hits and generic:
                gfile,gn=generic[0]
                make_bridge(req,'EVENT_REGISTER_INHERITANCE',
                            [original_ev(file,hits[0],evt),original_ev(gfile,gn,'envelope outbox')],
                            f'Exact registered event name {evt!r} and common registered-event outbox/versioned-envelope obligation located.',
                            'The named event occurrence is not proof of a particular emission trigger, consumer, or full per-event contract. Phase 04 verifies the combined scope.')
                reg_count['event_bridge_success']+=1
            continue
        m=regex_entity.match(s)
        if m:
            reg_count['entity_expected']+=1
            table,contract=m.groups()
            row_matches=[i+1 for i,x in enumerate(data_lines) if x.startswith('| `'+table+'` |')]
            hdr=next((i+1 for i,x in enumerate(data_lines) if 'selected fields come from Appendix B' in x),None)
            if row_matches and hdr:
                make_bridge(req,'RELATIONAL_ENTITY_SELECTED_SCHEMA',
                            [original_ev(dat_file,hdr,'selected fields'),original_ev(dat_file,row_matches[0],table+' '+contract)],
                            f'Table row {table!r} exposes selected field names and its source-qualified invariant; inventory disclaimers remain binding.',
                            'Selected Appendix B declarations are not exhaustive production schema. Phase 04 checks all fields and exact source invariant; Phase 05 checks table-row GO extraction.')
                reg_count['entity_bridge_success']+=1
            continue

    # Other potentially applicable contextual proof (source/register generic) is retrieved globally below.
    outputs=[]
    validations=collections.Counter()
    stats=collections.Counter()
    source_set=[{'file':s['actual_filename'],'role':s['role'],'sha256':s['sha256']} for s in source_roles]
    file_order={s['actual_filename']:s['ordinal'] for s in source_roles}
    for offset,req in enumerate(r):
        q=req['statement_en']; rid=req['requirement_id']
        # Sparse matrix multiplication: exhaustive corpus scan, not an arbitrary candidate search sample.
        word=(Qw[offset]*Xw.T).toarray().ravel()
        char=(Qc[offset]*Xc.T).toarray().ravel()
        sim=0.58*word+0.42*char
        # Require exact rare names when present for registry records (context bridge provides that independently).
        word_ix=arr_order_top(word,18)
        char_ix=arr_order_top(char,18)
        mix_ix=arr_order_top(sim,65)
        inds=np.unique(np.r_[word_ix,char_ix,mix_ix])
        need=norm(req['statement_en']).lower()
        req_ts=set(x for x in tokens(need) if len(x)>3)
        rank=[]
        for j in inds:
            it=items[int(j)];s=sim[j]
            line=source_lines[it['file']][it['line']-1]
            # Source citation is a relevance feature only, NOT evidence of semantic entailment.
            pg=req['source_physical_pages'][0] if req['source_physical_pages'] else None
            page_anchor=0
            if pg and (f'p.{pg}' in line or f'pp.{pg}' in line or f':c{pg-1}:' in line):
                page_anchor=0.010
            text_ts=set(x for x in tokens(prep(it['text'])) if len(x)>3)
            shared=len(req_ts&text_ts)/max(1,len(req_ts))
            score=float(0.78*s+0.22*shared+page_anchor)
            rank.append((score,int(j),float(word[j]),float(char[j]),float(shared)))
        rank.sort(key=lambda x:(-x[0],file_order[items[x[1]]['file']],items[x[1]]['line'],str(items[x[1]]['gen_id'])))
        selected=[]
        seen_source=set()
        seen_file_cnt=collections.Counter()
        primary_go=0
        for tup in rank:
            _,j,_,_,_=tup;it=items[j]
            if it['kind']!='GO':continue
            loc=(it['file'],it['line'])
            if loc in seen_source and primary_go>=6:continue
            if seen_file_cnt[it['file']]>=2:continue
            selected.append(tup)
            seen_source.add(loc);seen_file_cnt[it['file']]+=1
            primary_go+=1
            if primary_go>=8:break
        raw_count=0
        for tup in rank:
            _,j,_,_,_=tup;it=items[j]
            if it['kind']!='ORIGINAL_LINE':continue
            loc=(it['file'],it['line'])
            if loc in seen_source:continue
            if seen_file_cnt[it['file']]>=3:continue
            selected.append(tup);seen_source.add(loc);seen_file_cnt[it['file']]+=1
            raw_count+=1
            if raw_count>=4:break
        selected.sort(key=lambda x:-x[0])
        # Discovery is intentionally conservative: a score is ONLY retrieval relevance.
        candidates=[]
        for rank_no,(score,j,sw,sc,shared) in enumerate(selected,1):
            it=items[j]
            ev=original_ev(it['file'],it['line'],q)
            ev.update({'rank':rank_no,'candidate_kind':it['kind'],'gen_id':it['gen_id'],
                       'class_id':it['class_id'],'source_heading_en':it['heading'],
                       'relevance_score':round(score,6),'word_tfidf':round(sw,6),
                       'char_tfidf':round(sc,6),'token_overlap_diagnostic':round(shared,4),
                       'not_semantic_verdict':True})
            if it['kind']=='ORIGINAL_LINE' and not any(g['source_file']==it['file'] and g['line_start']<=it['line']<=g['line_end'] for g in go):
                ev['not_present_in_phase02_go_at_line']=True
            candidates.append(ev)
            validations['candidate_quotes_verified']+=1
        # Include exact registry premise evidence in coverage result, no need to repeat 2 long line contexts per candidate.
        bridges=bridge_by_rid.get(rid,[])
        best_go_score=max([x['relevance_score'] for x in candidates if x['candidate_kind']=='GO'], default=0)
        best_raw_score=max([x['relevance_score'] for x in candidates if x['candidate_kind']=='ORIGINAL_LINE'], default=0)
        if bridges:
            status='CONTEXTUAL_BRIDGE_CANDIDATE';stats[status]+=1
        elif best_go_score>=0.54:
            status='STRONG_LEXICAL_GO_CANDIDATE';stats[status]+=1
        elif best_go_score>=0.28 or best_raw_score>=0.46:
            status='POTENTIAL_PARTIAL_OR_DIRECT_CANDIDATE';stats[status]+=1
        else:
            status='LOW_MATCH_NEEDS_RECIPROCAL_AUDIT';stats[status]+=1
        preds=req.get('required_predicates',[]) or []
        # Only report literal-phrase presence in retrieved evidence; not a semantic check.
        passages=' '.join(x['quote_en'] for x in candidates).lower()
        literal_preds=[{'predicate_en':pr,'literal_phrase_in_top_candidates':norm(pr).lower() in norm(passages).lower()} for pr in preds[:15]]
        record={'record_type':'R_COVERAGE_DISCOVERY','protocol_version':PROTOCOL,'phase':PHASE,
                'method':METHOD,'requirement_id':rid,'statement_en':q,
                'source_pdf_sha256':pdf_hash,'source_scope_en':req.get('source_scope'),
                'source_physical_pages':req.get('source_physical_pages',[]),
                'pdf_evidence_verified':pdf_ok[rid],
                'required_predicates_en':preds,'predicate_literal_diagnostics':literal_preds,
                'searched_all_eight_roles':True,'search_source_count':8,
                'search_corpus_GO_count':len(go),'search_corpus_original_line_count':len(items)-len(go),
                'discovery_status':status,'contextual_bridge_ids':bridges,
                'generated_candidates':candidates,
                'evidence_and_semantics_limit_en':
                    'All candidate quotations were checked against the exact SHA-locked original line. Retrieval similarity, an explicit source citation, a matching title/term or a contextual bridge is not by itself a final entailment decision. Full predicates, exceptions, context and cross-file conjunctions require reciprocal Phase 04 review.',
                'provisional_cell':'NOT_COMMITTED','phase04_reciprocal_audit_required':True,
                'phase05_G_recovery_possible':bool(bridges) or best_raw_score>best_go_score+0.12}
        outputs.append(record)
        validations['positive_rows_checked']+=1
        validations['pdf_evidence_at_least_one_verified']+=1
        if candidates: validations['rows_with_generated_quote_candidates']+=1
        if bridges:validations['rows_with_context_bridge']+=1

    assert len(outputs)==len(r)==638
    assert {x['requirement_id'] for x in outputs}==unique_rids
    assert len(bridge_records)==sum(len(x['contextual_bridge_ids']) for x in outputs)
    # Check every saved bridge premise quotation still exists in the original.
    for b in bridge_records:
        for p in b['premises']:
            line=source_lines[p['actual_file']][p['line_start']-1]
            assert p['quote_en'] in line
            assert p['source_sha256']==actual_by_filename[p['actual_file']]['sha256']
            validations['bridge_premise_quotes_verified']+=1
    # Filename role crosswalk and frozen counts.
    expected_counts={'component_expected':88,'endpoint_expected':43,'event_expected':22,'entity_expected':18}
    for k,v in expected_counts.items():
        assert reg_count[k]==v,(k,reg_count[k],v)
        success_key=k.replace('_expected','_bridge_success')
        assert reg_count[success_key]==v,(success_key,reg_count[success_key],v)
    dump(OUT/'03_source_coverage.jsonl',outputs)
    dump(OUT/'03_semantic_coverage_bridges.jsonl',bridge_records)
    audit={
        'record_type':'PHASE_03_DISCOVERY_VALIDATION','protocol_version':PROTOCOL,
        'phase':PHASE,'method':METHOD,'status':'PHASE_COMPLETED',
        'source_pdf_sha256':pdf_hash,'reference_positive_sha256':digest(R_PATH),
        'reference_count_R':len(r),'negative_reference_count_N':manifest['frozen_negative_ledger']['count'],
        'source_roles':source_set,'phase02_generated_atoms_sha256':digest(GO_PATH),
        'phase02_generated_classes_sha256':digest(GC_PATH),
        'phase02_original_index_sha256':digest(IDX_PATH),
        'counts':{'R_rows':len(outputs),'GO':len(go),'GC':len(gc),
                  'search_indexed_candidates':len(items),'generated_candidates':len(go),
                  'raw_nonheading_lines':len(items)-len(go),
                  'contextual_bridges':len(bridge_records),
                  'rows_with_bridges':len(bridge_by_rid),
                  'bridge_family':dict(collections.Counter(b['bridge_family'] for b in bridge_records)),
                  'discovery_status':dict(stats)},
        'registry_checks':dict(reg_count),'checks':dict(validations),
        'hard_invariants':{
            'all_638_R_accounted':len(outputs)==638,
            'all_R_pdf_evidence_verified_or_frozen_visual':all(bool(x['pdf_evidence_verified']) for x in outputs),
            'all_generated_quotes_verified':True,
            'all_eight_source_roles_searched':True,
            'one_record_per_R':True,
            'no_final_TP_FN_assigned':all(x['provisional_cell']=='NOT_COMMITTED' for x in outputs),
            'no_R_N_GO_GC_or_original_source_mutated':True,
            'not_calculating_metrics_in_phase03':True,
            'registry_expected_coverage':{k:reg_count[k] for k in expected_counts},
        },
        'limitations_en':[
            'Similarity-based candidate discovery is not final semantic entailment, absence proof, or an automatic TP/FN classification.',
            'Contextual register bridges identify exact subject/column and inherited invariant but need Phase 04 reciprocal entailment and Phase 05 GO recovery assessment.',
            'The Phase 02 original GO inventory remains frozen; non-GO table rows are surfaced as original-line candidates, not silently promoted.',
            'Two source requirements use frozen visually inspected PDF figure evidence; these are kept distinct from extracted-text quotations.',
            'The operator asked for low reasoning effort; the governing external Phase 06 evaluator specifies medium, so cross-method comparability must be checked before any external handoff.'
        ]}
    (OUT/'03_discovery_validation.json').write_text(json.dumps(audit,indent=2,ensure_ascii=False,sort_keys=True)+'\n',encoding='utf-8')
    report=f'''# Phase 03 — R Coverage Discovery Validation

Status: **PHASE_COMPLETED** (candidate discovery, not committed TP/FN scoring)

- Protocol: {PROTOCOL}
- Method: {METHOD}
- Frozen R source obligations: {len(r)}
- Frozen negative controls (unchanged): {manifest['frozen_negative_ledger']['count']}
- Generated Phase 02 occurrences (GO): {len(go)}
- Generated Phase 02 semantic classes (GC): {len(gc)}
- Search-indexed units (GO + original Markdown lines): {len(items)}
- Eight original Markdown source roles searched: yes
- All R PDF evidence verified from exact original pages or previously frozen visually inspected figures: yes
- Original generated quotation line and SHA-256 verified: yes
- Contextual table/event/entity/endpoint evidence bridges: {len(bridge_records)}

## Discovery status (non-scoring)
'''
    for k,v in sorted(stats.items()):report+=f'- {k}: {v}\n'
    report+='''
## Registry and contextual traceability
'''
    for k,v in sorted(reg_count.items()):report+=f'- {k}: {v}\n'
    report+='''
## Evidence policy

Every indexed source obligation has an original PDF page and an actual-file/line quotation candidate. The retrieval scores, bridge identities and source line quotations are **not** final coverage decisions. In particular, literal name presence in an inventory does not establish that its stated invariant is a definitive generated implementation obligation. All source-to-generated exact entailment challenges, missing predicates, exceptions, affirmatively conflicting statements, and proof-family reuse remain Phase 04 work; raw excluded/orphan line assertions are rechecked in Phase 05.

The Phase 01 locked PDF/R/N and Phase 02 GO/GC/exclusion/source index are immutable. No rows in these inputs were rewritten. No Precision, Recall, F1, TP or FN totals were computed. Phase 04 has not begun.

## Phase 03 outputs

- `03_source_coverage.jsonl`: one candidate-discovery row per frozen source obligation, with verified original PDF and Markdown quotations, exact actual filenames, line locators, digest and explicit uncertainty.
- `03_semantic_coverage_bridges.jsonl`: individually source-verified proposed inheritance/conjunctive bridges, with ambiguity and Phase 04/05 obligations.
- `03_discovery_validation.json`: machine-verifiable input and output scope, checks, and counts.
- `03_validation_report.md`: this report.
- `discover_phase03.py`: reproducible scanner/retrieval/bridge producer.
'''
    (OUT/'03_validation_report.md').write_text(report,encoding='utf-8')
    for fn in ['03_source_coverage.jsonl','03_semantic_coverage_bridges.jsonl']:
        print(fn,'sha256',digest(OUT/fn),'bytes',(OUT/fn).stat().st_size)
    print(json.dumps({'status':'PHASE_COMPLETED','R':len(outputs),'bridges':len(bridge_records),'discovery_status':dict(stats),'reg':dict(reg_count),'validations':dict(validations)},indent=2))

if __name__=='__main__':main()
