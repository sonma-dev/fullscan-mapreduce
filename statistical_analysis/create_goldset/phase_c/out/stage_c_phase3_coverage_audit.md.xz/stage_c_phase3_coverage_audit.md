# Stage C Phase 3 — Coverage and Manifest Audit

**Scope:** The Stage C coverage/provenance pass only. No semantic Reduce was repeated; no chapter JSONL, positive ledger, negative ledger, or freeze artifact was changed.

## Executive findings

- Source identity: 90 physical PDF pages; SHA-256 agrees with the chapter manifest.

- Manifest: 29 segments; 90/90 pages assigned exactly once, with no unassigned or duplicate page assignments.

- Coverage reports: 29/29 present; 90/90 physical pages have exactly one explicit `inspected: true` record.

- Read-only comparison with the previously supplied chapter JSONLs: 2,926 positive candidate IDs and 421 control candidate IDs; every segment-level report has matching candidate totals and complete top-level ID lists. No missing or extra local candidate IDs were detected.

- **Confirmed missing PDF pages or local candidate IDs: none.** This is not a proof of semantic requirement completeness.

- **One localized reporting defect:** Chapter 9, physical PDF page 35, has two candidate-count discrepancies; see below.

- 151 per-page evidence/review notes are present in the existing coverage files. Their presence is not proof that an obligation was omitted.

## Candidate count and pagination reconciliation

The report uses two non-interchangeable count concepts: (a) unique chapter-local IDs and (b) citations or support occurrences per physical page. When a candidate has evidence on more than one page, page counts are not necessarily additive. A difference between the sum of page counts and the unique chapter total is not, by itself, a lost candidate.

| Segment | Positive IDs | Control IDs | Coverage pages | Status |
|---|---:|---:|---|---|
| `frontpage` | 18 | 8 | 1,2,3,4,5,6,7 | Reconciled |
| `chapter_1` | 107 | 14 | 8,9,10 | Reconciled |
| `chapter_2` | 127 | 20 | 11,12,13,14 | Reconciled |
| `chapter_3` | 130 | 16 | 15,16,17 | Reconciled |
| `chapter_4` | 117 | 15 | 18,19,20 | Reconciled |
| `chapter_5` | 117 | 17 | 21,22,23 | Reconciled |
| `chapter_6` | 128 | 15 | 24,25,26 | Reconciled |
| `chapter_7` | 114 | 18 | 27,28,29 | Reconciled |
| `chapter_8` | 112 | 18 | 30,31,32,33 | Reconciled |
| `chapter_9` | 112 | 13 | 34,35,36 | Count-definition anomaly (p.35) |
| `chapter_10` | 114 | 19 | 37,38,39 | Reconciled |
| `chapter_11` | 115 | 10 | 40,41,42,43 | Reconciled |
| `chapter_12` | 93 | 14 | 44,45,46,47 | Reconciled |
| `chapter_13` | 92 | 13 | 48,49,50 | Reconciled |
| `chapter_14` | 105 | 14 | 51,52,53 | Reconciled |
| `chapter_15` | 112 | 11 | 54,55,56 | Reconciled |
| `chapter_16` | 121 | 15 | 57,58,59,60 | Reconciled |
| `chapter_17` | 115 | 17 | 61,62,63 | Reconciled |
| `chapter_18` | 122 | 13 | 64,65,66,67 | Reconciled |
| `chapter_19` | 113 | 16 | 68,69,70 | Reconciled |
| `chapter_20` | 128 | 12 | 71,72,73 | Reconciled |
| `chapter_21` | 98 | 16 | 74,75,76,77 | Reconciled |
| `chapter_22` | 118 | 17 | 78,79,80,81 | Reconciled |
| `appendix_a` | 87 | 15 | 82,83,84 | Reconciled |
| `appendix_b` | 128 | 26 | 85,86 | Reconciled |
| `appendix_c` | 61 | 12 | 87 | Reconciled |
| `appendix_d` | 43 | 16 | 88 | Reconciled |
| `appendix_e` | 49 | 9 | 89 | Reconciled |
| `appendix_f` | 30 | 2 | 90 | Reconciled |

### Material reporting discrepancy

- **Chapter 9, page 35, positives:** reported `positive_candidate_count = 70` while 57 distinct local positive IDs cite that page. Exactly 70 positive PDF evidence excerpts cite the page.

- **Chapter 9, page 35, negative controls:** reported `negative_candidate_count = 8` while 5 distinct control IDs cite that page. Exactly 8 control evidence excerpts cite the page.

- The `counting_method_en` note says that per-page counts represent candidate records with evidence on that page. The apparent use of raw evidence excerpt counts on page 35 contradicts this description. This is a report-definition mismatch, **not a confirmed loss of source atoms**. The underlying Stage B files were not edited.

### Explicitly zero-candidate pages

- Pages: 1, 2, 3, 4, 5, 6, 14, 33, 43, 47, 60, 67, 77, 81.

- Physical pages 1–6 contain cover/contents and document-navigation information; the other zero-candidate pages contain representative operator-view figures rather than independently established chapter duties. Each has an explicit inspection record and rationale in its original coverage JSON.

## Open semantic and source-evidence issues (not new requirements)

- `chapter_9` pp. 35: Reported positive and control page counts appear to count evidence excerpts rather than distinct candidate records. Positive 70 vs 57 distinct IDs; controls 8 vs 5 distinct IDs. The source chapter input IDs and global totals are complete.

- `frontpage` pp. 2, 7: Whether the representative UI and normative-figure interpretation create independently testable obligations is unresolved in the coverage notes.

- `appendix_a` pp. 83, 84: REST role/status context and illustrative error envelope require cross-chapter interpretation; no missing local ID is confirmed.

- `appendix_b` pp. 85, 86: Broad table-level constraints and SQL/DML scope must be reconciled without inventing unstated fields or global defaults.

- `appendix_c` pp. 87: The A2A task envelope appears as an example; source evidence does not explicitly establish all example members as mandatory.

- `appendix_d` pp. 88: The exact definitions of release-blocking SEC-001..SEC-012 are not provided in Appendix D; no equivalence with T-01..T-12 can be assumed.

- `appendix_e` pp. 89: Source matrix references RPO/RTO and test thresholds; check cross-chapter support before scoring distinct obligations.

- `appendix_f` pp. 90: The chapter is titled Examples; YAML numeric settings and F.1 runbook normativity remain flagged instead of silently converted into mandatory requirements.

## Interpretation and limits

- All coverage files contain the required per-page accounting concepts, despite heterogeneous JSON key names (`pages`, `page_coverage`, `per_page`, etc.).

- For 11 segment/kind combinations, sums of per-page counts differ from unique chapter totals. This is explainable by multi-page evidence or citation multiplicity. Only the Chapter 9 page-35 mismatch is inconsistent with the report’s own distinct-candidate counting definition.

- The prior Phase 1 and Phase 2 source JSONLs were used **read-only** to compare declared candidate IDs/counts with actual inputs. They are not included in the newly supplied `process_c2.zip`; they were available from the preceding requests in this conversation. No missing inputs blocked this Phase 3 audit.

- The audit cannot certify full semantic recall against every normative sentence, diagram label or table cell of the PDF. Such an assertion would require independent source-to-map validation and belongs to Stage D, which has **not** been performed.

- No Stage A or Stage B file was modified, no new atomic requirement was introduced, no positive or negative ledger was regenerated, and no global Reduce reconciliation or freeze was performed.

