# Stage D — Independent Reference Validation and Provisional Freeze

**Protocol:** Gold Set Creation Protocol v1.0; compatibility: OrionDesk One-Pass Atomic Evaluation Protocol v6.2.
**Construction status:** `REFERENCE_FROZEN_PROVISIONAL`; **frozen reference version:** `oriondesk-od-ai-dds-001-r1.0-stage-d-provisional-v1`.
**Frozen at (observed UTC):** `2026-11-18T13:09:52Z`.
**Scope:** PDF reference construction validation only, not generation-method scoring.

## 1. Authoritative PDF and complete input inventory

- Source: `OrionDesk_AI_Detailed_Design_Specification(6).pdf`, OD-AI-DDS-001, baseline R1.0 / revision 1.3.
- Physical source pages verified: **90**. PDF SHA-256: `b71541e74564559d2cc0a84e9827086946998fbc6c627488fb9e7a7f9b0137c3`.
- Source SHA-256 matches the authoritative manifest embedded identically in all three source archives.
- All 29 manifest segments exist (front matter, Chapters 1–22, Appendices A–F); 90/90 pages are uniquely assigned and have explicit inspected-page entries.
- Every source-positive, source-control, and coverage file was parsed from its corresponding Stage C ZIP archive; the original archived files were not changed.

## 2. Full input-to-output reconciliation

| Measure | Positive (R) | Negative (N) |
|---|---:|---:|
| Original chapter/segment candidates | 2,926 | 421 |
| Original input IDs with one lineage row | 2,926 | 421 |
| Stage C final propositions | 2,729 | 384 |
| Stage D frozen propositions | **2,729** | **383** |
| Stage D change | 0 | -1 (source-scope correction and justified merge) |
| Output records carrying at least one review flag | 655 | 5 |

- Combined Stage D lineage rows: **3,347**; combined semantic decision records: **74**, including one Stage D correction.
- Positive lineage dispositions: `MERGED_EQUIVALENT` 28, `PARENT_SUMMARY_NONSCORING` 151, `RETAINED` 2729, `SPLIT_WITH_PROOF` 18.
- Negative lineage dispositions: `MERGED_EQUIVALENT` 38, `RETAINED` 383.
- Source and reverse-origin ID sets reconcile; no source IDs are missing, no dangling post-amendment reference IDs were found, and every final proposition retains PDF evidence.
- Counts are not an estimate of proof of completeness; output net reductions combine semantically different disposition types.

## 3. Evidence integrity and figure review

- Final inventories contain **4,033** evidence excerpt instances (3,514 positive and 519 negative), conserving the Stage C excerpt total after moving the retired control's citation to the surviving control.
- Of 4,033 excerpts, **3,898** have exact normalized native-PDF-text matches on the cited physical page.
- The remaining **135** excerpts cite figure-embedded content rather than selectable PDF text. They concern a small set of common figure assertions and component-box labels.
- The three common runtime-assertion bullets were visually inspected on all **22 chapter-opening figures** (physical pages 8, 11, 15, 18, 21, 24, 27, 30, 34, 37, 40, 44, 48, 51, 54, 57, 61, 64, 68, 71, 74 and 78). Figure 3.1 component labels were also checked against the rendered figure.
- All PDF evidence page locators fall in the valid 1–90 range. Evidence-text presence and selected visual checks do not establish that every derived proposition has fully correct scope, timing, modality or independent normative force.

## 4. Stage D corrections (non-destructive)

### 4.1 `NEG-00285` retired and reconciled into `NEG-00022`

- Source candidate: `CH20-N0012`, PDF physical page 73, Section 20.5 failure scenario B.
- The phrase "release publication" overextended the source. The actual text concerns a case/evidence publish gate rechecking permission changes between search and publication.
- After narrowing to the source-supported case/evidence publication gate, the invalid stale-evidence acceptance proposition is equivalent to the already existing `NEG-00022`; the page-73 source excerpt was added to its evidence.
- The source-local `CH20-N0012` remains untouched, and its lineage now reads `MERGED_EQUIVALENT -> NEG-00022`. The old final ID `NEG-00285` is retired. See `reference_amendments.jsonl` and `reduce_decisions.jsonl`.

### 4.2 Chapter 9 page 35 coverage counting amendment

- Source report claimed 70 positive and 8 negative candidates for page 35; these are evidence excerpt counts.
- Distinct source candidate IDs having at least one citation on that page number **57 positive** and **5 negative**.
- `coverage_amendments.jsonl` documents both corrections without changing any original Stage B chapter coverage files.
- Thirty additional reported-vs-all-citing-ID differences elsewhere match the relevant reports' first-evidence-page attribution convention and do not establish the same page-count-definition defect.

## 5. Independent semantic audit and limitations

- Structural schemas, page assignment, quotation presence, polarity fields, origin-lineage reversibility, and disposition counts were independently recomputed from the supplied source files.
- The sampled normative PDF passages, figure assertion panels, and the targeted Chapter 20 permission-change example were examined against the original PDF.
- A 1:1 semantic challenge of every final atomic statement and an independent full-page omission search have **not** been completed. The remaining issues below prevent `REFERENCE_FROZEN_VERIFIED`.
- Preliminary duplicate clusters requiring later meaning-level review include exact-text positive pairs/triples involving `PDF-00433`, `PDF-00553`, `PDF-01550`; `PDF-00660`, `PDF-00948`; `PDF-00918`, `PDF-01016`; `PDF-01304`, `PDF-01914`; `PDF-01850`, `PDF-02189`, plus negative pair `NEG-00042`, `NEG-00259`. Same words alone are not proof of identical full scope.
- Appendix C sample A2A task, Appendix D unspecified SEC-001–SEC-012, Appendix E test assertions and Appendix F example configuration still require detailed independent normativity and parent/child review.
- No generator output or benchmark score was introduced as a source of authority during this run; perfect source-only blinding cannot be guaranteed because earlier evaluation context was visible.

## 6. Open issues and freeze decision

- **D-OPEN-001 — Independent semantic source-to-ledger review:** Structural checks and exact-text quotation location do not validate all 2,729 positive predicates or all 383 control inversions for entailment, scope, and independent atomicity. A full per-proposition source-to-statement semantic adjudication has not been completed.
- **D-OPEN-002 — Completeness challenge:** All 90 pages are represented by prior Stage B coverage reports and checked for input/evidence presence, but independent page-by-page semantic re-extraction and omission audit are not proven complete. No 100% semantic recall claim is made.
- **D-OPEN-003 — Figure, example and appendix normativity:** Interpretation of front-matter illustration boundaries, Appendix C example A2A payload, Appendix D reference to undefined SEC-001 through SEC-012, Appendix E verification-matrix duplication, and Appendix F example configuration remains subject to detailed normativity review.
- **D-OPEN-004 — Residual possible duplicate and hierarchy clusters:** Five positive exact-normalized statement clusters (6 excess occurrences) and one negative same-text pair have scope differences or potentially distinct test duties. They were not silently merged. A complete broader paraphrase audit is not certified.
- **D-OPEN-005 — Coverage report consistency:** Chapter 9 physical page 35 contains two source-report count-definition errors. Non-destructive amendments correct page-local unique-candidate counts to 57 positives and 5 negative controls; the immutable Stage B coverage original is unchanged.
- **D-OPEN-006 — Source filename aliases:** Evidence file labels mention historical (1), (2), (3) PDF copies. The currently supplied original PDF hash matches all three manifest SHA-256 values; historical byte copies were not independently received for hash confirmation.
- **D-OPEN-007 — Blindness of independent construction:** Earlier evaluation concepts and methods were present in user-conversation context. No generated method-specific specification files or TP/FP/FN scores were read or used in this Stage D audit, but strict context isolation cannot be certified.

**Freeze decision:** The complete mandatory source and construction artifacts are present and parseable, and the source-page/lineage gates reconcile. The pair is therefore saved as a **provisionally frozen** reference, not a fully verified or certified semantic gold set. Downstream reuse must name this exact version and its two SHA-256 digests. Any accepted future corrections create a new version and require all compared methods to be re-evaluated against that same new version.

## 7. Frozen artifacts and hashes

- `common_atomic_reqs.jsonl`: SHA-256 `99d1b665e70cc4696f5508cfb8d32aca2833efa001b5fc3e5157b7a968379de6` (unchanged byte copy of uploaded Stage C positive ledger).
- `common_negative_controls.jsonl`: SHA-256 `586401b1c11dd0f74a5f1aab64465dacadfe6d6b56871e297067e6a76b8a0a6a` (one source-backed Stage D consolidation).
- `reduce_lineage.jsonl`: updated lineage, without editing original input.
- `reduce_decisions.jsonl`: updated decisions, including Stage D semantic rationale.
- `reference_amendments.jsonl`: one negative scope/merge amendment.
- `coverage_amendments.jsonl`: two page-count interpretation amendments.
- `reference_freeze.json`: freeze status, timestamp, hashes, open issues and limitations.

## 8. Explicitly not performed

- No Full Load, one-level, or two-level generated specification was inspected; no TP, FP, TN, FN, Precision, Recall, or F1 was computed.
- No original Stage A/Stage B or uploaded Stage C file was overwritten, no historical reference inventory was used to add requirements, and no missing candidate was fabricated to improve a score.
- No claim of exhaustive independent semantic coverage or complete elimination of duplicate requirements is made.

