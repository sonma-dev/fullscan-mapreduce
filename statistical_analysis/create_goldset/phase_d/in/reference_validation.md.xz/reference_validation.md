# Stage C — Global Reconciliation and Reference Validation

**Protocol:** Gold Set Creation Protocol v1.0  
**Scope:** Stage C only — final global reconciliation of pre-existing positive Reduce, negative-control Reduce, and page-coverage audit.  
**Status:** **STRUCTURALLY_RECONCILED_WITH_OPEN_REVIEW_ITEMS** (not independently validated or frozen).  
**Source:** OrionDesk AI Detailed Application Design Specification, OD-AI-DDS-001, R1.0 / revision 1.3.  
**SHA-256:** `b71541e74564559d2cc0a84e9827086946998fbc6c627488fb9e7a7f9b0137c3` (matches each of the three input-archive manifests).

## 1. Source and input inventory

| Input role | Segments / files | Original records | Reconciliation |
|---|---:|---:|---|
| Positive chapter JSONLs (`chapter_*.jsonl`, appendices, front matter) | 29 | 2,926 | All IDs found and unique |
| Negative chapter controls (`*_controls.jsonl`) | 29 | 421 | All IDs found and unique |
| Chapter coverage (`*_coverage.json`) | 29 | 90 physical pages | Phase 3 audit incorporated |
| Source partition (`chapter_manifest.json`) | 1 shared manifest in each archive | 29 named segments | Three manifests identical |

All Chapters 1–22, Appendices A–F, and the front-matter segment are present. The actual source PDF contains 90 physical pages. The source file supplied for this task has a verified SHA-256 identical to the manifest, although the historical PDF filename aliases `(1)`, `(2)`, and `(3)` appearing in evidence metadata were not all separately provided as byte streams.

## 2. Final positive and negative inventories

| Measure | Positive requirements (R) | Negative controls (N) |
|---|---:|---:|
| Local candidate IDs | 2,926 | 421 |
| Final propositions | **2,729** | **384** |
| Net count reduction | 197 | 37 |
| Local IDs with exactly one lineage source row | 2,926 | 421 |
| Missing source IDs | 0 | 0 |
| Invalid final references | 0 | 0 |
| Reverse origin/lineage mismatches | 0 | 0 |
| Final records with no evidence | 0 | 0 |
| Final records missing required schema fields | 0 | 0 |
| Final records carrying review flags | 655 | 6 |

**Positive lineage dispositions:** `RETAINED` = 2,729, `PARENT_SUMMARY_NONSCORING` = 151, `MERGED_EQUIVALENT` = 28, `SPLIT_WITH_PROOF` = 18.  
**Negative lineage dispositions:** `RETAINED` = 383, `MERGED_EQUIVALENT` = 37, `REQUIRES_REVIEW` = 1.

The positive net reduction of 197 is the difference between source-record and final-proposition counts. The 18 `SPLIT_WITH_PROOF` inputs each map to two independently retained output propositions; they do not represent 18 newly introduced, unmatched outputs. Parent-summary entries remain traceable but are not counted as new scored propositions. Do not interpret the reduction of 197 as the number of proved full-equivalence merges: the accounting also includes parent/non-scoring mappings and compound-to-existing-proposition mappings.

The negative net reduction is 37. One existing negative candidate (`CH20-N0012`) is marked `REQUIRES_REVIEW` and remains linked to `NEG-00285` instead of being silently removed.

## 3. Semantic decisions and disposition evidence

The combined decision ledger preserves **73** separate decision records: 32 positive and 41 negative. The positive records describe PARENT_CHILD_NONSCORING (9), SEMANTIC_EQUIVALENCE_MERGE (5), SPLIT_WITH_PROOF (18); the negative records describe MERGE_EQUIVALENT (15), RETAIN_DISTINCT_NON_EQUIVALENT (26).

For every non-retained positive ID and every negative ID marked `MERGED_EQUIVALENT`, at least one corresponding substantive decision record exists. All decision source IDs and final IDs resolve; all stated decision-to-lineage references are internally consistent. Each decision retains its original semantic rationale and evidence. Non-equivalence decisions remain as explicit preservation decisions rather than silently merged records.

The combined output retains both the source-specific audit fields and common `source_kind`, `local_source_id` / `original_ids`, and `final_ids` fields. This ensures downstream readers can identify exactly one source-lineage disposition per local ID without guessing how the original positive and negative schemas differ.

## 4. Evidence and PDF locator integrity

The final inventories contain 2,729 positive and 384 negative propositions, with **4,033** total evidence excerpts (3,514 positive; 519 negative).

- All evidence excerpts include a file label, valid 1-based physical page (1–90), a section/table/figure locator, and a non-empty quotation.
- **All original chapter evidence excerpts** are reachable in at least one final output mapped from their local ID; no original evidence excerpt was silently dropped.
- Every final excerpt belongs to a mapped original chapter record; no unsupported new excerpt was introduced by global reconciliation.
- 3,898/4,033 excerpts are directly locatable in normalized native PDF text; the remaining 135 excerpts all refer to figure content (135 explicitly figure-located). Figures are not fully represented by text extraction; their exact transcription is **not certified by this structural test** and remains subject to Stage D source/visual review.
- Evidence `file` labels span historical numbered PDF uploads; current supplied PDF checksum establishes the present document's identity against the manifest but does not independently prove the byte identity of each previously named upload.

These checks establish internal evidence conservation and page-validity, **not comprehensive independent quotation verification or complete semantic recall**.

## 5. Page coverage and count reconciliation

The Stage C Phase 3 audit records:

- 29/29 segment coverage files present; all 90/90 source pages assigned exactly once and explicitly inspected.
- Zero missing or extra original positive/control candidate IDs at the segment totals and top-level ID-list level.
- No unassigned pages; 14 explicitly zero-positive-candidate pages have coverage entries.
- Eleven segment/type combinations have non-additive sums of per-page evidence-supported counts. Most are attributable to multi-page evidence occurrences rather than missing local IDs.
- **Two genuine page-count-definition discrepancies:** Chapter 9 physical page 35 reports positive count 70 vs 57 distinct positive candidate IDs; it reports control count 8 vs 5 distinct control IDs. The reported counts equal raw supporting evidence excerpts, inconsistent with the report's stated unique-candidate counting method. Original Stage B files are left unchanged.
- The existing coverage reports contain 151 page-level evidence/review notes. These are uncertainty notes, not 151 confirmed omitted requirements.

## 6. Remaining review items — explicit, not silently repaired

1. **`CH20-N0012` -> `NEG-00285`: source-scope uncertainty.** The local negative counterfactual describes a release-publication scenario, while the cited evidence discusses re-authorization at a case/evidence publish gate. The equivalence and citation scope need targeted independent source review. It remains a distinct control with `REQUIRES_REVIEW` lineage status.
2. **Chapter 9, physical page 35: two page-count-definition errors.** Correct by a documented, non-destructive coverage amendment during the later validation workflow; do not rewrite immutable Stage B files.
3. **Illustration/example scope.** Front-matter architecture figures and Appendix C's illustrative A2A message, Appendix D's reference to SEC-001–SEC-012 without their definitions, Appendix E's test-matrix context, and Appendix F's example configuration/runbook require source-normativity review. Appendix A/B table/DDL scope and cross-chapter inheritance also require care.
4. **Possible residual same-text clusters.** The global exact-normalized-statement comparison found 5 positive clusters (a total of 6 excess same-text occurrences) and 1 negative cluster (one excess same-text occurrence). Different `scope_en`, local event, or cited component context means text identity alone is *not* proof of bidirectional semantic equivalence. No additional merge is imposed without review. IDs:
   - positive: `PDF-00433` (Design checkpoint 4.2), `PDF-00553` (Chapter 5 design checkpoint verification), `PDF-01550` (Rejected stale or unauthorized state changes)
   - positive: `PDF-00660` (Stale/unauthorized writes), `PDF-00948` (9.2 / design checkpoint)
   - positive: `PDF-00918` (Chapter 09 / diagnostic telemetry), `PDF-01016` (Chapter 10 / source-document privacy in telemetry)
   - positive: `PDF-01304` (Chapter 13: Workflow, Queues and Event Semantics), `PDF-01914` (Chapter 19 diagnostic telemetry)
   - positive: `PDF-01850` (Rejected stale or unauthorized stateful operations), `PDF-02189` (Rejected stale or unauthorized writes)
   - negative: `NEG-00042` (RunRequested diagnostics), `NEG-00259` (Diagnostic logging)

5. **Limit of global semantic verification.** This stage reconciles the completed LLM Reduce decisions, tests all ID and evidence mappings, and flags suspicious matching groups. It does not redo independent source-to-requirement extraction or certify that no undiscovered semantic duplicates or requirements remain. A separate Stage D reviewer must challenge semantic equivalence and normative force against the PDF itself.

## 7. Reconciliation identities checked

```text
positive_input_count                = 2926
positive_lineage_source_rows        = 2926
positive_final_propositions         = 2729
negative_input_count                = 421
negative_lineage_source_rows        = 421
negative_final_propositions         = 384
combined_source_lineage_rows        = 3347
combined_semantic_decisions         = 73
unmapped_input_local_ids            = 0
invalid_final_id_references         = 0
final_origin_reverse_mapping_errors = 0
original_citations_lost             = 0
new_citations_without_source        = 0
final_records_without_pdf_evidence  = 0
missing_source_physical_pages       = 0
unresolved_coverage_count_defects   = 2
unresolved_negative_scope_flags     = 1
```

## 8. Scope boundary and conclusion

**Stage C global reconciliation is complete at the structural/provenance level, with explicit open review items.** The complete positive and negative source inventories have one lineage source row per original local ID. Both final ledgers retain complete source-ID provenance and required PDF evidence fields. The PDF SHA-256, 90-page partition, chapter inventory, and page inspection records reconcile. Non-equivalence and source-scope uncertainties are documented without silently collapsing distinct requirements.

**No Stage A or Stage B input file was rewritten; the existing `common_atomic_reqs.jsonl` and `common_negative_controls.jsonl` were not modified.** No Stage D independent PDF source audit, reference freeze, historical baseline comparison, benchmark leakage, generated specification scoring, or TP/FP/FN/precision/recall/F1 computation was performed.

**Next required independent gate:** Stage D must review source normativity and evidence in detail, resolve or explicitly carry open issues, and only then determine whether the paired reference can be frozen and at what status. This report does not assert `REFERENCE_FROZEN_VERIFIED` or 100% semantic completeness.
