# OrionDesk AI — PDF-Grounded Atomic Reference Ledger Construction Protocol

**Protocol version:** 1.0  
**Short name:** Gold Set Creation Protocol  
**Execution environment:** SaaS-hosted ChatGPT, with human-orchestrated chapter-by-chapter Map and LLM-performed Reduce  
**Purpose:** Construct an auditable, PDF-grounded common atomic-requirement reference inventory **before** any metric evaluation.  
**Downstream compatibility:** OrionDesk One-Pass Atomic Evaluation Protocol v6.2, and a prospective v7.0 with a frozen reference.  
**Conversation language:** The user's chosen language.  
**Authored artifact language:** English, including Markdown, JSONL, reports, and JSON explanatory fields.  
**Status:** Construction procedure, not a metric-evaluation phase.

## 1. Objective and interpretation

Use SaaS-hosted ChatGPT to extract independently meaningful and testable normative requirements from the original OrionDesk detailed-design PDF **one chapter at a time**, preserving a separate `chapter_1.jsonl`, `chapter_2.jsonl`, etc. After all chapter files exist, **use SaaS-hosted ChatGPT itself to perform the Reduce**: reconcile chapter outputs, identify true semantic duplicates, preserve unique requirements and all source evidence, resolve cross-chapter applicability where supported, and write `common_atomic_reqs.jsonl`. Construct `common_negative_controls.jsonl` separately from PDF-explicit prohibitions, exclusions, and release deferrals. Validate and then freeze both reference files for subsequent evaluations.

The human operator chooses chapter boundaries, supplies the source segments and intermediate files, and decides when to run Map, Reduce, and freeze. **The LLM performs semantic extraction and semantic Reduce.** Human orchestration is not a demand for humans to manually merge thousands of requirements.

The final reference is an **adjudicated candidate gold set**, not proof that every source requirement has been found. Page coverage, lineage checks, and semantic review increase auditability but do not mathematically certify completeness.

### Non-negotiable principles

1. **PDF-only normative authority.** The original English PDF is the only source of requirement truth. No generated design Markdown, model output, previous gold set, earlier score, or evaluation judgment may add an obligation to the source inventory.
2. **No benchmark leakage.** Do not inspect or supply Full Load, one-level, or two-level generated specifications or their TP/FP/FN metrics during reference construction. Do not tailor the ledger to benefit any method. Prefer fresh, source-only ChatGPT conversations; disclose if relevant prior evaluation context was visible, because the system cannot establish perfect blindness by assertion.
3. **Chapter-scoped Map.** Each chapter is processed as a separate, bounded SaaS-hosted ChatGPT task. A large chapter may be subdivided into explicitly tracked, nonoverlapping page groups; those groups are combined without loss to produce exactly one chapter file.
4. **LLM Reduce, not manual rewriting.** Supply all completed chapter JSONLs to a separate ChatGPT Reduce task. The model must perform the semantic reconciliation and produce machine-readable final files and a complete input-to-output audit trail.
5. **No silent loss.** Every chapter requirement ID must have a documented final disposition and lineage. A lower output count is not evidence that all removed items were duplicates.
6. **Meaningful atomicity.** Count independently testable normative duties, not occurrences of prose. Do not mechanically split every phrase, copy global rules once per endpoint, or count a verification-matrix restatement again unless the PDF independently requires a distinct test obligation.
7. **Evidence before acceptance.** Every final positive or negative-control proposition requires real, recoverable PDF evidence with physical page and section/table/figure context. Never invent a quotation or page.
8. **Preserve modality and scope.** Retain actor, target, action or prohibition, `all`/`only`/`unless`, version, preconditions, timing, limits, exceptions, and outcome where they matter. Mere similarity does not prove equivalence.
9. **No Codex or cross-product handoff.** Semantic Map, Reduce, and review use SaaS-hosted ChatGPT. Its built-in Python capability may be used for deterministic file parsing and reconciliation checks; no Codex workflow is required.
10. **Frozen means frozen.** After reference freeze, metric-evaluation runs may report correction proposals but must not silently modify these files. A justified material revision creates a new reference version; comparisons using the new version require all methods to be rescored.
11. **No invented success metrics.** Report actual atom counts, duplication dispositions, page coverage, and unresolved issues from the files. Never pre-fill expected counts such as 1,024 or assert 100% coverage merely because all PDF pages were visited.

## 2. Inputs and separation of concerns

### 2.1 Mandatory input

- The authoritative English *OrionDesk AI Detailed Application Design Specification* PDF, expected for the current study to contain **90 physical pages**. Verify the actual page count and readable content before proceeding; do not trust a filename or an old summary.

### 2.2 Optional context and forbidden inputs

- **Allowed after construction, solely for compatibility reporting:** an earlier `common_atomic_reqs.jsonl` and `common_negative_controls.jsonl`. They must not be shown to chapter Map agents or the initial Reduce agent. Do not copy them as unstated authority.
- **Forbidden during Map and Reduce:** generated eight-document specification sets, experiment outcomes, historical false positives/false negatives, approval decisions, and previous reference judgments. Evaluation begins only after reference construction.
- The prior evaluation protocol may be used to define *format and semantic atomicity rules*, but it is not a source of actual PDF obligations.

### 2.3 Exact output names

| Output | Purpose |
|---|---|
| `chapter_manifest.json` | Source PDF identity, physical-page/chapter assignment, and unassigned-content check. |
| `chapter_1.jsonl`, `chapter_2.jsonl`, ... | Immutable, chapter-local positive requirement candidates with local IDs and PDF evidence. |
| `chapter_1_controls.jsonl`, `chapter_2_controls.jsonl`, ... | Chapter-local **bounded negative-control candidates** derived only from explicit exclusions, prohibitions, or deferrals; files may be empty. |
| `chapter_1_coverage.json`, `chapter_2_coverage.json`, ... | Physical-page coverage, tables/figures checks, record counts, and noted uncertainty. |
| `reduce_lineage.jsonl` | One complete disposition for every chapter-local positive and control candidate. |
| `reduce_decisions.jsonl` | Semantic equivalence, merges, exclusions, splits, cross-chapter links, and the actual PDF-grounded reason for each substantive decision. |
| `common_atomic_reqs.jsonl` | Final PDF-positive normative atomic requirements (`R`) using `PDF-*` IDs. |
| `common_negative_controls.jsonl` | Final fixed, bounded PDF-negative counterfactual controls (`N`) using `NEG-*` IDs. |
| `reference_validation.md` | Reconciled counts, source evidence checks, page coverage, open issues, and construction limitations. |
| `reference_freeze.json` | Reference version, PDF identifier, file digests, freeze status, and acceptance criteria. |

Store the files in a dedicated reference-construction directory. Never overwrite the input PDF, any chapter files, or previously frozen ledgers. Deliver files individually; a bundled archive is not required.

## 3. Stage A — PDF partition and chapter manifest

1. Verify the PDF is readable and determine the **actual physical page count**, including cover, table of contents, figures, appendices, and blank pages. The currently expected value is 90; a mismatch is a source-identity issue to resolve, not a reason to fabricate coverage.
2. Establish chapter boundaries from the PDF's actual contents. Use physical PDF page numbers (1-based), not printed page labels. Assign front matter, appendices, and material outside numbered chapters to named segments so **every physical page is assigned**.
3. For a chapter that begins or ends on a shared page, preserve each chapter's relevant subsections and document the overlap. Do not accidentally omit content or double-count obligations because pages overlap.
4. Produce `chapter_manifest.json` with `pdf_file`, `physical_page_count`, `segments[]` (`chapter_id`, `chapter_label`, `physical_pages`, `section_boundaries`, `source_file_or_page_selection`), and `unassigned_physical_pages`. The latter must be empty before Map begins.
5. Record source artifacts so their chapter boundaries can be reproduced. If chapters are supplied as extracted PDF segments rather than the full PDF, retain the original PDF physical-page mapping and ensure that tables, figures, and captions are not cut off.

**Gate A:** All source pages are accounted for and each chapter's source material can be inspected. If the PDF or a required page is unreadable, report the exact blocker; do not claim full-source coverage.

## 4. Stage B — SaaS-hosted ChatGPT chapter Map

**One independently completed Map task per chapter.** Supply only the corresponding PDF chapter/segment, its original physical-page map, and these instructions. A task may use multiple internal file/analysis steps, but must finish with its chapter-specific files; do not start another chapter in place of finishing the current one.

### 4.1 Extraction policy

For **every page of the assigned chapter**, inspect narrative, headings that confer scope, tables including row/column headers, diagrams, captions, footnotes, exceptions, appendices, and referenced conditions. Extract each PDF-backed **independently meaningful and testable** obligation. Capture required and forbidden actions as PDF-positive requirements: e.g., "must not publish without approval" is a positive requirement to enforce a prohibition.

- Extract distinct endpoint operations, actors, fields, constraints, validation timing, error behavior, workflow states/transitions, time limits, roles, access rights, and required outcomes **when the PDF establishes distinct testable duties**.
- Preserve explicit universal rules once at their stated scope. Do not create arbitrary endpoint copies of global boilerplate; independently specified endpoint duties remain separate.
- Preserve the full semantic context of short table cells and test expectations. A bare `201`, `NOT NULL`, or field name is not a self-contained requirement outside its row/table/section.
- Distinguish a test matrix's *evidence of an implementation obligation* from an independently mandated test execution or outcome. Do not count the same underlying implementation requirement twice.
- Exclude purely explanatory background, unadopted proposals, open architectural questions, examples without normative force, and purely future capabilities. Record their locations/reasons in the chapter coverage report, not in `R`.
- If a requirement refers to a rule in another chapter, preserve what is actually established here and add an unresolved `cross_chapter_references` entry. Do **not** invent details from an unseen chapter.
- Where the text is ambiguous, retain the actual quotation and flag the uncertainty. Do not silently strengthen `should` into `must` or turn an exception into an unconditional rule.

### 4.2 Local IDs and output

Create `chapter_<n>.jsonl`, with **one valid UTF-8 JSON object per line**. IDs are stable within the chapter: `CH01-00001`, `CH01-00002`, etc. Do **not** assign final `PDF-*` IDs at this stage. Every row must include:

- `chapter_atom_id`, `chapter_id`, `atomic_statement_en`, `modality`, `actor_en`, `target_en`, `action_en`, `scope_en`, `preconditions_en`, `exceptions_en`, `timing_en`, `outcome_en`, `version_en` (use JSON `null` if genuinely unstated);
- `pdf_evidence`: one or more objects with `file`, `physical_page`, `section_table_figure_locator`, `quote_en`, plus `table_context_en` when necessary;
- `atomicity_reason_en`, `cross_chapter_references` (array, possibly empty), and `review_flags` (array, possibly empty).

All `quote_en` values must be exact source quotations—not fabricated examples or paraphrases. Use a separate `atomic_statement_en` for normalization. Additional source locators are encouraged. Each chapter output must be valid JSONL; no prose or Markdown fences inside that file.

### 4.3 Explicit negative-control candidates

Create `chapter_<n>_controls.jsonl` from source-explicit exclusions, prohibitions, and release deferrals. Each row has a `chapter_control_id` (e.g., `CH01-N0001`), `counterfactual_statement_en`, `scope_en`, `construction_basis` (`EXPLICIT_PROHIBITION`, `EXPLICIT_EXCLUSION`, or `EXPLICIT_DEFERRAL`), `construction_rule_en`, and `pdf_evidence`. Construct an affirmative-sounding counterfactual the source explicitly rules out. Never invent arbitrary negatives from unmentioned features or blank TBDs.

A positive prohibition and its prohibited counterfactual can both exist, respectively in `R` and `N`, with **distinct polarity**. Do not put negative-control candidates into the positive chapter ledger. If a chapter has no valid negative candidates, provide an empty file and record zero in the coverage report.

### 4.4 Chapter completeness report

Create `chapter_<n>_coverage.json` with all assigned physical pages and one entry per page: `physical_page`, `inspected`, `positive_candidate_count`, `negative_candidate_count`, `tables_figures_checked`, `normative_exclusions`, `unresolved_evidence_issues`. A page may legitimately have zero requirements, but must be represented. Report all local IDs and total counts without claiming that page inspection proves semantic completeness.

**Gate B (per chapter):** Source pages inspected; every output record has an ID and genuine evidence; chapter JSONLs parse; all assigned pages appear in coverage; unclear content is reported rather than invented. Preserve chapter outputs exactly as completed when proceeding to Reduce.

## 5. Stage C — SaaS-hosted ChatGPT semantic Reduce

**Stage C clarification for already completed Maps:** Stage A and Stage B are immutable upstream procedures. In particular, the previously generated Stage B outputs for Chapters 1–22 remain valid inputs **as they are**. Do not revise their instructions, rerun their extraction, rename their records, regenerate missing entries, or modify any completed chapter file merely to satisfy Stage C. This clarification changes **only how Stage C ingests and reduces existing outputs**; it does not create new Stage A/Stage B deliverables.

Open a **separate Reduce task** in SaaS-hosted ChatGPT. The LLM, not the human operator, performs semantic consolidation. The four existing input-file roles are **not interchangeable** and **need not all occupy the same model prompt or upload batch**. The full required input inventory must nevertheless be accounted for across Stage C and Stage D. Do not supply the experiment's generated specification sets, historical reference ledgers, or scores. Original PDF passages may be consulted **only for targeted evidence clarification**, not as a pretext for unlogged, unbounded re-extraction.

### 5.0 Input roles and distinct passes (mandatory)

| Existing Stage A/B input | Stage C role | How it must be used |
|---|---|---|
| `chapter_<n>.jsonl` | **Positive semantic Reduce input (required).** | Read **every** chapter-positive record; semantically reconcile these files to construct `common_atomic_reqs.jsonl`. These are the primary LLM input files for positive-atom merging. |
| `chapter_<n>_controls.jsonl` | **Negative-control semantic Reduce input (required).** | Read **every** control candidate in a **separate negative-control reduction**, producing `common_negative_controls.jsonl`; an existing empty file contributes zero candidates. Do not mix controls into the positive ledger. |
| `chapter_<n>_coverage.json` | **Completeness and provenance audit input (required).** | Check pages inspected, positive/control counts, zero-requirement pages, tables/figures, exclusions and uncertainty; reconcile against the actual two chapter JSONLs. **Do not** treat coverage summaries as new atomic requirements or submit them as substitute positive/negative candidate records. |
| `chapter_manifest.json` | **Global source-partition and coverage audit input (required once).** | Check chapter-to-physical-page mappings and all named segments, unassigned pages, overlaps, and expected chapter IDs. The manifest is **not** a semantic-merge inventory and does not need to be repeated with every LLM Reduce call. |

The operator may supply the files in **separate passes** to avoid attachment-count and context limits:

1. **Input inventory and audit:** Establish the complete set of expected chapter/segment IDs from the manifest. For each chapter, verify that its three Stage B files exist; compare the record IDs and counts in the two JSONLs with its coverage report. The manifest is supplied once and the coverage reports may be processed in batches. Record missing or malformed inputs explicitly; **never fabricate a replacement Stage B artifact or silently skip a chapter**.
2. **Positive Reduce:** Submit the `chapter_<n>.jsonl` files (for Chapters 1–22 and every remaining assigned segment as available) to SaaS-hosted ChatGPT, **without needing the controls, coverage files, or manifest in the same semantic-reduction prompt**. Merge only justified full semantic equivalents, preserving complete PDF evidence and input-ID lineage; emit `common_atomic_reqs.jsonl` and the positive portion of the Reduce audit files.
3. **Negative-control Reduce:** Submit `chapter_<n>_controls.jsonl` files to a separate SaaS-hosted ChatGPT reduction. Merge only duplicate PDF-explicit excluded/prohibited/deferred counterfactuals at identical scope; emit `common_negative_controls.jsonl` and the control portion of the same audit ledgers. Preserve empty-file/zero-control information in the inventory.
4. **Global reconciliation:** Using the inventory, coverage reports, manifest, positive and control Reduce outputs, and both sets of lineage, check that **every original local ID** has exactly one final disposition, every relevant PDF page is accounted for, and no source record vanished. Produce the combined `reduce_lineage.jsonl`, `reduce_decisions.jsonl`, and `reference_validation.md`. Do not assume that successful file upload, ZIP extraction, or JSON parsing proves semantic completeness.

**Preservation rule:** This separation of concerns is an **ingestion and processing clarification only**. It does not change Stage B schemas, mandatory filenames, local ID conventions, existing Chapter 1–22 outputs, or the required final deliverables. If an actual Stage B file is missing or corrupt, document a blocking input defect rather than rewriting an already completed Map output or pretending the missing data were processed.

### 5.1 Lossless-first procedure

1. **Inventory first.** Parse all chapter positive JSONLs and all control JSONLs in their respective passes; enumerate every original `chapter_atom_id` and `chapter_control_id`, verify uniqueness and valid evidence locators, and record exact input counts before merging. Reconcile chapter-level counts against `chapter_<n>_coverage.json` and chapter presence against `chapter_manifest.json` in the audit pass.
2. **Group candidates without dropping any.** Normalize target, actor, action, modality, scope, conditions, exceptions, version, and outcome. Use identifiers and semantic aliases for candidate retrieval, not as the sole equivalence test.
3. **Test equivalence bidirectionally.** Merge only when each full proposition logically entails the other in the cited PDF context. Similar topics, partial overlap, parent/child containment, and common vocabulary are **not** sufficient for an equivalence merge.
4. **Preserve substantive differences.** Separate requirements with different endpoint methods, fields, actors, timing, scopes, error codes, exceptions, versions, or outcomes when those differences establish distinct testable obligations.
5. **Avoid parent/child inflation.** If a parent merely summarizes independently scored children, retain it as context, not an additional scored atom. Conversely, retain a PDF-mandated global universal duty as a single applicable atom; do not clone it mechanically for each endpoint.
6. **Audit chapter crossings.** Reconcile universal rules, cross-references, inherited table/section context, and rules defined elsewhere. Retain all source locators when duplicates share the same meaning; do not create an unsupported hybrid from pieces of different propositions.
7. **Handle ambiguous groups conservatively.** When full equivalence cannot be proved, keep the candidates separate and flag the relationship for review. An incorrect merge can silently erase a requirement; a documented potential duplicate is preferable to unproven deletion.
8. **Reduce controls separately.** Merge counterfactual controls only when they represent the same independently excluded/prohibited/deferred capability at the same scope. Maintain distinct polarity and do not respond to any generated predictions. Never treat a `chapter_<n>_coverage.json` entry as a control or as an atomic proposition.
9. **Assign final IDs** only after reconciliation. Use `PDF-00001` ... for final positive atoms and `NEG-00001` ... for final bounded controls. Choose a deterministic order (first supporting physical page, section, then earliest chapter-local ID). Never recycle a retired final ID within a frozen version.
10. **Emit full lineage.** Each input local ID must appear exactly once as a lineage source record, with one of: `RETAINED`, `MERGED_EQUIVALENT`, `SPLIT_WITH_PROOF`, `EXCLUDED_NONNORMATIVE`, `PARENT_SUMMARY_NONSCORING`, or `REQUIRES_REVIEW`. For splits, list *all* resulting final IDs; for merges, list the shared final ID. Every disposition needs an explanation and PDF locator(s). A retained final output may have several source IDs; no source ID may disappear without a disposition.

The Reduce must **not** invent requirements to fill perceived gaps in a chapter. If a material omission is discovered against the original PDF, issue an explicit `SOURCE_OMISSION_PROPOSAL` with PDF evidence; incorporate it only via a documented source-audit amendment before freeze, maintaining lineage. Do not silently patch the chapter outputs.

### 5.2 Required final positive ledger

`common_atomic_reqs.jsonl` contains one final JSON record for each PDF-supported, independently meaningful, testable positive requirement. Mandatory fields:

- `source_id`, `atomic_statement_en`, `actual_label` (= `1`), `modality`, `actor_en`, `target_en`, `action_en`, `scope_en`, `preconditions_en`, `exceptions_en`, `timing_en`, `outcome_en`, `version_en`, `pdf_evidence`, `origin_chapter_atom_ids` (nonempty array), `reconciliation_note_en`, and `review_flags`.

Retain complete evidence for all surviving occurrences and context needed to defend the proposition. JSON schema extensions are allowed, but do not silently rename `source_id` or replace `pdf_evidence` with a generated-document citation.

### 5.3 Required final negative-control ledger

`common_negative_controls.jsonl` contains one fixed counterfactual per distinct explicitly unsupported capability. Mandatory fields:

- `negative_control_id`, `counterfactual_statement_en`, `actual_label` (= `0`), `scope_en`, `construction_basis`, `construction_rule_en`, `pdf_evidence`, `origin_chapter_control_ids` (nonempty array), and `rationale_en`.

Use negative controls as a **bounded diagnostic set**. Their number is not the population count of all things absent from the PDF. Ensure no semantically identical proposition is assigned both actual labels. A PDF-positive prohibition remains a positive duty; the excluded behavior may also be represented as a negative counterfactual without conflating their logical polarity.

### 5.4 Audit outputs

- `reduce_lineage.jsonl`: per original positive/control candidate, the exact disposition, final ID(s), reason, and evidence. Include candidates that are excluded or left unresolved. Both the positive and negative reduction passes contribute to this **single final** lineage ledger.
- `reduce_decisions.jsonl`: one record per significant semantic merge, split, parent/child decision, exclusion, cross-chapter scope reconciliation, or source-audit addition, with original IDs, final IDs, relevant quotations, and the bidirectional semantic argument. A record that says only "duplicate" is insufficient. Combine decisions from the two separate Reduce passes without omitting either set.
- `reference_validation.md`: full input/output count reconciliation, controls and positives separately, chapter-file/manifest/coverage checks, and all unresolved risks.

**Gate C:** All four input roles have been accounted for **across the separate processing passes**; every input positive/control ID has an explained disposition; final records have source evidence; unique IDs and valid JSONL are confirmed; the Reduce did not lose material requirements during summarization. If the complete positive or control input set does not fit in one task, perform documented intermediate Reduce batches with preserved lineage and **do a final global comparison across all intermediate results**. Do not discard intermediate files, truncate inputs, silently summarize away records, or require already finished Chapters 1–22 to be reprocessed.

## 6. Stage D — Independent reference validation and freeze

A separate SaaS-hosted ChatGPT validation task receives the **original PDF**, every chapter JSONL/coverage report, the Reduce outputs, and the full lineage/decision files. Its responsibility is to challenge the reference construction, not to calculate any generation method's score.

### 6.1 Mandatory validation checks

1. **Source identity and page coverage.** All actual PDF physical pages, including nonchapter material, are assigned and inspected; page reports and manifest reconcile. Revisit evidence-uncertain tables, diagrams, captions, and appendices.
2. **Quote integrity.** Verify the actual PDF text or figure/table content supporting every final proposition's target, action, scope, timing, and outcome. A quoted keyword alone must not be promoted into a stronger rule.
3. **Atomicity and deduplication.** Challenge over-splitting, duplicate universal boilerplate, repeated test-matrix rows, accidental parent/child double counts, and improper mergers of endpoint/field/version-specific obligations.
4. **Completeness challenge.** Review each page's normative material against the local Map output, rather than checking only whether some row cites the page. List any newly found obligations as source-audit amendments with precise PDF evidence.
5. **Cross-chapter applicability.** Confirm that shared definitions, global rules, and referenced conditions are not ignored, applied outside their scope, or counted repeatedly.
6. **Control polarity.** Derive negative controls only from explicit PDF exclusions/prohibitions/deferrals; keep `R` and `N` semantically disjoint as *labeled propositions*.
7. **Lineage and counts.** Every chapter-local candidate is accounted for; final records trace to all relevant originals; reported merges/splits are supported; no silent records disappeared.
8. **Machine checks.** Use ChatGPT's Python capability if helpful to parse JSONL, check required fields, duplicate IDs, evidence page bounds, chapter-page coverage, lineage cardinality, and count equations. Programmatic checks **cannot** establish semantic entailment or completeness by themselves.
9. **Blindness and fairness.** Confirm no generated method output or metric score was used to shape `R`/`N`. Disclose deviations from intended source-only operation.

### 6.2 Reconciliation identities

Let `I_R` be all original chapter positive-candidate IDs and `I_N` all original chapter negative-candidate IDs. Require:

```text
number_of_positive_lineage_rows = |I_R|
number_of_negative_lineage_rows = |I_N|
every local input ID appears in exactly one lineage source row
every final source_id and negative_control_id is unique
every final positive/negative record has at least one actual PDF evidence locator
every final output ID is reachable from input lineage or an explicitly documented source-audit amendment
all included PDF evidence pages fall within the verified source page range
all assigned PDF physical pages have explicit inspection records
```

Do **not** require `|I_R| = |R|` or `|I_N| = |N|`: justified merges, exclusions, and splits can change the number of final propositions. Instead report each disposition category and its effect on the totals. Validate semantic meaning separately from arithmetic.

### 6.3 Freeze and correction policy

1. Correct clear PDF-grounded mistakes **before** freeze, using a non-destructive amendment file or explicit revision of the working final ledger and an accompanying decision/lineage delta. Original chapter JSONLs remain unchanged.
2. Freeze the accepted `common_atomic_reqs.jsonl` and `common_negative_controls.jsonl` as a **paired reference version** after validation. Write `reference_freeze.json` with `protocol_version`, `reference_version`, `source_pdf`, `source_pdf_sha256`, `common_atomic_reqs_sha256`, `common_negative_controls_sha256`, `frozen_at_utc` (actual observed value, never invented), `validation_status`, `open_issues`, and `limitations`.
3. Use `REFERENCE_FROZEN_VERIFIED` only if required evidence, lineage, and semantic checks were actually completed with no material unresolved issues. Otherwise use `REFERENCE_FROZEN_PROVISIONAL` with explicit, itemized risks; do not claim certified coverage. If source pages or mandatory artifacts are missing/unreadable, use `REFERENCE_BLOCKED` and do not release a finalized reference.
4. During later metric evaluation, provide the **same frozen pair** of `R`/`N` files to all methods, and record the reference version/digests in every result. Evaluation AI may produce `reference_correction_proposals.jsonl` but may not edit the frozen pair.
5. If a correction is later accepted, produce a new reference version from PDF evidence with preserved old-to-new ID crosswalk, changed file digests, and new freeze record. Recompute **every** compared method against the same new reference version. Do not mix old and new reference scores as though they shared one denominator.
6. Historical v6.2 reference inventories may be compared **only after** initial construction and source-only validation. Create `legacy_reference_crosswalk.jsonl` when comparability is needed; keep the old input originals and historical metrics intact. An existing `PDF-*` ID is not proof that two differently sourced requirements are semantically identical.

**Gate D:** A usable pair of reference files and an auditable freeze record exist, or an explicit blocked/provisional status explains why complete claims cannot be made.

## 7. Compatibility with the OrionDesk metric evaluation protocol

This protocol is an **upstream reference-construction process**, **not** one of the six metric-evaluation phases in v6.2. It produces the same canonical input basenames required by v6.2:

```text
common_atomic_reqs.jsonl
common_negative_controls.jsonl
```

The v6.2 protocol currently permits PDF-grounded changes to these inventories during evaluation. That policy **conflicts with a strict freeze**. To adopt strict freeze in a v7.0 metric-evaluation protocol, explicitly replace the later-phase working-ledger mutation rules with: **read-only frozen reference, correction-proposals ledger, new reference version for accepted repairs, and across-method rerun**. Merely attaching these files to an unmodified v6.2 evaluation does not enforce immutability.

Continue to apply the evaluation protocol's two distinct measurement layers: PDF-positive coverage for TP/FN and generated-claim correctness for distinct unsupported propositions/negative-control assertions. Do not label a claim FP merely because it lacks a one-to-one ledger match; the evaluation must check actual PDF support. Conversely, do not reclassify a genuinely unsupported claim as a duplicate to reduce FP.

## 8. Operator procedure and bounded workflow

The operator carries out four stages in order:

1. **Partition:** Upload the PDF and request Stage A only. Save the manifest and verify that every physical page is assigned.
2. **Map:** For each assigned chapter, open a source-scoped ChatGPT task, request Stage B for that chapter, download/save its three required outputs, and do not alter earlier chapter files while processing subsequent chapters.
3. **Reduce:** Upload all chapter outputs to ChatGPT; request Stage C. The LLM performs the merge and supplies both final inventories and the full lineage/decision records. If batching is necessary, retain all intermediate JSONLs and their lineage; run a final global deduplication pass.
4. **Validate/Freeze:** Upload the source PDF and all construction outputs in ChatGPT; request Stage D, resolve known evidence defects in the working ledger, and freeze the resulting reference pair. Only then begin any Full Load/MapReduce metric evaluation.

Avoid unbounded re-analysis loops. Work through the designated review once, correct concrete defects, and publish honest unresolved issues. Each stage must produce actual files, not a declaration that the files would be created later. Do not skip a stage because a plausible-looking final count was obtained.

### Copy-ready chapter Map instruction

> Apply **Stage B** of `goldset_creation_protocol.md` to the attached source PDF chapter only. Use the provided physical-page mapping. Extract every independently meaningful and testable PDF-backed normative obligation, retaining exact evidence and inherited table context. Produce `chapter_<n>.jsonl`, `chapter_<n>_controls.jsonl`, and `chapter_<n>_coverage.json` as real English-language files. Do not inspect prior gold sets, generated design specifications, or evaluation metrics. Do not assign final `PDF-*` IDs. Complete this chapter before any other chapter.

### Copy-ready Reduce instruction

> Apply **Stage C** of `goldset_creation_protocol.md` to all attached chapter JSONLs and coverage reports. **You, the SaaS-hosted ChatGPT LLM, must perform the semantic Reduce.** Inventory every local ID before grouping; merge only full semantic equivalents, preserve scope-specific duties, cross-chapter evidence, and complete lineage. Produce `common_atomic_reqs.jsonl`, `common_negative_controls.jsonl`, `reduce_lineage.jsonl`, `reduce_decisions.jsonl`, and `reference_validation.md` as real English-language files. Never discard an input without an explicit disposition and reason. Do not use generated specifications, previous gold sets, or metric scores.

### Copy-ready validation/freeze instruction

> Apply **Stage D** of `goldset_creation_protocol.md` to the original PDF and all attached construction outputs. Reconcile all page/atom/evidence/lineage records, challenge incorrect merges and over-splitting, perform documented PDF-backed corrections to the working reference, and produce `reference_validation.md` and `reference_freeze.json`. Freeze the final pair of common JSONLs only when its actual status is documented. Do not calculate TP, FP, FN, Precision, Recall, or F1 in this task.

## 9. Final acceptance checklist

- [ ] Original PDF identity and physical page count checked; all pages assigned and inspected.
- [ ] Separate chapter JSONLs exist, have unique local IDs, preserve real PDF quotations, and pass parsing.
- [ ] Per-chapter coverage includes pages with zero extracted requirements.
- [ ] LLM performed Reduce using all chapter records, with no silent truncation or untracked omission.
- [ ] Every original positive/control candidate has an explicit lineage disposition.
- [ ] Equivalence merges, parent/child exclusions, scope adjustments, and splits have actual semantic reasons and source evidence.
- [ ] Final positive ledger uses `source_id` / `PDF-*` and positive actual polarity.
- [ ] Final negative ledger uses `negative_control_id` / `NEG-*` and bounded, PDF-explicit negative construction.
- [ ] All material open questions, unverified evidence, and source coverage limitations are disclosed.
- [ ] Final paired reference is either verifiably frozen, explicitly provisional, or blocked; its status is not fabricated.
- [ ] Metric evaluation has not started and no generated-method results were used to alter the reference.

**Final directive:** Construct the reference using **human-orchestrated, SaaS-hosted ChatGPT chapter Maps and LLM semantic Reduce**. Preserve every chapter result and every mapping to the final PDF-grounded reference; distinguish real duplication from omission; validate the complete reference against the original PDF; then freeze one shared positive/negative inventory for fair, repeatable metric evaluations. Do not use Codex and do not edit frozen reference files during scoring.
