# OrionDesk AI — PDF-Grounded Atomic Reference Ledger Construction Protocol

**Protocol version:** 2.0  
**Short name:** Gold Set Creation Protocol  
**Execution environment:** SaaS-hosted ChatGPT, with human-orchestrated chapter-by-chapter Map and LLM-performed Reduce  
**Purpose:** Construct a defensible, non-inflated, PDF-grounded common atomic-requirement reference inventory before any metric evaluation.  
**Downstream compatibility:** OrionDesk One-Pass Atomic Evaluation Protocol v8.3 and later frozen-reference evaluators, using the same canonical JSONL basenames and immutable-reference rules.  
**Conversation language:** The user's chosen language.  
**Authored artifact language:** English, including Markdown, JSONL, reports, and JSON explanatory fields.  
**Status:** Reference construction, not metric evaluation.

## 1. Objective and interpretation

Use SaaS-hosted ChatGPT to inspect the original OrionDesk detailed-design PDF chapter by chapter (Stage A/B); perform a global, cross-chapter semantic Reduce of all chapter candidates (Stage C); and independently challenge source fidelity, coverage, atomicity, over-splitting, and negative-control inflation before freezing a **single common reference** (Stage D). The human operator orchestrates inputs; the LLM performs semantic Map, Reduce, and adjudication. Deterministic code may support indexing and verification but cannot establish logical equivalence on its own.

The scoring unit is a **distinct PDF-grounded, independently meaningful, testable normative proposition**, not an occurrence of language, a component name, a line, a citation, or a test-matrix entry. Preserve the PDF's actual scope and modality. Multiple source locations can support one canonical proposition. Multiple independently stated endpoint-, field-, actor-, condition-, or outcome-specific duties may legitimately remain separate.

**Explicit methodological precedent (v6.1):** The earlier *OrionDesk AI Six-Turn Semantic-Entailment Atomic Requirement Evaluation Protocol v6.1* expressly required **"Meaningful atomicity; no artificial multiplication"**. It prohibited manufacturing multiple identical source atoms by repeating universal boilerplate for every endpoint or chapter without distinct testable obligations, and required repeated test-matrix language to be treated as evidence unless a distinct verification duty was established. Version 2.0 applies that rule throughout Stages A–D. This historical protocol supplies a **methodological constraint only**, never a PDF fact, reference ID, atom count, or target score.

A complete-looking or numerically smaller inventory is not necessarily a correct inventory. This protocol must guard against **over-splitting, under-splitting, semantic over-merging, and omission** at the same time. The final product is an adjudicated, source-grounded candidate benchmark, not a mathematical certificate of full semantic completeness.

### Non-negotiable principles

1. **PDF-only normative authority.** The original English PDF alone establishes requirements; previous gold sets, generated specifications, historical scores, and prior adjudications are not source evidence.
2. **Strict benchmark isolation.** Do not inspect generated Full Load, One-Level, or Two-Level specifications or their TP/FP/FN metrics during construction, Map, Reduce, or validation. Earlier evaluation protocols may supply methodology only. Disclose contextual contamination rather than claiming unprovable blindness.
3. **No artificial multiplication.** A PDF-wide or defined-class rule is not independently scored for each endpoint, component, chapter, role, event, table, or test merely because it is repeated or applies to many targets.
4. **No destructive over-merging.** Preserve genuinely distinct method/path, actor, field, predicate, precondition, exception, timing, version, and outcome obligations. Scope containment and shared vocabulary do not automatically imply equivalence.
5. **No parent/child double counting.** If a parent summarizes fully scored children, treat the parent as context; if a general rule itself is the canonical scored unit, treat its applications as traceable scope memberships, not extra scored copies, unless an additional independent duty exists.
6. **No test-matrix inflation.** A test that repeats a product obligation is supporting evidence, not another source atom. A separately mandated verification execution, evidence-retention duty, or distinct expected result may be counted once when genuinely independent.
7. **Controls are bounded.** One distinct prohibited/deferred/excluded capability at a defined scope produces at most one canonical counterfactual control. Repeated text and actor-specific instantiations do not create arbitrary additional `NEG-*` controls.
8. **Complete PDF and lineage traceability.** Process each physical page, full table/figure context, every chapter-local ID, and all Reduce dispositions. A lower count is not proof of legitimate consolidation.
9. **Evidence and modality.** Every scored proposition requires actual physical-page evidence and a predicate-level description preserving `must`/`may`, `all`/`only`, conditions, exceptions, version, and timing. Never invent or paraphrase a quotation as an exact PDF quote.
10. **SaaS-hosted LLM workflows.** A separate ChatGPT task performs the semantic Reduce and Stage D review; Python may perform deterministic indexing, hash, lineage, and coverage checks. No Codex handoff is required.
11. **Freeze integrity and fairness.** Construction creates a new paired reference version. Later evaluators cannot silently modify it; any accepted correction creates a new version, and every compared generation method must be rescored against the same reference.
12. **Measured validation only.** Report actual records and unresolved limitations, not predetermined historical counts, favorable scores, or a claim of perfect recall from visiting each page. Apply the bounded-review policy without silently discarding source material.

## 2. Inputs and separation of concerns

### 2.1 Mandatory input

- The authoritative English *OrionDesk AI Detailed Application Design Specification* PDF, expected in the present study to have **90 physical pages**. Verify actual physical page count and source identity; copied filenames and timestamp suffixes are not authority.

### 2.2 Methodological context and forbidden inputs

- The historical v6.1 evaluation protocol may be consulted only for its **atomicity, scope, evidence, and anti-duplication rules**. It is not a source of normative OrionDesk requirements, reference IDs, or baseline totals.
- Do **not** provide historical `common_atomic_reqs.jsonl`, `common_negative_controls.jsonl`, previous reference judgments, Full Load/MapReduce-generated documents, experiment results, or scores to Stage A/B/C construction or source-semantic Stage D challenge. A previous reference may be compared **only after** the new source-only benchmark has been finalized and its construction decisions fixed; comparison must not change the PDF-derived verdicts.
- Any unavoidable prior context exposure must be recorded as a limitation; do not retrospectively claim a clean blinded context.

### 2.3 Exact output names

| Output | Purpose |
|---|---|
| `chapter_manifest.json` | Physical PDF identity/partition plus non-scoring global-rule and repeated-pattern candidate register. |
| `chapter_1.jsonl`, `chapter_2.jsonl`, ... | Immutable chapter-local positive candidates with full PDF evidence and atomicity rationale. |
| `chapter_1_controls.jsonl`, `chapter_2_controls.jsonl`, ... | Chapter-local bounded counterfactual candidates; files may be empty. |
| `chapter_1_coverage.json`, `chapter_2_coverage.json`, ... | Physical-page coverage, normative exclusions, repeat-family notes and scope links. |
| `reduce_lineage.jsonl` | Exactly one disposition per original local positive/control ID, including non-scored dispositions. |
| `reduce_decisions.jsonl` | PDF-grounded substantive consolidation, subsumption, split, exclusion and control decisions. |
| `common_atomic_reqs.jsonl` | Final positive normative requirements (`R`), canonical `PDF-*` IDs. |
| `common_negative_controls.jsonl` | Final bounded negative controls (`N`), canonical `NEG-*` IDs. |
| `reference_validation.md` | Full count reconciliation, repeat-family/atomicity diagnostics, source audit and open risks. |
| `reference_freeze.json` | Reference version, actual SHA-256 values, freeze status and limitations. |

All artifacts are English UTF-8. Keep source PDF, chapter files, intermediate Reduce outputs, and previously frozen versions unchanged; write a new construction version in a dedicated directory. Deliver individual files; no archive is necessary.

## 3. Stage A — PDF partition and cross-chapter rule planning

1. **Verify source integrity.** Open the authoritative PDF; record actual physical-page count, source digest, and readable page coverage. Include front matter, chapter headings, tables, figures, captions, appendices, and page-spanning continuations. A stated 90-page expectation is a check, not a substitute for inspection.
2. **Partition without semantic fragmentation.** Assign each physical page to one or more explicit segments, maintaining the exact section/paragraph/table/figure boundaries on overlapping pages. Assign every page, including non-normative pages; do not count a page twice merely because two segments use it.
3. **Pre-register likely cross-cutting families without scoring.** Read the PDF's chapter structure and identify repeated-rule *candidates* such as universal boundary metadata, validation-before-allocation, common audit/telemetry tests, tenant authorization, event-envelope constraints, and repeated non-goals. Mark each as `POTENTIAL_GLOBAL_RULE`, `POTENTIAL_REPEATED_BOILERPLATE`, `POTENTIAL_TEST_RESTATEMENT`, `POTENTIAL_PARENT_CHILD`, or `UNCERTAIN`. These are **retrieval hints**, not accepted atoms or automatic merges.
4. **Record scope ownership.** For each candidate family, note the defining page/section (if known), claimed or explicitly stated scope, likely application sites, known exceptions, and whether the PDF actually says `all`/`every` or merely repeats similar prose. Never infer a universal rule from chapter frequency alone.
5. **Track cross-chapter dependencies.** Note references whose definitions occur elsewhere and pages where a row or figure inherits context from a prior section. Stage B will capture them without fabricating missing clauses; Stage C will resolve them globally.
6. **Write `chapter_manifest.json`.** Required fields: `pdf_file`, `pdf_sha256`, `physical_page_count`, `segments` (`chapter_id`, `chapter_label`, `physical_pages`, `section_boundaries`, `source_file_or_page_selection`), `unassigned_physical_pages`, `cross_chapter_rule_candidates`, and `known_segment_overlaps`. Every rule candidate records a source locator and `not_scored=true`.
7. **Document omissions and ambiguity.** If a page, table image or key figure is unreadable, identify that location precisely; do not describe partial inspection as complete.

**Gate A:** Every physical page is accounted for and can be inspected; chapter boundaries are reproducible; potentially repeated universal/test families and scope dependencies are discoverable without creating any scored requirements. Failure to read mandatory source content is a genuine input blocker.

## 4. Stage B — SaaS-hosted ChatGPT chapter Map

Complete one bounded ChatGPT Map task per chapter/segment, preserving a separate chapter output and its source-page mapping. Supply only that chapter's PDF content, the Stage A source-only manifest, and these instructions. Chapters may be divided into tracked, lossless page groups when needed; finish the chapter before advancing.

### 4.1 Extraction and source-atomicity rules

Inspect every page's narrative, tables (row/column headers and full rows), figures, captions, exceptions, footnotes, and acceptance statements. Construct a normative proposition **only if it has an independently identifiable test or acceptance consequence in its actual scope**. A prohibition is a positive requirement to enforce the prohibition; its forbidden counterpart may separately qualify as a bounded control.

1. **Universal and repeated duties:** Extract an explicitly universal or clearly class-scoped obligation **once** with its original scope and evidence; attach subsequent repeated passages as evidence or application sites. Do not manufacture one atom per endpoint/chapter/component solely from identical wording. In a chapter-local Map, retain a `CROSS_CHAPTER_RULE_CANDIDATE` flag if the global definition is not yet visible; do not assert that unseen chapters are equivalent.
2. **Application sites are not independent duties:** If a named component merely inherits a common rule, record the component as an `applicability_target` or source locator, not as another scored proposition. Extract a separate item only when the PDF supplies an additional actor, operation, path, schema, status, exception, time bound, independent test duty, or outcome.
3. **Endpoint-specific contracts:** Keep distinct `METHOD /path`, distinct success/error statuses, guards and request or response duties independently testable. A general validation rule does not replace a separate explicit status or timeout obligation.
4. **Fields and DDL:** Reconstruct each field from entity/table/column context. Distinct type, nullability, key, default or relationship constraints may be separate only if independently meaningful and source-backed; a single `tenant_id` label cannot generate multiple generic obligations or invented constraints.
5. **Parent/child and lists:** Preserve the least redundant set of independently testable claims. If a parent restates the totality of separately scored children, store it as context/evidence; do not score the summary again. If the parent adds an independent universal constraint, keep that added condition as its own proposition.
6. **Test-matrix rows:** Distinguish implementation behavior from a separately mandated verification action. Repeated examples or rows that merely demonstrate the behavior are evidence links; independently required execution, outcome verification, negative testing, retention, sign-off or reproducibility may be scored **once at the appropriate scope**. Repeated four-test boilerplate must not yield a four-by-component multiplication without source-grounded independent duties.
7. **Modality and examples:** Preserve `must`, `may`, `optional`, `deferred`, `out of scope`, adopted alternatives, and conditions. Exclude illustrative samples, proposed mechanisms, open questions, and non-normative UI values from positive assertions. Record exclusions with evidence, not invented substitute specifications.
8. **Cross-chapter rules:** Preserve the quoted local text and `cross_chapter_references`; Stage C may consolidate it with a global or related rule after reviewing both sources. Do not preemptively merge unknown requirements or repeat a global rule just to fill a chapter's output.
9. **Independent-atom test:** For each candidate, ask: *If this atom were removed, what distinct normative obligation or testable failure would cease to be represented?* If none, treat it as repeated evidence, membership, or a parent summary rather than another positive atom. Retain the reason either way.
10. **Efficient processing:** Create page/section/target indexes once per chapter; classify repeated rows as families and adjudicate their representative predicates plus all distinct deviations. Do not spend one full semantic analysis per mechanically repeated phrase, but retain every location in the coverage report.

### 4.2 Local records and stable lineage

Create `chapter_<n>.jsonl`, one valid UTF-8 JSON object per line. Use stable IDs such as `CH01-00001`; do not assign final `PDF-*` IDs. Each positive candidate contains:

- `chapter_atom_id`, `chapter_id`, `atomic_statement_en`, `modality`, `actor_en`, `target_en`, `action_en`, `scope_en`, `preconditions_en`, `exceptions_en`, `timing_en`, `outcome_en`, `version_en` (JSON `null` only when genuinely unstated);
- `pdf_evidence`: actual `file`, `physical_page`, `section_table_figure_locator`, `quote_en`, and `table_context_en` for inherited table meanings;
- `atomicity_reason_en`, `independent_test_en`, `rule_family_key`, `scope_kind` (`UNIVERSAL`, `DEFINED_CLASS`, or `SPECIFIC`), `applicability_targets`, `parent_or_related_local_ids`, `cross_chapter_references`, `review_flags`.

`rule_family_key` is a grouping hint, not proof of equivalence. `independent_test_en` describes a distinct normative failure/test if one exists. `applicability_targets` records explicitly grounded members; it is not a list of new source-positive IDs. Missing optional context uses `null` or an empty array, never a manufactured assertion. Exact quotations must be present and checked against source text or directly inspected visual content; do not label a paraphrase a quotation.

Repeated local passages that are **not** independent atoms need not be emitted as extra positive rows. They must still be logged by range, family, and disposition in `chapter_<n>_coverage.json` so that no source evidence silently disappears. If an independently asserted candidate is later subsumed globally, Stage C preserves its ID and lineage.

### 4.3 Negative-control Map policy

Create `chapter_<n>_controls.jsonl` only for affirmative counterfactuals that explicitly violate a PDF prohibition, explicit exclusion, or release deferral. Each row records `chapter_control_id` (e.g., `CH01-N0001`), `counterfactual_statement_en`, `scope_en`, `construction_basis` (`EXPLICIT_PROHIBITION`, `EXPLICIT_EXCLUSION`, or `EXPLICIT_DEFERRAL`), `construction_rule_en`, `rule_family_key`, and `pdf_evidence`.

One forbidden capability is normally one counterfactual at its actually stated scope, not one per role, endpoint, chapter, table, test case, or example. Create distinct controls only when the PDF excludes materially distinct actions or conditions that can independently be asserted. Do not infer controls from silence, missing fields, `TBD`, or an unadopted optional capability. Keep a positive prohibition and its counterfactual logically distinct. Empty control files are valid and must be recorded as zero.

### 4.4 Source coverage and local review

Create `chapter_<n>_coverage.json` listing every assigned physical page and `physical_page`, `inspected`, `positive_candidate_count`, `negative_candidate_count`, `tables_figures_checked`, `normative_exclusions`, `unresolved_evidence_issues`, `repeated_rule_families`, `non_scoring_application_sites`, `test_restatements`, and `cross_chapter_dependencies`. Include section/table-level checks and locations of intentionally unscored repeats. A page may contain no unique requirements and must still appear.

Perform one bounded local check for duplicate paraphrases, false universalization, and unjustified splits. Do **not** perform a global Reduce here. Record uncertain family relationships for Stage C rather than creating redundant atoms as a hedge.

**Gate B (per chapter):** Every assigned page/section/table is accounted for; every scored local candidate is complete and source-backed; repeated-rule applications and test restatements are traceable; IDs and JSONL parse; exclusion and uncertainty records exist. Preserve the completed chapter files unchanged for Stage C.

## 5. Stage C — SaaS-hosted ChatGPT semantic Reduce

Use a **separate, source-only ChatGPT Reduce task**. The LLM performs global semantic consolidation; Python may group records and verify count/lineage invariants. Do not alter any Stage A/B originals. The four input roles are processed in separate batches if necessary, but all must be accounted for across Stage C and D. No generated design specifications, previous gold sets, previous metrics or evaluation judgments are permitted.

### 5.0 Required input roles and passes

| Stage A/B input | Role | Required treatment |
|---|---|---|
| `chapter_<n>.jsonl` | Positive semantic Reduce | Read all records; reconcile their predicates, global families, scopes and sources into canonical positive requirements. |
| `chapter_<n>_controls.jsonl` | Negative-control Reduce | Process separately; deduplicate explicit counterfactual **capabilities**, never infer controls from absence. |
| `chapter_<n>_coverage.json` | Source/evidence audit | Reconcile page and ID totals, unscored repeated sites, tables/figures and unresolved cross-chapter contexts; never turn reports into source atoms. |
| `chapter_manifest.json` | Global partition/family hints | Confirm all segments/overlaps, candidate global definitions and the inspected page universe; families are candidate links, not automatic adjudications. |

Use an inventory pass, grouped positive Reduce, separate control Reduce, and a global reconciliation pass. Retain intermediate batches and their input-ID memberships. A local batch is **not** the final global deduplication scope.

### 5.1 Positive Reduce: semantic equivalence, universal scope and independent duties

1. **Inventory first.** Parse every original chapter positive ID and preserve every evidence locator; reconcile the chapter manifest, coverage counts, and repeated-source registers. Missing actual input is a blocker, not a license to assume the chapter contains no obligations.
2. **Index meaningful predicates.** Group candidates by exact identifier/path/field, normalized actor-action-object, preconditions, time/number/status, scope and polarity, and `rule_family_key`; use bounded semantic ranking only inside plausible groups. Do not perform unconstrained all-pairs comparisons.
3. **Resolve global rule families before scoring.** For each repetitive family, find the exact defining PDF passages and scope. If the PDF establishes a universal or explicitly class-scoped duty, create **one canonical proposition** with all relevant source locators and a non-scoring applicability map. Do not generate one final `PDF-*` ID per application instance without an independently different duty.
4. **Do not fake equivalence.** Distinguish `MUTUALLY_EQUIVALENT` (identical full predicates), `UNIVERSAL_APPLICATION` (specific instance covered by a proven general rule), `PARENT_SUMMARY` (context only), `TEST_RESTATEMENT`, and `RELATED_DISTINCT` (separate testable duty). A particular instance does not logically entail its universal parent; subsumption is **not** recorded as bidirectional equivalence.
5. **Preserve real specificity.** Keep a specific API status, access predicate, field constraint, actor, unique exception, timing limit, or endpoint-specific test result if it adds a normative predicate beyond the common parent. Multiple requirements may share some predicates without being duplicates.
6. **Prevent field inflation.** Combine table heading, row, column, unit and entity scope; reject orphan fragment atoms, duplicated header-derived duties and artificial type/default/nullability multiplication when no independently stated constraint exists. Keep independent attributes only when each can be tested and omitted separately.
7. **Prevent test inflation.** Compare acceptance/verification matrices against substantive duties and prior independent test obligations. Store repeated test cases as supporting evidence or applicability where they do not require independent testing. A distinct mandated test operation or evidence-retention result remains independently scorable if explicitly supported.
8. **Prevent parent/child inflation.** Do not score a summary alongside its complete set of scored children. If a parent adds one irreducible general predicate, retain only that extra obligation. Conversely, do not split a universal rule into one per child just because it covers many targets.
9. **Audit cross-chapter applicability.** Resolve definitions, aliases, exceptions and affected members without building invented hybrids. One rule may have multiple evidence locations; unrelated obligations cannot be combined simply to reduce counts.
10. **Handle ambiguous clusters without hiding risk.** When a plausible duplicate cannot be proven, retain the distinct candidate with a review flag and a concise distinguishing predicate; when an apparent requirement is an unsupported parent/repeated instance, record why it is non-scoring. Every decision references real PDF evidence. Use a targeted cross-group collision check for paraphrases missed by blocking, emphasizing high-frequency repeated families.
11. **Assign final `PDF-*` IDs only after global reconciliation**, in stable source-page/section/local-ID order. Number reflects independent obligations, not the volume of quoted evidence. Do not choose a desired reference size or recall score.
12. **Preserve complete source-to-final lineage.** Every local candidate has exactly one disposition: `RETAINED`, `MERGED_EQUIVALENT`, `SUBSUMED_BY_UNIVERSAL`, `PARENT_SUMMARY_NONSCORING`, `TEST_EVIDENCE_NONSCORING`, `EXCLUDED_NONNORMATIVE`, `SPLIT_WITH_PROOF`, or `REQUIRES_REVIEW`. For universal subsumption, link to the canonical parent ID, inherited target/application and actual PDF scope proof. For split records list all output IDs; for exclusions give source-based reasons. `REQUIRES_REVIEW` may not silently disappear: retain as an explicitly flagged distinct scorable obligation if defensible, or keep the reference provisional pending material resolution.

**Independent scoring test (mandatory):** For each final positive atom, state the specific normative predicate that would disappear if that item were removed while all other final atoms remained. If there is none, revisit the merger, parent/child relation, or repeat-family treatment before accepting the atom. This test must not erase genuinely independent constraints.

If the source audit finds a PDF obligation omitted from all chapter candidates, log a `SOURCE_OMISSION_PROPOSAL` with real evidence and incorporate it **only through a documented Stage D source amendment**; never silently rewrite a chapter file. Source-only additions are not justified by generated-method omissions or scores.

### 5.2 Negative-control Reduce

Read all local control candidates separately and group by prohibited/deferred/excluded **capability plus scope and polarity**, not by occurrence count. A global exclusion is one counterfactual with many source locators, not per-component/endpoint permutations. Do not create controls for each conceivable way to violate a general prohibition. Keep distinct independent counterfactuals when the PDF really forbids different actions, versions, or conditional permissions. Record every removed control's source ID and reason. No positive and negative pair may represent the same logical proposition with identical polarity.

### 5.3 Final ledger fields

`common_atomic_reqs.jsonl` contains one UTF-8 JSON record per final independent positive obligation. Required fields:

- `source_id`, `atomic_statement_en`, `actual_label` (= 1), `modality`, `actor_en`, `target_en`, `action_en`, `scope_en`, `preconditions_en`, `exceptions_en`, `timing_en`, `outcome_en`, `version_en`, `pdf_evidence`, `origin_chapter_atom_ids`, `reconciliation_note_en`, `review_flags`;
- `rule_family_key`, `scope_kind`, `independent_test_en`, `applicability_targets` (allowed to be empty), and `additional_source_locators` (all supporting repeats, when any).

`common_negative_controls.jsonl` contains one canonical PDF-explicit negative counterfactual each, with `negative_control_id`, `counterfactual_statement_en`, `actual_label` (= 0), `scope_en`, `construction_basis`, `construction_rule_en`, `pdf_evidence`, `origin_chapter_control_ids`, `rationale_en`, `rule_family_key`, and `additional_source_locators`.

Preserve full evidence and original local IDs. For a legitimate source-only amendment, `origin_chapter_atom_ids` can be empty **only** when a documented `SOURCE_OMISSION_AMENDMENT` ID links it to original PDF evidence in `reduce_decisions.jsonl`; no untraced final row is allowed. The original canonical ID keys must not be renamed.

### 5.4 Audit outputs, reconciliation and efficiency

- `reduce_lineage.jsonl`: exactly one disposition per original positive/control ID, each with destination ID(s) or explicit non-scoring disposition, source citation, predicate/scope justification and family grouping. Non-scoring evidence sites are also traceable via chapter coverage reports.
- `reduce_decisions.jsonl`: meaningful equivalence vs subsumption distinctions, parent/child, universal membership, field/test normalization, control consolidation, exclusions/splits, cross-chapter context and source-only amendments. Include PDF quotes or resolvable evidence IDs; a label such as `duplicate` alone is inadequate.
- `reference_validation.md`: input/output reconciliation, counts by `UNIVERSAL`/`DEFINED_CLASS`/`SPECIFIC`, repeat-family application counts vs scored atoms, controls by excluded capability, no-scoring explanations, high-impact ambiguous groups, and all upstream limitations.

Use deterministic grouping and representative semantic judgments for proven same-scope repetitions, checking each member for unique exceptions. Use one final targeted cross-group collision audit rather than unrestricted repeated all-pairs review. Preserve all intermediate batch memberships and a complete final global deduplication pass.

**Gate C:** All four input roles accounted for; every original chapter candidate has one justified outcome; positive and negative reductions are separate; every final item has valid evidence and an independent-obligation rationale; universal applications, parent summaries and repeated test rows do not generate duplicate scored atoms; no unsupported merge or material silent loss; all JSONLs and counts reconcile. If a genuinely material ambiguity persists, preserve it explicitly and lower freeze status rather than inventing certainty or multiplying atoms reflexively.

## 6. Stage D — Independent reference validation and freeze

Use a **separate SaaS-hosted ChatGPT validation task** that receives the original PDF, complete chapter Map files/coverage reports, manifest, current positive/control Reduce outputs, and full lineage and decisions. Challenge benchmark construction without accessing generated-method specifications or scores. Stage D validates and repairs the *working* reference, not already frozen pairs.

### 6.1 Mandatory validation procedure

1. **Source identity and page coverage:** Verify the actual physical PDF and every assigned page, including shared boundaries, visual figures, table cells, captions, and appendices. Reconcile manifest and every chapter coverage report. Pages with zero scored atoms remain reviewed pages, not omissions by default.
2. **Item-level evidence integrity:** Check every final record's required fields, PDF page bounds and actual quoted text/visual locator. For full semantic certification, verify all material predicates of each atom; do not mistake quotation presence or matching nouns for complete entailment.
3. **Universal-family audit (exhaustive at family level):** Examine **every** detected repeated-rule family and its general/scoped definition. Compare representative instantiations plus all scope or predicate deviations. Verify that one universal is not cloned per endpoint/component/chapter, that each application is traceable, and that explicit exceptions are not lost.
4. **Parent/child audit:** Check every detected parent/child or general/specific collision. Remove double-scored summaries, retain additional independent predicates, and verify no true specific duty was lost during canonicalization.
5. **Test-obligation audit:** Inspect all families of recurring positive/cross-tenant/duplicate/evidence-retention test prose, their matrix restatements, and separately mandated outcomes. Do not score one per component merely because the wording was repeated. Equally, do not suppress a source-mandated distinct test action or measurable outcome.
6. **Physical schema and interface audit:** Verify independently testable field/type/nullability/key/default/relationship duties, endpoint method/path and statuses, pre-allocation timing, event fields, actors, and exception logic. Reject invented standalone fragments and excessive merging of truly separate contracts.
7. **Negative-control anti-inflation audit:** Group all final `NEG-*` items by PDF-explicit excluded capability, polarity, scope and version. Collapse repeated/per-actor/per-endpoint copies without unique independently prohibited behavior. Preserve legitimate distinct prohibitions and deferred-version conditions. Keep positive prohibition duties and forbidden counterfactuals logically distinct.
8. **Source completeness challenge:** Compare every physical page's substantive normative sections, diagrams and relevant appendices against local candidate coverage, with targeted deep review for sparse/uncertain pages and global-rule families. Missing obligations get PDF-cited `SOURCE_OMISSION_AMENDMENT` entries without modifying immutable chapter files. Do not use prior gold-set counts as a completeness test.
9. **Lineage and semantic non-loss:** Reconcile all local IDs, lineage dispositions, universe counts, scope application sites, source omissions, and evidence locations. For every merge or exclusion, test whether a unique testable obligation disappeared. For every retained atom, check its independent-obligation reason.
10. **Bounded risk-based adversarial review:** Fully challenge all identified repeated-rule families, high-impact security/approval/tenancy constraints, exact API/status/DDL predicates, known parent-child collisions and negative-control families. Additionally sample ordinary distinct records reproducibly across chapters, scope types and atom families; record population, sampling method, review count and findings. If a concrete systematic flaw is found, review its **entire affected family** and correct it; do not restart all source extraction or claim unchecked semantics were independently reviewed.
11. **Mechanical verification:** Use deterministic scripts for parse/ID/digest/quote-locator/page/lineage membership and count checks. Include duplicate normalized-text diagnostics, multi-atom-per-quote ratios, repeated-family fan-out, parent/child collisions, and controls-per-excluded-capability counts. These are **review triggers**, not automatic merge rules or fixed thresholds.
12. **Method isolation and fairness:** Document which PDF evidence and source-only materials were available; exclude generated specs, earlier scores and prior gold sets from semantic adjudication. Contextual leakage, if present, must be disclosed without pretending it can be erased.

### 6.2 Reconciliation identities and inflation diagnostics

Let `I_R` and `I_N` be the original chapter-local positive/control ID sets; `R` and `N` are final canonically scored positive/control ID sets. Assert:

```text
positive_lineage_rows = |I_R|
negative_lineage_rows = |I_N|
each_original_local_ID_has_exactly_one_lineage_disposition = true
each_final_R_or_N_ID_is_unique = true
each_final_item_has_real_PDF_evidence = true
each_final_item_has_independent_obligation_or_exclusion_rationale = true
each_final_item_has_input_lineage_or_documented_source_amendment = true
all_required_physical_pages_have_inspection_records = true
all_scoped_universal_application_sites_have_traceable_parent_or_reason = true
all_non_scoring_repeated_evidence_is_traceable = true
```

Do not impose `|I_R| = |R|` or `|I_N| = |N|`; documented merges, subsumptions, exclusions, splits and source amendments legitimately change counts. Report *both* the input-output count reconciliation and the semantic meaning of each change.

Report at least: scored positive atoms by scope kind; total cited PDF locations vs distinct canonical atoms; number of universal families and non-scoring application sites; repeated four-test boilerplate families; parent/child and test-matrix double-count corrections; independently justified specific endpoint/field duties; negative-control capability families; material merge uncertainties and audit sample coverage. **No numerical target or maximum allowable atom count is prescribed.** Unusually large atom-per-quote/family ratios trigger review, not automatic deletion.

### 6.3 Correction, freeze and comparator policy

1. Repair proven source-backed errors **before freeze** using explicit working-reference amendments, updated Reduce decisions and stable old/new crosswalks. Do not edit original PDF, chapter files, or old frozen inventories.
2. A candidate reference is not certified simply because it has valid JSON and a lineage row for every input. Maintain separate structural, evidence-integrity and semantic-atomicity results in `reference_validation.md`.
3. Freeze only after creating the final `common_atomic_reqs.jsonl` and `common_negative_controls.jsonl` pair and its `reference_freeze.json`, with `protocol_version`, `reference_version`, `source_pdf`, actual `source_pdf_sha256`, both JSONL SHA-256 digests, actual observed `frozen_at_utc`, `validation_status`, `open_issues`, and `limitations`.
4. Use `REFERENCE_FROZEN_VERIFIED` **only** when the actually performed source, item-level semantic, lineage, atomicity, global-family, and control audits justify that claim, with no material unresolved defects. Use `REFERENCE_FROZEN_PROVISIONAL` when honest residual semantic-review limits remain; itemize their affected families and counts. If a mandatory source/input is unreadable, use `REFERENCE_BLOCKED` and do not present a finalized comparable reference.
5. Keep the paired frozen R/N files byte-identical across Full Load, One-Level and Two-Level method evaluations. The evaluation phase may submit `reference_correction_proposals.jsonl` but must never modify the frozen ledger or its ID universe.
6. If later correction is accepted, create a **new reference version**, preserve source evidence and the old-to-new ID crosswalk, re-freeze with new hashes and **rescore every method**. Never compare metrics from differently atomized reference versions as if they shared the same denominator.
7. Only **after** the source-only Stage D decisions are fixed may an operator produce optional `legacy_reference_crosswalk.jsonl` and compare past reference counts as compatibility diagnostics. Historical ID equality or earlier high scores cannot establish source truth.

**Gate D:** A complete, source-traceable, non-inflated paired reference and documented freeze status exist. Identified material universal-rule inflation, parent/test double counts, unsupported control proliferation or silent lineage loss must be corrected or explicitly classified as unresolved material limitations; do not describe them as verified. An actually missing mandatory source is a blocker, not an ordinary ambiguity.

## 7. Compatibility with downstream evaluation

This is an **upstream, four-stage source-reference construction protocol**, not a Phase of any metric evaluator. Its canonical outputs are:

```text
common_atomic_reqs.jsonl
common_negative_controls.jsonl
reference_freeze.json
```

These files are input to OrionDesk One-Pass Atomic Evaluation Protocol v8.3 or a compatible later evaluator. Use the PDF as source authority for any generated-claim validity challenge, but do not mutate the frozen R/N during scoring. Fixed `R` supplies source-positive coverage (TP/FN); fixed `N` supplies bounded absent-counterfactual controls; distinct generated-only unsupported propositions supply the remaining FP candidates. A general generated specification rule may cover multiple **genuinely distinct** source-positive atoms where material entailment and scope membership are proven. It must not encourage replication of one universal PDF obligation into many source atoms.

Precision, Recall and F1 are benchmark-version-specific measurements. **Changing atomization changes the denominator and may change score interpretation even with identical generated specifications.** Never describe a score difference across different `reference_version` values as a change in generation quality without rescoring all methods on one shared benchmark.

## 8. Operator procedure and bounded workflow

The human operator executes four ordered stages, with one complete stage per requested work unit unless a genuine missing-input blocker occurs:

1. **Stage A — Partition and rule planning:** Supply the PDF, verify physical pages and define all chapter/extra segments; emit a complete manifest with cross-chapter global/repetition family candidates. Do not count atoms here.
2. **Stage B — Chapter Map:** Complete one source-scoped chapter at a time, recording independently testable duties, exact citations, repeat families, application sites, test re-statements, and exclusions. Produce each chapter's two JSONLs and coverage JSON; keep completed files immutable.
3. **Stage C — Semantic Reduce:** Supply all chapter positive/control files in separate semantic passes plus the manifest/coverage for audit; LLM performs global equivalence, subsumption and scope adjudication. Generate R/N, one-to-one input lineage, decisions and a global reconciliation report. Do not force a desired total.
4. **Stage D — Validate/Freeze:** Challenge all repeated-rule and negative-control families, evidence, parent/child/test collisions and PDF omissions; perform risk-based targeted semantic review and structural checks. Apply documented working-reference corrections; freeze a new paired reference or report provisional/blocked status honestly.

Avoid endless repeat cycles and all-pairs semantic searches. Reuse indexed candidates and representative same-rule reasoning; examine every materially different condition and every high-impact collision. Each stage must produce actual English files, not a promise of future work. Do not start metric evaluation until Stage D freezes an auditable paired reference.

### Copy-ready Stage A instruction

> Apply Stage A of `create_goldset_protocol-2.0.md` to the original OrionDesk PDF. Verify the PDF and all physical pages; partition chapters and nonchapter pages, identify cross-chapter universal/repeated/test-boilerplate candidate families without scoring them, and write `chapter_manifest.json` in English. Do not inspect generated specifications, previous gold sets, or historical metrics.

### Copy-ready chapter Map instruction

> Apply Stage B of `create_goldset_protocol-2.0.md` to this source PDF chapter only, using its physical page map. Extract each independently meaningful PDF-backed obligation once within its true scope; do not multiply universal rules or repeat tests per component without distinct duties. Record application sites, non-scoring repeats, inherited table context and real citations. Write `chapter_<n>.jsonl`, `chapter_<n>_controls.jsonl`, and `chapter_<n>_coverage.json` in English. Do not use earlier gold sets or generated specifications.

### Copy-ready Reduce instruction

> Apply Stage C of `create_goldset_protocol-2.0.md` to all source-only chapter JSONLs and their audit files. You, the SaaS-hosted ChatGPT LLM, perform semantic Reduce. Reconcile each original local ID, consolidate universal boilerplate as one justified scoped duty, distinguish subsumption from equivalence, preserve distinct endpoint/field/exception obligations, treat repeated verification matrices as evidence unless separately testable, and deduplicate controls by prohibited capability. Write the two common JSONLs, `reduce_lineage.jsonl`, `reduce_decisions.jsonl`, and `reference_validation.md` in English. Do not target an atom count or historical score.

### Copy-ready validation/freeze instruction

> Apply Stage D of `create_goldset_protocol-2.0.md` to the original PDF, all chapter Map records and the full Reduce ledger. Challenge universal-rule fan-out, parent/child and test-matrix double scoring, field/endpoint distinctness, negative-control inflation, actual quote support, and omissions. Correct demonstrated working-reference errors with lineage, disclose limitations and create the two final JSONLs and `reference_freeze.json` with actual SHA-256 values. Do not calculate generation-method scores.

## 9. Final acceptance checklist

- [ ] Actual PDF identity and full physical-page assignment verified, including figures/tables/appendices.
- [ ] Cross-chapter universal, repeated boilerplate and test-family candidates registered without creating scored atoms.
- [ ] Every chapter Map has unique local IDs, genuine PDF quotes, inherited table context and independent-test rationales.
- [ ] Repeated scope applications and test restatements are traceable even when not independently scored.
- [ ] Source-only LLM Reduce read all local records with complete one-to-one input-ID disposition.
- [ ] Universal applications were **not** converted to multiple scored copies; scope membership is documented.
- [ ] Equivalence, universal subsumption, parent-summary and test-evidence exclusions have separate semantics and actual PDF proof.
- [ ] Unique API/field/actor/condition/exception/test outcome duties survived without improper mergers.
- [ ] Negative controls are bounded by genuinely distinct, source-explicit forbidden/deferred/excluded capabilities.
- [ ] Stage D challenged every repeated-rule/control family and high-risk atomicity collision, plus a recorded reproducible ordinary sample.
- [ ] All PDF source amendments are explicitly justified and do not modify immutable chapter originals.
- [ ] Complete counts, source evidence, lineages, exclusions and open risks are disclosed; semantic certification is not inferred from arithmetic.
- [ ] Paired R/N hashes and reference version are fixed before use, or a provisional/blocked status honestly explains why.
- [ ] No generated-method specifications or performance scores shaped the benchmark. No fixed expected positive/control count was used.

**Final directive:** Build the benchmark from the original PDF alone through source-scoped chapter Maps, global LLM semantic Reduce, and independent Stage D source/atomicity review. Follow the v6.1 prohibition against artificial multiplication of universal boilerplate. Preserve genuine independent duties and all lineage, eliminate repeated parent/test/control inflation, and freeze one common paired reference for fair across-method evaluation. Never optimize the Gold Set for prior results or change it silently during metric evaluation.
