#!/usr/bin/env python3
"""OrionDesk v10.6 Phase 04 reciprocal source coverage audit.

This is a source/quote-checked reciprocal discovery and evidentiary audit. It does
not fabricate semantic entailment or produce final TP/FN classifications.
All original Phase 01-03 files are read-only.
"""
from __future__ import annotations
import collections, hashlib, json, re, unicodedata, pathlib, math, sys, datetime
from sklearn.feature_extraction.text import TfidfVectorizer, ENGLISH_STOP_WORDS
import numpy as np
import fitz

ROOT=pathlib.Path('/mnt/data/oriondesk_fullload_v10_6')
PH=ROOT/'phase04'
PH.mkdir(exist_ok=True)
SRC=pathlib.Path('/mnt/data')
FILES={
 'phase01':ROOT/'phase01/01_reference_lock.json',
 'phase02':ROOT/'phase02/02_phase_summary.json',
 'phase03':ROOT/'phase03/03_phase_summary.json'
}

def sha(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def jsonl(path):
 with open(path,encoding='utf-8') as f:
  for ln in f:
   if ln.strip(): yield json.loads(ln)
def writejson(path,obj):
 with open(path,'w',encoding='utf-8') as f:json.dump(obj,f,ensure_ascii=False,sort_keys=True,indent=2);f.write('\n')
def writejsonl(path,records):
 with open(path,'w',encoding='utf-8') as f:
  for r in records:f.write(json.dumps(r,ensure_ascii=False,sort_keys=True,separators=(',',':'))+'\n')
def norm(s):return ' '.join(unicodedata.normalize('NFKC',str(s)).casefold().split())
def ctext(s):
 s=unicodedata.normalize('NFKC',str(s)); s=re.sub(r'([a-z])([A-Z])',r'\1 \2',s)
 return s.lower().replace('_',' ').replace('-', ' ')
STOP=set(ENGLISH_STOP_WORDS)|{'source','specified','specification','confirmed','requirement','data','system','use','using','must','shall','ensure','with','for','from','and','the','that','each','all','an','its','their','as','of','this','these','those','given','where','applicable','provides','support','supported','required','requires','require','should','implemented','implement','provide','implementing','enforce','including','include','not','never'}
IRREG={'ingestion':'ingest','ingested':'ingest','indexes':'index','indexing':'index','indexed':'index','generated':'generate','generation':'generate','retrieving':'retrieve','retrieval':'retrieve','retrieved':'retrieve','validates':'validat','validated':'validat','validation':'validat','verifies':'verifi','verified':'verifi','verification':'verifi','permissions':'permission','sources':'source','requirements':'requirement','decisions':'decision','approvals':'approval','documents':'document','policies':'policy','identity':'ident','identities':'ident','authorization':'authoriz','authorized':'authoriz','authorise':'authoriz','authentication':'authenticat','authenticated':'authenticat','untrusted':'untrust','trust':'trust','reviewed':'review','reviewer':'review','retries':'retry','retrying':'retry','replayed':'replay','persisted':'persist','persistence':'persist','preserves':'preserv','immutable':'immut','versioned':'version','versions':'version','budgeting':'budget','budgets':'budget','queueing':'queue','queued':'queue','failed':'fail','failures':'fail','failure':'fail','closed':'close','closure':'close','case':'case','cases':'case'}
def tokens(s):
 words=re.findall(r'[a-zA-Z0-9][a-zA-Z0-9_.-]*',ctext(s)); r=[]
 for w in words:
  w=IRREG.get(w,w)
  if len(w)>4 and w.endswith('ies'): w=w[:-3]+'y'
  elif len(w)>5 and w.endswith('ing'):w=w[:-3]
  elif len(w)>5 and w.endswith('ed'):w=w[:-2]
  elif len(w)>4 and w.endswith('s') and not w.endswith('ss'):w=w[:-1]
  if w and w not in STOP and len(w)>1:r.append(w)
 return r

def overlap(query,txt):
 q=set(tokens(query)); t=set(tokens(txt)); return round(len(q&t)/len(q),4) if q else 0.0

def core_numbers(s):
 # Numeric and recognizable contract literals; not an automatically complete entailment check
 return set(re.findall(r'(?<!\w)(?:\d+(?:[.,]\d+)*(?:\s?%|\s?ms|\s?mb|\s?min|\s?hours)?|(?:GET|POST|PUT|PATCH|DELETE)\s+/[\w/{}.-]+)(?!\w)',s, re.I))

def markers(s):
 t=ctext(s)
 phrases=['must not','shall not','never','no ','only','before','after','at least','at most','maximum','minimum','unless','without','cannot','fail closed','same transaction','atomic','idempotency','tenant','revision','approved','current','audit']
 return [p for p in phrases if p in t]

def citation_valid(c,lines,sha_expected):
 fp=c.get('file',''); loc=lines.get(fp); 
 if loc is None: return False,'UNKNOWN_FILE'
 if sha_expected!=loc['sha256'] or c.get('file_sha256') != loc['sha256']:return False,'SOURCE_DIGEST_MISMATCH'
 start,end=c.get('line_start'),c.get('line_end')
 if type(start)!=int or type(end)!=int or not (1<=start<=end<=len(loc['lines'])):return False,'INVALID_LINE_RANGE'
 quote=c.get('quote_en') or ''
 text='\n'.join(loc['lines'][start-1:end]);
 if not quote or norm(quote) not in norm(text): return False,'QUOTE_LINE_MISMATCH'
 return True,'VERIFIED'

def intro():
 lock=json.loads(FILES['phase01'].read_text()); p2=json.loads(FILES['phase02'].read_text());p3=json.loads(FILES['phase03'].read_text())
 assert lock['protocol_version']=='10.6' and lock['frozen_r_count']==638 and lock['frozen_n_count']==142
 assert p2['status']=='COMPLETE' and p3['all_r_indexed']
 assert sha(FILES['phase01'])==p2['phase01_lock_sha256']
 assert sha(ROOT/'phase02/02_generated_atoms_final.jsonl')==p2['output_sha256']['02_generated_atoms_final.jsonl']
 assert sha(ROOT/'phase02/02_generated_classes_final.jsonl')==p2['output_sha256']['02_generated_classes_final.jsonl']
 assert sha(ROOT/'phase02/02_generated_classes_final.jsonl')==p3['generated_classes_sha256']
 for role in lock['source_roles_ordered']:
  assert sha(role['original_path'])==role['sha256'],role['role']
 assert sha(SRC/'common_atomic_reqs(4).jsonl')==lock['frozen_r_sha256']
 assert sha(SRC/'common_negative_controls(4).jsonl')==lock['frozen_n_sha256']
 assert sha(SRC/'reference_freeze(4).json')==lock['reference_freeze_sha256']
 assert sha(SRC/'OrionDesk_AI_Detailed_Design_Specification(4).pdf')==lock['pdf_sha256']
 return lock,p2,p3

lock,p2,p3=intro()
R=list(jsonl(SRC/'common_atomic_reqs(4).jsonl'))
G=list(jsonl(ROOT/'phase02/02_generated_atoms_final.jsonl'))
GC=list(jsonl(ROOT/'phase02/02_generated_classes_final.jsonl'))
P3=list(jsonl(ROOT/'phase03/03_source_coverage.jsonl'))
bridges={x['source_id']:x for x in jsonl(ROOT/'phase03/03_semantic_coverage_bridges.jsonl')}
assert len(R)==len(P3)==638 and len(G)==5046 and len(GC)==4861
assert [r['requirement_id'] for r in R]==[p['source_id'] for p in P3]
source_files={s['actual_filename']:{'role':s['role'],'sha256':s['sha256'],'lines':pathlib.Path(s['original_path']).read_text(encoding='utf-8').splitlines()} for s in lock['source_roles_ordered']}
go_by_id={g['gen_id']:g for g in G}

# Independent reciprocal search: bag-of-words + character n-grams, distinct from Phase03.
# Corpus includes all original eligible GO plus all substantive raw source lines
# not restricted to Phase03's top candidates.
orig=list(jsonl(ROOT/'phase02/02_original_text_index.jsonl'))
line_docs=[d for d in orig if d['scan_class'] not in ('BLANK','STRUCTURAL_OR_REFERENCE') and len(d['original_text_en'].strip())>=22]
search_docs=G + line_docs
search_text=[(d['statement_en']+' '+(d.get('source_quote_en') or '')) if 'gen_id' in d else d['original_text_en'] for d in search_docs]
qtext=[]
for r in R:
 pred=' '.join(r.get('required_predicates') or [])
 qtext.append(r['statement_en']+' '+pred)
# Keep retrieval methods independent of the previous per-role matching.
wvec=TfidfVectorizer(ngram_range=(1,2),sublinear_tf=True,strip_accents='unicode',min_df=1,stop_words='english',max_features=160000)
cvec=TfidfVectorizer(analyzer='char_wb',ngram_range=(3,5),min_df=2,sublinear_tf=True,max_features=180000)
wD=wvec.fit_transform(search_text); cD=cvec.fit_transform(search_text)
wQ=wvec.transform(qtext);cQ=cvec.transform(qtext)
S=(0.6*(wQ@wD.T)+0.4*(cQ@cD.T)).tocsr()
N=len(G)

def as_cand(d,score,channel):
 if 'gen_id' in d:
  return {'gen_id':d['gen_id'],'class_id':d['class_id'],'file':d['actual_filename'],'file_sha256':d['original_file_sha256'],'line_start':d['line_start'],'line_end':d['line_end'],'quote_en':d['source_quote_en'],'statement_en':d['statement_en'],'inherited_heading_path':d.get('heading_path',[]),'independent_score':round(float(score),5),'retrieval_channel':channel,'source_type':'ELIGIBLE_GO'}
 return {'gen_id':None,'class_id':None,'file':d['actual_filename'],'file_sha256':d['file_sha256'],'line_start':d['line'],'line_end':d['line'],'quote_en':d['original_text_en'],'statement_en':d['original_text_en'],'inherited_heading_path':d.get('heading_path',[]),'independent_score':round(float(score),5),'retrieval_channel':channel,'source_type':'ORIGINAL_LINE_FALLBACK'}

def best_independent(i,k=20):
 row=S.getrow(i);vals=row.data;ind=row.indices
 if not len(vals):return []
 sel=np.argsort(-vals)[:max(k*4,100)]
 ret=[];seen=set()
 for t in sel:
  ix=int(ind[t]);d=search_docs[ix];cc=as_cand(d,float(vals[t]),'INDEPENDENT_WORD_CHAR_TFIDF')
  key=(cc['file'],cc['line_start'],cc['quote_en'])
  if key in seen:continue
  seen.add(key);ret.append(cc)
  if len(ret)>=k: break
 return ret

def eval_predicate(predicate,candidates):
 # Lexical diagnostic: a full predicate may be established by varied phrasings;
 # a token-level score is never semantic entailment on its own.
 ranked=[]
 for c in candidates:
  ratio=overlap(predicate,c['statement_en']+' '+c['quote_en'])
  ranked.append((ratio,c))
 ranked.sort(key=lambda z:(z[0], z[1].get('independent_score', z[1].get('search_score',0))),reverse=True)
 best=ranked[0][1] if ranked else None
 return {'predicate_en':predicate,'best_token_coverage_diagnostic':ranked[0][0] if ranked else 0.0,
         'best_candidate_gen_id':best.get('gen_id') if best else None,
         'best_candidate_file':best['file'] if best else None,
         'best_candidate_line':best['line_start'] if best else None,
         'best_candidate_quote_en':best['quote_en'] if best else None,
         'lexical_condition_not_semantic_proof':True}

AUD=[];TPAUD=[];FNAUD=[]
status_counter=collections.Counter();reasons=collections.Counter();candidate_errors=collections.Counter();strong_changed=collections.Counter()
strong_n=0; independent_new=0; inspected_ids=set(); e3=0
for i,(r,p) in enumerate(zip(R,P3)):
 sid=r['requirement_id'];is_strong=p['coverage_discovery_status']=='STRONG_TEXTUAL_COVERAGE_CANDIDATE'
 if is_strong:strong_n+=1
 old=p['generated_evidence_candidates']
 old_valid=[]
 for c in old:
  ok,err=citation_valid(c,source_files,c.get('file_sha256'))
  if ok:old_valid.append(c)
  else:candidate_errors[err]+=1
 indep=best_independent(i,k=20)
 new_valid=[]
 for c in indep:
  ok,err=citation_valid(c,source_files,c.get('file_sha256'))
  if ok:new_valid.append(c)
  else:candidate_errors[err]+=1
 # Combine top Phase03, 20 independent, and all explicit bridge sources (allow up to 45).
 by_key={}
 for c in old_valid+new_valid:
  key=(c['file'],c['line_start'],norm(c['quote_en']))
  if key not in by_key:by_key[key]=c
  elif c.get('independent_score',0)>by_key[key].get('independent_score',0):by_key[key]=c
 if sid in bridges:
  for bid in bridges[sid]['candidate_gen_ids']:
   if bid in go_by_id:
    g=go_by_id[bid]; c=as_cand(g,0.0,'PHASE03_BRIDGE')
    if citation_valid(c,source_files,c['file_sha256'])[0]:by_key[(c['file'],c['line_start'],norm(c['quote_en']))]=c
 candidates=list(by_key.values())
 # Prioritize old matches and new independent search, keep sufficient distinct roles.
 candidates.sort(key=lambda c:(max(c.get('search_score',0),c.get('independent_score',0)), c.get('gen_id') is not None), reverse=True)
 if len(candidates)>40:
  keep=candidates[:32]
  seenrole={source_files[x['file']]['role'] for x in keep}
  for c in candidates[32:]:
   ro=source_files[c['file']]['role']
   if ro not in seenrole:keep.append(c); seenrole.add(ro)
  candidates=keep
 oldkeys={(c['file'],c['line_start'],norm(c['quote_en'])) for c in old_valid}
 novel=[c for c in candidates if (c['file'],c['line_start'],norm(c['quote_en'])) not in oldkeys]
 bestp=old_valid[0] if old_valid else None
 # Best quote-overlap is only diagnostic, not full semantic proof.
 pp=r.get('required_predicates') or [r['statement_en']]
 pchecks=[eval_predicate(x,candidates) for x in pp]
 all_covered=all(z['best_token_coverage_diagnostic']>=0.69 for z in pchecks)
 any_covered=any(z['best_token_coverage_diagnostic']>=0.35 for z in pchecks)
 top=candidates[:12]
 # Exact PDF quote reproduced in a positively asserted source is a strong
 # candidate, but some source quotes are fragments, so also require statement
 # token completeness, no proposal/commentary and all key numerals.
 long_pdf_quotes=[e['quote'] for e in r.get('pdf_evidence',[]) if e.get('pdf_verification')=='PDF_TEXT_EXACT' and len(e.get('quote','').strip())>=28]
 exact_hits=[]
 for c in candidates:
  if c['source_type']!='ELIGIBLE_GO':continue
  txt=c['statement_en']+' '+c['quote_en']; nt=norm(txt)
  if not any(norm(eq) in nt for eq in long_pdf_quotes):continue
  if overlap(r['statement_en'],txt)<0.68:continue
  rnums={norm(x) for x in core_numbers(r['statement_en'])}
  if any(q not in norm(txt) for q in rnums):continue
  if 'proposal' in ctext(txt) or 'needs confirmation' in ctext(txt):continue
  exact_hits.append(c)
 # More strict direct documentation evidence as independent full-text paraphrase
 # only when almost every source-core token appears, no qualifier contradictions;
 # still mark for semantic review rather than authorizing a TP.
 close_candidates=[c for c in candidates if c['source_type']=='ELIGIBLE_GO' and overlap(r['statement_en'],c['statement_en']+' '+c['quote_en']) >= .86]
 if exact_hits:
  grade='DIRECT_QUOTE_REPRODUCED_ENTAILMENT_PENDING'; out='DIRECT_QUOTE_CANDIDATE_CHECKED'; evidence_provisional='STRONG_PROVISIONAL_SUPPORT'; e3+=1
 elif all_covered and close_candidates:
  grade='NEAR_PARAPHRASE_ENTAILMENT_PENDING';out='WHOLE_PREDICATE_LEXICAL_CANDIDATE';evidence_provisional='PROVISIONAL_SUPPORT_NEEDS_SEMANTIC_REVIEW'
 elif all_covered:
  grade='CONJUNCTIVE_SCOPE_ENTAILMENT_PENDING';out='MULTIPART_CANDIDATE_SCOPE_NOT_PROVEN';evidence_provisional='UNRESOLVED'
 elif any_covered:
  grade='PARTIAL_LEXICAL_EVIDENCE';out='PARTIAL_PREDICATE_SUPPORT_CHALLENGE';evidence_provisional='UNRESOLVED'
 else:
  grade='INSUFFICIENT_CANDIDATE_EVIDENCE';out='NO_VERIFIED_FULL_MATCH_AFTER_RECIPROCAL_SEARCH';evidence_provisional='UNRESOLVED'
 # The audit cannot infer logical nonentailment from retrieval failure.
 condition_flags=[]
 for m in markers(r['statement_en']):
  if m in ['tenant','revision','approved','current','audit']:continue
  if candidates and not any(m in ctext(c['statement_en']+' '+c['quote_en']) for c in candidates[:20]): condition_flags.append(m)
 scope_flags=[]
 if any(c['source_type']=='ORIGINAL_LINE_FALLBACK' for c in top):scope_flags.append('RAW_LINE_FALLBACK_REQUIRES_PHASE05_ELIGIBILITY_CHECK')
 if len({c['file'] for c in top})>1:scope_flags.append('CROSS_FILE_APPLICATION_NOT_PROVEN_BY_RETRIEVAL')
 if not exact_hits:scope_flags.append('NO_COMPLETE_DIRECT_PDF_QUOTE_CONFIRMED')
 if any('needs confirmation' in ctext(c['quote_en']) or 'proposal' in ctext(c['quote_en']) for c in top):scope_flags.append('UNADOPTED_OR_UNRESOLVED_CONTENT_IN_CANDIDATE')
 old_top_keys={(c['file'],c['line_start']) for c in old_valid[:3]}
 novel_above=[c for c in novel if c.get('independent_score',0)>=0.24 and (c['file'],c['line_start']) not in old_top_keys]
 if novel_above:independent_new+=1
 # Summarize a max 12 evidence lines plus predicate-specific evidence so output remains auditable.
 candidates_out=[]
 for c in top:
  candidates_out.append({k:c.get(k) for k in ['gen_id','class_id','file','file_sha256','line_start','line_end','quote_en','statement_en','retrieval_channel','source_type','search_score','independent_score','inherited_heading_path'] if k in c}|{'verified_original':True})
 # Verify PDF's original quote availability from 01 validated lock; source references unchanged.
 pdf_evidence=[{'physical_page':e['physical_page'],'quote_en':e.get('quote'),'figure_locator':e.get('figure_locator',e.get('locator')),'pdf_verification':e.get('pdf_verification'),'source_pdf_sha256':lock['pdf_sha256']} for e in r.get('pdf_evidence',[])]
 rec={
  'record_type':'PHASE04_SOURCE_RECIPROCAL_AUDIT','method':'fullload','protocol_version':'10.6','source_id':sid,
  'source_statement_en':r['statement_en'],'source_scope':r.get('source_scope'),'source_pdf_sha256':lock['pdf_sha256'],
  'pdf_evidence':pdf_evidence,'required_predicates_en':pp,'predicate_scope_warning_en': [pred for pred in pp if len(set(tokens(pred))) > 1.35*max(1,len(set(tokens(r['statement_en']))))], 'phase03_provisional_retrieval_status':p['coverage_discovery_status'],
  'phase03_candidate_count':len(old),'phase04_candidate_count_checked':len(candidates),
  'phase04_independent_new_candidate_count':len(novel),
  'independent_better_candidate_found':bool(novel_above),
  'independent_challenge_candidates':[{k:c.get(k) for k in ['file','file_sha256','line_start','line_end','gen_id','class_id','quote_en','statement_en','source_type','independent_score']} for c in novel_above[:5]],
  'predicate_support_checks':pchecks,
  'phase04_evidence_grade':grade,'phase04_audit_result':out,
  'provisional_source_coverage_status':evidence_provisional,
  'candidate_evidence':candidates_out,
  'candidate_quote_hashes_and_original_lines_verified':True,
  'source_pdf_quotations_verified_by_immutable_phase01_audit':True,
  'scope_and_negation_cautions':scope_flags,
  'potential_qualifier_gaps':condition_flags,
  'support_bridge_id':bridges[sid]['bridge_id'] if sid in bridges else None,
  'direct_quote_candidate_gen_ids':[c['gen_id'] for c in exact_hits[:8]],
  'countercheck_en':'A lexical similarity, unverified conjunctive transfer, or absence from retrieval is not sufficient to commit TP or FN. Check the full actor, target, condition, exception, timing and applicability in original context.',
  'final_scoring_cell':None,
  'final_binary_decision_deferred_to_phase07':True,
  'reference_immutable':True,
 }
 AUD.append(rec);status_counter[out]+=1
 if is_strong or exact_hits:
  TPAUD.append({'record_type':'PHASE04_PROVISIONAL_TP_CHALLENGE','protocol_version':'10.6','method':'fullload','source_id':sid,
    'phase03_strong_candidate':is_strong,'e3_direct_source_quote_candidate':bool(exact_hits),
    'full_predicate_support_independently_proven':False,
    'strongest_generated_evidence':candidates_out[:5],
    'predicate_support_checks':pchecks,
    'potential_qualifier_gaps':condition_flags,
    'source_scope_en':r.get('source_scope'),'phase04_result':out,
    'tp_not_committed_from_search_alone':True,
    'original_pdf_quote':pdf_evidence[:2],
    'audit_note_en':'Even a strong text hit must cover the complete conditional source proposition. A reproduced direct quotation is a high-grade candidate, not a counted TP until justified semantic acceptance.'})
 if not is_strong:
  root='UNRESOLVED_SCOPE_OR_ENTAILMENT'
  if grade=='DIRECT_QUOTE_REPRODUCED_ENTAILMENT_PENDING':root='PHASE03_RETRIEVAL_MISS_CHALLENGED_BY_DIRECT_QUOTATION'
  elif grade=='NEAR_PARAPHRASE_ENTAILMENT_PENDING':root='PHASE03_RETRIEVAL_MISS_CHALLENGED_BY_NEAR_PARAPHRASE'
  elif grade=='CONJUNCTIVE_SCOPE_ENTAILMENT_PENDING':root='CROSS_CLAUSE_OR_CROSS_FILE_SUPPORT_REQUIRES_SCOPE_CHECK'
  elif grade=='PARTIAL_LEXICAL_EVIDENCE':root='STRONGEST_INSPECTED_EVIDENCE_PARTIAL_OR_UNCERTAIN'
  else:root='NO_COMPLETE_QUOTE_FOUND_NOT_PROOF_OF_ABSENCE'
  FNAUD.append({'record_type':'PHASE04_PROVISIONAL_MISS_ROOT_CAUSE_AUDIT','protocol_version':'10.6','method':'fullload','source_id':sid,'source_statement_en':r['statement_en'],
    'phase03_status':p['coverage_discovery_status'],'root_cause_status':root,'missing_source_predicates_not_proved':True,
    'strongest_inspected_near_matches':candidates_out[:6],
    'independent_new_challenge_evidence':rec['independent_challenge_candidates'],
    'predicate_support_checks':pchecks,
    'phase04_result':out,
    'fn_not_proved_by_retrieval_failure':True,'final_fn_committed':False,
    'pdf_evidence':pdf_evidence[:2]})

p4files=['04_coverage_audit.jsonl','04_tp_evidence_audit.jsonl','04_fn_root_cause_audit.jsonl']
for name,rows in zip(p4files,[AUD,TPAUD,FNAUD]):writejsonl(PH/name,rows)
summary={
 'record_type':'PHASE04_SUMMARY','phase':'04','protocol_version':'10.6','method':'fullload','status':'COMPLETE_EVIDENCE_DISCOVERY_AND_RECIPROCAL_AUDIT',
 'source_r_count':len(R),'frozen_n_count':142,'eligible_go_count':len(G),'unique_gc_count':len(GC),
 'full_r_audit_count':len(AUD),'phase03_provisional_strong_tp_count':strong_n,
 'provisional_tp_challenge_records':len(TPAUD),'provisional_miss_challenge_records':len(FNAUD),
 'phase04_audit_result_counts':dict(status_counter),'independent_new_candidate_challenge_count':independent_new,
 'direct_pdf_quote_candidate_count':e3,
 'source_candidate_evidence_all_original_lines_verified':not candidate_errors,
 'invalid_generated_evidence':dict(candidate_errors),
 'no_provisional_fn_promoted_solely_from_retrieval_absence':True,
 'source_pdf_unchanged':True,'r_n_reference_unchanged':True,'all_original_eight_markdown_unchanged':True, 'frozen_required_predicate_scope_flags':sum(bool(x['predicate_scope_warning_en']) for x in AUD),
 'final_semantic_cells_committed':0,'final_tp':None,'final_fn':None,
 'phase05_not_started':True,
 'phase01_lock_sha256':sha(FILES['phase01']),'phase02_go_sha256':sha(ROOT/'phase02/02_generated_atoms_final.jsonl'),
 'phase02_gc_sha256':sha(ROOT/'phase02/02_generated_classes_final.jsonl'),
 'phase03_source_coverage_sha256':sha(ROOT/'phase03/03_source_coverage.jsonl'),
 'pdf_sha256':lock['pdf_sha256'],'r_sha256':lock['frozen_r_sha256'],'n_sha256':lock['frozen_n_sha256'],
 'source_files_sha256':{x['actual_filename']:x['sha256'] for x in lock['source_roles_ordered']},
 'output_sha256':{fn:sha(PH/fn) for fn in p4files},
 'limitations_en':[
    'This phase independently challenges all R candidates, including every initially strong text match and every proposed retrieval miss. It is an evidence-first reciprocal audit, not a substitute for Phase 07 complete independent semantic classification.',
    'Lexical predicate coverage is diagnostic; it does not by itself prove logical entailment, applicable scope, or absence of missing exceptions.',
    'The phase preserves unresolved items instead of fabricating FN from retrieval misses. Phase 05 must reinspect excluded assertions and effective GC validity; Phase 07 commits mandatory binary item decisions.',
    'Phase 02 generated-class eligibility is frozen as a prior-phase artifact and may contain metadata/noise requiring Phase 05 re-evaluation.'
 ]
}
writejson(PH/'04_phase_summary.json',summary)
report=f'''# OrionDesk Phase 04 — TP/FN Reciprocal Evidence Audit\n\nProtocol version: 10.6  \nGeneration method: fullload  \nStatus: COMPLETE (reciprocal evidence audit only; semantic scoring remains uncommitted)\n\n## Scope and results\n\n- Frozen positive R: {len(R)}; frozen negative N: 142.\n- Confirmed Phase 02 eligible GO: {len(G)}; unique GC: {len(GC)} (unchanged).\n- Reciprocal source audits: {len(AUD)}, including every Phase 03 record.\n- Initially strong text candidates explicitly challenged: {strong_n}.\n- Provisional TP evidence-challenge records (including new direct-quote candidates): {len(TPAUD)}.\n- Provisional miss/partial-support challenge records: {len(FNAUD)}.\n- Source items with substantial independent new search evidence: {independent_new}.\n- Items with reproducible original PDF quote in a qualifying generated assertion: {e3}.\n- Evidence statuses: {json.dumps(dict(status_counter),sort_keys=True)}.
- R atoms with potentially overbroad frozen supporting predicate hints: {sum(bool(x['predicate_scope_warning_en']) for x in AUD)} (flagged, not changed).\n- Invalid generated quote/line/hash candidates found: {sum(candidate_errors.values())}.\n\n## Guardrails\n\n- A retrieved near match or token overlap is not full semantic entailment. Predicate scores are explicitly diagnostic and document an audited search challenge, not a binary decision.\n- No absent/low-scoring retrieval is counted as a proven false negative. No automatic TP/FN metric cells are issued.\n- Actual original Markdown filenames, exact source lines, and SHA-256 are checked for every retained evidence candidate. PDF evidence and source reference identities were validated at Phase 01 and rechecked against the immutable hash lock.\n- Potentially incomplete conditions, exceptions, timing, scope, numerical values, and mixed proposal/content labels are recorded for subsequent manual semantic scrutiny.\n- Phase 02 GO/GC classification remains frozen and may need Phase 05 exclusion reassessment.\n\n## Outputs\n\n- `04_coverage_audit.jsonl`: all {len(AUD)} R records, PDF evidence, checked original Markdown candidates, independent retrieval challenge, per-predicate diagnostics, and unresolved entailment limitations.\n- `04_tp_evidence_audit.jsonl`: all {strong_n} initially strong R candidates plus newly found exact-source-quote candidates, with entire-proposition challenge.\n- `04_fn_root_cause_audit.jsonl`: every initially partial, weak, or missing R candidate, together with near misses and alternative evidence.\n- `04_phase_summary.json`: identity/digest, census and audit outcomes.\n- `validate_phase04.py`: independent mechanical integrity audit.\n\nNo Phase 05 work or external semantic evaluation was performed.\n'''
(PH/'04_phase_report.md').write_text(report,encoding='utf-8')
print(json.dumps({k:summary[k] for k in ['source_r_count','provisional_tp_challenge_records','provisional_miss_challenge_records','phase04_audit_result_counts','independent_new_candidate_challenge_count','direct_pdf_quote_candidate_count','invalid_generated_evidence']},indent=2))
