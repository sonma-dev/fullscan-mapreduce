# OrionDesk Phase 04 — TP/FN Reciprocal Evidence Audit

Protocol version: 10.6  
Generation method: fullload  
Status: COMPLETE (reciprocal evidence audit only; semantic scoring remains uncommitted)

## Scope and results

- Frozen positive R: 638; frozen negative N: 142.
- Confirmed Phase 02 eligible GO: 5046; unique GC: 4861 (unchanged).
- Reciprocal source audits: 638, including every Phase 03 record.
- Initially strong text candidates explicitly challenged: 69.
- Provisional TP evidence-challenge records (including new direct-quote candidates): 78.
- Provisional miss/partial-support challenge records: 569.
- Source items with substantial independent new search evidence: 297.
- Items with reproducible original PDF quote in a qualifying generated assertion: 24.
- Evidence statuses: {"DIRECT_QUOTE_CANDIDATE_CHECKED": 24, "MULTIPART_CANDIDATE_SCOPE_NOT_PROVEN": 243, "NO_VERIFIED_FULL_MATCH_AFTER_RECIPROCAL_SEARCH": 25, "PARTIAL_PREDICATE_SUPPORT_CHALLENGE": 276, "WHOLE_PREDICATE_LEXICAL_CANDIDATE": 70}.
- R atoms with potentially overbroad frozen supporting predicate hints: 67 (flagged, not changed).
- Invalid generated quote/line/hash candidates found: 0.

## Guardrails

- A retrieved near match or token overlap is not full semantic entailment. Predicate scores are explicitly diagnostic and document an audited search challenge, not a binary decision.
- No absent/low-scoring retrieval is counted as a proven false negative. No automatic TP/FN metric cells are issued.
- Actual original Markdown filenames, exact source lines, and SHA-256 are checked for every retained evidence candidate. PDF evidence and source reference identities were validated at Phase 01 and rechecked against the immutable hash lock.
- Potentially incomplete conditions, exceptions, timing, scope, numerical values, and mixed proposal/content labels are recorded for subsequent manual semantic scrutiny.
- Phase 02 GO/GC classification remains frozen and may need Phase 05 exclusion reassessment.

## Outputs

- `04_coverage_audit.jsonl`: all 638 R records, PDF evidence, checked original Markdown candidates, independent retrieval challenge, per-predicate diagnostics, and unresolved entailment limitations.
- `04_tp_evidence_audit.jsonl`: all 69 initially strong R candidates plus newly found exact-source-quote candidates, with entire-proposition challenge.
- `04_fn_root_cause_audit.jsonl`: every initially partial, weak, or missing R candidate, together with near misses and alternative evidence.
- `04_phase_summary.json`: identity/digest, census and audit outcomes.
- `validate_phase04.py`: independent mechanical integrity audit.

No Phase 05 work or external semantic evaluation was performed.
