#!/usr/bin/env python3
"""Independent Phase 04 identity, census and evidence-locator validator."""
import pathlib,json,hashlib,collections,unicodedata
root=pathlib.Path('/mnt/data/oriondesk_fullload_v10_6'); d=root/'phase04'

def sha(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def norm(s):return ' '.join(unicodedata.normalize('NFKC',str(s)).casefold().split())
def jl(p):return [json.loads(s) for s in pathlib.Path(p).read_text().splitlines() if s.strip()]
lock=json.loads((root/'phase01/01_reference_lock.json').read_text());p2=json.loads((root/'phase02/02_phase_summary.json').read_text());p3=json.loads((root/'phase03/03_phase_summary.json').read_text());p4=json.loads((d/'04_phase_summary.json').read_text())
r=jl('/mnt/data/common_atomic_reqs(4).jsonl');old=jl(root/'phase03/03_source_coverage.jsonl');a=jl(d/'04_coverage_audit.jsonl');tp=jl(d/'04_tp_evidence_audit.jsonl');fn=jl(d/'04_fn_root_cause_audit.jsonl');G=jl(root/'phase02/02_generated_atoms_final.jsonl'); GC=jl(root/'phase02/02_generated_classes_final.jsonl')
assert sha(root/'phase01/01_reference_lock.json')==p4['phase01_lock_sha256']
assert sha(root/'phase02/02_generated_atoms_final.jsonl')==p4['phase02_go_sha256']
assert sha(root/'phase02/02_generated_classes_final.jsonl')==p4['phase02_gc_sha256']
assert sha(root/'phase03/03_source_coverage.jsonl')==p4['phase03_source_coverage_sha256']
assert sha('/mnt/data/common_atomic_reqs(4).jsonl')==p4['r_sha256']==lock['frozen_r_sha256']
assert sha('/mnt/data/common_negative_controls(4).jsonl')==p4['n_sha256']==lock['frozen_n_sha256']
assert sha('/mnt/data/OrionDesk_AI_Detailed_Design_Specification(4).pdf')==p4['pdf_sha256']==lock['pdf_sha256']
assert len(r)==len(a)==len(old)==638 and len(G)==5046 and len(GC)==4861
assert len(set(x['source_id'] for x in a))==638
assert [x['source_id'] for x in a]==[x['requirement_id'] for x in r]==[x['source_id'] for x in old]
assert len(tp)==len(set(x['source_id'] for x in tp))==78
assert len(fn)==len(set(x['source_id'] for x in fn))==569
strong={x['source_id'] for x in old if x['coverage_discovery_status']=='STRONG_TEXTUAL_COVERAGE_CANDIDATE'}
assert len(strong)==69
assert strong.issubset({x['source_id'] for x in tp})
assert {x['source_id'] for x in fn}==({x['source_id'] for x in old}-strong)
assert {x['source_id'] for x in tp}==strong.union({x['source_id'] for x in a if x['direct_quote_candidate_gen_ids']})
assert sum(p4['phase04_audit_result_counts'].values())==638
assert collections.Counter(x['phase04_audit_result'] for x in a)==p4['phase04_audit_result_counts']
assert p4['provisional_tp_challenge_records']==78 and p4['provisional_miss_challenge_records']==569
assert p4['direct_pdf_quote_candidate_count']==sum(bool(x['direct_quote_candidate_gen_ids']) for x in a)
assert p4['independent_new_candidate_challenge_count']==sum(x['independent_better_candidate_found'] for x in a)
assert len(set(g['gen_id'] for g in G))==len(G)
gids=set(g['gen_id'] for g in G)
source={x['actual_filename']:(x['sha256'],pathlib.Path(x['original_path']).read_text(encoding='utf8').splitlines()) for x in lock['source_roles_ordered']}
checks=0
for ai,(x,ref) in enumerate(zip(a,r)):
 assert x['record_type']=='PHASE04_SOURCE_RECIPROCAL_AUDIT'
 assert x['source_statement_en']==ref['statement_en']; assert x['final_scoring_cell'] is None
 assert x['final_binary_decision_deferred_to_phase07'] and x['reference_immutable']
 assert len(x['pdf_evidence'])==len(ref['pdf_evidence'])
 for e,orig in zip(x['pdf_evidence'],ref['pdf_evidence']):
  assert e['physical_page']==orig['physical_page']
  assert e['quote_en']==orig.get('quote')
  assert e['source_pdf_sha256']==lock['pdf_sha256']
 for c in x['candidate_evidence']+x['independent_challenge_candidates']:
  assert c['file'] in source
  h,lines=source[c['file']]
  assert c['file_sha256']==h and sha('/mnt/data/'+c['file'])==h
  s,t=c['line_start'],c['line_end']; assert 1<=s<=t<=len(lines)
  assert norm(c['quote_en']) in norm('\n'.join(lines[s-1:t]))
  if c.get('gen_id') is not None: assert c['gen_id'] in gids
  checks+=1
 for pc in x['predicate_support_checks']:
  assert 0<=pc['best_token_coverage_diagnostic']<=1
  if pc.get('best_candidate_file'):
   fname=pc['best_candidate_file'];line=pc['best_candidate_line'];q=pc['best_candidate_quote_en']
   assert fname in source
   assert 1<=line<=len(source[fname][1])
   assert norm(q) in norm(source[fname][1][line-1]);checks+=1
files=('04_coverage_audit.jsonl','04_tp_evidence_audit.jsonl','04_fn_root_cause_audit.jsonl')
for f in files: assert sha(d/f)==p4['output_sha256'][f]
res={'record_type':'PHASE04_INDEPENDENT_VALIDATION','protocol_version':'10.6','phase':'04','status':'PASS',
 'r_count':638,'strong_preliminary_candidate_checked':69,'complete_provisional_miss_challenges':569,
 'coverage_audit_count':638,'tp_challenge_count':78,'fn_root_cause_count':569,
 'verified_generated_evidence_locations':checks,'source_digests_valid':True,
 'all_pdf_original_evidence_identical_to_frozen_r':True,
 'every_original_r_id_once':True,'no_binary_fp_fn_inferred_from_retrieval':True,
 'previous_phase_files_modified':False,
 'audit_files_sha256':{f:sha(d/f) for f in files}}
(d/'04_validation_results.json').write_text(json.dumps(res,indent=2,sort_keys=True)+'\n',encoding='utf8');print(json.dumps(res,indent=2))
