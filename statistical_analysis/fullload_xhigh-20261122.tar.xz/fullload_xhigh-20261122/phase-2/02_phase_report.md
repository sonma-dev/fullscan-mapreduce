# Phase 02 — Definitive Generated Occurrence and Semantic Class Inventory

**Status:** COMPLETE | **Protocol:** 10.6 | **Method:** fullload

All eight original Markdown sources were verified against the immutable Phase 01 lock and processed without altering the PDF, reference ledgers or Markdown bytes.

- Original Markdown lines indexed: **8330** (including structural, metadata, and blank lines).
- Eligible generated assertion occurrences (GO): **5046**.
- Consolidated generated proposition classes (GC): **4861**.
- Noneligible assertion fragments or excluded original lines: **10219**.
- Repeated semantic classes: **141**, cross-file repeated classes: **134**.
- Excess duplicate occurrences: **185** (within-file **15**; across-file **170**).
- Raw occurrence duplicate ratio: **3.666270%**.
- Near-equivalence candidates held apart for later review: **17**.

## Source coverage by file

| Original Markdown | Lines | GO |
|---|---:|---:|
| `01_screen_functions(4).md` | 864 | 724 |
| `02_api(4).md` | 1201 | 699 |
| `03_data(4).md` | 1034 | 718 |
| `04_batch_functions(5).md` | 1323 | 772 |
| `05_business_rules(4).md` | 1442 | 721 |
| `06_exception_handling(6).md` | 737 | 574 |
| `07_processing_flows(6).md` | 1143 | 730 |
| `08_architecture_decision(5).md` | 586 | 108 |

## Interpretation and constraints

All eligible GO records retain the literal source quote, exact line, table cell, full row, heading context, actual role filename and original SHA-256. Conditional and negative restrictions are included when they state definite behavior. Unapproved proposals, explicit TBDs, missing-contract questions, illustrative values, links and nondefinitive fragments are excluded and preserved for Phase 05 reassessment.

Conservative semantic clustering does not accept merely similar topical claims; incompatible numbers, named API paths, polarity, and explicit literals prevent automatic merging. `EXPECTED_REUSE` and `REDUNDANT_DUPLICATE` are separated in the duplicate ledger. Any candidate not proven equivalent remains distinct and may be revisited in the later required full-population validity audit. GO/GC are **not** TP/FP counts.

## Completion checks

- All source lines accounted for in original-line index: PASS.
- Every definitive generated occurrence assigned one effective class: PASS.
- Within + across-file duplicate excess equals GO minus GC: PASS.
- Source/hash lock and frozen reference invariants: PASS.
- Phase 03 not started. No PDF entailment, R coverage, N assertion, or precision/recall/F1 score is claimed.

## Deliverables

`02_generated_atoms_final.jsonl`, `02_generated_classes_final.jsonl`, `02_excluded_units.jsonl`, `02_duplicate_classes.jsonl`, `02_original_text_index.jsonl`, `02_similarity_review_candidates.jsonl`, `02_near_duplicate_review.jsonl`, `02_phase_summary.json`, and reproducible `extract_phase02.py`.
