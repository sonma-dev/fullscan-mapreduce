#!/usr/bin/env python3
"""Independent mechanical audit of Phase 02 generated GO/GC provenance and counts."""
import json,hashlib,collections,re
from pathlib import Path
ROOT=Path('/mnt/data/oriondesk_fullload_v10_6')
P=ROOT/'phase02'
lock=json.loads((ROOT/'phase01/01_reference_lock.json').read_text())
summary=json.loads((P/'02_phase_summary.json').read_text())
sha=lambda path:hashlib.sha256(Path(path).read_bytes()).hexdigest()
load=lambda f:[json.loads(line) for line in open(P/f,encoding='utf8') if line.strip()]
assert sha(ROOT/'phase01/01_reference_lock.json') == summary['phase01_lock_sha256']
assert lock['status']=='COMPLETE' and summary['status']=='COMPLETE'
assert sha('/mnt/data/OrionDesk_AI_Detailed_Design_Specification(4).pdf')==lock['pdf_sha256']
assert sha('/mnt/data/common_atomic_reqs(4).jsonl')==lock['frozen_r_sha256']
assert sha('/mnt/data/common_negative_controls(4).jsonl')==lock['frozen_n_sha256']
original={}
for role in lock['source_roles_ordered']:
    assert sha(role['original_path'])==role['sha256']
    original[role['actual_filename']]=(role['sha256'],Path(role['original_path']).read_text(encoding='utf8').splitlines())
GO=load('02_generated_atoms_final.jsonl');GC=load('02_generated_classes_final.jsonl')
EX=load('02_excluded_units.jsonl');DU=load('02_duplicate_classes.jsonl')
IDX=load('02_original_text_index.jsonl');SIM=load('02_similarity_review_candidates.jsonl')
assert len(GO)==summary['eligible_GO'] and len(GC)==summary['unique_GC']
assert len(EX)==summary['excluded_fragment_or_line_units'] and len(DU)==summary['repeated_class_count']
assert len(IDX)==sum(len(lines) for digest,lines in original.values())
assert len(set(r['gen_id'] for r in GO))==len(GO)
assert len(set(r['class_id'] for r in GC))==len(GC)
assert len(set(r['excluded_id'] for r in EX))==len(EX)
byid={g['gen_id']:g for g in GO};byclass={c['class_id']:c for c in GC};exid={x['excluded_id']:x for x in EX}
seen=collections.Counter()
for c in GC:
    assert c['occurrence_count']==len(c['member_gen_ids'])
    assert c['representative_gen_id']==c['member_gen_ids'][0]
    for k in c['member_gen_ids']:
        assert k in byid and byid[k]['class_id']==c['class_id'];seen[k]+=1
assert all(x==1 for x in seen.values()) and len(seen)==len(GO)
counts=collections.Counter(x['actual_filename'] for x in GO)
assert all(counts[x['actual_filename']]==x['eligible_occurrences'] for x in summary['source_files'])
idxby=collections.defaultdict(dict)
for r in IDX:
    assert r['line_accounted_for']
    fn=r['actual_filename'];li=r['line']
    assert fn in original and 1<=li<=len(original[fn][1])
    assert r['original_text_en']==original[fn][1][li-1]
    assert r['file_sha256']==original[fn][0]
    assert li not in idxby[fn]
    idxby[fn][li]=r
    for gid in r['eligible_gen_ids']:
        assert gid in byid and byid[gid]['line_start']==li and byid[gid]['actual_filename']==fn
    for eid in r['excluded_unit_ids']:
        assert eid in exid and exid[eid]['line_start']==li and exid[eid]['actual_filename']==fn
    if r['line_type'] not in ('blank','heading','table_header','table_separator','separator','metadata','code_fence'):
        assert r['eligible_gen_ids'] or r['excluded_unit_ids'],(fn,li)
assert all(len(idxby[fn])==len(lines) for fn,(_,lines) in original.items())

# Exact original quote is required, not an invented paraphrase. Check each
# split literal against its original source line, with only whitespace fold.
def normalize(x):return ' '.join(x.split())
for r in GO+EX:
    fn=r['actual_filename'];li=r['line_start'];raw=original[fn][1][li-1]
    assert r['original_file_sha256']==original[fn][0]
    quote=r['source_quote_en']
    assert normalize(quote) in normalize(raw),(r.get('gen_id',r.get('excluded_id')),fn,li,quote[:60])
    if r['record_type']=='GENERATED_OCCURRENCE':
        assert r['eligibility']=='DEFINITIVE' and r['line_start']==r['line_end']
        assert r['statement_en']

within=across=0
assert len(DU)==sum(c['occurrence_count']>1 for c in GC)
for c in DU:
    assert c['class_id'] in byclass
    assert c['occurrence_count']==len(c['members'])
    within+=c['within_file_excess'];across+=c['across_file_excess']
assert (within,across)==(summary['within_file_excess'],summary['across_file_excess'])
assert within+across==len(GO)-len(GC)
assert len(SIM)==summary['unmerged_near_similarity_pairs_flagged']
for cand in SIM:
    assert cand['candidate_a'] in byid and cand['candidate_b'] in byid
    assert byid[cand['candidate_a']]['class_id']!=byid[cand['candidate_b']]['class_id']
for fn,expected in summary['output_sha256'].items():assert sha(P/fn)==expected
print(json.dumps({'status':'PASS','source_files':len(original),'physical_lines_indexed':len(IDX),
                  'source_quotes_verified':len(GO)+len(EX),
                  'eligible_GO':len(GO),'unique_GC':len(GC),'duplicates_within':within,
                  'duplicates_across':across,'exclusion_units':len(EX),
                  'unmerged_similarity_pairs':len(SIM),'reference_unchanged':True},indent=2))
