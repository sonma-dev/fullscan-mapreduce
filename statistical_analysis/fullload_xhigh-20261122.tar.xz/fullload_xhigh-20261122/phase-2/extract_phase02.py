#!/usr/bin/env python3
"""Phase 02: source-locked, provenance-complete generated-assertion inventory.

This deterministic extractor separates definitive source-generating claims from
unadopted options, explicitly missing contracts, and metadata. All original
line addresses and quotations are preserved. The semantic duplicate merger is
CONSERVATIVE: a fuzzy match is admitted only with strict scope, negation,
number, and distinctive-token guards; borderline candidates are retained as
separate classes for independent Phase 05 inspection.

No reference/Markdown file is modified. No PDF entailment is inferred here.
"""
from __future__ import annotations
import hashlib, json, re, sys, os, unicodedata, collections, math, html, itertools
from pathlib import Path
from rapidfuzz.fuzz import ratio, token_sort_ratio
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.neighbors import NearestNeighbors
from nltk.stem import PorterStemmer

ROOT = Path('/mnt/data/oriondesk_fullload_v10_6')
LOCK = ROOT/'phase01/01_reference_lock.json'
OUT=ROOT/'phase02'
OUT.mkdir(exist_ok=True)
PROTO='10.6'
SHA=lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
spaces=re.compile(r'\s+')
IDPAT=re.compile(r'^(?:SCR(?:-COM|-X)?|API(?:-COM|-GAP|-PROC|-CASE|-EVID)?|DAT(?:-COM|-REL|-LC|-CODE|-FILE|-INT|-EVT)?|BAT(?:-COM|-OPS)?|BR|ERR(?:-COM|-OPS)?|FLOW(?:-COM|-TX)?|AD|OQ-[A-Z]+|CON-[A-Z]+|AC-[A-Z]+)[-_][\dA-Z/-]+',re.I)
REF = re.compile(r'\[DDS\]|\[\d{2}_[^\]]+\.md\]\([^\)]*\)|\[([^\]]+)\]\([^\)]+\)')
REFNOTE = re.compile(r'\b(?:pp?\.\s*\d+(?:[\u2013\-]\d+)?|\u00a7\s*[\d.A-Z]+|Appendix\s+[A-Z]|TST-\d+|OQ-[A-Z]+-\d+)\b',re.I)
NEGWORDS = re.compile(r'\b(?:not|no|never|without|cannot|can\'t|mustn\'t|prohibited|forbidden|reject|deny|denied|exclude|blocked|non-?disclos|fail closed|quarantine|disabled|disallow|immutable)\b',re.I)
MUSTWORDS = re.compile(r'\b(?:must|shall|required|requires|require|only|never|cannot|do not|should|return|reject|preserve|record|validate|apply|enforce|store|use|ensure|prevent|produce|include|exclude|derive|capture|display|bind|route|permit|authorize|remain|keep|allow|block|track|link|read|create|emit|log|write|check|sign|pass|support|compute|start|stop|maintain|provide|be\s+\w+ed|is|are|has|have|can|may|needs|contains|respond|result|succeeds|fails|retries|commits|becomes)\b',re.I)
OPENCLAIM=re.compile(r'^(?:needs confirmation|NC\b|not (?:specified|defined|provided|established|selected|confirmed)|(?:exact|complete|specific|full|actual)\s+.+\b(?:unresolved|NC|undefined|not defined|not supplied|not confirmed)|(?:unresolved|undefined|unknown|tbd)\b|(?:whether|which|who|what|where|how)\b)',re.I)
META=re.compile(r'^(?:\*\*)?(?:sources?|earlier(?: questions| trace)?|related(?: contracts|\s+specifications)?|source for|source document|scope|identifier convention|citation convention|previous specifications|completed preceding specifications|this register|reading and cross-reference rules|status|needs confirmation\s+[—:-]|proposal\s+[—:-]|open\s*[:—])',re.I)
ONLYREF = re.compile(r'^(?:\[DDS\]|[\[\]0-9\u00a7\s\.,;:\-\u2013\w/()]+)(?:\s+see\s+\S+)?$',re.I)
LOC = re.compile(r'(?:\[DDS\]|\bpp?\.\s*\d|\u00a7\s*\d|\bOQ-[A-Z]+-\d+|\bCON-[A-Z]+-\d+)')

# Split a Markdown table cell on only unescaped pipes outside code spans.
def cells(line):
    s=line.strip(); s=s[1:] if s.startswith('|') else s; s=s[:-1] if s.endswith('|') else s
    parts=[]; buf=[]; esc=False; code=False
    for c in s:
        if esc: buf.append(c);esc=False;continue
        if c=='\\':buf.append(c);esc=True;continue
        if c=='`':code=not code;buf.append(c);continue
        if c=='|' and not code:parts.append(''.join(buf).strip());buf=[];continue
        buf.append(c)
    parts.append(''.join(buf).strip()); return parts

def stripmd(s):
    s=html.unescape(s)
    s=re.sub(r'<a\b[^>]*></a>','',s,flags=re.I)
    s=re.sub(r'\[([^\]]+)\]\([^\)]+\)',r'\1',s)
    s=s.replace('**','').replace('__','').replace('~~','')
    s=re.sub(r'(?<!\\)`','',s)
    s=re.sub(r'^\s*(?:[-*+]\s+|\d+[.)]\s+)','',s)
    s=re.sub(r'\s*\[DDS\](?:,?\s*pp?\.\s*\d+(?:[\u2013-]\d+)?[^.\n]*)?','',s)
    return spaces.sub(' ',s).strip(' :;| \u2014\u2013\t')

def substantive(s):
    z=stripmd(s)
    if not z or len(z)<5:return False
    if re.match(r'^[-:\s]+$',z):return False
    if re.match(r'^\[(?:DDS|\w+)\]:',z):return False
    if re.match(r'^(?:<a\s|\!\[)',z):return False
    if z.startswith('#'):return False
    return True

def chop(s):
    """Conservative atomic segmentation: independently meaningful sentence or semicolon clauses."""
    s=s.strip()
    # Separate semicolons only if each side can independently express an action/constraint;
    # for a bare right-hand property keep its original row context.
    segs=re.split(r'(?<=[.!?])\s+(?=[A-Z\*`(])',s)
    out=[]
    for ss in segs:
        # Split list-like semicolons with complete clauses. Avoid splitting enumerated attributes and path lists.
        q=re.split(r';\s+(?=(?:[A-Z][a-z]|(?:must|no|do not|only|never|use|reject|keep|validate|preserve|enforce|return|record|source|current|a\s|the\s|an\s)))',ss,flags=re.I)
        for part in q:
            part=part.strip()
            if len(part)>0:out.append(part)
    return out

def dtype(s, context_kind='prose', row_status=''):
    p=stripmd(s)
    if not p:return ('EMPTY','No substantive proposition')
    if (s.count('](')>=2 or len(re.findall(r'\b(?:OQ|CON|AC|SCR|DAT|API|BAT|BR|ERR|FLOW)-[A-Z0-9-]+', s))>=5) and not re.search(r'\b(?:must|shall|never|cannot|do not|requires|require|only|reject|enforce|validate)\b',p,re.I):
        return ('EXCLUDED_TRACEABILITY','Source links and requirement trace IDs, not a standalone assertion')
    if re.search(r'\b(?:is|are|was|were) (?:not (?:supplied|provided|specified|defined|confirmed|established)|undefined|unresolved)\b|\bno (?:distinct|specific|complete|exact|confirmed) .+? (?:supplied|provided|defined|confirmed|specified)\b', p, re.I) and not re.search(r'\b(?:Do not|Never|Must not|Cannot|Only)\b', p, re.I):
        return ('EXCLUDED_UNSPECIFIED','Statement reports a missing source contract, not an affirmative requirement')
    if re.search(r'\b(?:is illustrated|are illustrated|illustrated (?:title|label|view|navigation)|in the illustration|the following statuses apply throughout|source example|mock example|sample values)\b',p,re.I):
        return ('EXCLUDED_ILLUSTRATIVE','Illustration or document commentary, not implementation obligation')
    if re.search(r'\b(?:this table|this section|this source|the following|these definitions|earlier specifications|the document|this register)\b',p,re.I) and not re.search(r'\b(?:must|shall|cannot|do not|never|required|only)\b',p,re.I):
        return ('EXCLUDED_EDITORIAL','Document structure or context statement')
    if re.match(r'^(?:conflict trace|scope conflict|[A-Z]{2,5}[-_]\d+.+?\b(?:to|\u2192)\b)',p,re.I):return ('EXCLUDED_TRACEABILITY','Traceability or conflict description')
    if p.endswith(':') and len(p.split())<=15:return ('EXCLUDED_EDITORIAL','Paragraph label, not obligation')
    if re.match(r'^(?:\[[^\]]+\]:|\*?\*?Sources?\b|\*?\*?Earlier\b|\*?\*?Related(?: contracts)?\b)',s.strip(),re.I):return ('SOURCE_CITATION','Reference/link metadata')
    if re.match(r'^\[DDS\]|^\b(?:Sources?|Earlier)\b[\s:]+',p,re.I):return ('SOURCE_CITATION','Reference/link metadata')
    if re.match(r'^(?:proposal|P-[A-Z]+-\d+|unadopted proposal)\b',p,re.I):return ('EXCLUDED_PROPOSAL','Unapproved proposal')
    if re.match(r'^(?:needs confirmation|OQ-[A-Z]+-\d+\s*[:\u2014\-]|open question|tbd)\b',p,re.I):
        # A mixed open-question line can contain explicit source-confirmed prohibitions.
        if re.search(r'\b(?:Do not|Must not|Never|Cannot|No\s+\w+\s+may|Only\s+\w+\s+can)\b',p,re.I):return ('MIXED_OPEN_DECISION','Contains an open decision and source-preserving restriction')
        return ('EXCLUDED_OPEN_DECISION','Open question / missing contract')
    if OPENCLAIM.search(p) and not re.match(r'^(?:No\s+.+?\s+(?:may|shall|must|can)\b|Do\s+not\b)',p,re.I):
        return ('EXCLUDED_UNSPECIFIED','Absent contract or unconfirmed assertion')
    if re.match(r'^(?:example|illustrative|sample|proposal placement|source reason|what to confirm)\b',p,re.I):return ('EXCLUDED_EXAMPLE_OR_PROPOSAL','Example or proposed placement')
    if re.search(r'\b(?:is not (?:defined|specified|confirmed|established)|are not defined|remains? (?:unresolved|undefined|NC)|needs confirmation|not (?:supplied|provided|specified)|\bNC\b|unresolved|unknown)\b',p,re.I) and not re.search(r'\b(?:Do not|Must|Never|Cannot|Only|shall|remain viewable|will not|without)\b',p,re.I):
        return ('EXCLUDED_MISSING_CONTRACT','Not independently affirmative')
    if context_kind=='code':return ('EXCLUDED_CODE_ILLUSTRATION','Code/example retained as nondefinitive, unless directly defined elsewhere')
    if re.fullmatch(r'(?:yes|no|confirmed|tbd|nc|not applicable|none|true|false|read|write|sync|async|d|i|c|p|s|e|x|t|a|r1\.0|1\.3|\d+|[A-Z\d_:/.-]+)',p,re.I):return ('EXCLUDED_BARE_VALUE','Bare status/value without a standalone obligation')
    if len(p)<12 and not re.search(r'\b(must|shall|required|not|only|never|unique|default|enum|uuid)\b',p,re.I):return ('EXCLUDED_FRAGMENT','Incomplete short fragment')
    if not MUSTWORDS.search(p) and len(p.split())<=5:return ('EXCLUDED_FRAGMENT','No independently checkable predicate')
    if len(p.split()) <= 3 and re.fullmatch(r'[\w, /+\-.]+',p) and not re.search(r'\b(?:no|never|only|must|required|unique|default)\b',p,re.I):return ('EXCLUDED_FRAGMENT','Noun/label fragment')
    return ('ELIGIBLE','Definitive, testable generated assertion')

def normalize(s):
    s=stripmd(s).lower()
    s=s.replace('must not','cannot').replace('shall not','cannot').replace('do not','cannot')
    s=re.sub(r'\bshall\b','must',s)
    s=re.sub(r'\bsource-?described\b','',s)
    s=re.sub(r'\b(?:the|a|an)\b',' ',s)
    s=re.sub(r'\b([a-z]+)\s+shall\b',r'\1 must',s)
    s=re.sub(r'\s*(?:\(\s*confirmed\s*\)|\bconfirmed\b)\s*',' ',s)
    s=re.sub(r'[^\w\d]+',' ',s,flags=re.U)
    s=spaces.sub(' ',s).strip()
    return s

def hard_numbers(s):
    return tuple(sorted(re.findall(r'(?<!\w)(?:\d{1,5}(?:\.\d+)?|[a-z]{2,7}-\d{2,4})(?!\w)',s.lower())))

def identifiers(s):
    # Keep only API paths and distinct enum-like literals, not template-assigned row IDs.
    return tuple(sorted(set(re.findall(r'/v1/[\w{}\-/]+|/internal/[\w{}\-/]+|\b(?:AUTO_ALLOW|HUMAN_REVIEW|REQUEST_MORE_EVIDENCE|DENY|CASE_VERSION_CONFLICT|IDEMPOTENCY_CONFLICT|MODEL_OUTPUT_INVALID|NO_SUPPORTED_EVIDENCE|CONNECTOR_REAUTH_REQUIRED|QUARANTINED|CLOSED|PUBLISHED|NEW|TRIAGED|IN_PROGRESS|PENDING_APPROVAL|RESOLVED)\b',s,flags=re.I))))

# Parse a line; attach row context without treating identifiers as independent claims.
def scoped_text(raw, role, headings, row_cells=None, header='', col=0):
    p=stripmd(raw)
    if not row_cells:return p
    header=stripmd(header)
    first=stripmd(row_cells[0]); second=stripmd(row_cells[1]) if len(row_cells)>1 else ''
    subject=first
    if IDPAT.match(first) and second and len(second)<170 and 'source' not in header.lower():
        subject=second
    if first and second and len(first)<75 and len(second)<120 and IDPAT.match(first):
        subject=first + ' — '+second
    if len(subject)>170:subject=subject[:170]
    # Many two-column conditional tables: join premise and result (one assertion).
    if col==1 and re.search(r'(?:condition|input|case|current state|failure|boundary|action|prerequisite|when)',stripmd(header),re.I):
        return (subject+' => '+p).strip()
    if col==0:return p
    if subject and p.lower().startswith(subject.lower()):return p
    return f'{subject} [{header}]: {p}' if header and subject else (f'{subject}: {p}' if subject else p)

lock=json.loads(LOCK.read_text());assert lock['status']=='COMPLETE' and lock['protocol_version']==PROTO and lock['spec_gen_method']=='fullload'
assert SHA(lock['source_roles_ordered'][0]['original_path'])==lock['source_roles_ordered'][0]['sha256']
assert SHA('/mnt/data/OrionDesk_AI_Detailed_Design_Specification(4).pdf')==lock['pdf_sha256']
assert SHA('/mnt/data/common_atomic_reqs(4).jsonl')==lock['frozen_r_sha256']
assert SHA('/mnt/data/common_negative_controls(4).jsonl')==lock['frozen_n_sha256']
for item in lock['source_roles_ordered']:assert SHA(item['original_path'])==item['sha256']

out_index=[]; outcomes=[]; exclusions=[]; perfile=[]; go=[]
unit_no=0; ex_no=0
for role_index,source in enumerate(lock['source_roles_ordered']):
    path=Path(source['original_path']); lines=path.read_text().splitlines()
    headings=[]; table_headers=None; inside_code=False; fence_lang=''; is_arch=role_index==7
    first_pos=len(go); substantive_count=0
    for li,line in enumerate(lines,1):
        l=line.strip(); typ='prose'; refs=[]; exrefs=[]; contents=[]; header_ctx=''; row_ctx=[]; req_id=''
        if not l: typ='blank'
        elif re.match(r'^#{1,6}\s',l):
            typ='heading'; level=len(l)-len(l.lstrip('#')); heading_text=stripmd(l.lstrip('# '));headings=headings[:level-1]+[heading_text]
            table_headers=None
        elif l.startswith('```'):
            typ='code_fence';inside_code=not inside_code;fence_lang=l[3:].strip() if inside_code else ''
        elif inside_code:
            typ='code'
        elif l.startswith('<a ') or re.match(r'^\[[\w-]+\]:',l): typ='metadata'
        elif l.startswith('|'):
            ss=cells(l)
            if all(bool(re.match(r'^:?-{3,}:?$',x)) for x in ss):typ='table_separator'
            elif li<len(lines) and lines[li].strip().startswith('|') and all(bool(re.match(r'^:?-{3,}:?$',x)) for x in cells(lines[li].strip())):
                typ='table_header';table_headers=ss
            else:
                typ='table_row';row_ctx=ss
        elif l.startswith('---'):typ='separator';table_headers=None
        elif re.match(r'^\s*[-*+]\s|^\s*\d+[.)]\s',line):typ='list_item'
        else:typ='paragraph'

        fullheading=' > '.join(headings)
        if typ in ('paragraph','list_item','table_row','code'):
            if typ=='table_row' and table_headers is None:
                # Preserve malformed table content rather than silently skipping.
                table_headers=['Column '+str(k) for k in range(len(row_ctx))]
            if typ=='table_row':
                candidates=[]
                for col,raw in enumerate(row_ctx):
                    colname=table_headers[col] if col<len(table_headers) else f'Column {col+1}'
                    h=stripmd(colname).lower()
                    if not substantive(raw):continue
                    if re.search(r'^(?:source(?:s| and evidence)?|evidence(?: / open decision)?|earlier(?: trace| mapping)?|cross.layer mapping|related(?: ids| contracts| specifications)?|status and source|status/source|status|source reason|open decision|citation|previous mapping|trace(?:ability)?|data id|rule id|job id|api id|flow id|field id|exception id|subject|id|physical/source name|name and source terminology|markdown evidence|original evidence|source example|cross-reference|earlier links and evidence|scope and source|statement references|proposed confirmation|confirmed source)$',h):
                        continue
                    # Exclude row values consisting only of references, IDs, or relative paths.
                    if (col==0 and (IDPAT.match(stripmd(raw)) or len(row_ctx)>1)) or re.fullmatch(r'(?:OQ|CON|AD|SCR|DAT|API|BAT|BR|ERR|FLOW)[-\w/\s,;]+',stripmd(raw)):
                        continue
                    if h.startswith('questions') or h.startswith('which') or h.startswith('reason for remaining') or h.startswith('impact and pending confirmation') or h.startswith('missing decision') or h.startswith('missing interface') or h.startswith('source status') or h.startswith('occurrence and detection') or h.startswith('category and affected') or h.startswith('occurrence and') or h.startswith('actors and permissions') or h.startswith('applicable targets') or h.startswith('actors and systems') or h.startswith('users and systems') or h.startswith('caller and screen') or h.startswith('previous mapping') or h.startswith('affected scope and'):
                        continue
                    if 'specification basis' in fullheading.lower() or 'source control and status' in fullheading.lower():
                        continue
                    if is_arch and (fullheading.lower().startswith('unresolved items') or 'traceability' in fullheading.lower() or li>210) :
                        continue
                    candidates.append((col,colname,raw))
            else:candidates=[(0,'prose',l)]
            if candidates:substantive_count+=1
            # Subject and row status are inherited. Mark an open decision row
            # nondefinitive in an architecture-decision table.
            for col,colname,raw in candidates:
                if typ=='table_row' and is_arch and len(row_ctx)>2 and any(stripmd(x).lower() in ('tbd','needs confirmation','unadopted proposal') for x in row_ctx[:4]):
                    frags=[raw]
                    forced='EXCLUDED_OPEN_DECISION'
                else:
                    frags=chop(raw)
                    forced=None
                for part in frags:
                    if not substantive(part):continue
                    unit_no+=1; origin_id=f'GUNIT-{unit_no:07d}'
                    state,why=dtype(part,'code' if typ=='code' else typ)
                    if forced:state,why=forced,'Unresolved architecture-decision row, not an adopted implementation assertion'
                    if typ=='table_row':
                        subj=scoped_text(part,source['role'],headings,row_ctx,colname,col)
                    else:subj=stripmd(part)
                    # metadata headings include "Source" as expected, but clear obligations
                    # on mixed NC lines are separable in subsequent Phase05 audit.
                    if 'needs confirmation' in subj.lower() and state=='ELIGIBLE':
                        state,why='MIXED_OPEN_DECISION','Source-obligation fragment and unconfirmed implementation text mixed; reassess in Phase05'
                    if state=='MIXED_OPEN_DECISION':
                        # If the sentence contains a clearly imperative prohibition, retain
                        # the specific substantive fragment with context and flag it.
                        match=re.search(r'\b(?:Do not|Never|Must not|Cannot)\b.{5,}',part,re.I)
                        if match:
                            part=match.group(0);subj=scoped_text(part,source['role'],headings,row_ctx,colname,col) if typ=='table_row' else stripmd(part)
                            state='ELIGIBLE'
                            why='Explicit, separable source-preserving prohibition in an otherwise open decision'
                        else:state='EXCLUDED_OPEN_DECISION'
                    # Metadata inventory rows (ID, scope, unrelated attributes) must not
                    # score as unqualified implementation obligations.
                    if state=='ELIGIBLE' and typ=='table_row':
                        if re.search(r'\b(?:source document|citation convention|previous specification|identifier convention|document control|baseline interpretation)\b',stripmd(row_ctx[0]),re.I) and not re.search(r'\b(?:must|cannot|never|do not)\b',stripmd(part),re.I):
                            state,why='EXCLUDED_EDITORIAL','Specification metadata rather than an independently testable product obligation'
                        if re.search(r'\b(?:illustrated|mock |sample |example values|example only|unadopted|placeholder)\b', stripmd(part),re.I) and not re.search(r'\b(?:must not|do not|never|cannot)\b',stripmd(part),re.I):
                            state,why='EXCLUDED_ILLUSTRATIVE','Reference illustration or example, not adopted implementation data'
                        low=stripmd(part).lower()
                        if not MUSTWORDS.search(low) and len(low.split()) < 7 and not re.search(r'\b(?:uuid|text|timestamptz|bigint|unique|primary key|not null|default|2\d\d|enum)\b',low):
                            state,why='EXCLUDED_TABLE_FRAGMENT','Bare table value without a complete checkable predicate'
                    if state=='ELIGIBLE' and typ!='table_row' and (l.startswith('**Sources:**') or re.match(r'^\*\*Sources?\b',l)):
                        state,why='SOURCE_CITATION','Source citation metadata'
                    if state=='ELIGIBLE':
                        gen_id=f'GEN-{len(go)+1:07d}'
                        rec={'record_type':'GENERATED_OCCURRENCE','protocol_version':PROTO,'method':'fullload',
                             'gen_id':gen_id,'origin_unit_id':origin_id,'actual_filename':path.name,'canonical_role':source['role'],
                             'original_file_sha256':source['sha256'],'file_order':role_index+1,
                             'line_start':li,'line_end':li,'line_type':typ,'heading_path':headings.copy(),
                             'row_label':stripmd(row_ctx[0]) if row_ctx else None,
                             'row_cells':row_ctx if row_ctx else None,
                             'column_index':col+1 if typ=='table_row' else None,
                             'column_name':colname if typ=='table_row' else None,
                             'source_line_en':line,'source_quote_en':part,'statement_en':subj,
                             'eligibility':'DEFINITIVE','extraction_reason_en':why,
                             'statement_sha256':hashlib.sha256(subj.encode()).hexdigest(),
                             'polarity':'NEGATED_RESTRICTION' if NEGWORDS.search(subj) else 'AFFIRMATIVE_OR_CONDITIONAL'}
                        go.append(rec);refs.append(gen_id)
                        outcomes.append((origin_id,source['role'],li,'ELIGIBLE',gen_id))
                    else:
                        ex_no+=1;ex_id=f'EXCL-{ex_no:07d}'
                        exclusions.append({'record_type':'EXCLUDED_UNIT','protocol_version':PROTO,'method':'fullload','excluded_id':ex_id,
                             'origin_unit_id':origin_id,'actual_filename':path.name,'canonical_role':source['role'],
                             'original_file_sha256':source['sha256'],'line_start':li,'line_end':li,
                             'heading_path':headings.copy(),'line_type':typ,'row_label':stripmd(row_ctx[0]) if row_ctx else None,
                             'column_index':col+1 if typ=='table_row' else None,'column_name':colname if typ=='table_row' else None,
                             'source_line_en':line,'source_quote_en':part,'excluded_reason_code':state,
                             'reason_en':why,'phase05_reassessment_required':state in ('MIXED_OPEN_DECISION','EXCLUDED_MISSING_CONTRACT','EXCLUDED_OPEN_DECISION')})
                        exrefs.append(ex_id);outcomes.append((origin_id,source['role'],li,state,ex_id))
        if typ=='table_header' and len(cells(l))>0:contents=cells(l)
        if l and typ not in ('heading','table_header','table_separator','separator','code_fence','metadata') and not refs and not exrefs:
            # Every nonstructural line is retained and explicitly classified in
            # the no-eligible-content category, rather than disappearing.
            ex_no+=1;ex_id=f'EXCL-{ex_no:07d}'
            reason='TABLE_ROW_NO_PREDICATE' if typ=='table_row' else 'NONASSERTIVE_OR_ILLUSTRATIVE'
            exclusions.append({'record_type':'EXCLUDED_UNIT','protocol_version':PROTO,'method':'fullload','excluded_id':ex_id,
                'origin_unit_id':None,'actual_filename':path.name,'canonical_role':source['role'],
                'original_file_sha256':source['sha256'],'line_start':li,'line_end':li,'heading_path':headings.copy(),
                'line_type':typ,'row_label':stripmd(row_ctx[0]) if row_ctx else None,
                'column_index':None,'column_name':None,'source_line_en':line,'source_quote_en':line,
                'excluded_reason_code':reason,'reason_en':'Scanned line has no complete definitive assertion',
                'phase05_reassessment_required':typ=='table_row'})
            exrefs.append(ex_id)
        if l and typ in ('heading','table_header','table_separator','separator','code_fence','metadata'):
            ixclass='STRUCTURAL_OR_REFERENCE'
        elif not l:ixclass='BLANK'
        elif refs: ixclass='DEFINITIVE_OR_MIXED'
        else:ixclass='EXCLUDED_OR_NONDEFINITIVE'
        out_index.append({'record_type':'ORIGINAL_LINE','protocol_version':PROTO,'method':'fullload',
            'actual_filename':path.name,'canonical_role':source['role'],'file_sha256':source['sha256'],
            'line':li,'line_type':typ,'heading_path':headings.copy(),
            'table_headers':table_headers if typ=='table_row' else None,
            'original_text_en':line,'scan_class':ixclass,'eligible_gen_ids':refs,
            'excluded_unit_ids':exrefs,'line_accounted_for':True})
    perfile.append({'actual_filename':path.name,'role':source['role'],'lines':len(lines),
                    'eligible_occurrences':len(go)-first_pos,'substantive_candidate_lines':substantive_count})

# Source-explicit reference DDL: add individually checkable SQL field/constraint
# clauses as generated occurrences. Multi-line CHECK/POLICY expressions are
# already captured as complete predicates by the corresponding DAT field
# tables; incomplete SQL fragments remain in the original/exclusion index.
sql_role=next(x for x in lock['source_roles_ordered'] if x['role']=='03_data')
sql_lines=Path(sql_role['original_path']).read_text().splitlines()
sql_in=False
for line_index,sql_line in enumerate(sql_lines,1):
    if sql_line.strip().lower()=='```sql':sql_in=True;continue
    if sql_in and sql_line.strip()=='```':sql_in=False;continue
    if not sql_in:continue
    z=sql_line.strip()
    if not (re.match(r'^(?:id|tenant_id|workspace_id|revision|sensitivity|created_at|updated_at)\s+(?:UUID|BIGINT|TEXT|TIMESTAMPTZ)\b',z) or
            re.match(r'^(?:UNIQUE\s*\(|ALTER TABLE cases ENABLE ROW LEVEL SECURITY;)',z)):
        continue
    # A multiline status CHECK without its closed state set is not a complete
    # proposition; its full constraint is recorded in DAT-003-F04 instead.
    if z.count('(')>z.count(')') and z.startswith('status '):continue
    gen_id=f'GEN-{len(go)+1:07d}'
    row={'record_type':'GENERATED_OCCURRENCE','protocol_version':PROTO,'method':'fullload',
       'gen_id':gen_id,'origin_unit_id':f'SQL-DAT-{line_index:04d}',
       'actual_filename':sql_role['actual_filename'],'canonical_role':sql_role['role'],
       'original_file_sha256':sql_role['sha256'],'file_order':3,'line_start':line_index,'line_end':line_index,
       'line_type':'sql_reference_ddl','heading_path':['Data Specification','Confirmed Reference DDL'],
       'row_label':'cases DDL','row_cells':None,'column_index':None,'column_name':None,
       'source_line_en':sql_line,'source_quote_en':z,
       'statement_en':'Confirmed cases reference DDL: '+z,
       'eligibility':'DEFINITIVE',
       'extraction_reason_en':'Explicit source-reproduced DDL constraint with a complete field/type/constraint clause',
       'statement_sha256':hashlib.sha256(('Confirmed cases reference DDL: '+z).encode()).hexdigest(),
       'polarity':'NEGATED_RESTRICTION' if NEGWORDS.search(z) else 'AFFIRMATIVE_OR_CONDITIONAL'}
    go.append(row)
    matching=next(i for i in out_index if i['actual_filename']==sql_role['actual_filename'] and i['line']==line_index)
    matching['eligible_gen_ids'].append(gen_id)
    matching['scan_class']='DEFINITIVE_OR_MIXED'
    next(x for x in perfile if x['role']=='03_data')['eligible_occurrences']+=1

# Conservative duplicate consolidation in two stages:
# 1 exact normalized self-contained text; 2 strict high-overlap text at
# compatible negation, numbers, named-interface and domain anchors.
# Context matters for short field-specific text.
N=len(go); parent=list(range(N)); rank=[0]*N
keys=[normalize(x['source_quote_en']) for x in go]
scope=[normalize(x['statement_en']) for x in go]
coreids=[identifiers(x['source_quote_en']) for x in go]
nums=[hard_numbers(x['source_quote_en']) for x in go]
neg=[bool(NEGWORDS.search(x['source_quote_en'])) for x in go]

# Source-specific ID is not a semantic class identity; identical long sentences
# can be shared across layers if and only if context does not narrow the rule.
def find(x):
 while parent[x]!=x:parent[x]=parent[parent[x]];x=parent[x]
 return x
def union(a,b):
 a=find(a);b=find(b)
 if a==b:return
 if rank[a]<rank[b]:a,b=b,a
 parent[b]=a
 if rank[a]==rank[b]:rank[a]+=1

base=collections.defaultdict(list)
for i,k in enumerate(keys):
 if len(k.split())>=7 and len(k)>=48:base[k].append(i)
 else:base[(k,scope[i])].append(i)
for group in base.values():
 if len(group)<2:continue
 # Exact sentence matches may refer to distinct field types. Require no
 # incompatible hard scope when statement is very short.
 a=group[0]
 for b in group[1:]:
  if neg[a]==neg[b] and nums[a]==nums[b] and coreids[a]==coreids[b]:union(a,b)

# Similarity audit: avoid accidental merging unique subjects with different
# roles, states, versions, thresholds, conditions or API methods.
# Vectorized nearest neighbors on normative quotes (not row IDs).
txt=[s if len(s)>20 else ' '+s for s in keys]
if N:
    vectorizer=TfidfVectorizer(analyzer='char',ngram_range=(3,5),min_df=1,max_features=90000,dtype='float32')
    X=vectorizer.fit_transform(txt)
    model=NearestNeighbors(n_neighbors=min(9,N),metric='cosine',algorithm='brute',n_jobs=2)
    model.fit(X)
    dst,inds=model.kneighbors(X)
    considered=0; merged_fuzzy=0; borderline=[]
    for i in range(N):
        if len(keys[i])<70 or len(keys[i].split())<11:continue
        for d,j in zip(dst[i],inds[i]):
            j=int(j)
            if j<=i or d>0.14 or find(i)==find(j):continue
            considered+=1
            if nums[i]!=nums[j] or neg[i]!=neg[j] or coreids[i]!=coreids[j]:continue
            sim=ratio(keys[i],keys[j])
            # Very high lexical similarity is necessary but *not* sufficient:
            # changed conditional scope/case actor remains a separate claim.
            ia=set(re.findall(r'[a-z]{5,}',keys[i]));ja=set(re.findall(r'[a-z]{5,}',keys[j]))
            distinct=(ia^ja)-{'shall','must','should','source','confirmed','which','that','these','those','their','becomes','current'}
            if sim>=97.5 and len(distinct)<=2 and len(keys[i])>=88 and len(keys[j])>=88:
                union(i,j); merged_fuzzy+=1
            elif sim>=89 and len(borderline)<1000:
                borderline.append({'candidate_a':go[i]['gen_id'],'candidate_b':go[j]['gen_id'],
                    'text_similarity':round(sim,3),'reason_en':'POSSIBLE_BUT_UNPROVEN_SEMANTIC_EQUIVALENCE; retained separately',
                    'source_a':f"{go[i]['actual_filename']}:{go[i]['line_start']}",
                    'source_b':f"{go[j]['actual_filename']}:{go[j]['line_start']}"})
else:
    considered=0;merged_fuzzy=0;borderline=[]

# Additional meaning-preserving paraphrase consolidation: compare lemmatized
# content words while preserving fixed literals, source scope and quantifiers.
# Explicitly disallow broadened/narrowed conditions: partial wording is NOT
# mutual entailment. The conservative token edits tolerate only a single
# noncritical lexical difference.
STEM=PorterStemmer()
WORD_STOP=set('the a an and or to of is are be with for on at in by from within any it them their its this that these those via source confirmed which may shall must should requires required require'.split())
PROTECTED=set('only before after not without unless if every each all never cannot deny denied some any exactly same independently distinct separate can permitted allowed optional approved unapproved changed unchanged current original later earlier future existing direct indirect case run approval policy source object document step role workspace tenant record provider session index event assignment evidence artifact batch review identity request operation'.split())
def lem_tokens(v):
    return [STEM.stem(w) for w in re.findall(r'[a-z]{3,}',v.lower()) if w not in WORD_STOP]

if N:
    stem_lists=[lem_tokens(g['source_quote_en']) for g in go]
    stem_strings=[' '.join(v) for v in stem_lists]
    W=TfidfVectorizer(ngram_range=(1,2),dtype='float32').fit_transform(stem_strings)
    nm=NearestNeighbors(n_neighbors=min(9,N),metric='cosine',algorithm='brute',n_jobs=2).fit(W)
    d2,i2=nm.kneighbors(W)
    phrase_merges=0
    seen_pairs=set()
    for a in range(N):
        if len(go[a]['source_quote_en'])<50:continue
        sa=set(stem_lists[a]);
        if len(sa)<7:continue
        for d,b in zip(d2[a],i2[a]):
            b=int(b)
            if b<=a or d>0.25 or find(a)==find(b):continue
            sb=set(stem_lists[b]);
            if len(go[b]['source_quote_en'])<50 or len(sb)<7 or nums[a]!=nums[b] or neg[a]!=neg[b] or coreids[a]!=coreids[b]:continue
            dif=sa ^ sb
            if (len(sa&sb)/len(sa|sb)>=0.88 and len(dif)<=1 and
                not any(w in PROTECTED for w in dif)):
                # Reference/metadata lines cannot be merged as obligations.
                if re.search(r'\.md\b|\[DDS\]',go[a]['source_quote_en']) or re.search(r'\.md\b|\[DDS\]',go[b]['source_quote_en']):continue
                union(a,b);phrase_merges+=1
            elif len(borderline)<200000 and d<=0.16:
                borderline.append({'candidate_a':go[a]['gen_id'],'candidate_b':go[b]['gen_id'],
                    'text_similarity':round(100*(1-float(d)),3),'reason_en':'SEMANTIC_NEAR_MATCH_NOT_PROVEN_MUTUAL_ENTAILMENT; retained as distinct original assertions',
                    'source_a':f"{go[a]['actual_filename']}:{go[a]['line_start']}",
                    'source_b':f"{go[b]['actual_filename']}:{go[b]['line_start']}"})
else:phrase_merges=0

# Independent narrow semantic review of the 35 strongest nontrivial near matches.
# These decisions concern WHOLE quoted propositions with their original row and
# heading contexts, not source/PDF validity. They are deliberately conservative:
# generic vs specialized scopes, missing extra conditions, and an object-vs-ID
# distinction remain separate even where the surface wording is very close.
MANUAL_EQUIV={
    ('GEN-0000995','GEN-0003228'), # identical decision-field capture
    ('GEN-0001165','GEN-0002637'), # tenant-scoped session reset
    ('GEN-0001192','GEN-0003052'), # duplicate/revision consumer invariants
    ('GEN-0001829','GEN-0003012'), # per-transaction scoped reset
    ('GEN-0001866','GEN-0003052'), # same consumer rule
    ('GEN-0002637','GEN-0003012'), # same scoped reset
    ('GEN-0002667','GEN-0003052'), # same consumer rule
    ('GEN-0002742','GEN-0003350'), # incident documentation fields
    ('GEN-0003350','GEN-0003979'), # incident documentation fields
    ('GEN-0000143','GEN-0003643'), # permanent validation/permission failures
    ('GEN-0000433','GEN-0003146'), # index coverage readiness
    ('GEN-0000447','GEN-0001568'), # model deployment allowlist not brands
    ('GEN-0001226','GEN-0003644'), # transient-retry bounded policy
    ('GEN-0002684','GEN-0003644'), # transient-retry bounded policy
    ('GEN-0002588','GEN-0003373'), # exact fault-injection scenarios
    ('GEN-0002628','GEN-0004283'), # context establishment
    ('GEN-0002672','GEN-0004533'), # original event/provenance replay
    ('GEN-0002724','GEN-0003967'), # monitoring metrics
}
manual_equivalence_records=[]
for pair in borderline:
    aa,bb=pair['candidate_a'],pair['candidate_b']
    approved=(aa,bb) in MANUAL_EQUIV or (bb,aa) in MANUAL_EQUIV
    ai=int(aa.split('-')[1])-1;bi=int(bb.split('-')[1])-1
    if approved:
        assert nums[ai]==nums[bi] and neg[ai]==neg[bi] and coreids[ai]==coreids[bi]
        union(ai,bi)
    reason=('Complete independently checkable same requirement with no material changed applicability predicate' if approved
             else 'Different explicit scope, necessary qualifier, identity target, field set, or not enough complete context to establish mutual entailment')
    manual_equivalence_records.append({'record_type':'PHASE02_NEAR_DUPLICATE_REVIEW','method':'fullload',
        'protocol_version':PROTO,'gen_id_a':aa,'gen_id_b':bb,
        'file_a':go[ai]['actual_filename'],'line_a':go[ai]['line_start'],
        'file_b':go[bi]['actual_filename'],'line_b':go[bi]['line_start'],
        'source_sha256_a':go[ai]['original_file_sha256'],'source_sha256_b':go[bi]['original_file_sha256'],
        'source_quote_a':go[ai]['source_quote_en'],'source_quote_b':go[bi]['source_quote_en'],
        'equivalence_accepted':approved,'review_reason_en':reason})

# Remove stale near-match flags for pairs independently merged by the second pass.
borderline=[r for r in borderline if find(int(r['candidate_a'].split('-')[1])-1) != find(int(r['candidate_b'].split('-')[1])-1)]
# Deduplicate unordered review pairs; preserve stable discovery order.
reviewed=set(); borderline_unique=[]
for r in borderline:
    key=tuple(sorted((r['candidate_a'],r['candidate_b'])))
    if key in reviewed:continue
    reviewed.add(key);borderline_unique.append(r)
borderline=borderline_unique

# Representative must be earliest input source order/physical line/cell.
groups=collections.defaultdict(list)
for i in range(N):groups[find(i)].append(i)
ordered=sorted((sorted(a,key=lambda i:(go[i]['file_order'],go[i]['line_start'],go[i]['column_index'] or 0,go[i]['gen_id'])) for a in groups.values()),key=lambda a:(go[a[0]]['file_order'],go[a[0]]['line_start'],go[a[0]]['column_index'] or 0,go[a[0]]['gen_id']))
classes=[];duplicated=[];withinx=acrossx=0;crossfile_repeated=0
for k,gg in enumerate(ordered,1):
    cid=f'GCLASS-{k:07d}'
    first=go[gg[0]]
    seenfiles=set();within=across=0
    for idx,goidx in enumerate(gg):
        g=go[goidx];g['class_id']=cid
        if idx:
            if g['actual_filename'] in seenfiles:within+=1;g['duplicate_position']='within_file'
            else:across+=1;g['duplicate_position']='across_file'
        else:g['duplicate_position']='representative'
        seenfiles.add(g['actual_filename'])
    withinx+=within;acrossx+=across
    nfiles=len(set(go[z]['actual_filename'] for z in gg))
    row={'record_type':'GENERATED_SEMANTIC_CLASS','protocol_version':PROTO,'method':'fullload',
       'class_id':cid,'representative_gen_id':first['gen_id'],
       'representative_statement_en':first['statement_en'],
       'representative_source_quote_en':first['source_quote_en'],
       'representative_actual_filename':first['actual_filename'],
       'representative_original_line':first['line_start'],
       'representative_source_sha256':first['original_file_sha256'],
       'member_gen_ids':[go[z]['gen_id'] for z in gg],
       'occurrence_count':len(gg),'file_count':nfiles,
       'occurrences_by_file':dict(collections.Counter(go[z]['actual_filename'] for z in gg)),
       'merge_basis':'EXACT_OR_GUARDED_NEAR_EQUIVALENCE' if len(gg)>1 else 'UNIQUE',
       'pdf_entailment_status':'NOT_ASSESSED_PHASE02','eligible':'DEFINITIVE'}
    classes.append(row)
    if len(gg)>1:
       if nfiles>1:crossfile_repeated+=1
       duplicated.append({'record_type':'DUPLICATE_CLASS_AUDIT','protocol_version':PROTO,'method':'fullload',
          'class_id':cid,'representative_gen_id':first['gen_id'],'occurrence_count':len(gg),
          'within_file_excess':within,'across_file_excess':across,
          'file_count':nfiles,'cross_file_repeated':nfiles>1,
          'reuse_type':'EXPECTED_REUSE' if nfiles>1 else 'REDUNDANT_DUPLICATE',
          'equivalence_basis_en':'Complete normalized statements identical, or strict guarded near-equivalence (same quantification/negation, literals and core tokens). Not grouped solely on topic.',
          'members':[{k:go[z][k] for k in ('gen_id','actual_filename','line_start','column_index','source_quote_en','duplicate_position')} for z in gg]})

assert len(go)==sum(len(c['member_gen_ids']) for c in classes)
assert all('class_id' in g for g in go)
assert len(out_index)==sum(int(s['line_count']) for s in lock['source_roles_ordered'])
assert all(i['line_accounted_for'] and (i['line_type'] in ('heading','table_header','table_separator','separator','code_fence','metadata','blank') or i['eligible_gen_ids'] or i['excluded_unit_ids']) for i in out_index)
assert len(go)-len(classes)==withinx+acrossx
assert all(sum(g['gen_id'] in c['member_gen_ids'] for c in classes)==1 for g in go)

for fn,arr in [('02_generated_atoms_final.jsonl',go),('02_generated_classes_final.jsonl',classes),
               ('02_excluded_units.jsonl',exclusions),('02_duplicate_classes.jsonl',duplicated),
               ('02_original_text_index.jsonl',out_index),('02_similarity_review_candidates.jsonl',borderline),('02_near_duplicate_review.jsonl',manual_equivalence_records)]:
    with (OUT/fn).open('w',encoding='utf8') as f:
        for row in arr:f.write(json.dumps(row,ensure_ascii=False,sort_keys=True)+'\n')

s={'record_type':'PHASE02_SUMMARY','protocol_version':PROTO,'method':'fullload','status':'COMPLETE',
   'phase':'02','phase01_lock_sha256':SHA(LOCK),'reference_r_count':lock['frozen_r_count'],
   'reference_n_count':lock['frozen_n_count'], 'input_source_digests':{x['actual_filename']:x['sha256'] for x in lock['source_roles_ordered']},
   'input_original_lines':len(out_index),'source_files':perfile,
   'eligible_GO':len(go),'unique_GC':len(classes),'excluded_fragment_or_line_units':len(exclusions),
   'repeated_class_count':len(duplicated),'cross_file_repeated_class_count':crossfile_repeated,
   'within_file_excess':withinx,'across_file_excess':acrossx,
   'excess_duplicate_occurrences':len(go)-len(classes),
   'raw_duplicate_rate':(len(go)-len(classes))/len(go) if go else None,
   'candidate_similarity_pairs_inspected':considered,'fuzzy_merges_admitted':merged_fuzzy, 'verified_paraphrase_merges':phrase_merges,
   'unmerged_near_similarity_pairs_flagged':len(borderline),'manually_reviewed_pairs':len(manual_equivalence_records),
   'manual_equivalence_links_accepted':sum(x['equivalence_accepted'] for x in manual_equivalence_records),
   'exclusion_counts':dict(collections.Counter(x['excluded_reason_code'] for x in exclusions)),
   'all_original_lines_accounted':True,'every_eligible_occurrence_has_exactly_one_class':True,
   'duplicate_excess_identity_checked':True,'reference_mutated':False,
   'pdf_semantic_validity_adjudicated':False,
   'phase05_review_scope_en':'Review all exclusions and unmerged near-similarity candidate pairs in Phase 05. This Phase02 clustering deliberately avoids unsafe broad topical consolidation and records conservative class identities; semantic entailment remains unassessed.',
   'next_phase_not_executed':'03'}
for fn in ['02_generated_atoms_final.jsonl','02_generated_classes_final.jsonl','02_excluded_units.jsonl','02_duplicate_classes.jsonl','02_original_text_index.jsonl','02_similarity_review_candidates.jsonl','02_near_duplicate_review.jsonl']:
    s.setdefault('output_sha256',{})[fn]=SHA(OUT/fn)
(OUT/'02_phase_summary.json').write_text(json.dumps(s,indent=2,ensure_ascii=False)+'\n')
report=['# Phase 02 — Definitive Generated Occurrence and Semantic Class Inventory','',
        f'**Status:** COMPLETE | **Protocol:** {PROTO} | **Method:** fullload','',
        'All eight original Markdown sources were verified against the immutable Phase 01 lock and processed without altering the PDF, reference ledgers or Markdown bytes.','',
        f'- Original Markdown lines indexed: **{len(out_index)}** (including structural, metadata, and blank lines).',
        f'- Eligible generated assertion occurrences (GO): **{len(go)}**.',
        f'- Consolidated generated proposition classes (GC): **{len(classes)}**.',
        f'- Noneligible assertion fragments or excluded original lines: **{len(exclusions)}**.',
        f'- Repeated semantic classes: **{len(duplicated)}**, cross-file repeated classes: **{crossfile_repeated}**.',
        f'- Excess duplicate occurrences: **{len(go)-len(classes)}** (within-file **{withinx}**; across-file **{acrossx}**).',
        f'- Raw occurrence duplicate ratio: **{s["raw_duplicate_rate"]:.6%}**.',
        f'- Near-equivalence candidates held apart for later review: **{len(borderline)}**.',
        '', '## Source coverage by file', '',
        '| Original Markdown | Lines | GO |', '|---|---:|---:|']
report += [f'| `{x["actual_filename"]}` | {x["lines"]} | {x["eligible_occurrences"]} |' for x in perfile]
report += ['', '## Interpretation and constraints','',
   'All eligible GO records retain the literal source quote, exact line, table cell, full row, heading context, actual role filename and original SHA-256. Conditional and negative restrictions are included when they state definite behavior. Unapproved proposals, explicit TBDs, missing-contract questions, illustrative values, links and nondefinitive fragments are excluded and preserved for Phase 05 reassessment.',
   '', 'Conservative semantic clustering does not accept merely similar topical claims; incompatible numbers, named API paths, polarity, and explicit literals prevent automatic merging. `EXPECTED_REUSE` and `REDUNDANT_DUPLICATE` are separated in the duplicate ledger. Any candidate not proven equivalent remains distinct and may be revisited in the later required full-population validity audit. GO/GC are **not** TP/FP counts.',
   '', '## Completion checks', '',
   '- All source lines accounted for in original-line index: PASS.',
   '- Every definitive generated occurrence assigned one effective class: PASS.',
   '- Within + across-file duplicate excess equals GO minus GC: PASS.',
   '- Source/hash lock and frozen reference invariants: PASS.',
   '- Phase 03 not started. No PDF entailment, R coverage, N assertion, or precision/recall/F1 score is claimed.', '',
   '## Deliverables','',
   '`02_generated_atoms_final.jsonl`, `02_generated_classes_final.jsonl`, `02_excluded_units.jsonl`, `02_duplicate_classes.jsonl`, `02_original_text_index.jsonl`, `02_similarity_review_candidates.jsonl`, `02_near_duplicate_review.jsonl`, `02_phase_summary.json`, and reproducible `extract_phase02.py`.','']
(OUT/'02_phase_report.md').write_text('\n'.join(report),encoding='utf8')
print(json.dumps({'go':len(go),'gc':len(classes),'excluded':len(exclusions),'dups':len(duplicated),'within':withinx,'across':acrossx,'perfile':perfile,'summary':str(OUT/'02_phase_summary.json')},indent=2))
