# Phase 06 — Negative Controls, Residual Candidate Consolidation, Exhaustive v5 Queue

## Status

**Phase 06 preparation and exhaustive queue construction: COMPLETE (offline tests passed).**
**External Azure evaluation handoff: BLOCKED / NOT SUBMITTED (no endpoint or API key in this environment).**
No Phase 07, Phase 08, or Phase 09 scoring was performed.

## Frozen scope and population

- Method: `fullload`; protocol: `10.6`; operator assistant effort: `xhigh`.
- Source authority: original 90-physical-page PDF, unchanged SHA-256 `b71541e74564559d2cc0a84e9827086946998fbc6c627488fb9e7a7f9b0137c3`.
- Frozen positive reference: R=638; frozen negative controls: N=142; source ledgers unchanged.
- Original generated occurrences GO=5,046; original Phase02 semantic classes GC=4,861.
- Phase05 provisional nondefinitive GC exclusions: 476; Phase05 recovered candidates: 7.
- Phase06 separately verified 16 cross-file bidirectional complete-clause equivalent class pairs, rejecting nine other plausible matches and preserving original Phase02/Phase05 bytes.
- Effective pending GC: 4376 (including 176 previously flagged eligibility-review classes).
- Pending population C=638+142+4376 = **5156**; selected K = **5156**, no numeric cap omissions.
- Frozen queue SHA-256: `f0ee6dac19a32e41c2a83c1030bff2ddcf904d1e7a516b609853e22599d4981a`.
- Batch size: 8; 645 primary batches; final batch: four items; additional retries per batch: three; worst-case submissions: 2,580. None were sent.

## Negative controls and generated residuals

Every frozen N was searched against the full effective generated-class set. The 142 control audit records contain 2,272 ranked source-quotation candidates (16 per N) with original file hashes and line numbers. Each potential affirmation must be independently checked for actual polarity: a generated prohibition of a forbidden action is NOT an assertion of that action.

Every effective generated class is linked to the original Markdown quotation and to PDF evidence candidates where found. There are no *independently established* generated-only unsupported residuals at this stage. That does **not** mean actual F=0: unsupportedness, exact N/F overlap, and final residual merging remain pending semantic decisions. The class cross-file scan also records up to eight nearest neighbors for each of 4376 classes, identifying additional possible textual overlaps without illegitimate merges.

Seventy-four Phase05 exclusion-review fragments were separately indexed. No unverified sentence fragment was silently promoted into a new definitive class; they remain documented as potential interpretation/atomization gaps. This is a material limitation rather than a certification that all exclusions are correct.

## Evaluator regression and dry run

The recovered source evaluator and the protocol execution derivative agree exactly (AST comparison) for `SYSTEM_PROMPT`, `RESULT_SCHEMA` and `suggest()`. The Phase06 derivative corrects only the deployed reasoning setting from `medium` to the protocol-required `high`, retaining original judgment logic and its SHA-verified filename-alias resolver.

The mandatory offline alias/quotation suite passed **19/19** cases: original/canonical/copy-suffix names, reverse alias, multiline proof, role ambiguity, wrong role, wrong line, altered quote, differing alias digest, mutated original and original PDF physical-page quotation. The source-lock adapter maps exactly eight original verified filenames without rewriting the original Phase01 reference lock.

Evaluator dry-run succeeded with 5156 items, 645 batches, a four-item final batch and 9 original source documents (one 90-page PDF plus eight Markdown originals). External submissions: **0**. The independent Phase06 validator passed **28 checks**, failed **0**.

## Integrity and limitations

The original reference freeze, original R/N JSONL, original PDF and Phase01–05 phase artifacts were not modified. Original Phase02 validator's missing `02_similarity_review_candidates.jsonl` reference remains a historical artifact defect documented in Phase05. Phase06's independent source/queue/hash checks do not rely on that missing filename.

This Phase06 delivers a complete deterministic pending-item selection and handoff. It **does not** certify TP/FN/FP/TN, semantic PDF support, statistical scores, exhaustiveness of all-pairs semantic duplicate groups, or independent approval of all remaining eligibility exclusions. The original v5 evaluator has not been executed against Azure here due to missing credentials; no results have been invented.

## Principal outputs

- `06_fp_controls.jsonl`
- `06_fp_residual_candidates.jsonl`
- `06_class_supersession_audit.jsonl`
- `06_semantic_near_duplicate_candidates.jsonl`
- `06_mixed_exclusion_audit.jsonl`
- `06_llm_queue_v10.6.jsonl`
- `06_queue_selection.json`
- `06_batch_boundaries.jsonl`
- `06_evaluator_source_lock.json`
- `06_evaluator_regression_results.json`
- `06_evaluator_dry_run.log`
- `06_validation_results.json`
- `06_external_handoff.json`
- `semantic_decision_evaluator_v10.6_unlimited.py`

**Numbered phases after 06 have NOT been started.**
