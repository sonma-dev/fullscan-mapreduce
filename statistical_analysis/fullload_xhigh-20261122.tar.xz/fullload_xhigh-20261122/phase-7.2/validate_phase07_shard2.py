#!/usr/bin/env python3
"""Independent mechanical validation of Phase 07 Shard 2 complete artifacts."""
from pathlib import Path
import hashlib,json,re,collections,unicodedata
import fitz
B=Path('/mnt/data');D=B/'oriondesk_fullload_v10_6/phase07';R=B/'oriondesk_fullload_v10_6'
read=lambda p:[json.loads(x) for x in open(p,encoding='utf8') if x.strip()]
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
norm=lambda s:' '.join(unicodedata.normalize('NFKC',str(s)).casefold().split())
q=read(R/'phase06/06_llm_queue_v10.6.jsonl');s=read(D/'07_shard2_assigned_items.jsonl');x=read(D/'07_shard2_adjudications.jsonl');a=read(D/'07_shard2_decision_audit.jsonl');s1=read(D/'07_shard1_final_adjudications.jsonl');m=read(B/'semantic_decisions(2).jsonl')
lock=json.loads((D/'07_partition_lock.json').read_text());su=json.loads((D/'07_shard2_adjudication_summary.json').read_text());man=json.loads((D/'07_shard2_output_manifest.json').read_text());run=json.loads((B/'run_state(1).json').read_text())
checks={}
def check(name,val):checks[name]=bool(val)
check('protocol_10_6',su['protocol_version']=='10.6' and lock['protocol_version']=='10.6')
check('reference_hash_positive',sha(B/'common_atomic_reqs(4).jsonl')==lock['frozen_r_sha256'])
check('reference_hash_negative',sha(B/'common_negative_controls(4).jsonl')==lock['frozen_n_sha256'])
check('pdf_sha',sha(B/'OrionDesk_AI_Detailed_Design_Specification(4).pdf')==lock['pdf_sha256'])
check('queue_sha',sha(R/'phase06/06_llm_queue_v10.6.jsonl')==lock['queue_sha256'])
check('external_v5_sha',sha(B/'semantic_decisions(2).jsonl')==lock['external_decisions_sha256'])
check('journals_sha',sha(B/'batch_journals(1).zip')==lock['batch_journals_zip_sha256'])
check('reference_lock_current',run['pdf_sha256']==lock['pdf_sha256'] and run['queue_sha256']==lock['queue_sha256'])
check('assigned_2578',len(s)==2578)
check('adjudications_2578',len(x)==2578)
check('audit_2578',len(a)==2578)
check('shard1_2578',len(s1)==2578)
check('queue_5156',len(q)==5156)
check('v5_5156',len(m)==5156)
check('assigned_order',[y['item_id'] for y in s]==[y['item_id'] for y in x]==[y['item_id'] for y in a])
check('no_shard_overlap',set(y['item_id'] for y in s).isdisjoint(y['item_id'] for y in s1))
check('all_ids_covered',set(y['item_id'] for y in s+s1)==set(y['item_id'] for y in q)==set(y['item_id'] for y in m))
check('shard_records_unique',len(set(y['item_id'] for y in x))==len(x))
check('shard_identity_correct',all(y['shard_id']==2 for y in x))
check('original_pdf_hash_on_records',all(y['source_pdf_sha256']==lock['pdf_sha256'] for y in x))
check('original_queue_unchanged',all(y['source_reference_unchanged'] is True for y in x))
check('original_v5_link',all(y['v5_record_sha256']==b['v5_record_sha256'] for y,b in zip(x,s)))
check('all_final_direction_specific',all((y['final_cell'] in ('TP','FN')) if y['direction']=='R' else (y['final_cell'] in ('TN','FP')) if y['direction']=='N' else (y['final_cell'] in ('TP','FP') or (y['final_cell'] is None and y['eligibility_status']=='EXCLUDED_NONDEFINITIVE')) for y in x))
check('no_eligible_semantic_null',all(y['final_cell'] is not None or y['eligibility_status']=='EXCLUDED_NONDEFINITIVE' for y in x))
c=collections.Counter((y['direction'],y['final_cell'] if y['final_cell'] else 'EXCLUDED') for y in x)
check('r_sum_319',c['R','TP']+c['R','FN']==319)
check('n_sum_71',c['N','TN']+c['N','FP']==71)
check('g_sum_2188',c['G','TP']+c['G','FP']+c['G','EXCLUDED']==2188)
check('g_tp_no_canonical_doublecount',all(y['canonical_counting_scope']=='G_DIAGNOSTIC_NOT_CANONICAL_TP' for y in x if y['direction']=='G' and y['final_cell']=='TP'))
check('g_fp_candidate_only',all(y['canonical_counting_scope']=='G_FP_CANDIDATE_NEEDS_PHASE08_DEDUP' for y in x if y['direction']=='G' and y['final_cell']=='FP'))
check('n_fp_n_only',all(y['canonical_counting_scope']=='N_CANONICAL' for y in x if y['direction']=='N'))
check('source_hash_map_equal',all(y['generated_file_sha256']==run['file_sha256'] for y in x))
file_map={'01':'01_screen_functions(4).md','02':'02_api(4).md','03':'03_data(4).md','04':'04_batch_functions(5).md','05':'05_business_rules(4).md','06':'06_exception_handling(6).md','07':'07_processing_flows(6).md','08':'08_architecture_decision(5).md'}
flines={k:(B/v).read_text(encoding='utf8').splitlines() for k,v in file_map.items()}
pdf=fitz.open(B/'OrionDesk_AI_Detailed_Design_Specification(4).pdf');pages=[norm(p.get_text('text')) for p in pdf];bad=[];number_gen=0;number_pdf=0;visual=0
for y in x:
 for z in y['generated_evidence']:
  rr=z['role'];st=z['line_start'];en=z['line_end'];quoted=z['quote_en'];number_gen+=1
  if not (rr in flines and st>=1 and en>=st and en<=len(flines[rr]) and norm(quoted) in norm('\n'.join(flines[rr][st-1:en])) and z['sha256']==run['file_sha256'][re.sub(r'\(\d+\)','',file_map[rr])]):bad.append((y['item_id'],'generated',rr,st,en))
 for z in y['pdf_evidence']:
  pg=z['physical_page'];quoted=z['quote_en'];number_pdf+=1
  if z.get('verification_method')=='PDF_FIGURE_VISUALLY_INSPECTED':
   visual+=1
   if not (pg==78 and quoted in ('immutable evidence and versioned policy inputs','tenant_id and actor context at every boundary') and z['page_render_sha256']==sha(B/'_phase7B_visual/page78.png')):bad.append((y['item_id'],'visual',pg))
  elif not(1<=pg<=90 and norm(quoted) in pages[pg-1]):bad.append((y['item_id'],'pdf',pg))
check('all_quotation_bytes_verified',not bad)
check('r_pdf_evidence_present',all(y['pdf_evidence'] for y in x if y['direction']=='R'))
check('g_support_pdf_evidence_present',all(y['pdf_evidence'] for y in x if y['direction']=='G' and y['final_cell']=='TP'))
check('g_origin_evidence_present',all(y['generated_evidence'] for y in x if y['direction']=='G'))
check('visual_source_page_78',visual==2)
check('summary_counts_match',sum(y['count'] for y in su['by_direction_cell'])==2578 and set((y['direction'],y['cell'],y['count']) for y in su['by_direction_cell'])==set((d,cell,count) for (d,cell),count in c.items()))
check('input_blockers_empty',not (D/'07_shard2_input_blockers.jsonl').read_text().strip())
check('phase07_shard_completed',su['status']=='COMPLETE')
check('manifest_hashes_valid',all(sha(D/name)==v for name,v in man['files_sha256'].items()))
check('status_no_phase08',su['phase08_not_started'] is True and su['phase07_full_integration_not_performed'] is True)
check('G_FP_not_as_R_TP',all(y['canonical_counting_scope'] != 'R_CANONICAL' for y in x if y['direction']=='G'))
check('v5_past_kept_immutable',len(m)==len(q) and all(y['was_external_llm_selected'] for y in x))
check('no_logic_relabel_on_lost_visual',all(y.get('source_pdf_sha256')==run['pdf_sha256'] for y in x))
check('source_sha_all_roles',all(sha(B/f)==lock['source_actual_file_sha256'][f] for f in file_map.values()))
check('item_direction_matches_queue',all(y['direction']==j['direction'] for y,j in zip(x,s)))
check('shard_order_R_N_G',all(['R','N','G'].index(x[i]['direction'])<=['R','N','G'].index(x[i+1]['direction']) for i in range(len(x)-1)))
check('model_provenance_version',all(y['prior_v5_decision_status']==j['prior_v5_decision_status'] for y,j in zip(x,s)))
check('summary_no_invalid_missing',su['unresolved_eligible_count']==0 and su['missing_assigned_ids']==0 and su['duplicate_assigned_ids']==0)
report={'record_type':'PHASE07_SHARD2_INDEPENDENT_VALIDATION','protocol_version':'10.6','status':'PASS' if all(checks.values()) else 'FAIL','checks':checks,'checked':len(checks),'passed':sum(checks.values()),'failed':sum(not v for v in checks.values()),'original_generated_quotations_verified':number_gen,'original_pdf_quotations_verified':number_pdf,'visual_figures_explicitly_checked':visual,'quote_errors':bad[:40],'original_pdf_sha256':run['pdf_sha256'],'original_queue_sha256':run['queue_sha256'],'shard2_final_counts':{f'{d}:{cell}':v for (d,cell),v in c.items()}}
(D/'07_shard2_validation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2,sort_keys=True)+'\n',encoding='utf8')
print(json.dumps({'status':report['status'],'passed':report['passed'],'checked':report['checked'],'errors':bad[:5],'original_generated_quotations_verified':number_gen,'original_pdf_quotations_verified':number_pdf},indent=2));assert report['status']=='PASS'
