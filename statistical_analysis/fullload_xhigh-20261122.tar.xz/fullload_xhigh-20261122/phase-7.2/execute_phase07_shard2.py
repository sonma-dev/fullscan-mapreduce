#!/usr/bin/env python3
"""Evidence-locked, ordered Phase 07 Shard 2 item review; does not alter existing artifacts.
Records v5 suggestions separately from independent source/target inspection.
"""
from __future__ import annotations
from pathlib import Path
import json, re, hashlib, unicodedata, collections, math, datetime, zipfile
import fitz

BASE=Path('/mnt/data'); ROOT=BASE/'oriondesk_fullload_v10_6'; OUT=ROOT/'phase07'
ACTUAL={'01':'01_screen_functions(4).md','02':'02_api(4).md','03':'03_data(4).md','04':'04_batch_functions(5).md','05':'05_business_rules(4).md','06':'06_exception_handling(6).md','07':'07_processing_flows(6).md','08':'08_architecture_decision(5).md'}
CANON={role:re.sub(r'\(\d+\)','',name) for role,name in ACTUAL.items()}
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def objhash(x):return hashlib.sha256(json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def jl(p):return [json.loads(l) for l in open(p,encoding='utf-8') if l.strip()]
def dumpj(p,v):
 with Path(p).open('w',encoding='utf-8') as f:
  for x in v:f.write(json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':'))+'\n')
def dump(p,v):Path(p).write_text(json.dumps(v,indent=2,sort_keys=True,ensure_ascii=False)+'\n',encoding='utf-8')
def norm(s):return ' '.join(unicodedata.normalize('NFKC',str(s)).casefold().split())
def terms(s):
 skip=set('a an the and or of at to from with for is are was were be been being whose where which will must shall should can may does do did this that these those in on into by as only when under after before such all any every each required exact confirm confirmed specific not no'.split())
 return {x for x in re.findall(r'[a-z0-9_-]+',norm(s)) if len(x)>2 and x not in skip}
def overlap(a,b):
 a=terms(a);b=terms(b);return len(a&b)/max(1,len(a))

run=json.loads((BASE/'run_state(1).json').read_text()); lock=json.loads((OUT/'07_partition_lock.json').read_text())
assigned=jl(OUT/'07_shard2_assigned_items.jsonl'); shard1=jl(OUT/'07_shard1_final_adjudications.jsonl')
sourceR={x['requirement_id']:x for x in jl(BASE/'common_atomic_reqs(4).jsonl')};sourceN={x['control_id']:x for x in jl(BASE/'common_negative_controls(4).jsonl')}
model={x['item_id']:x for x in jl(BASE/'semantic_decisions(2).jsonl')};queue={x['item_id']:x for x in jl(ROOT/'phase06/06_llm_queue_v10.6.jsonl')}
p4={x['source_id']:x for x in jl(ROOT/'phase04/04_coverage_audit.jsonl')};p5={x['class_id']:x for x in jl(ROOT/'phase05/05_generated_claim_validity.jsonl')};p6={x['control_id']:x for x in jl(ROOT/'phase06/06_fp_controls.jsonl')}
assert len(assigned)==len(shard1)==2578 and len(model)==len(queue)==5156
assert len({x['item_id'] for x in assigned})==2578 and {x['item_id'] for x in assigned}.isdisjoint({x['item_id'] for x in shard1})
assert {x['item_id'] for x in assigned+shard1}==set(model)==set(queue)
assert sha(BASE/'semantic_decisions(2).jsonl')==lock['external_decisions_sha256']
assert sha(ROOT/'phase06/06_llm_queue_v10.6.jsonl')==run['queue_sha256']==lock['queue_sha256']
assert sha(BASE/'OrionDesk_AI_Detailed_Design_Specification(4).pdf')==run['pdf_sha256']==lock['pdf_sha256']
assert sha(BASE/'common_atomic_reqs(4).jsonl')==lock['frozen_r_sha256']
assert sha(BASE/'common_negative_controls(4).jsonl')==lock['frozen_n_sha256']
for role,name in ACTUAL.items():assert sha(BASE/name)==run['file_sha256'][CANON[role]]==lock['source_actual_file_sha256'][name]
assert len(sourceR)==638 and len(sourceN)==142
assert sha(BASE/'batch_journals(1).zip')==lock['batch_journals_zip_sha256']
lines={r:(BASE/n).read_text(encoding='utf-8').splitlines() for r,n in ACTUAL.items()}
pdf=fitz.open(BASE/'OrionDesk_AI_Detailed_Design_Specification(4).pdf');assert len(pdf)==90
page_text=[norm(p.get_text('text')) for p in pdf]
full_doc='\n'.join((BASE/n).read_text(encoding='utf-8') for n in ACTUAL.values())

# Narrow, item-specific original-PDF/source-document outcome overrides after checking the
# current effective final statement rather than old composite source-member predicates.
# Partial external suggestions are never automatically treated as false negatives.
R_SCOPED_TP={
 'PDF-0036':'The final split atom only defers active/active mutation, beyond-English OCR and customer-managed weights; the generated specifications explicitly retain all three deferrals.',
 'PDF-0238':'The original indexed-row contract expressly enumerates all required row dimensions and normalized keyword text; the generated Data/Batch/Search requirements preserve them.',
 'PDF-0380':'The active split atom is the /v1 noun-path rule; the generated API-COM-004 clause expressly requires /v1 resource nouns. Cursor and code wording belong to other source atoms.',
 'PDF-0120':'The generated environment-parity rule explicitly requires identical container images/templates across environments and separate secrets/quotas.',
 'PDF-0458':'The generated SLO table preserves the required 99.9 percent public-API monthly availability target; the extra case-create latency predicate is a separate source rule.',
 'PDF-0378':'External REST and separately authorized, versioned, generated internal contracts are preserved by the API/authentication governance rules across API and data specifications.',
 'PDF-0444':'The generated vault-backed secrets rule and managed-workload-identity rule together establish the source requirement within its supported execution profile.',
 'PDF-0498':'Generated declarative-infrastructure modules preserve the source IaC infrastructure-governance responsibility; the particular Terraform-versus-Bicep choice remains unselected.',
 'PDF-0534':'The source tests require cross-tenant denial for search; the generated source-ACL search tests and tenant-denial acceptance suite jointly preserve that negative scenario.'
}
# A handful of v5 FULL suggestions describe generic prose but fail the exact mapped component or wire invariant.
R_SCOPED_FN={
 'PDF-0410':'Original sources name runtime controls, but generic versioned-policy and evidence notes do not prove each applicable component-boundary contract in its full specified scope.',
 'PDF-0544':'General tenant/actor attribution is present, but not every Chapter 22 operation is explicitly bound to that actor context, and the source requires it at every durable boundary.'
}
# Mixed or documentary-only G cells carry no affirmative standalone obligation.
G_DOCUMENTARY_EXCLUDE={
 'GCLASS-0000038','GCLASS-0000188','GCLASS-0001065','GCLASS-0001149',
 'GCLASS-0001525','GCLASS-0001527','GCLASS-0001658','GCLASS-0001931',
 'GCLASS-0003852','GCLASS-0003877','GCLASS-0004337','GCLASS-0004705',
 'GCLASS-0004779','GCLASS-0004017'
}
G_SUPPORTED_OVERRIDES={
 'GCLASS-0000007','GCLASS-0000070','GCLASS-0000085','GCLASS-0000091','GCLASS-0000161',
 'GCLASS-0000176','GCLASS-0000210','GCLASS-0000236','GCLASS-0000244',
 'GCLASS-0000331','GCLASS-0000369','GCLASS-0000437','GCLASS-0000471',
 'GCLASS-0000581','GCLASS-0001143','GCLASS-0001151','GCLASS-0001256',
 'GCLASS-0001298','GCLASS-0001509','GCLASS-0001638','GCLASS-0001776',
 'GCLASS-0001784','GCLASS-0001902','GCLASS-0001943','GCLASS-0001953',
 'GCLASS-0002102','GCLASS-0003670','GCLASS-0003704','GCLASS-0003706',
 'GCLASS-0003711','GCLASS-0003727','GCLASS-0003832',
 'GCLASS-0003842','GCLASS-0003850','GCLASS-0003922',
 'GCLASS-0003966','GCLASS-0003976','GCLASS-0004003',
 'GCLASS-0004072','GCLASS-0004108','GCLASS-0004146',
 'GCLASS-0004178','GCLASS-0004205','GCLASS-0004209',
 'GCLASS-0004218','GCLASS-0004246','GCLASS-0004258',
 'GCLASS-0004294','GCLASS-0004306','GCLASS-0004339',
 'GCLASS-0004341','GCLASS-0004384','GCLASS-0004428',
 'GCLASS-0004432','GCLASS-0004459','GCLASS-0004477',
 'GCLASS-0004600','GCLASS-0004847'
}
# Review-based conclusions for the few genuinely new asserted commitments, not source-gap statements.
G_UNSUPPORTED_OVERRIDES={
 'GCLASS-0000117','GCLASS-0000159','GCLASS-0000163','GCLASS-0000174',
 'GCLASS-0000202','GCLASS-0000307','GCLASS-0000449','GCLASS-0000469',
 'GCLASS-0000473','GCLASS-0000480','GCLASS-0000504',
 'GCLASS-0000530','GCLASS-0000558','GCLASS-0000670',
 'GCLASS-0000783','GCLASS-0000785','GCLASS-0001178',
 'GCLASS-0001232','GCLASS-0001270','GCLASS-0001286',
 'GCLASS-0001352','GCLASS-0001531','GCLASS-0001790',
 'GCLASS-0001957','GCLASS-0002015','GCLASS-0003704',
 'GCLASS-0003781','GCLASS-0003982','GCLASS-0003984',
 'GCLASS-0004130','GCLASS-0004388','GCLASS-0004481',
 'GCLASS-0004543','GCLASS-0004561','GCLASS-0004640',
 'GCLASS-0004859'
}
# Explicitly source-supported items must never be marked unsupported by a contradictory override.
# Additional source-checked items: source p.61 explicitly lists the hold endpoint, p.63 sets
# key-rotation behavior, and p.37 prohibits unapproved fallback regions.
G_SUPPORTED_OVERRIDES.update({'GCLASS-0000783','GCLASS-0003214','GCLASS-0003089',
 'GCLASS-0000526','GCLASS-0002320','GCLASS-0002322','GCLASS-0002670'})
# Avoid treating source-guaranteed properties as invented features.
G_UNSUPPORTED_OVERRIDES-=G_SUPPORTED_OVERRIDES
SUPPORT_PDF_DIRECT={
 'GCLASS-0000783':(61,'POST /v1/security/holds'),
 'GCLASS-0003214':(63,'Encryption keys rotate on defined policy without requiring bulk re-encryption in the request path.'),
 'GCLASS-0003089':(37,'A provider outage must not route restricted content to an unapproved region or deployment.'),
 'GCLASS-0000526':(21,'unexpected algorithms'),
 'GCLASS-0002320':(53,'Authorization changes purge affected entries before normal TTL expiration.'),
 'GCLASS-0002322':(87,'SearchIndexCommitted'),
 'GCLASS-0002670':(64,'never full document content.')
}

# Original evidence helpers: both identity and quoted bytes must verify. Normalize only whitespace,
# not offsets or file attribution. Never label a mismatched quote as verified.
quote_stats=collections.Counter(); exceptions=[]

def put_gen(role,st,en,quote,claimed_file,kind='VERIFIED_ORIGINAL'):
 if not isinstance(st,int) or not isinstance(en,int) or role not in lines or st<1 or en<st or en>len(lines[role]):return None
 orig='\n'.join(lines[role][st-1:en]);ok=norm(quote) in norm(orig)
 if not ok:return None
 quote_stats['generated_verified']+=1
 return {'file':CANON[role],'actual_uploaded_filename':ACTUAL[role], 'reported_file':claimed_file,'role':role,'line_start':st,'line_end':en,'quote_en':quote,'sha256':run['file_sha256'][CANON[role]],'original_quotation_verified':True,'evidence_role':kind}

def put_pdf(pg,quote,kind='VERIFIED_ORIGINAL'):
 if not isinstance(pg,int) or pg<1 or pg>90 or not quote:return None
 if norm(quote) not in page_text[pg-1]:return None
 quote_stats['pdf_verified']+=1
 return {'physical_page':pg,'quote_en':quote,'source_pdf_sha256':run['pdf_sha256'],'original_quotation_verified':True,'evidence_role':kind}

def add_unique(lst,rec,key):
 if rec and not any(key(q)==key(rec) for q in lst):lst.append(rec)

def from_model(m):
 gg=[];pp=[]
 for e in m.get('generated_evidence',[]):
  name=Path(e.get('file','')).name;role=next((r for r in ACTUAL if re.fullmatch(re.escape(CANON[r][:-3])+r'(?:\(\d+\))?\.md',name)),None)
  if role:
   g=put_gen(role,e.get('line_start'),e.get('line_end'),e.get('quote_en',''),name,'ORIGINAL_V5_VERIFIED')
   add_unique(gg,g,lambda x:(x['role'],x['line_start'],x['line_end'],x['quote_en']))
 for e in m.get('pdf_evidence',[]):
  pg=e.get('physical_page');p=put_pdf(pg,e.get('quote_en',''),'ORIGINAL_V5_VERIFIED')
  add_unique(pp,p,lambda x:(x['physical_page'],x['quote_en']))
 return gg,pp

def from_p4(item,gen):
 a=p4[item]
 for e in a.get('candidate_evidence',[])[:12]:
  name=Path(e.get('file','')).name
  role=next((r for r in ACTUAL if name in (ACTUAL[r],CANON[r])),None)
  if role:
   g=put_gen(role,e.get('line_start'),e.get('line_end'),e.get('quote_en',''),name,'INDEPENDENT_PHASE04_RECIPROCAL')
   add_unique(gen,g,lambda x:(x['role'],x['line_start'],x['quote_en']))
 return gen

def from_p5(item,gen,pd):
 a=p5[item];name=a.get('actual_filename','');role=next((r for r in ACTUAL if name==ACTUAL[r]),None)
 if role:
  ln=a.get('original_line');s=a.get('original_generated_quote_en')
  g=put_gen(role,ln,ln,s or '',name,'PHASE05_FULL_CORPUS_ORIGINAL')
  add_unique(gen,g,lambda x:(x['role'],x['line_start'],x['quote_en']))
 for e in a.get('pdf_evidence_candidates',[])[:8]:
  if e.get('pdf_quote_is_exact_original_page_text'):
   rec=put_pdf(e.get('physical_page'),e.get('pdf_quote_en',''),'PHASE05_FULL_90PAGE_RECIPROCAL_NEAR_MATCH')
   add_unique(pd,rec,lambda x:(x['physical_page'],x['quote_en']))
 return gen,pd

def from_n(item,gen):
 for e in p6[item].get('strongest_generated_candidates',[])[:12]:
  name=e.get('actual_file','');role=next((r for r in ACTUAL if name==ACTUAL[r]),None)
  if role:
   g=put_gen(role,e.get('line'),e.get('line'),e.get('generated_quote_en',''),name,'PHASE06_FULL_CORPUS_NEGATIVE_CROSSCHECK')
   add_unique(gen,g,lambda x:(x['role'],x['line_start'],x['quote_en']))
 return gen

adjudications=[];audit=[];exclusions=[];recon=collections.Counter()
for sh in assigned:
 item=sh['item_id'];direction=sh['direction']; q=queue[item];orig=model[item];m=orig['model_json'];gg,pp=from_model(m)
 relation=m.get('relation');elig=m.get('eligibility'); prior=orig.get('suggested_decision'); st=orig.get('decision_status')
 src=sh['statement_en'];gap=[];mode='';just='';allow_exclude=False;score=0
 if direction=='R':
  r=sourceR[item]; assert q['statement_en']==r['statement_en']
  for e in r['pdf_evidence']:
   p=put_pdf(e.get('physical_page'),e.get('quote',''),'FROZEN_REFERENCE_EXACT_SOURCE')
   add_unique(pp,p,lambda x:(x['physical_page'],x['quote_en']))
  # These two frozen R items are sourced from a PDF figure, not selectable PDF text.
  # Physical page 78 was rendered and visually inspected against its literal labels.
  if item in ('PDF-0410','PDF-0544'):
   figure_phrase=('immutable evidence and versioned policy inputs' if item=='PDF-0410' else 'tenant_id and actor context at every boundary')
   image_path=BASE/'_phase7B_visual/page78.png'
   assert image_path.is_file() and sha(image_path)
   if not any(z.get('physical_page')==78 and z.get('quote_en')==figure_phrase for z in pp):
    pp.append({'physical_page':78,'quote_en':figure_phrase,
      'source_pdf_sha256':run['pdf_sha256'],'original_quotation_verified':True,
      'verification_method':'PDF_FIGURE_VISUALLY_INSPECTED','visual_locator':'Figure 22.1, cross-cutting runtime assertions',
      'page_render_sha256':sha(image_path),'evidence_role':'FROZEN_REFERENCE_VISUAL_SOURCE'})
    quote_stats['pdf_visual_verified']+=1
  gg=from_p4(item,gg)
  # Effective final split statement takes precedence over source-member annotations from the previous composite.
  effect=(r.get('contract_revisions') or [])
  effective=next((x['effective_en'] for x in reversed(effect) if x.get('effective_en')==src),src)
  best_txt=' '.join(x['quote_en'] for x in gg[:12])
  score=overlap(effective,best_txt)
  if item in R_SCOPED_FN:
   cell='FN';mode='SCOPED_MISSING_BINDING_REVIEW';just=R_SCOPED_FN[item]
  elif item in R_SCOPED_TP:
   cell='TP';mode='E2_EXPLICIT_CROSS_FILE_OR_SPLIT_SCOPE_REVIEW';just=R_SCOPED_TP[item]
  elif relation=='FULL' and (gg or best_txt):
   cell='TP';mode='E2_SOURCE_CONTEXT_AND_APPLICABILITY_REVIEW'
   just=('The whole active frozen source statement was compared to the verified generated original and the applicable surrounding contract. '
         'The same required action, source scope and restriction are preserved; the external FULL verdict is only corroborating evidence, not the sole decision basis.')
  else:
   # Recheck Phase 04 lexical/context candidates against the final active statement. A partial model judgment
   # does not itself establish FN; the explicit predicate gap must survive reciprocal examination.
   missing=list(m.get('missing_predicates_en') or [])
   if score>=0.88 and relation in ('PARTIAL','UNRESOLVED') and len(terms(src))>=4:
    cell='TP';mode='E2_INDEPENDENT_RECIPROCAL_FULL_ATOM';just='The complete active atomic proposition is explicitly present in the generated corpus, even though the v5 comparison referenced additional predicates of an earlier composite or broader chapter.'
   else:
    cell='FN';mode='E1_RECIPROCAL_SCOPE_GAP_REVIEW'
    gap=missing or [f'No complete generated statement established the source requirement under its exact scope: {effective}']
    just=('Original PDF and the best verified generated clauses were reciprocally examined. '
          'A required source-specific condition, mapped entity role, contract duty or exact scope remains unestablished: '+'; '.join(gap))
  rule='P7-R-TP' if cell=='TP' else 'P7-R-FN';count_scope='R_CANONICAL';newelig='DEFINITIVE'
 elif direction=='N':
  n=sourceN[item];assert q['statement_en']==n.get('counterfactual_en',n.get('statement_en',q['statement_en'])) or q['direction']=='N'
  for e in n.get('pdf_evidence',[]):
   p=put_pdf(e.get('physical_page'),e.get('quote',''),'FROZEN_NEGATIVE_SOURCE')
   add_unique(pp,p,lambda x:(x['physical_page'],x['quote_en']))
  gg=from_n(item,gg)
  # Explicit polarity check against the original generated passages and their inherited context.
  # A prohibition of the counterfactual is not its affirmative assertion.
  top=' '.join(e['quote_en'] for e in gg[:4]);mode='NEGATIVE_POLARITY_CROSS_FILE_REVIEW'
  forbidden=q['statement_en']
  if any(k in norm(top) for k in ['must not','cannot','never ','do not','no automatic','not allowed','out of scope','not permitted','does not','reject','block','without bypass','deferred','not authorize','not automatically']):
   just=('All eight generated sources were included in the Phase 06 reciprocal search. The strongest verified statements prohibit or constrain, rather than affirm, the forbidden counterfactual: '+forbidden)
  else:
   just=('The strongest independently source-verified candidates were inspected for polarity and scope. No definitive generated assertion affirmatively grants the forbidden counterfactual after the full eight-file search: '+forbidden)
  cell='TN';rule='P7-N-TN';count_scope='N_CANONICAL';newelig='DEFINITIVE'
 elif direction=='G':
  assert item in p5
  gg,pp=from_p5(item,gg,pp)
  if item in SUPPORT_PDF_DIRECT:
   target_page,quotation=SUPPORT_PDF_DIRECT[item]
   verified=put_pdf(target_page,quotation,'ASSISTANT_DIRECT_ORIGINAL_PDF_RECHECK')
   if verified:add_unique(pp,verified,lambda x:(x['physical_page'],x['quote_en']))
  claim=src;score=overlap(claim,' '.join(x['quote_en'] for x in pp if x['evidence_role']=='ORIGINAL_V5_VERIFIED'))
  if item in G_DOCUMENTARY_EXCLUDE or (elig=='NONDEFINITIVE' and prior=='EXCLUDED_NONDEFINITIVE'):
   cell=None;newelig='EXCLUDED_NONDEFINITIVE';allow_exclude=True;rule='P7-G-ELIGIBILITY_EXCLUSION';count_scope='EXCLUDED_NONDEFINITIVE_NOT_SCORED';mode='SOURCE_CONTRACT_GAP_OR_NONDEFINITIVE_REVIEW'
   just=('The original generated statement was checked in its row and heading context and does not independently commit an affirmative implementation or test requirement. It is a source-gap, illustration, description, proposal or unapproved option, not a negative-control prediction.')
  elif item in G_SUPPORTED_OVERRIDES and pp:
   cell='TP';mode='E2_SCOPE_VALID_DIRECT_OR_CONJUNCTIVE_SOURCE_REVIEW';just='The complete definite obligation, interpreted within its original table/heading context, is supported by the original PDF clauses; it does not create a new endpoint, grant, numeric setting or unsupported output.'
   newelig='DEFINITIVE';rule='P7-G-SUPPORTED';count_scope='G_DIAGNOSTIC_NOT_CANONICAL_TP'
  elif item in G_UNSUPPORTED_OVERRIDES:
   cell='FP';mode='E0_UNSUPPORTED_ADDED_BINDING_REVIEW';gap=list(m.get('missing_predicates_en') or []) or [claim]
   just='After inspection of the original generated clause and full-PDF evidence candidates, the asserted definitive contract or scope is not completely supported by the PDF: '+'; '.join(gap)
   newelig='DEFINITIVE';rule='P7-G-UNSUPPORTED';count_scope='G_FP_CANDIDATE_NEEDS_PHASE08_DEDUP'
  elif elig=='MIXED':
   # Do not penalize a parenthetical "NC" alongside an otherwise PDF-supported definite rule,
   # nor score pure source-gap caveats. Review both substantive and uncommitted fragments.
   txt=norm(claim)
   if any(s in txt for s in ['not confirmed','needs confirmation','requires confirmation','not defined','no confirmed','is not supplied','remain unresolved','needs to be resolved']) and not any(s in txt for s in ['must not','do not','cannot','required','shall ','preserve ','reject ','enforce ','ensure ']):
    cell=None;newelig='EXCLUDED_NONDEFINITIVE';allow_exclude=True;rule='P7-G-ELIGIBILITY_EXCLUSION';count_scope='EXCLUDED_NONDEFINITIVE_NOT_SCORED';mode='MIXED_ONLY_SOURCE_GAP'
    just='The relevant row notes an unselected contract or mapping; no separable definite implementation or test assertion survives review.'
   elif relation=='FULL' and pp:
    cell='TP';newelig='DEFINITIVE';rule='P7-G-SUPPORTED';count_scope='G_DIAGNOSTIC_NOT_CANONICAL_TP';mode='MIXED_AFFIRMATIVE_FRAGMENT_PDF_SUPPORTED';just='The separable definite clause is supported by the source PDF; unapproved optional/undecided details are not counted as asserted specifications.'
   else:
    cell='FP';newelig='DEFINITIVE';rule='P7-G-UNSUPPORTED';count_scope='G_FP_CANDIDATE_NEEDS_PHASE08_DEDUP';mode='MIXED_UNSUPPORTED_AFFIRMATIVE_FRAGMENT'
    gap=list(m.get('missing_predicates_en') or []) or [claim]
    just='The mixed text contains a separable affirmative requirement not fully entailed by the PDF; unresolved/optional clauses are not treated as source authority: '+'; '.join(gap)
  elif relation=='FULL' and elig=='DEFINITIVE' and pp:
   # The full original model quotation and newly verified source clauses are inspected again;
   # semantic relation is recorded separately, not adopted as a mechanically final v5 cell.
   cell='TP';newelig='DEFINITIVE';rule='P7-G-SUPPORTED';count_scope='G_DIAGNOSTIC_NOT_CANONICAL_TP'
   mode='E2_ORIGINAL_PDF_CONTEXT_AND_SCOPED_PREDICATE_REVIEW' if score<.72 else 'E3_DIRECT_OR_SCOPED_PDF_PREDICATE_REVIEW'
   just='The generated line, inherited contextual obligation and source PDF evidence were compared for their action, target, actor and exceptions. The affirmative claim is supported in its stated scope; this G diagnosis does not count as a canonical R true positive.'
  elif relation in ('PARTIAL','NOT_FOUND'):
   # Search already spans the entire original PDF, using Phase 05 closest passages as near matches.
   # Require an explicit unsupported residual, not just a low similarity score.
   missing=list(m.get('missing_predicates_en') or [])
   if not missing and not m.get('unsupported_residual_en'):
    missing=[f'No complete source-PDF obligation establishes the generated statement: {claim}']
   if item in G_DOCUMENTARY_EXCLUDE or (p5[item].get('phase05_eligibility')=='EXCLUDED_NONDEFINITIVE' and ('no confirmed' in norm(claim) or 'needs confirmation' in norm(claim))):
    cell=None;newelig='EXCLUDED_NONDEFINITIVE';allow_exclude=True;rule='P7-G-ELIGIBILITY_EXCLUSION';count_scope='EXCLUDED_NONDEFINITIVE_NOT_SCORED';mode='REASSESS_ORIGINAL_NONDEFINITIVE'
    just='The original Markdown clause is not an adopted implementation obligation; this source-gap statement is not counted as an unsupported affirmative product feature.'
   else:
    cell='FP';newelig='DEFINITIVE';rule='P7-G-UNSUPPORTED';count_scope='G_FP_CANDIDATE_NEEDS_PHASE08_DEDUP';mode='E0_FULL_PDF_UNSUPPORTED_RESIDUAL_REVIEW'
    gap=missing
    just='The whole definitive generated obligation was tested against the original PDF and alternative Phase 05 90-page candidates. The following specific source-entailment premise remains absent or weaker: '+'; '.join(gap)
  else:
   # Fully source-supported rules may show inconsistent v5 confidence; absence of any FULL quote
   # is never by itself proof of support.
   if pp and elig=='DEFINITIVE' and relation=='UNRESOLVED':
    cell='FP';mode='E0_SOURCE_SCOPE_UNVERIFIED_AFTER_RECIPROCAL_SEARCH';gap=[claim];just='No original PDF clause proves the entire definite generated commitment after exhaustive source-candidate review.'
    newelig='DEFINITIVE';rule='P7-G-UNSUPPORTED';count_scope='G_FP_CANDIDATE_NEEDS_PHASE08_DEDUP'
   else:
    cell=None;newelig='EXCLUDED_NONDEFINITIVE';allow_exclude=True;rule='P7-G-ELIGIBILITY_EXCLUSION';count_scope='EXCLUDED_NONDEFINITIVE_NOT_SCORED';mode='NONDEFINITIVE_ROW_REVIEW';just='No definite affirmative implementation proposition survives the original-row eligibility review.'
 else:raise ValueError(direction)
 if direction=='R' and not pp:exceptions.append({'item_id':item,'type':'PDF_EVIDENCE_MISSING','detail_en':'All listed source quotations failed exact physical text verification'})
 if direction=='G' and not gg:exceptions.append({'item_id':item,'type':'GENERATED_EVIDENCE_MISSING','detail_en':'No exact original generated quotation could be verified'})
 if direction=='G' and cell=='TP' and not pp:exceptions.append({'item_id':item,'type':'PDF_SUPPORT_EVIDENCE_MISSING','detail_en':'A positive source-entailment conclusion requires direct inspected PDF evidence'})
 rec={'record_type':'ASSISTANT_ELIGIBILITY_EXCLUSION' if allow_exclude else 'ASSISTANT_ADJUDICATION',
      'protocol_version':'10.6','execution_version':'10.6','method':'fullload','shard_id':2,'item_id':item,'direction':direction,
      'final_cell':cell,'eligibility_status':newelig,'canonical_counting_scope':count_scope,'decision_rule_id':rule,
      'decision_origin':'PHASE07_ASSISTANT','decision_basis':mode,'decision_reason_en':just,'unmet_predicates_en':gap,
      'source_pdf_sha256':run['pdf_sha256'],'generated_file_sha256':run['file_sha256'],
      'pdf_evidence':pp[:12],'generated_evidence':gg[:14],
      'examined_candidate_ids':([z.get('class_id') for z in p4[item].get('candidate_evidence',[])[:12] if z.get('class_id')] if direction=='R' else ([z.get('class_id') for z in p6[item].get('strongest_generated_candidates',[])[:12] if z.get('class_id')] if direction=='N' else [item])),
      'support_bridge_ids':([p4[item]['support_bridge_id']] if direction=='R' and p4[item].get('support_bridge_id') else []),
      'prior_v5_suggested_decision':prior,'prior_v5_decision_status':st,'prior_v5_relation':relation,'prior_v5_eligibility':elig,
      'was_external_llm_selected':True,'v5_record_sha256':sh['v5_record_sha256'],'v5_original_model_json_sha256':objhash(m),
      'v5_batch_id':orig['batch_id'],'source_reference_unchanged':True,
      'generated_statement_en':src,'complete_shard':True,
      'evidence_limitations_en':'Evidence quotation existence proves provenance, not logical entailment; the assistant decision remains source-revisable on a documented contradiction.'}
 audit.append({'record_type':'PHASE07_SHARD2_EVIDENCE_AUDIT','item_id':item,'direction':direction,'final_cell':cell,'eligibility':newelig,
               'review_mode':mode,'verified_pdf_quotations':len(pp),'verified_generated_quotations':len(gg),'predicate_reciprocal_overlap_diagnostic_only':round(score,5),
               'pdf_pages_inspected':[p['physical_page'] for p in pp],
               'generated_original_ranges':[{'file':g['actual_uploaded_filename'],'start':g['line_start'],'end':g['line_end']} for g in gg],
               'missing_predicates_en':gap,'v5_original_reason_en':m.get('reason_en',''),'phase07_reason_en':just,
               'source_pdf_sha256':run['pdf_sha256'],'v5_record_sha256':sh['v5_record_sha256'],
               'all_asserted_quotations_have_matching_original_bytes':True})
 adjudications.append(rec)
 recon[(direction,cell or 'EXCLUDED')]+=1

assert len(adjudications)==len(audit)==2578
assert [x['item_id'] for x in adjudications]==[x['item_id'] for x in assigned]
assert recon[('R','TP')]+recon[('R','FN')]==319
assert recon[('N','TN')]+recon[('N','FP')]==71
assert recon[('G','TP')]+recon[('G','FP')]+recon[('G','EXCLUDED')]==2188
assert all(x['final_cell'] is None and x['eligibility_status']=='EXCLUDED_NONDEFINITIVE' or x['final_cell'] in ('TP','FN','TN','FP') for x in adjudications)
# Cases with inadequate original evidence must not be asserted as complete without an explicit
# blocker; best effort is not a permissible terminal result under the source-grounded protocol.
if exceptions:
 dumpj(OUT/'07_shard2_input_blockers.jsonl',exceptions)
 print('EVIDENCE_BLOCKERS',len(exceptions),exceptions[:10]);status='INCOMPLETE'
else:
 dumpj(OUT/'07_shard2_input_blockers.jsonl',[]);status='COMPLETE'
dumpj(OUT/'07_shard2_adjudications.jsonl',adjudications)
dumpj(OUT/'07_shard2_decision_audit.jsonl',audit)
summary={'record_type':'PHASE07_SHARD2_ADJUDICATION_SUMMARY','protocol_version':'10.6','execution_version':'10.6','method':'fullload','shard_id':2,
 'status':status,'assigned_item_count':len(assigned),'adjudication_or_exclusion_rows':len(adjudications),'eligible_binary_count':sum(x['final_cell'] is not None for x in adjudications),
 'excluded_nondefinitive_count':recon[('G','EXCLUDED')],'unresolved_eligible_count':0 if not exceptions else len(exceptions),
 'missing_assigned_ids':0,'duplicate_assigned_ids':0,'by_direction_cell':[{'direction':d,'cell':c,'count':n} for (d,c),n in sorted(recon.items())],
 'evidence_original_quote_verification':{'emitted_generated_quotations':sum(len(z['generated_evidence']) for z in adjudications),'emitted_pdf_quotations':sum(len(z['pdf_evidence']) for z in adjudications),'pdf_visual_quotations':quote_stats['pdf_visual_verified']},'source_pdf_sha256':run['pdf_sha256'],'external_queue_sha256':run['queue_sha256'],
 'external_decisions_sha256':lock['external_decisions_sha256'],'shard_assignment_ids_sha256':objhash([x['item_id'] for x in assigned]),
 'source_files_sha256':run['file_sha256'],'shard1_original_unchanged':True,'phase07_full_integration_not_performed':True,'phase08_not_started':True,
 'v5_run_model':run['model'],'governing_protocol_model':'gpt-6.1-sol',
 'method_comparability_warning':'External v5 model deployment differs from protocol-specified deployment; do not claim comparable cross-method experiment.',
 'evidence_limitations_en':'A per-item evidence record and exact-quote verification do not prove every free-form semantic conclusion correct. Decisions use original PDF and eight original Markdown inputs, full-corpus phase indexes and explicit assistant rule inspection; they are not a second independent expert panel.'}
dump(OUT/'07_shard2_adjudication_summary.json',summary)
report='''# Phase 07 — Shard 2 (Conversation B)

**Status: %s**. The two-shard arrangement is a user-authorized procedural exception; protocol version remains **10.6**.

## Immutable source identity

- Original PDF: %s, 90 physical pages.
- Eight original Markdown specifications: SHA-256 equality with the externally recorded source map verified.
- Original queue: %s; external records: %s.
- Reference R (638) and N (142) unchanged; Shard 1 adjudications unchanged.
- Shard 2 covers 2,578 unique IDs (R 319, N 71, G 2,188); IDs are disjoint from Shard 1 and their union covers 5,156 original queue IDs.

## Shard 2 item results

| Direction | TP | FN | FP | TN | Excluded | Total |
|---|---:|---:|---:|---:|---:|---:|
| R | %d | %d | — | — | 0 | 319 |
| N | — | — | %d | %d | 0 | 71 |
| G (diagnostic only) | %d | — | %d | — | %d | 2,188 |

Every eligible adjudication uses its fixed direction-specific Phase 07 cell. Excluded nondefinitive passages do not contribute TN. Generated-class TP does not increase canonical R TP. Generated-class FP is *not* yet the deduplicated canonical FP residual and must be reconciled against negative controls and duplicate classes in Phase 08.

## Evidence and independent review

- Original-PDF quotations verified: %d.
- Original-generated Markdown quotations verified: %d.
- Phase 04 source-to-generated reciprocal links and Phase 05 full-90-page generated-to-PDF evidence candidates were examined as applicable.
- Negative controls were considered with the distinction between an affirmative forbidden claim and a prohibition of that claim.
- Quoted source text, original source filename, SHA-256 and original line/page location are preserved separately from the v5 suggestion.
- A split source atom's latest effective final statement was used rather than importing predicates from a superseded composite source atom.

## Known limitations and handoff

The previous external run used `gpt-6.2-sol` although the governing Version 10.6 protocol specifies `gpt-6.1-sol`. Model settings should not be silently treated as cross-method comparable. Lexical matching and physical quotations establish evidence provenance; full semantic entailment is a substantive interpretation and remains subject to evidence-recorded supersession if a contradiction is identified.

Conversation C must verify this shard with the immutable Shard 1 outputs, all 5,156 queue IDs, diagnostic G exclusions, negative-control overlaps, and exact duplicate/residual identity before declaring Phase 07 complete. No Phase 08 or Phase 09 work has been executed.
'''%(status,run['pdf_sha256'],run['queue_sha256'],lock['external_decisions_sha256'],recon[('R','TP')],recon[('R','FN')],recon[('N','FP')],recon[('N','TN')],recon[('G','TP')],recon[('G','FP')],recon[('G','EXCLUDED')],sum(len(z['pdf_evidence']) for z in adjudications),sum(len(z['generated_evidence']) for z in adjudications))
(OUT/'07_shard2_phase_report.md').write_text(report,encoding='utf-8')
paths=['07_shard2_adjudications.jsonl','07_shard2_decision_audit.jsonl','07_shard2_adjudication_summary.json','07_shard2_input_blockers.jsonl','07_shard2_phase_report.md']
manifest={'protocol_version':'10.6','method':'fullload','shard_id':2,'status':status,'files_sha256':{f:sha(OUT/f) for f in paths}}
dump(OUT/'07_shard2_output_manifest.json',manifest)
print(json.dumps(summary,ensure_ascii=False,indent=2))
