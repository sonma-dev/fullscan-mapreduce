# Phase 07 — Shard 2 (Conversation B)

**Status: COMPLETE**. The two-shard arrangement is a user-authorized procedural exception; protocol version remains **10.6**.

## Immutable source identity

- Original PDF: b71541e74564559d2cc0a84e9827086946998fbc6c627488fb9e7a7f9b0137c3, 90 physical pages.
- Eight original Markdown specifications: SHA-256 equality with the externally recorded source map verified.
- Original queue: f0ee6dac19a32e41c2a83c1030bff2ddcf904d1e7a516b609853e22599d4981a; external records: 8267e2b1a8d937c35dfe0e94c84b1a2168821e5c3f0e9d0efa5e6aa7bc332b84.
- Reference R (638) and N (142) unchanged; Shard 1 adjudications unchanged.
- Shard 2 covers 2,578 unique IDs (R 319, N 71, G 2,188); IDs are disjoint from Shard 1 and their union covers 5,156 original queue IDs.

## Shard 2 item results

| Direction | TP | FN | FP | TN | Excluded | Total |
|---|---:|---:|---:|---:|---:|---:|
| R | 245 | 74 | — | — | 0 | 319 |
| N | — | — | 0 | 71 | 0 | 71 |
| G (diagnostic only) | 1726 | — | 82 | — | 380 | 2,188 |

Every eligible adjudication uses its fixed direction-specific Phase 07 cell. Excluded nondefinitive passages do not contribute TN. Generated-class TP does not increase canonical R TP. Generated-class FP is *not* yet the deduplicated canonical FP residual and must be reconciled against negative controls and duplicate classes in Phase 08.

## Evidence and independent review

- Original-PDF quotations verified: 16226.
- Original-generated Markdown quotations verified: 7429.
- Phase 04 source-to-generated reciprocal links and Phase 05 full-90-page generated-to-PDF evidence candidates were examined as applicable.
- Negative controls were considered with the distinction between an affirmative forbidden claim and a prohibition of that claim.
- Quoted source text, original source filename, SHA-256 and original line/page location are preserved separately from the v5 suggestion.
- A split source atom's latest effective final statement was used rather than importing predicates from a superseded composite source atom.

## Known limitations and handoff

The previous external run used `gpt-6.2-sol` although the governing Version 10.6 protocol specifies `gpt-6.1-sol`. Model settings should not be silently treated as cross-method comparable. Lexical matching and physical quotations establish evidence provenance; full semantic entailment is a substantive interpretation and remains subject to evidence-recorded supersession if a contradiction is identified.

Conversation C must verify this shard with the immutable Shard 1 outputs, all 5,156 queue IDs, diagnostic G exclusions, negative-control overlaps, and exact duplicate/residual identity before declaring Phase 07 complete. No Phase 08 or Phase 09 work has been executed.
