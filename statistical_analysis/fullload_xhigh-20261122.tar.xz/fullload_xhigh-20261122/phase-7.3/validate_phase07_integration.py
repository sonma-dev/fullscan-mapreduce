#!/usr/bin/env python3
"""Independent verification for Phase 07 integration, no semantic re-adjudication or Phase 08 scoring."""
from collections import Counter
from pathlib import Path
import hashlib, json, zipfile
P=Path('/mnt/data/oriondesk_fullload_v10_6/phase07');R=Path('/mnt/data');P6=P.parent/'phase06'
checks={}
def ck(name,condition):
 checks[name]=bool(condition)
 if not condition: raise AssertionError(name)
def digest(x):return hashlib.sha256(x.read_bytes()).hexdigest()
def readjson(name):return json.loads((P/name).read_text(encoding='utf8'))
def readrows(path):
 with path.open(encoding='utf8') as f:return [json.loads(x) for x in f if x.strip()]
lock=readjson('07_partition_lock.json');sm=readjson('07_adjudication_summary.json');report=readjson('07_integration_validation.json')
for name,sha in lock['source_actual_file_sha256'].items():ck('source_'+name,digest(R/name)==sha)
for name,key in [('semantic_decisions(2).jsonl','external_decisions_sha256'),('semantic_summary(1).json','external_summary_sha256'),('run_state(1).json','run_state_sha256'),('batch_journals(1).zip','batch_journals_zip_sha256')]:ck('ext_'+key,digest(R/name)==lock[key])
ck('queue_hash',digest(P6/'06_llm_queue_v10.6.jsonl')==lock['queue_sha256'])
ck('R_hash',digest(R/'common_atomic_reqs(4).jsonl')==lock['frozen_r_sha256'])
ck('N_hash',digest(R/'common_negative_controls(4).jsonl')==lock['frozen_n_sha256'])
orig_a=readrows(P/'07_shard1_final_adjudications.jsonl');orig_b=readrows(P/'07_shard2_adjudications.jsonl')
assigned_a=readrows(P/'07_shard1_assigned_items.jsonl');assigned_b=readrows(P/'07_shard2_assigned_items.jsonl')
ck('shard_counts',len(orig_a)==len(orig_b)==len(assigned_a)==len(assigned_b)==2578)
ck('assigned_shard1_equals_decisions',set(x['item_id'] for x in orig_a)==set(x['item_id'] for x in assigned_a))
ck('assigned_shard2_equals_decisions',set(x['item_id'] for x in orig_b)==set(x['item_id'] for x in assigned_b))
ck('shards_disjoint',set(x['item_id'] for x in orig_a).isdisjoint(set(x['item_id'] for x in orig_b)))
q=readrows(P6/'06_llm_queue_v10.6.jsonl');ck('queue_5156',len(q)==5156)
ck('queue_exact_unique',len(set(x['item_id'] for x in q))==5156)
ck('source_shard_universe',set(x['item_id'] for x in q)==set(x['item_id'] for x in orig_a+orig_b))
source_r={x['requirement_id'] for x in readrows(R/'common_atomic_reqs(4).jsonl')};source_n={x['control_id'] for x in readrows(R/'common_negative_controls(4).jsonl')}
ck('R_source_count',len(source_r)==638)
ck('N_source_count',len(source_n)==142)
active=readrows(P/'07_assistant_adjudications.jsonl');excluded=readrows(P/'07_eligibility_exclusions.jsonl');idx=readrows(P/'07_phase07_population_index.jsonl')
ck('all_population_count',len(active)+len(excluded)==len(idx)==5156)
ck('population_has_queue_order',[x['item_id'] for x in idx]==[x['item_id'] for x in q])
ck('population_identical_id_universe',set(x['item_id'] for x in idx)==set(x['item_id'] for x in active+excluded))
ck('no_duplicate_active_ids',len(set(x['item_id'] for x in active))==len(active))
ck('no_duplicate_exclusion_ids',len(set(x['item_id'] for x in excluded))==len(excluded))
ck('active_exclusion_disjoint',set(x['item_id'] for x in active).isdisjoint(set(x['item_id'] for x in excluded)))
ck('R_exact_reference_ids',{x['item_id'] for x in active if x['direction']=='R'}==source_r)
ck('N_exact_reference_ids',{x['item_id'] for x in active if x['direction']=='N'}==source_n)
ck('eligible_R_binary',all(x['final_cell'] in ('TP','FN') for x in active if x['direction']=='R'))
ck('eligible_N_binary',all(x['final_cell'] in ('FP','TN') for x in active if x['direction']=='N'))
ck('eligible_G_binary',all(x['final_cell'] in ('TP','FP') for x in active if x['direction']=='G'))
ck('excluded_G_only',all(x['direction']=='G' and x['final_cell'] is None for x in excluded))
ck('no_final_unresolved',all(x['final_cell'] not in (None,'UNRESOLVED') for x in active))
ck('all_source_identity',all(x['source_pdf_sha256']==lock['pdf_sha256'] and x['source_reference_unchanged'] is True for x in active+excluded))
ck('all_assistant_origin',all(x['decision_origin']=='PHASE07_ASSISTANT' for x in active+excluded))
ck('no_extraneous_score_vocabulary',all('BEST_EFFORT' not in x and 'unreliable' not in x for x in active+excluded))
counts=Counter((x['direction'],x['final_cell']) for x in active)
ck('tp_fn_r_formula',counts['R','TP']+counts['R','FN']==638)
ck('tn_fp_n_formula',counts['N','TN']+counts['N','FP']==142)
ck('gc_class_formula',counts['G','TP']+counts['G','FP']+len(excluded)==4376)
ck('reported_summary_counts',sm['binary_and_diagnostic_cells']=={'R_TP':counts['R','TP'],'R_FN':counts['R','FN'],'N_FP':counts['N','FP'],'N_TN':counts['N','TN'],'G_SUPPORTED_DIAGNOSTIC_TP':counts['G','TP'],'G_UNSUPPORTED_DIAGNOSTIC_FP_CANDIDATES':counts['G','FP'],'G_NONDEFINITIVE_EXCLUSIONS':len(excluded)})
ck('old_shard_hashes_preserved',all(digest(P/f)==h for f,h in sm['original_shard_files'].items()))
sup=readrows(P/'07_superseding_adjudications.jsonl');ck('exact_two_supersessions',set(x['item_id'] for x in sup)=={'GCLASS-0003481','GCLASS-0003705'} and len(sup)==2)
idxid={x['item_id']:x for x in idx}
ck('superseded_exclusion',idxid['GCLASS-0003481']['eligibility']=='EXCLUDED_NONDEFINITIVE' and idxid['GCLASS-0003481']['active_cell'] is None)
ck('superseded_supported',idxid['GCLASS-0003705']['active_cell']=='TP')
orig={x['item_id']:x for x in orig_a+orig_b}
ck('supersessions_preserve_prior_cells',all(x['prior_final_cell']==orig[x['item_id']]['final_cell'] for x in sup))
ck('supersessions_original_hashes',all(x['superseded_record_sha256']==hashlib.sha256(json.dumps(orig[x['item_id']],sort_keys=True,ensure_ascii=False,separators=(',',':')).encode()).hexdigest() for x in sup))
ck('phase08_not_started',sm['phase08_not_started'] and sm['canonical_fp_residual_semantic_dedup']=='DEFERRED_TO_PHASE08')
ck('cross_method_warning',sm['external_configuration_warning']['cross_method_comparability']=='NOT_ESTABLISHED')
ck('input_blocker_empty',(P/'07_input_blockers.jsonl').stat().st_size==0)
records=readrows(P/'07_decision_audit.jsonl')
ck('audit_all_5156',sum(x.get('record_type')=='PHASE07_INTEGRATION_ITEM_AUDIT' for x in records)==5156)
ck('risk_10_recorded',sum(x.get('record_type')=='PHASE07_CROSS_SHARD_CONSISTENCY_CHECK' for x in records)==10)
ck('quote_1_recorded',sum(x.get('record_type')=='PHASE07_PROVENANCE_QUOTE_CORRECTION' for x in records)==1)
ck('audit_immutable_link',all(x['original_shard_record_sha256']==hashlib.sha256(json.dumps(orig[x['item_id']],sort_keys=True,ensure_ascii=False,separators=(',',':')).encode()).hexdigest() for x in idx))
ck('all_quote_checks_declared',sm['original_quote_verification']=={'generated_original_literals_verified':13994,'pdf_original_text_literals_verified':22110,'pdf_original_visual_evidence_verified':3})
ck('no_duplicated_source_type',all(x['record_type']=='ASSISTANT_ADJUDICATION' for x in active))
ck('no_excluded_as_tn',all(x['record_type']=='PHASE07_NONDEFINITIVE_EXCLUSION' for x in excluded))
ck('summary_count_eligible',sm['population']['eligible_final_binary_items']==len(active))
ck('summary_count_excluded',sm['population']['nondefinitive_excluded_items']==len(excluded))
# Full v5-journal content comparison, independent of the integration implementation.
prior=readrows(R/'semantic_decisions(2).jsonl');v5={x['item_id']:x for x in prior};
with zipfile.ZipFile(R/'batch_journals(1).zip') as z:
 ck('ZIP_integrity',z.testzip() is None)
 js=[x for x in z.namelist() if x.endswith('.json')];ck('323_archived_journals',len(js)==323)
 batch_items={}
 for f in js:
  j=json.loads(z.read(f));ck('j'+f.split('/')[-1],j['queue_sha256']==lock['queue_sha256'] and j['pdf_sha256']==lock['pdf_sha256'])
  for e in j['item_records']:
   assert e['item_id'] not in batch_items
   batch_items[e['item_id']]=e
 ck('all_journal_v5_IDs_match',set(batch_items)==set(v5))
 ck('all_journal_v5_record_contents_match',all(batch_items[i]==v5[i] for i in batch_items))
for x in active+excluded:
 ck('sha_item_'+x['item_id'],x['v5_record_sha256']==hashlib.sha256(json.dumps(v5[x['item_id']],sort_keys=True,ensure_ascii=False,separators=(',',':')).encode()).hexdigest())
metadata={'record_type':'PHASE07_INDEPENDENT_VALIDATION','status':'PASS','checks_passed':sum(checks.values()),'checks_failed':[k for k,v in checks.items() if not v],'population_total':len(idx),'eligible_binary_total':len(active),'excluded_nondefinitive_total':len(excluded),'counts':{f'{d}_{c}':v for (d,c),v in counts.items()},'source_reference_unchanged':True,'phase08_not_started':True,'caveat_en':'Mechanical and quote provenance validation does not prove exhaustive semantic entailment; targeted cross-shard consistency corrections have explicit evidence-linked supersession.'}
(P/'07_independent_integration_validation.json').write_text(json.dumps(metadata,ensure_ascii=False,sort_keys=True,indent=2)+'\n')
print(json.dumps({'status':'PASS','checks':metadata['checks_passed'],'eligible_binary':len(active),'excluded':len(excluded),'counts':metadata['counts']}))
