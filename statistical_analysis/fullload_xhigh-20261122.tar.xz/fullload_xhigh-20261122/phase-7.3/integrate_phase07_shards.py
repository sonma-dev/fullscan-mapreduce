#!/usr/bin/env python3
"""Phase 07 / v10.6: immutable shard integration, source identity checks and explicit supersessions.
No Phase 08 residual deduplication or final metrics are performed here.
"""
from __future__ import annotations
import json, hashlib, os, copy, re, unicodedata, collections, zipfile
from pathlib import Path
import fitz
from sklearn.feature_extraction.text import TfidfVectorizer

ROOT=Path('/mnt/data'); OUT=ROOT/'oriondesk_fullload_v10_6'/'phase07'; P6=OUT.parent/'phase06'
def sha(path):
 h=hashlib.sha256()
 with open(path,'rb') as f:
  for b in iter(lambda:f.read(2**20),b''): h.update(b)
 return h.hexdigest()
def jj(x):return json.dumps(x,sort_keys=True,ensure_ascii=False,separators=(',',':'))
def wh(name,records):
 path=OUT/name
 with path.open('w',encoding='utf8',newline='\n') as f:
  for record in records:f.write(jj(record)+'\n')
 return path
def jrows(path):
 with open(path,encoding='utf8') as f:
  for n,s in enumerate(f,1):
   if s.strip(): yield json.loads(s)
def dump(name,obj):
 path=OUT/name;path.write_text(json.dumps(obj,ensure_ascii=False,indent=2,sort_keys=True)+'\n',encoding='utf8');return path

def norm(t):return re.sub(r'\s+',' ',unicodedata.normalize('NFKC',t or '')).strip()

lock=json.loads((OUT/'07_partition_lock.json').read_text())
assert lock['protocol_version']=='10.6' and lock['assignment_exhaustive'] and lock['assignment_disjoint']
for name,hashval in lock['source_actual_file_sha256'].items(): assert sha(ROOT/name)==hashval,('source digest',name)
for name,key in [('semantic_decisions(2).jsonl','external_decisions_sha256'),('semantic_summary(1).json','external_summary_sha256'),('run_state(1).json','run_state_sha256'),('batch_journals(1).zip','batch_journals_zip_sha256')]:assert sha(ROOT/name)==lock[key],name
queue=P6/'06_llm_queue_v10.6.jsonl';assert sha(queue)==lock['queue_sha256']
assert sha(ROOT/'common_atomic_reqs(4).jsonl')==lock['frozen_r_sha256']
assert sha(ROOT/'common_negative_controls(4).jsonl')==lock['frozen_n_sha256']
q=list(jrows(queue)); qids=[r['item_id'] for r in q];assert len(qids)==5156 and len(set(qids))==5156
original_v5=list(jrows(ROOT/'semantic_decisions(2).jsonl'));v5={r['item_id']:r for r in original_v5}
assert len(v5)==len(original_v5)==5156 and set(v5)==set(qids)
s1=list(jrows(OUT/'07_shard1_final_adjudications.jsonl'));s2=list(jrows(OUT/'07_shard2_adjudications.jsonl'))
assigned1=list(jrows(OUT/'07_shard1_assigned_items.jsonl'));assigned2=list(jrows(OUT/'07_shard2_assigned_items.jsonl'))
assert len(s1)==len(s2)==len(assigned1)==len(assigned2)==2578
assert set(r['item_id'] for r in s1)==set(r['item_id'] for r in assigned1)
assert set(r['item_id'] for r in s2)==set(r['item_id'] for r in assigned2)
assert set(r['item_id'] for r in s1).isdisjoint(set(r['item_id'] for r in s2))
assert set(r['item_id'] for r in s1+s2)==set(qids)
assign={r['item_id']:r for r in assigned1+assigned2}; original={r['item_id']:r for r in s1+s2}
for i in qids:
 d=original[i];v=v5[i]
 assert d['direction']==v['direction']==assign[i]['direction']; assert d['method']=='fullload'
 assert d['prior_v5_suggested_decision']==v['suggested_decision']
 assert d['prior_v5_decision_status']==v['decision_status']
 assert d['was_external_llm_selected'] is True and d['source_reference_unchanged'] is True
 assert d['source_pdf_sha256']==lock['pdf_sha256']
 assert d['v5_record_sha256']==hashlib.sha256(jj(v).encode()).hexdigest()
 assert d['v5_original_model_json_sha256']==hashlib.sha256(jj(v['model_json']).encode()).hexdigest()
 assert d['v5_batch_id']==v['batch_id']
 assert all(d['generated_file_sha256'].get((name.split('(')[0]+'.md' if '(' in name else name))==digest for name,digest in lock['source_actual_file_sha256'].items() if name.endswith('.md'))

# Verify committed journals and v5 batch membership (not a new external evaluation).
zipf=zipfile.ZipFile(ROOT/'batch_journals(1).zip');assert zipf.testzip() is None
zfiles=[s for s in zipf.namelist() if s.endswith('.json')]
assert len(zfiles)==323
jitems={}
for f in zfiles:
 j=json.loads(zipf.read(f));assert j['batch_id']==Path(f).stem
 assert j['queue_sha256']==lock['queue_sha256'] and j['pdf_sha256']==lock['pdf_sha256']
 assert len(j['item_records'])==j['batch_size']
 for x in j['item_records']:
  assert x['item_id'] not in jitems
  jitems[x['item_id']]=x
assert set(jitems)==set(v5)

# Two evidenced supersessions, without rewriting either original shard.
supersessions=[]
for item_id,old_cell,new_cell,old_elig,new_elig,rule,reason,proof in [
 ('GCLASS-0003481','TP',None,'DEFINITIVE','EXCLUDED_NONDEFINITIVE','P7-G-ELIGIBILITY_EXCLUSION',
  'The statement in BR conflict register CON-BR-005 is a description of an unresolved discrepancy between source passages. Its source-evidence-and-issue cell does not impose an independent affirmative implementation or test obligation. The equivalent API conflict-register entry GCLASS-0001369 was excluded on the same eligibility rule. The underlying actual self-approval prohibition is independently extracted in other definitive classes.',
  [{'generated_file':'05_business_rules(4).md','line':1369,'quote_en':'Explicit high-risk self-approval prohibition versus broader `no self approval` and example false setting.'}, {'pdf_page':11,'quote_en':'An analyst may request a draft but cannot approve their own high-risk recommendation.'}]),
 ('GCLASS-0003705','FP','TP','DEFINITIVE','DEFINITIVE','P7-G-SUPPORTED',
  'The actual atomic generated clause is the prohibition on presenting a denied/more-evidence/review outcome as approved or published success, not a requirement to display each policy outcome in a particular UI control. The PDF explicitly prohibits representing partial processing as an approved answer and restricts final publication to the evidence and approval gate. The prior shard-1 FP explanation attributed an adjacent distinct-display clause to this atomic item; GCLASS-0003704 already separately covers that adjacent clause.',
  [{'generated_file':'06_exception_handling(6).md','line':274,'quote_en':'Do not present it as approved/published success.'}, {'pdf_page':13,'quote_en':'Partial processing must never be misrepresented as an approved answer.'}, {'pdf_page':12,'quote_en':'The final reply is published only when required evidence exists and the approval policy is satisfied.'}])
]:
 prev=original[item_id];assert prev['shard_id']==1 and prev['final_cell']==old_cell and prev['eligibility_status']==old_elig
 entry={'record_type':'PHASE07_SUPERSEDING_ADJUDICATION','protocol_version':'10.6','item_id':item_id,'direction':'G','method':'fullload','shard_origin':1,'superseded_record_sha256':hashlib.sha256(jj(prev).encode()).hexdigest(),'prior_final_cell':old_cell,'new_final_cell':new_cell,'prior_eligibility':old_elig,'new_eligibility':new_elig,'new_rule_id':rule,'reason_en':reason,'verified_evidence':proof,'source_pdf_sha256':lock['pdf_sha256'],'source_reference_unchanged':True,'original_shard_preserved':True}
 supersessions.append(entry)

sup_map={x['item_id']:x for x in supersessions}
new=[];aud=[];corrections=[]
for pos,item_id in enumerate(qids,1):
 before=original[item_id];rec=copy.deepcopy(before)
 rec['protocol_version']='10.6';rec['execution_version']='10.6'
 rec['record_type']='ASSISTANT_ADJUDICATION' if rec['final_cell'] is not None else 'PHASE07_NONDEFINITIVE_EXCLUSION'
 rec['phase07_integration_order']=pos
 rec['original_shard_id']=before['shard_id']
 rec['original_shard_record_sha256']=hashlib.sha256(jj(before).encode()).hexdigest()
 if item_id in sup_map:
  x=sup_map[item_id]
  rec['final_cell']=x['new_final_cell'];rec['eligibility_status']=x['new_eligibility'];rec['decision_rule_id']=x['new_rule_id'];rec['decision_reason_en']=x['reason_en'];rec['unmet_predicates_en']=[]
  rec['canonical_counting_scope']=('G_DIAGNOSTIC_NOT_CANONICAL_TP' if x['new_final_cell']=='TP' else 'NONDEFINITIVE_EXCLUDED_NOT_SCORED')
  rec['integration_supersession']={'prior_record_sha256':x['superseded_record_sha256'],'reference':'07_superseding_adjudications.jsonl'}
 # Preserve immutable old v5 raw record, correcting only observed quotation-case transcription.
 if item_id=='GCLASS-0001813':
  for evid in rec['pdf_evidence']:
   if evid.get('physical_page')==22 and evid.get('quote_en')=='each tenant-owned row has tenant_id':
    evid['original_shard_quote_en']=evid['quote_en'];evid['quote_en']='Each tenant-owned row has tenant_id'
    evid['phase07_integration_quote_case_correction']=True
    corrections.append({'record_type':'PHASE07_PROVENANCE_QUOTE_CORRECTION','item_id':item_id,'physical_page':22,'reported_quote_en':'each tenant-owned row has tenant_id','corrected_literal_quote_en':'Each tenant-owned row has tenant_id','original_shard_preserved':True})
 rec['record_type']='ASSISTANT_ADJUDICATION' if rec['final_cell'] is not None else 'PHASE07_NONDEFINITIVE_EXCLUSION'
 new.append(rec)
 aud.append({'record_type':'PHASE07_INTEGRATION_ITEM_AUDIT','item_id':item_id,'direction':rec['direction'],'shard':rec['original_shard_id'],'source_queue_position':pos,'original_shard_record_sha256':rec['original_shard_record_sha256'],'active_cell':rec['final_cell'],'active_eligibility':rec['eligibility_status'],'rule':rec['decision_rule_id'],'superseded':item_id in sup_map,'source_pdf_sha256':lock['pdf_sha256'],'v5_original_suggestion':rec['prior_v5_suggested_decision'],'v5_original_status':rec['prior_v5_decision_status'],'original_v5_record_sha256':rec['v5_record_sha256'],'originals_unchanged':True})

# Original quotation provenance. Image-only evidence must be visually inspected, not treated as parsed text.
source_map={name.split('(')[0]: name for name in lock['source_actual_file_sha256'] if name.endswith('.md')}
lines={stem:(ROOT/actual).read_text(encoding='utf8').splitlines() for stem,actual in source_map.items()}
pdf=fitz.open(ROOT/'OrionDesk_AI_Detailed_Design_Specification(4).pdf')
pagetxt={i+1:norm(pg.get_text(sort=False)) for i,pg in enumerate(pdf)}
visual_accepted={('GCLASS-0000237',7,'DECISION GATE'),('PDF-0410',78,'immutable evidence and versioned policy inputs'),('PDF-0544',78,'tenant_id and actor context at every boundary')}
errors=[];counts=collections.Counter();quote_checks={}
for rec in new:
 id=rec['item_id'];t={'generated':0,'pdf_literal':0,'pdf_visual':0};
 for e in rec['generated_evidence']:
  f=e.get('file','');stem=f.split('(')[0].removesuffix('.md');start=e.get('line_start');end=e.get('line_end')
  if stem not in lines or not isinstance(start,int) or not isinstance(end,int) or not 1<=start<=end<=len(lines[stem]) or norm(e.get('quote_en','')) not in norm(' '.join(lines[stem][start-1:end])):
   errors.append({'item_id':id,'type':'GENERATED_ORIGINAL_QUOTE_MISMATCH','evidence':e});continue
  t['generated']+=1;counts['generated_original_literals_verified']+=1
 for e in rec['pdf_evidence']:
  pg=e.get('physical_page');qt=norm(e.get('quote_en',''))
  if pg not in pagetxt or not qt:
   errors.append({'item_id':id,'type':'PDF_LOCATOR_ERROR','evidence':e});continue
  if qt in pagetxt[pg]:t['pdf_literal']+=1;counts['pdf_original_text_literals_verified']+=1
  elif (id,pg,qt) in visual_accepted:
   t['pdf_visual']+=1;counts['pdf_original_visual_evidence_verified']+=1
  else:errors.append({'item_id':id,'type':'PDF_ORIGINAL_QUOTE_MISMATCH','evidence':e})
 quote_checks[id]=t
assert not errors,errors[:6]
assert counts['pdf_original_visual_evidence_verified']==3
# Supplemental cross-shard semantic high-similarity inspection (distinct obligations retain own cell).
Rpairs=[('PDF-0407','PDF-0102','DIFFERENT_REGISTERED_ENDPOINT','SSE stream endpoint differs from run-read endpoint; no identical proposition.'),('PDF-0305','PDF-0102','DIFFERENT_REGISTERED_ENDPOINT','Run steps endpoint differs from run-read endpoint; no identical proposition.')]
Gp=[('GCLASS-0003637','GCLASS-0003636','DISTINCT_CLAIM','Provider 429 occurrence differs from claimed user-facing persistence of upstream throttling.'),('GCLASS-0003705','GCLASS-0003704','EVIDENCED_SUPERSESSION','Nonpublication prohibition is independently supported; specific distinct-outcome presentation is a separate obligation.'),('GCLASS-0003616','GCLASS-0003615','DISTINCT_CLAIM','Absence of an invented duplicate-specific HTTP code is commentary; duplicate consumer outcome recording is a definitive duty.'),('GCLASS-0003734','GCLASS-0003735','DISTINCT_CLAIM','User-facing indexing/workflow status projection differs from operational backlog alert.'),('GCLASS-0003481','GCLASS-0001369','EVIDENCED_SUPERSESSION','Both are conflict-register descriptions and are nondefinitive after consistent eligibility review.'),('GCLASS-0001315','GCLASS-0001316','DISTINCT_CLAIM','Unresolved input-condition phrasing differs from definitive publication gate outcome.'),('GCLASS-0001974','GCLASS-0001973','DISTINCT_CLAIM','Acceptance prerequisites differ from macro execution prohibition.'),('GCLASS-0001321','GCLASS-0001322','DISTINCT_CLAIM','Test stimulus differs from expected authorized override outcome.')]
cross=[]
for aid,bid,status,reason in Rpairs+Gp:
 cross.append({'record_type':'PHASE07_CROSS_SHARD_CONSISTENCY_CHECK','shard1_item_id':aid,'shard2_item_id':bid,'initial_shard1_cell':original[aid]['final_cell'],'initial_shard2_cell':original[bid]['final_cell'],'final_shard1_cell':next(x['final_cell'] for x in new if x['item_id']==aid),'final_shard2_cell':next(x['final_cell'] for x in new if x['item_id']==bid),'review_conclusion':status,'source_grounded_reason_en':reason,'original_shards_unchanged':True})

# Canonical population integrity and phase 7 scoring rule (excluding nondefinitive generated classes).
assert len(new)==5156
active=[d for d in new if d['eligibility_status']=='DEFINITIVE']
excluded=[d for d in new if d['eligibility_status']=='EXCLUDED_NONDEFINITIVE']
assert len(active)+len(excluded)==5156
assert all(d['final_cell'] in ({'TP','FN'} if d['direction']=='R' else {'TN','FP'} if d['direction']=='N' else {'TP','FP'}) for d in active)
assert all(d['final_cell'] is None and d['direction']=='G' for d in excluded)
R=[d for d in active if d['direction']=='R'];N=[d for d in active if d['direction']=='N'];G=[d for d in active if d['direction']=='G']
assert len(R)==638 and len(N)==142 and len(R)+len(N)+len(G)+len(excluded)==5156
assert len({d['item_id'] for d in new})==5156
counts_cell=collections.Counter((d['direction'],d['final_cell']) for d in new if d['final_cell'] is not None)
assert counts_cell[('R','TP')]+counts_cell[('R','FN')]==638
assert counts_cell[('N','FP')]+counts_cell[('N','TN')]==142
ids_by_direction={direction:[d['item_id'] for d in new if d['direction']==direction] for direction in ('R','N','G')}
assert list(ids_by_direction.keys())==['R','N','G']
assert len(ids_by_direction['G'])==4376
external_suggestions=collections.Counter(str(v['suggested_decision']) for v in v5.values())
conf_diff={'protocol_model':'gpt-6.1-sol','external_model':'gpt-6.2-sol','cross_method_comparability':'NOT_ESTABLISHED','protocol_requested_reasoning_effort':'high','source_external_reasoning_effort':'high'}
assert all(d['decision_origin']=='PHASE07_ASSISTANT' for d in new)
assert all(d['source_reference_unchanged'] is True for d in new)
assert all('BEST_EFFORT' not in d and 'unreliable' not in d for d in new)

wh('07_assistant_adjudications.jsonl',active)
wh('07_eligibility_exclusions.jsonl',excluded)
wh('07_phase07_population_index.jsonl',[{'record_type':'PHASE07_POPULATION_ITEM','item_id':d['item_id'],'direction':d['direction'],'original_shard_id':d['original_shard_id'],'active_cell':d['final_cell'],'eligibility':d['eligibility_status'],'decision_rule_id':d['decision_rule_id'],'original_shard_record_sha256':d['original_shard_record_sha256'],'superseded':d['item_id'] in sup_map} for d in new])
wh('07_decision_audit.jsonl',aud+cross+corrections)
wh('07_superseding_adjudications.jsonl',supersessions)
wh('07_input_blockers.jsonl',[])

diagnostic={'R_TP':counts_cell[('R','TP')],'R_FN':counts_cell[('R','FN')],'N_FP':counts_cell[('N','FP')],'N_TN':counts_cell[('N','TN')],'G_SUPPORTED_DIAGNOSTIC_TP':counts_cell[('G','TP')],'G_UNSUPPORTED_DIAGNOSTIC_FP_CANDIDATES':counts_cell[('G','FP')],'G_NONDEFINITIVE_EXCLUSIONS':len(excluded)}
summary={'record_type':'PHASE07_ADJUDICATION_SUMMARY','status':'COMPLETE','protocol_version':'10.6','execution_version':'10.6','method':'fullload','phase08_not_started':True,'no_final_precision_recall_f1_calculated':True,'phase07_three_conversation_operator_exception':True,'source_pdf_sha256':lock['pdf_sha256'],'frozen_r_sha256':lock['frozen_r_sha256'],'frozen_n_sha256':lock['frozen_n_sha256'],'queue_sha256':lock['queue_sha256'],'external_decisions_sha256':lock['external_decisions_sha256'],'original_shard_files':{name:sha(OUT/name) for name in ['07_shard1_final_adjudications.jsonl','07_shard2_adjudications.jsonl','07_shard1_assigned_items.jsonl','07_shard2_assigned_items.jsonl']},'input_sources':lock['source_actual_file_sha256'],'population':{'total_external_items':5156,'shard1_records':2578,'shard2_records':2578,'eligible_final_binary_items':len(active),'nondefinitive_excluded_items':len(excluded),'final_semantic_unresolved_eligible':0,'missing_ids':0,'duplicate_ids':0,'v5_original_unresolved_review_items':720,'v5_suggestions_distribution':dict(external_suggestions)},'binary_and_diagnostic_cells':diagnostic,'source_control_equations':{'R_TP_plus_FN_equals_638':True,'N_FP_plus_TN_equals_142':True,'G_supported_plus_unsupported_plus_excluded_equals_4376':True},'all_ids_by_direction':ids_by_direction,'eligible_generated_ids':[d['item_id'] for d in G],'nondefinitive_excluded_ids':[d['item_id'] for d in excluded],'superseding_item_ids':[x['item_id'] for x in supersessions],'supersession_count':len(supersessions),'cross_shard_semantic_risk_comparisons':len(cross),'cross_shard_semantic_risks_resolved_with_original_evidence':len(cross),'original_quote_verification':dict(counts),'source_pdf_visual_evidence_pages':[7,78],'quotation_transcription_corrections':corrections,'external_configuration_warning':conf_diff,'canonical_fp_residual_semantic_dedup':'DEFERRED_TO_PHASE08','notes_en':['Diagnostic G:TP does not create additional canonical R:TP.','Diagnostic G:FP is not the final count of distinct unsupported residual false positives.','Original v5 batch journals and both shard files remain unmodified.','Quotation existence is not independent expert certification of every semantic classification.']}
dump('07_adjudication_summary.json',summary)

report=f'''# Phase 07 / Three-conversation Shard Integration (Version 10.6)

## Status
COMPLETE. Phase 08 has not begun. This was the operator-authorized multi-conversation execution exception; all other Phase 07 decision semantics remain unchanged.

## Input integrity
- Frozen authoritative PDF: 90 physical pages; SHA-256 `{lock['pdf_sha256']}`.
- Eight original Markdown roles matched the recorded SHA-256. Frozen R/N and the 5,156-item queue matched the lock.
- Original 5,156 external per-item results and 323 batch journals matched their immutable identities; all ZIP members passed integrity validation.
- The Shard 1 and Shard 2 assignment ID sets are disjoint and exhaust the original queue, 2,578 each; no original phase or shard file was edited.

## Final Phase 07 item inventory
- Canonical R: TP {diagnostic['R_TP']}, FN {diagnostic['R_FN']} (638 total).
- Canonical N: FP {diagnostic['N_FP']}, TN {diagnostic['N_TN']} (142 total).
- Generated class diagnostic: supported G:TP {diagnostic['G_SUPPORTED_DIAGNOSTIC_TP']}, unsupported G:FP candidates {diagnostic['G_UNSUPPORTED_DIAGNOSTIC_FP_CANDIDATES']}, excluded nondefinitive G {len(excluded)} (4,376 total).
- Eligible item-level decisions {len(active)}. Unclassified eligible items: zero. Each ID appears once in the unified population index.

## Explicit evidence-based supersessions
- `GCLASS-0003481`: Diagnostic TP -> NONDEFINITIVE EXCLUSION. Original conflict-register *description* is not an independent affirmative obligation; compare `GCLASS-0001369`.
- `GCLASS-0003705`: Diagnostic FP -> TP. Its scoped atomic requirement prohibits falsely presenting nonpublication as approved success, directly supported by the PDF page 13; the previous rationale used its neighboring but different display requirement.
- Both earlier shard decisions remain byte-for-byte unchanged; the new, source-referenced records appear in `07_superseding_adjudications.jsonl`.

## Cross-shard semantic consistency
Ten high-similarity cross-shard pairs with differing provisional dispositions were examined. Eight involve different independently testable predicates, while two have explicit supersessions. This comparison is targeted and does not imply exhaustive all-pairs semantic equivalence across all generated classes. Cross-file residual semantic consolidation and N/FP overlap counting are Phase 08 tasks.

## Original quotation validation
- Markdown original-line quotations verified: {counts['generated_original_literals_verified']}.
- Original PDF text quotations verified: {counts['pdf_original_text_literals_verified']}.
- Image-backed quotations independently observed in source PDF figures: {counts['pdf_original_visual_evidence_verified']} (pages 7 and 78).
- One capitalization-only PDF quotation in the unified output was corrected to the precise page 22 source text; the unchanged reported wording is retained in the per-item evidence and audit journal.

## Limitations and release conditions
- The external Azure run used `gpt-6.2-sol`, while the protocol identifies `gpt-6.1-sol`. Method-comparability is **not established**, even though input/journal integrity passed. Do not report comparable cross-method metrics without an identically configured evaluation policy.
- Mechanical proof-of-quotation cannot certify unrestricted semantic entailment. The item-level assistant adjudications are the authority for Phase 08 subject to explicit evidence-preserving correction if future semantic contradictions are found.
- No Precision, Recall, F1, canonical unsupported residual deduplication or Phase 08 ledger is produced here.
'''
(OUT/'07_integration_report.md').write_text(report,encoding='utf8')

validation={'record_type':'PHASE07_SHARD_INTEGRATION_VALIDATION','protocol_version':'10.6','status':'PASS','checks':{
 'original_pdf_digest_matches':True,'original_generated_source_digests_match':True,'reference_positive_digest_matches':True,'reference_negative_digest_matches':True,'frozen_queue_digest_matches':True,'external_results_digest_matches':True,'external_summary_digest_matches':True,'external_run_state_digest_matches':True,'batch_journals_archive_digest_matches':True,'batch_journals_crc_valid':True,'all_323_batch_journals_accounted':True,'journal_item_ids_complete':True,'both_shard_assignments_disjoint':True,'both_shard_assignments_exhaustive':True,'shard1_2578_records':True,'shard2_2578_records':True,'no_item_id_duplicates':True,'v5_record_sha_matches_for_every_item':True,'v5_model_json_sha_matches_for_every_item':True,'unchanged_v5_suggestions_and_statuses':True,'all_original_quote_evidence_verified':True,'visual_pdf_evidence_inspected':True,'two_semantic_supersessions_written':True,'original_shard_files_preserved':True,'eligible_binary_decisions_complete':True,'no_missing_ids':True,'no_eligible_null_cell':True,'R_TP_plus_FN_equals_638':True,'N_FP_plus_TN_equals_142':True,'G_diagonostic_plus_exclusions_equals_4376':True,'all_10_identified_cross_shard_high_similarity_risks_reviewed':True,'phase08_not_started':True,'no_scores_calculated':True,'no_unverified_semantic_proof_promoted_as_literal_quote':True},'counts':diagnostic,'original_quote_verifications':dict(counts),'supersession_ids':[x['item_id'] for x in supersessions],'external_model_mismatch_recorded':True}
dump('07_integration_validation.json',validation)
filenames=['07_assistant_adjudications.jsonl','07_eligibility_exclusions.jsonl','07_phase07_population_index.jsonl','07_decision_audit.jsonl','07_superseding_adjudications.jsonl','07_input_blockers.jsonl','07_adjudication_summary.json','07_integration_validation.json','07_integration_report.md','integrate_phase07_shards.py']
dump('07_integration_output_manifest.json',{'record_type':'PHASE07_INTEGRATION_OUTPUT_MANIFEST','protocol_version':'10.6','files':{x:{'sha256':sha(OUT/x),'size_bytes':(OUT/x).stat().st_size} for x in filenames},'source_reference_unchanged':True})
print(json.dumps({'status':'COMPLETE','counts':diagnostic,'cross_audit':len(cross),'external_integrity':'PASS','quote_checks':dict(counts),'phase08':'NOT_STARTED'},ensure_ascii=False))
