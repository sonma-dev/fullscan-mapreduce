# Phase 07 — Conversation A / Shard 1: Evidence Adjudication (Partial)

**Status: INCOMPLETE — Not a completed Phase 07 shard.**
**Protocol:** 10.6. **Generation method:** `fullload`. **Original source:** 90-page PDF, 8 generated Markdown files, frozen R=638 and N=142.

## Source and external evidence lock

- The source PDF SHA-256 and all eight original Markdown SHA-256 values match the uploaded external run metadata.
- The full external queue has 5,156 unique IDs, with 323 successfully committed batch journals and zero final failed batches. External suggestions are preserved without modification.
- Shards were created in original direction order (R, N, G), using odd 1-based positions within each direction for shard 1 and even positions for shard 2. Assignment: R=319, N=71, G=2,188; each shard has 2,578 IDs, with zero overlap and exhaustive union.
- The external model is **`gpt-6.2-sol`**; protocol 10.6 specifies **`gpt-6.1-sol`**. This is a noncomparability risk, not silently corrected.

## Verified shard-1 work

| Population | Accepted supported | Accepted missing/unsupported | Eligibility-excluded | Still pending |
|---|---:|---:|---:|---:|
| Frozen R (319) | TP 239 | FN 80 | 0 | 0 |
| Frozen N (71) | — | — | 0 | 0; TN 71, FP 0 |
| Generated G (2,188) | Diagnostic TP 85 | Diagnostic FP 136 | 171 | 1,796 |

**Totals:** 611 evidence-recorded binary decisions and 171 separately marked nondefinitive eligibility exclusions, for 782 recorded dispositions and 1,796 still needing independent semantic review.

The 136 diagnostic G:FP items are **not canonical FP counts**. They require Phase 08 semantic consolidation and overlap checks. The 85 diagnostic G:TP items are not added to source R true positives.

## Independent mechanical verification

- Validator: 37/37 controls passed.
- Original generated Markdown quotations checked: 4,766.
- Original physical-PDF text quotations checked: 2,104.
- No invented semantic cells were created for pending IDs. A source quote is not, by itself, sufficient to prove whole-claim entailment.
- The original v5 model JSON, batch journals, reference ledgers and earlier phase files remain immutable.

## Completion gate and next operation

The pending 1,796 generated-class IDs remain in `07_shard1_pending.jsonl`. They have no finalized assistant cell. Consequently this conversation **cannot declare shard 1 complete, cannot authorize Phase 07 consolidation, and cannot proceed to Phase 08**. The proper next processing step is additional independent adjudication **within shard 1** of precisely those IDs, followed by revalidation; no status should be inferred from v5 `FULL`, `NOT_FP`, `PARTIAL` or `UNRESOLVED` alone.
