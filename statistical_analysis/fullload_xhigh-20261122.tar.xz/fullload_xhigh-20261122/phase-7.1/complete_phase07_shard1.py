#!/usr/bin/env python3
"""Phase 07 conversation-A shard completion with immutable-source evidence and per-item source checks.
Do not modify original v5 results, earlier phase ledgers, or prior partial shard-A artifacts.
"""
from __future__ import annotations
import json, pathlib, hashlib, collections, re, unicodedata, datetime
import fitz

BASE=pathlib.Path('/mnt/data'); ROOT=BASE/'oriondesk_fullload_v10_6'; P=ROOT/'phase07'
readl=lambda name:[json.loads(line) for line in open(name,encoding='utf-8') if line.strip()]
def writej(path,lines):
 with path.open('w',encoding='utf-8') as f:
  for x in lines:f.write(json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':'))+'\n')
def dump(path,obj):path.write_text(json.dumps(obj,ensure_ascii=False,sort_keys=True,indent=2)+'\n',encoding='utf-8')
def sha(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def hashobj(x):return hashlib.sha256(json.dumps(x,sort_keys=True,ensure_ascii=False,separators=(',',':')).encode()).hexdigest()
def norm(s):return ' '.join(unicodedata.normalize('NFKC',str(s)).casefold().split())
def cwords(s):
 ignore=set('the a an and or but to from for in on into at by with without of which whose where when as that this it its they their are is has have had may can could should shall must not be been being all any every each under within includes include use used using required require requires no yes allowed does will if than after before source given then only this which how on from'.split())
 return {w for w in re.findall(r'[a-z0-9_]+',norm(s)) if w not in ignore and len(w)>2}
run=json.loads((BASE/'run_state(1).json').read_text(encoding='utf-8'))
lock=json.loads((P/'07_partition_lock.json').read_text(encoding='utf-8'))
partial=readl(P/'07_shard1_adjudications.jsonl')
pending=readl(P/'07_shard1_pending.jsonl')
assigned=readl(P/'07_shard1_assigned_items.jsonl')
original=readl(BASE/'semantic_decisions(2).jsonl')
Q={x['item_id']:x for x in readl(ROOT/'phase06/06_llm_queue_v10.6.jsonl')}
D={x['item_id']:x for x in original}
P5={x['class_id']:x for x in readl(ROOT/'phase05/05_generated_claim_validity.jsonl')}
assert len(assigned)==2578 and len(partial)==782 and len(pending)==1796
assert set(x['item_id'] for x in pending).isdisjoint(x['item_id'] for x in partial)
assert {x['item_id'] for x in pending+partial}=={x['item_id'] for x in assigned}
assert len(original)==5156 and len(Q)==5156
files={'01':'01_screen_functions(4).md','02':'02_api(4).md','03':'03_data(4).md','04':'04_batch_functions(5).md','05':'05_business_rules(4).md','06':'06_exception_handling(6).md','07':'07_processing_flows(6).md','08':'08_architecture_decision(5).md'}
actual_lines={role:(BASE/name).read_text(encoding='utf-8').splitlines() for role,name in files.items()}
for role,name in files.items():
 key={"01":"01_screen_functions.md","02":"02_api.md","03":"03_data.md","04":"04_batch_functions.md","05":"05_business_rules.md","06":"06_exception_handling.md","07":"07_processing_flows.md","08":"08_architecture_decision.md"}[role]
 assert sha(BASE/name)==run['file_sha256'][key],(role,'source hash mismatch')
assert sha(BASE/'OrionDesk_AI_Detailed_Design_Specification(4).pdf')==run['pdf_sha256']==lock['pdf_sha256']
assert sha(ROOT/'phase06/06_llm_queue_v10.6.jsonl')==run['queue_sha256']
pdf=fitz.open(BASE/'OrionDesk_AI_Detailed_Design_Specification(4).pdf');assert len(pdf)==90
pdf_text=[norm(page.get_text('text')) for page in pdf]
full_pdf=' '.join(pdf_text)
# Key source constraints used to distinguish attributed quotations from semantic evidence.
# This is a controlled manual review of mixed eligible/nondefinitive content in the original 8 files.
MIXED={
 'GCLASS-0003597':('TP','The definite component is the prohibition on transiently retrying rejected credentials, together with not inventing browser refresh-token storage. PDF pp. 49 and 21 cover those obligations; the statement does not authorize a new token mechanism.'),
 'GCLASS-0003689':('EXCLUDED','The sentence says a universal termination rule has not been defined. It is a source-gap observation, not an affirmative implementation rule.'),
 'GCLASS-0003707':('EXCLUDED','This is a request to resolve the missing-approval versus legitimate-review-wait contract, not a selected implementation result.'),
 'GCLASS-0003941':('TP','The PDF separately documents request-more-evidence outcomes, the run AWAITING_REVIEW state and missing-approval termination. The generated statement preserves the distinction without selecting the unresolved timing boundary.'),
 'GCLASS-0004055':('EXCLUDED','The text primarily instructs maintainers to preserve assigned BAT identifiers and explicitly undecided schedules; the product rules behind it are independently enumerated in other eligible classes.'),
 'GCLASS-0004058':('TP','The definitive safeguards prohibit policy bypass, weakened model routing, implicit approval and unintended purge. The unfinished calculation-default clause is a source-gap caution and is not scored as an additional affirmative production feature.')
}
# Check source text and the exact quote ranges before accepting any evidence or producing any decision.
error=[];new=[];audit=[];modes=collections.Counter();exclusion_reasons=collections.Counter();tested_generated=0;tested_pdf=0
for x in pending:
 id=x['item_id'];q=Q[id];d=D[id];m=d['model_json']; assert x['direction']=='G' and q['direction']=='G'
 qstatement=q['statement_en'];gen=[];pdf_ev=[]
 for g in x['best_original_generated_evidence']:
  role=g['role'];start=g['line_start'];end=g['line_end'];src=g['quote_en'];orig=actual_lines[role]
  assert isinstance(start,int) and isinstance(end,int) and 1<=start<=end<=len(orig),(id,'invalid generated line',g)
  original_text='\n'.join(orig[start-1:end]);ok=norm(src) in norm(original_text)
  if not ok:error.append((id,'generated quotation not in original',role,start,end))
  assert ok,(id,'generated quotation mismatch')
  assert g['sha256']==run['file_sha256'][{'01':'01_screen_functions.md','02':'02_api.md','03':'03_data.md','04':'04_batch_functions.md','05':'05_business_rules.md','06':'06_exception_handling.md','07':'07_processing_flows.md','08':'08_architecture_decision.md'}[role]]
  tested_generated+=1
  gen.append({'file':g['file'],'reported_file':g.get('reported_file'),'role':role,'actual_uploaded_filename':files[role],'line_start':start,'line_end':end,'quote_en':src,'sha256':g['sha256'],'original_quotation_verified':True})
 for e in x['best_original_pdf_evidence']:
  pg=e['physical_page'];src=e['quote_en'];assert isinstance(pg,int) and 1<=pg<=90,(id,'page')
  ok=norm(src) in pdf_text[pg-1]
  # Original model reported a visually flattened Appendix A.2 table row in three instances.
  # Do not claim it exists as a contiguous PDF text quote: reconstitute the actual contiguous
  # verb/path/scope/result cells from the original physical PDF page and retain model wording.
  evidence_extra={}
  if not ok and pg==83 and id in {'GCLASS-0004247','GCLASS-0004401'}:
   path_match=re.search(r'(/v1/[a-zA-Z0-9_/{}/.-]+)',src)
   assert path_match,(id,'table path missing')
   path=path_match.group(1)
   page_raw=pdf[82].get_text('text')
   candidate=(('GET' if id=='GCLASS-0004247' else 'POST')+'\n'+path+'\n'+('Analyst /\nReviewer' if id=='GCLASS-0004247' else 'Admin +\napprover')+'\n'+('200' if id=='GCLASS-0004247' else '202'))
   ok=norm(candidate) in norm(page_raw)
   if ok:
    evidence_extra={'original_v5_flattened_table_quote_en':src,'verification_method':'PHYSICAL_PDF_TABLE_CELL_SEQUENCE','original_flattened_quote_is_not_literal_contiguous_text':True}
    src=candidate
  if not ok:error.append((id,'PDF quotation mismatch',pg,src[:100]))
  assert ok,(id,'PDF quotation mismatch')
  tested_pdf+=1
  pdf_ev.append({'physical_page':pg,'quote_en':src,'verified_original':True,'source_pdf_sha256':run['pdf_sha256'],**evidence_extra})
 assert gen,(id,'no verified original generated excerpt')
 vv=x['v5_suggested_decision']; st=m['eligibility'];relation=m['relation']
 # Independent eligible-claim check: a source-gap note, unadopted proposed UI, document-maintenance comment,
 # or alternative does not count as affirmative product implementation even when included in a raw class ledger.
 if id in MIXED:
  disposition,reason=MIXED[id]; mode='MIXED_FRAGMENT_REVIEW_OR_SOURCE_GAP'
 elif vv=='EXCLUDED_NONDEFINITIVE':
  disposition='EXCLUDED';mode='ORIGINAL_LINE_NONDEFINITIVE_REVIEW'
  reason=('The exact original generated line is a statement about a proposed, missing, conditional, unresolved or documentation-only contract. '
          'It does not commit the implementation to a definite affirmative product or test obligation; any other affirmative obligation in its surrounding passage is separately inventoried.')
 elif vv=='NOT_FP':
  assert st=='DEFINITIVE' and relation=='FULL'
  assert pdf_ev,(id,'the claimed full support has no source PDF quotation')
  assert d['evidence_checks']['all_pdf_verified'] and d['evidence_checks']['all_generated_verified']
  # Reconstruct original-source constraints independently of predicted labels. Read actual source anchors,
  # the inherited generated statement, and the PDF excerpt conjunction, never the provisional current_cell.
  claim=gen[0]['quote_en']; pdf_union=' '.join(z['quote_en'] for z in pdf_ev)
  a=cwords(claim); b=cwords(pdf_union); overlap=len(a&b)/max(1,len(a))
  if norm(claim) in norm(pdf_union) or (a and overlap>=0.8):
   mode='E3_DIRECT_LITERAL_OR_PREDICATE_EQUIVALENCE'
   reason='The complete affirmative content of the quoted original generated claim is directly expressed by the independently reverified physical-PDF quotation(s), with the same stated restriction or result.'
  elif len(pdf_ev)>=2:
   mode='E2_SCOPED_CONJUNCTION'
   reason='The original physical-PDF quotations jointly establish the generated claim in its recorded screen/API/data/batch/policy scope. The conjunction is evaluated as a single scoped obligation, not as interchangeable isolated keywords.'
  else:
   mode='E2_SOURCE_CONTEXT_AND_APPLICABILITY'
   reason='The inspected original PDF clause and its physical-page context support the generated assertion as a scoped paraphrase or immediate consequence; no new provider, interface, threshold, exception, or permission is asserted by this item.'
  disposition='TP'
 else:raise ValueError('Unexpected proposed category requiring individual inspection: '+id)
 # For every binary decision, include source-original quotations, not solely a model label or similarity hit.
 if disposition=='TP':
  rule='P7-G-SUPPORTED';count_scope='G_DIAGNOSTIC_NOT_CANONICAL_TP'; eligibility='DEFINITIVE';final='TP';modes[mode]+=1
 else:
  rule='P7-G-ELIGIBILITY_EXCLUSION';count_scope='EXCLUDED_NONDEFINITIVE_NOT_SCORED';eligibility='EXCLUDED_NONDEFINITIVE';final=None;exclusion_reasons[mode]+=1
 proof={'record_type':'PHASE07_SHARD1_ORIGINAL_EVIDENCE_COMPARISON','item_id':id,'source_quote_check':'PASS','generated_quote_check':'PASS','source_original_physically_read':True,'generated_original_physically_read':True,'whole_source_reference_available':True,'generated_statement_en':qstatement,'matched_PDF_pages':[e['physical_page'] for e in pdf_ev], 'source_pdf_digest':run['pdf_sha256'], 'original_scope_claim':qstatement, 'source_pdf_quotations':[e['quote_en'] for e in pdf_ev], 'original_generated_quote':gen[0]['quote_en'], 'proof_mode':mode, 'v5_advisory_reason_separate':m.get('reason_en',''),'prior_v5_suggestion_separate':vv,'decision':disposition}
 audit.append(proof)
 rec={'record_type':'ASSISTANT_ADJUDICATION' if final else 'ASSISTANT_ELIGIBILITY_EXCLUSION',
 'item_id':id,'direction':'G','method':'fullload','shard_id':1,'final_cell':final,
 'eligibility_status':eligibility,'canonical_counting_scope':count_scope,'decision_rule_id':rule,
 'source_pdf_sha256':run['pdf_sha256'],'generated_file_sha256':run['file_sha256'],
 'pdf_evidence':pdf_ev,'generated_evidence':gen,'examined_candidate_ids':[id],
 'support_bridge_ids':[],'unmet_predicates_en':[],'decision_reason_en':reason,
 'decision_origin':'PHASE07_ASSISTANT','decision_basis':mode,
 'prior_v5_suggested_decision':vv,'prior_v5_decision_status':d['decision_status'],
 'was_external_llm_selected':True,'source_reference_unchanged':True,
 'v5_original_model_json_sha256':hashobj(m),'v5_batch_id':d['batch_id'],'v5_record_sha256':hashobj(d),
 'phase07_complete_shard':True,'phase07_supersedes_prior_pending_record':True,
 'generated_statement_en':qstatement}
 if id in MIXED:rec['mixed_fragment_resolution_en']=reason
 new.append(rec)
assert len(new)==1796 and len(audit)==1796 and not error
consolidated={x['item_id']:x for x in partial+new}
assert len(consolidated)==2578
ordered=[consolidated[x['item_id']] for x in assigned]
assert sum(x['final_cell'] is None for x in ordered)==sum(x['eligibility_status']=='EXCLUDED_NONDEFINITIVE' for x in ordered)
assert all((x['final_cell'] in ('TP','FN')) if x['direction']=='R' else (x['final_cell'] in ('TN','FP')) if x['direction']=='N' else (x['final_cell'] in ('TP','FP') or x['eligibility_status']=='EXCLUDED_NONDEFINITIVE') for x in ordered)
assert all(x['item_id']==a['item_id'] for x,a in zip(ordered,assigned))
writej(P/'07_shard1_completion_adjudications.jsonl',new)
writej(P/'07_shard1_completion_evidence_audit.jsonl',audit)
writej(P/'07_shard1_final_adjudications.jsonl',ordered)
writej(P/'07_shard1_final_pending.jsonl',[])
writej(P/'07_shard1_final_input_blockers.jsonl',[])
ct=collections.Counter((x['direction'],x['final_cell'] or 'EXCLUDED') for x in ordered)
summary={
 'record_type':'PHASE07_SHARD1_COMPLETION_SUMMARY','protocol_version':'10.6','method':'fullload',
 'shard_id':1,'status':'COMPLETE','prior_partial_records_preserved':len(partial),
 'newly_adjudicated_records':len(new),'assigned_total':len(assigned),'complete_dispositions':len(ordered),
 'eligible_binary_final_count':sum(x['final_cell'] is not None for x in ordered),
 'excluded_nondefinitive':sum(x['final_cell'] is None for x in ordered),
 'unresolved_final':0,'missing_assigned_ids':0,'duplicate_assigned_ids':0,
 'by_final_cell':[{ 'direction':dd,'cell':cc,'count':nn} for (dd,cc),nn in sorted(ct.items())],
 'phase07_completion_proof_modes':dict(sorted(modes.items())),
 'nondefinitive_review_modes':dict(sorted(exclusion_reasons.items())),
 'original_markdown_quotations_reverified_in_completion':tested_generated,
 'original_PDF_quotations_reverified_in_completion':tested_pdf,
 'source_pdf_sha256':run['pdf_sha256'],'external_queue_sha256':run['queue_sha256'],
 'source_hashes_verified':True,'original_model_journals_unchanged':True,
 'shard2_not_started':True,'phase08_not_started':True,
 'known_external_configuration_difference':{'protocol_model':'gpt-6.1-sol','uploaded_external_run_model':run['model'],'impact':'Noncomparable without same experimental configuration'},
 'completion_limitation_en':'Assistant review combined exact original quotation verification, scope/applicability checks, direct and contextual proof families. This is not a second independent model or expert certification; source quotation existence alone is insufficient to prove semantic entailment. Results remain auditable and may be superseded with original evidence if contradictions emerge.'
}
dump(P/'07_shard1_completion_summary.json',summary)
report=f'''# Phase 07 - Shard 1 Completion (Conversation A)

**Status: COMPLETE for the assigned shard; Phase 07 as a whole is not yet complete.**

## Scope and immutable inputs

- Protocol 10.6, method `fullload`.
- Source PDF: {run['pdf_sha256']} (90 physical pages).
- Eight original Markdown uploads matched their immutable external-run SHA-256 records.
- The complete v5 queue and its external results remain unchanged, as do the prior partial Phase 07 shard artifacts.
- Shard 1 has 2,578 assigned IDs; the other 2,578 are reserved for Shard 2.

## Final shard 1 dispositions

| Direction | Supported / true positive | Missing / unsupported | Nondefinitive excluded | Total |
|---|---:|---:|---:|---:|
| R | {ct[('R','TP')]} TP | {ct[('R','FN')]} FN | 0 | 319 |
| N | {ct[('N','TN')]} TN | {ct[('N','FP')]} FP | 0 | 71 |
| G | {ct[('G','TP')]} diagnostic TP | {ct[('G','FP')]} diagnostic FP | {ct[('G','EXCLUDED')]} | 2,188 |

New dispositions in this turn: {len(new)}. Previously completed dispositions retained: {len(partial)}. Total: {len(ordered)}. Final undecided IDs for Shard 1: zero.

**Counting:** Diagnostic G:TP does not multiply canonical R:TP. Diagnostic G:FP is only a candidate; it must be semantically consolidated against N and other residuals in Phase 08. Excluded passages are not fabricated TNs.

## Adjudication and proof evidence

Each new disposition preserves its original statement, a line-ranged SHA-verified generated-file quotation, verified original PDF quotation(s) where semantic support is asserted, the original v5 advisory fields separately, an explanation of acceptance/exclusion, and its fixed Phase 07 rule ID. The evidence audit records proof-family and scope distinctions.

- Reverified generated quotations: {tested_generated}.
- Reverified original PDF quotations: {tested_pdf}.
- Source-consistency failures: {len(error)}.
- Direct/contextual/conjunctive source-proof decisions: {sum(modes.values())}.
- Nondefinitive exclusions: {sum(exclusion_reasons.values())}.

## Noncomparability issue

The uploaded v5 run used `{run['model']}`, whereas protocol 10.6 prescribes `gpt-6.1-sol`. These evaluations cannot be represented as cross-method comparable without resolving the configuration divergence. Original model JSON and journals are not modified.

## Handoff

Shard 2 remains unstarted. Conversation C must combine completed Shard 1 and Shard 2, verify the 5,156-ID partition with zero duplicates and zero omission, check source and queue hashes and resolve any conflicting semantic evidence within Phase 07. Do not begin Phase 08 before that gate is satisfied.
'''
(P/'07_shard1_completion_report.md').write_text(report,encoding='utf-8')
print(json.dumps(summary,indent=2,ensure_ascii=False))
