#!/usr/bin/env python3
"""Independent mechanical validation of the immutable Phase-07 shard1 completion bundle."""
import json, pathlib, hashlib, collections, unicodedata
import fitz
B=pathlib.Path('/mnt/data');P=B/'oriondesk_fullload_v10_6/phase07';ROOT=P.parent
readl=lambda x:[json.loads(z) for z in open(x,encoding='utf8') if z.strip()]
sha=lambda p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
N=lambda z:' '.join(unicodedata.normalize('NFKC',str(z)).casefold().split())
lock=json.loads((P/'07_partition_lock.json').read_text());run=json.loads((B/'run_state(1).json').read_text())
A=readl(P/'07_shard1_assigned_items.jsonl');B2=readl(P/'07_shard2_assigned_items.jsonl');O=readl(P/'07_shard1_adjudications.jsonl');C=readl(P/'07_shard1_completion_adjudications.jsonl');F=readl(P/'07_shard1_final_adjudications.jsonl')
AUD=readl(P/'07_shard1_completion_evidence_audit.jsonl');Q=readl(ROOT/'phase06/06_llm_queue_v10.6.jsonl');q={x['item_id']:x for x in Q}
origfiles={'01':'01_screen_functions(4).md','02':'02_api(4).md','03':'03_data(4).md','04':'04_batch_functions(5).md','05':'05_business_rules(4).md','06':'06_exception_handling(6).md','07':'07_processing_flows(6).md','08':'08_architecture_decision(5).md'}
basekeys=['01_screen_functions.md','02_api.md','03_data.md','04_batch_functions.md','05_business_rules.md','06_exception_handling.md','07_processing_flows.md','08_architecture_decision.md']
origlines={i:(B/name).read_text(encoding='utf8').splitlines() for i,name in origfiles.items()}
pdf=fitz.open(B/'OrionDesk_AI_Detailed_Design_Specification(4).pdf');pages=[N(z.get_text('text')) for z in pdf]
checks={}
def ck(name,condition):
 checks[name]=bool(condition)
 if not condition:raise AssertionError(name)
ck('protocol_10_6',run['protocol_version']=='10.6')
ck('pdf_sha_lock',sha(B/'OrionDesk_AI_Detailed_Design_Specification(4).pdf')==run['pdf_sha256']==lock['pdf_sha256'])
ck('pdf_page_count_90',len(pdf)==90)
ck('source_SHA_manifest',all(sha(B/origfiles[i])==run['file_sha256'][basekeys[j]] for j,i in enumerate(origfiles)))
ck('external_queue_SHA',sha(ROOT/'phase06/06_llm_queue_v10.6.jsonl')==run['queue_sha256'])
ck('external_run_completed',json.loads((B/'semantic_summary(1).json').read_text())['completed_items']==5156)
ck('partition_sizes',len(A)==len(B2)==2578 and len(Q)==5156)
ck('partition_unique',len({x['item_id'] for x in A+B2})==5156)
ck('partition_complete',set(x['item_id'] for x in A+B2)==set(x['item_id'] for x in Q))
ck('shard1_final_2578',len(F)==2578)
ck('shard1_final_unique',len({x['item_id'] for x in F})==2578)
ck('shard1_unchanged_old_plus_completion',len(O)==782 and len(C)==1796 and F==[({x['item_id']:x for x in O+C})[a['item_id']] for a in A])
ck('completion_conforms_pending_IDs',{x['item_id'] for x in C}=={x['item_id'] for x in readl(P/'07_shard1_pending.jsonl')})
ck('no_duplicate_or_omitted_G',collections.Counter(x['direction'] for x in F)=={'R':319,'N':71,'G':2188})
ck('binary_direction',all((x['final_cell'] in ('TP','FN')) if x['direction']=='R' else (x['final_cell'] in ('TN','FP')) if x['direction']=='N' else (x['final_cell'] in ('TP','FP') or x.get('eligibility_status')=='EXCLUDED_NONDEFINITIVE') for x in F))
ck('no_null_eligible',all(x['final_cell'] is not None or x.get('eligibility_status')=='EXCLUDED_NONDEFINITIVE' for x in F))
ck('excluded_only_generated',all(x['direction']=='G' for x in F if x['final_cell'] is None))
ck('new_records_have_reason',all(x.get('decision_reason_en') and x.get('decision_rule_id') for x in C))
ck('new_source_immutable_flag',all(x.get('source_reference_unchanged') for x in C))
ck('new_uses_frozen_pdf_digest',all(x['source_pdf_sha256']==run['pdf_sha256'] for x in C))
ck('new_generated_digest_registry',all(x['generated_file_sha256']==run['file_sha256'] for x in C))
ck('new_external_trace',all(x['item_id'] in q and x['prior_v5_decision_status'] for x in C))
ck('no_new_FP_asserted_from_exclusions',all(x['final_cell'] is None for x in C if x['eligibility_status']=='EXCLUDED_NONDEFINITIVE'))
ck('G_diagnostic_TP_scope',all(x['canonical_counting_scope']=='G_DIAGNOSTIC_NOT_CANONICAL_TP' for x in C if x['final_cell']=='TP'))
ck('G_exclusion_scope',all(x['canonical_counting_scope']=='EXCLUDED_NONDEFINITIVE_NOT_SCORED' for x in C if x['final_cell'] is None))
ck('all_new_lines_verified',all(1<=g['line_start']<=g['line_end']<=len(origlines[g['role']]) and N(g['quote_en']) in N('\n'.join(origlines[g['role']][g['line_start']-1:g['line_end']])) for x in C for g in x['generated_evidence']))
ck('all_new_PDF_quote_verified',all(1<=e['physical_page']<=90 and N(e['quote_en']) in pages[e['physical_page']-1] for x in C for e in x['pdf_evidence']))
ck('all_supported_G_PDF_evidence',all(len(x['pdf_evidence'])>=1 for x in C if x['final_cell']=='TP'))
ck('original_v5_model_json_preserved',len(readl(B/'semantic_decisions(2).jsonl'))==5156)
ck('audit_one_per_new',len(AUD)==len(C)==1796 and len({x['item_id'] for x in AUD})==1796)
ck('prior_partial_file_manifest_unchanged',all(sha(P/z['filename'])==z['sha256'] for z in json.loads((P/'07_shard1_output_manifest.json').read_text())['files']))
ck('empty_new_pending',not readl(P/'07_shard1_final_pending.jsonl'))
ck('zero_input_blockers',not readl(P/'07_shard1_final_input_blockers.jsonl'))
ck('all_mixed_original_reviewed',all(next(x for x in C if x['item_id']==k)['mixed_fragment_resolution_en'] for k in ['GCLASS-0003597','GCLASS-0003689','GCLASS-0003707','GCLASS-0003941','GCLASS-0004055','GCLASS-0004058']))
ct=collections.Counter((x['direction'],x['final_cell'] or 'EXCLUDED') for x in F)
ck('R_319_conservation',ct[('R','TP')]+ct[('R','FN')]==319)
ck('N_71_conservation',ct[('N','TN')]+ct[('N','FP')]==71)
ck('G_2188_conservation',ct[('G','TP')]+ct[('G','FP')]+ct[('G','EXCLUDED')]==2188)
ck('model_configuration_difference_logged',run['model']=='gpt-6.2-sol' and 'gpt-6.1-sol' in (P/'07_shard1_completion_report.md').read_text())
ck('phase08_not_started',not (ROOT/'phase08').exists())
V={'record_type':'PHASE07_SHARD1_FINAL_INDEPENDENT_VALIDATION','status':'PASS','check_count':len(checks),'passed':len(checks),'checks':checks,'assigned':2578,'decisions':len(F),'pending':0,'cell_counts':{f'{d}:{c}':n for (d,c),n in sorted(ct.items())},'source_pdf_sha256':run['pdf_sha256'],'queue_sha256':run['queue_sha256'],'comment':'Mechanical verification does not independently certify semantic entailment. The item-level sourced decision records are authoritative for this shard subject to Phase 07 reconciliation.'}
(P/'07_shard1_completion_validation.json').write_text(json.dumps(V,ensure_ascii=False,sort_keys=True,indent=2)+'\n',encoding='utf8')
print('PASS',len(checks),'checks',ct)
