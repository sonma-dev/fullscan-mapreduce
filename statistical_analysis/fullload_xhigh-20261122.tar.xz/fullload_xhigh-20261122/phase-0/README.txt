OrionDesk AI — Full Load Atomic Evaluation (Protocol Version 10.6)

Archive layout:
  phase-0/    Original supplied PDF, eight generated Markdown specifications, protocol, frozen reference and evaluator reference scripts
  phase-1/    Reference lock
  phase-2/    Generated GO/GC extraction
  phase-3/    Source coverage discovery
  phase-4/    Reciprocal TP/FN audit
  phase-5/    Generated validity and exclusions
  phase-6/    Negative controls, queue, and actual external evaluation journals/results
  phase-7.1/  Shard 1 adjudication, initial and completion records
  phase-7.2/  Shard 2 adjudication
  phase-7.3/  Shard integration and Phase 07 superseding corrections
  phase-8/    Independent reconciliation and canonical ledger
  phase-9/    Independent metrics and report

Original input filenames and generated artifact filenames have been preserved.
Prior provisional records are included alongside finalized outputs for traceability.
See phase-0/ARCHIVE_MANIFEST.json for SHA-256 hashes of all bundled original files.
