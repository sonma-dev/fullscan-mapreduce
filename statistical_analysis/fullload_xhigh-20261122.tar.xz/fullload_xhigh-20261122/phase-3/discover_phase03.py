#!/usr/bin/env python3
"""Source-grounded Phase 03 R coverage DISCOVERY, not final semantic scoring.
All original input bytes are SHA-locked. Retrieval is an evidence-candidate generator;
score/anchor matches never constitute standalone semantic-entailment verification.
"""
from __future__ import annotations
import argparse, collections, hashlib, json, math, os, re, sys
from pathlib import Path
import numpy as np
import fitz
from sklearn.feature_extraction.text import TfidfVectorizer, ENGLISH_STOP_WORDS
from sklearn.preprocessing import normalize as normalize_sparse
ROOT=Path('/mnt/data'); RUN=ROOT/'oriondesk_fullload_v10_6'; OUT=RUN/'phase03'; OUT.mkdir(exist_ok=True)
P01=RUN/'phase01'; P02=RUN/'phase02'
H=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
J=lambda p:json.loads(Path(p).read_text(encoding='utf-8'))
JL=lambda p:[json.loads(x) for x in open(p,encoding='utf-8') if x.strip()]
def write_json(p,x):Path(p).write_text(json.dumps(x,ensure_ascii=False,indent=2,sort_keys=True)+'\n',encoding='utf-8')
def write_jl(p,rows):
 with open(p,'w',encoding='utf-8') as f:
  for r in rows:f.write(json.dumps(r,ensure_ascii=False,sort_keys=True)+'\n')
def norm(x):return ' '.join(str(x).replace('\u00ad','').split())
def tok(x):
 x=x.lower().replace('authorisation','authorization').replace('authorise','authorize').replace('authorised','authorized')
 x=re.sub(r'([a-z])(\d)',r'\1 \2',x)
 return [t for t in re.findall(r'[a-z][a-z0-9_./:-]*|\d+(?:\.\d+)?',x) if t not in ENGLISH_STOP_WORDS and len(t)>1]
IDENT=re.compile(r'(?<!\w)(?:/(?:v1|internal)/[\w{}./-]+|(?:GET|POST|PATCH|PUT|DELETE)\s+/(?:v1|internal)/[\w{}./-]+|\b(?:TST|SEC|T|API|SCR|BR|BAT|DAT|ERR|FLOW)-\d{2,4}\b)')
NUM=re.compile(r'\b(?:\d+(?:\.\d+)?\s*(?:%|MB|GB|ms|hours?|days?|seconds?|tokens?|pages?|dimensional)|\d{3,5}-dimensional|(?:RPO|RTO)\s*\d+)\b',re.I)
SYN={'retrieval':'retrieve','retrieved':'retrieve','retrieves':'retrieve','reviewed':'review','reviewer':'review','approvals':'approval','approved':'approval','approving':'approval','publishing':'publish','published':'publish','publication':'publish','authorizations':'authorization','authorized':'authorization','authorise':'authorization','tenant-scoped':'tenant','tenancy':'tenant','dependencies':'dependency','exceptions':'exception','failed':'failure','failing':'failure','updating':'update','updates':'update','operations':'operation','stored':'store','storage':'store','generating':'generate','generation':'generate','versions':'version','versioned':'version','sources':'source','cited':'citation','citations':'citation','validated':'validate','validating':'validate','immutable':'immutability','deduplicated':'deduplication','duplicates':'duplicate','credential':'credentials'}
def content_words(x):return {SYN.get(t,t) for t in tok(x) if len(t)>2}
def anchor_conflicts(r,g):
 """Only explicit mutually exclusive anchors are reported; absence is not contradiction."""
 ra=set(IDENT.findall(r)); ga=set(IDENT.findall(g));
 # numeric source values must not be swapped in candidate proof
 rn={norm(x).lower() for x in NUM.findall(r)}; gn={norm(x).lower() for x in NUM.findall(g)}
 # Distinct endpoint path isn't necessarily contradictory when text describes multiple endpoints
 rpaths={x for x in ra if '/v1/' in x or '/internal/' in x}; gpaths={x for x in ga if '/v1/' in x or '/internal/' in x}
 mism=[]
 if rpaths and gpaths and not (rpaths&gpaths):mism.append('DIFFERENT_EXPLICIT_ROUTE')
 if rn and gn and not rn.intersection(gn):mism.append('DIFFERENT_NUMERIC_ANCHOR_REQUIRES_REVIEW')
 return mism

def untrusted_meta(stmt):
 l=stmt.lower()
 return (l.startswith(('confirmed:','needs confirmation','proposal:','nc:','source:')) or 'this is not a confirmed' in l or 'not selected' in l or 'undefined contract' in l or 'does not establish' in l)

def main():
 lock=J(P01/'01_reference_lock.json')
 assert lock['phase']=='01' and lock['protocol_version']=='10.6'
 assert lock['frozen_r_count']==638 and lock['frozen_n_count']==142
 for x in lock['source_roles_ordered']:
  assert H(x['original_path'])==x['sha256'],f'Source digest mismatch {x["actual_filename"]}'
 srcs=lock['source_roles_ordered']
 assert H(ROOT/'OrionDesk_AI_Detailed_Design_Specification(4).pdf')==lock['pdf_sha256']
 assert H(ROOT/'common_atomic_reqs(4).jsonl')==lock['frozen_r_sha256']
 assert H(ROOT/'common_negative_controls(4).jsonl')==lock['frozen_n_sha256']
 assert H(ROOT/'reference_freeze(4).json')==lock['reference_freeze_sha256']
 R=JL(ROOT/'common_atomic_reqs(4).jsonl'); G=JL(P02/'02_generated_atoms_final.jsonl'); C=JL(P02/'02_generated_classes_final.jsonl')
 assert len(R)==638 and len(G)==5046 and len(C)==4861
 assert len({r['requirement_id'] for r in R})==638
 assert len({g['gen_id'] for g in G})==5046 and len({c['class_id'] for c in C})==4861
 pre=J(P02/'02_phase_summary.json'); assert pre['protocol_version']=='10.6'
 text_lines={x['actual_filename']:Path(x['original_path']).read_text(encoding='utf-8').splitlines() for x in srcs}
 go_by={g['gen_id']:g for g in G}; doc=[]; idx=[]
 for c in C:
  g=go_by[c['representative_gen_id']];
  d=(g['statement_en']+' '+g['statement_en']+' '+g['source_quote_en']+' '+' '.join(g['heading_path'][-2:]))
  doc.append(d);idx.append(g)
 role_indices={x["role"]:[] for x in srcs}
 for ci,g in enumerate(idx):role_indices[g["canonical_role"]].append(ci)
 # Index every original physical Markdown line as a fallback to uncover extraction misses.
 originals=JL(P02/'02_original_text_index.jsonl')
 raw=[x for x in originals if x['original_text_en'].strip() and x['scan_class'] not in ('BLANK','STRUCTURAL_OR_REFERENCE')]
 rawtxt=[x['original_text_en']+' '+' '.join(x['heading_path'][-2:]) for x in raw]
 print(f'INDEX R={len(R)}, GCLASS={len(C)}, RAW_LINES={len(raw)}',flush=True)
 query=[r['statement_en']+' '+r['statement_en']+' '+' '.join(r.get('required_predicates') or [])+' '+' '.join(e.get('quote','') for e in r['pdf_evidence'][:2]) for r in R]
 # Word/phrase & char ngram channels allow abbreviations and compound rephrases.
 all_docs=doc+rawtxt
 vecw=TfidfVectorizer(ngram_range=(1,2),sublinear_tf=True,token_pattern=r'(?u)\b[\w./:-]{2,}\b',max_features=140000)
 wc=vecw.fit_transform(all_docs);wq=vecw.transform(query)
 vecc=TfidfVectorizer(analyzer='char_wb',ngram_range=(3,5),min_df=2,max_features=105000,sublinear_tf=True)
 cc=vecc.fit_transform(all_docs);cq=vecc.transform(query)
 scores=(wq@wc.T).tocsr().astype(np.float32); scores=scores.multiply(.65)+(cq@cc.T).tocsr().multiply(.35)
 assert scores.shape==(638,len(all_docs))
 srcpdf=fitz.open(str(ROOT/'OrionDesk_AI_Detailed_Design_Specification(4).pdf'))
 assert len(srcpdf)==90
 pdfpages=[norm(p.get_text('text')) for p in srcpdf]
 source_quote_check=0
 for r in R:
  verified=False
  for e in r.get('pdf_evidence',[]):
   page=e['physical_page']; quote=norm(e.get('quote',e.get('visible_text','')))
   if e.get('pdf_verification')=='PDF_VISUAL_INSPECTED':
    verified=True;continue
   if quote in pdfpages[page-1]:source_quote_check+=1;verified=True
  assert verified,f'PDF source evidence not verified: {r["requirement_id"]}'
 # Multiple source original docs represented; query top ranks; do not assert entailment from similarity.
 result=[]; bridges=[]; inventory=[]; audit=[]
 for i,r in enumerate(R):
  row=scores.getrow(i)
  arr=row.toarray().reshape(-1)
  # Broader search union from GO class and raw original line channels.
  gtop=np.argsort(arr[:len(C)])[-32:][::-1]
  rawtop=np.argsort(arr[len(C):])[-14:][::-1]
  choices=[]
  for p in gtop:
   g=idx[int(p)];l=text_lines[g['actual_filename']];s,e=int(g['line_start']),int(g['line_end'])
   if not (1<=s<=e<=len(l)):raise RuntimeError(f'bad GO locator {g["gen_id"]}')
   quote=norm(g['source_quote_en']);window=norm(' '.join(l[s-1:e]));
   if quote and quote not in window:raise RuntimeError(f'unverified GO quote {g["gen_id"]}')
   choices.append(dict(source_type='ELIGIBLE_GO',gen_id=g['gen_id'],class_id=g['class_id'],file=g['actual_filename'],canonical_role=g['canonical_role'],file_sha256=g['original_file_sha256'],line_start=s,line_end=e,quote_en=g['source_quote_en'],statement_en=g['statement_en'],search_score=round(float(arr[p]),5),quote_verified_original=True,source_hash_verified=True,inherited_heading_path=g['heading_path'],possible_metadata_misclassification=untrusted_meta(g['statement_en']),explicit_anchor_cautions=anchor_conflicts(r['statement_en'],g['statement_en'])))
  for p in rawtop:
   q=int(p);x=raw[q];ln=x['line'];line=text_lines[x['actual_filename']][ln-1]
   assert line==x['original_text_en']
   choices.append(dict(source_type='ORIGINAL_LINE_FALLBACK',gen_id=None,class_id=None,file=x['actual_filename'],canonical_role=x['canonical_role'],file_sha256=x['file_sha256'],line_start=ln,line_end=ln,quote_en=line,statement_en=line,search_score=round(float(arr[len(C)+q]),5),quote_verified_original=True,source_hash_verified=True,inherited_heading_path=x['heading_path'],possible_metadata_misclassification=True,explicit_anchor_cautions=anchor_conflicts(r['statement_en'],line)))
  choices.sort(key=lambda x:(-x['search_score'],x['source_type']!='ELIGIBLE_GO',x['file'],x['line_start']))
  # Keep up to 14 with strong file diversification, plus top direct candidates.
  used=set(); selection=[]
  for x in choices:
   k=(x['file'],x['line_start'],x['quote_en'])
   if k not in used and len(selection)<8:selection.append(x);used.add(k)
  for x in choices:
   k=(x['file'],x['line_start'],x['quote_en'])
   if k in used:continue
   if x['file'] not in {y['file'] for y in selection} and len(selection)<12:
    selection.append(x);used.add(k)
  # Re-sort evidence after diversification; avoid storing verbatim long table rows endlessly.
  selection.sort(key=lambda x:-x['search_score'])
  best=next((x for x in selection if x['source_type']=='ELIGIBLE_GO' and not x['possible_metadata_misclassification'] and not x['explicit_anchor_cautions']),None)
  if best is None:status='NO_UNCONTESTED_ELIGIBLE_CANDIDATE'
  elif best['search_score']>=.76:status='STRONG_TEXTUAL_COVERAGE_CANDIDATE'
  elif best['search_score']>=.26:status='CONTEXTUAL_OR_PARTIAL_CANDIDATE'
  else:status='UNCERTAIN_LOW_SIMILARITY'
  # Exhaustively probe each original role (including roles absent from global top hits).
  per_role=[]
  for role,available in role_indices.items():
   local_best=max(available,key=lambda j:float(arr[j]))
   gg=idx[local_best]
   per_role.append({"role":role,"actual_filename":gg["actual_filename"],"sha256":gg["original_file_sha256"],"best_candidate_gen_id":gg["gen_id"],"best_candidate_class_id":gg["class_id"],"line_start":gg["line_start"],"line_end":gg["line_end"],"search_score":round(float(arr[local_best]),5),"quote_en":gg["source_quote_en"],"role_probe_status":"CANDIDATE_ONLY_NO_SEMANTIC_VERDICT"})
  # Source content token estimate only for discovery diagnostics, never full entailment determination.
  terms=content_words(r['statement_en'])
  if best:
   tw=content_words(best['statement_en']);lexical=round(len(terms&tw)/max(1,len(terms)),4)
  else:lexical=0.0
  # One paragraph/row may not include all predicates: bridges keep distinct claims separated.
  sub=[x for x in r.get('required_predicates',[]) if x.strip()]
  if not sub or len(sub)==1: sub=re.split(r'\s*;\s*|\s+and\s+(?=(?:a |the |current |source |role |policy |review|run|case|document|approval|model|tool))',r['statement_en'])
  sub=[x for x in sub if len(content_words(x))>=2]
  part=[]
  for pred in sub[:15]:
   t=content_words(pred)
   options=sorted(((len(t&content_words(x['statement_en']))/max(1,len(t)),x) for x in selection if x['source_type']=='ELIGIBLE_GO' and not x['possible_metadata_misclassification']),key=lambda z:-z[0]);
   if options and options[0][0]>=.30:
    fraction,x=options[0];part.append({'predicate_en':pred,'lexical_overlap':round(fraction,3),'candidate_gen_id':x['gen_id'],'candidate_class_id':x['class_id'],'candidate_file':x['file'],'candidate_line_start':x['line_start']})
  bid=None
  unique_gen=list(dict.fromkeys(x['candidate_gen_id'] for x in part))
  unique_files={x['candidate_file'] for x in part}
  if len(sub)>=2 and len(part)>=2 and len(unique_gen)>=2:
   bid='BRIDGE-R-'+r['requirement_id'].split('-')[-1]
   bridges.append({'record_type':'SEMANTIC_COVERAGE_BRIDGE_CANDIDATE','protocol_version':'10.6','method':'fullload','bridge_id':bid,'source_id':r['requirement_id'],'physical_pages':r['source_physical_pages'],'source_statement_en':r['statement_en'],'predicate_support_candidates':part,'candidate_gen_ids':unique_gen,'distinct_file_count':len(unique_files),'bridge_status':'CONTEXTUAL_OR_CONJUNCTIVE_CANDIDATE_NOT_PROVEN','scope_gate_en':'Phase 04 must verify each predicate, actor, trigger, object, numeric boundary, exclusions, and cross-file applicability; lexical overlap is not entailment.'})
  rowout={'record_type':'SOURCE_COVERAGE_DISCOVERY','protocol_version':'10.6','method':'fullload','source_id':r['requirement_id'],'frozen_reference_status':r['score_status'],'pdf_source_sha256':lock['pdf_sha256'],'pdf_physical_pages':r['source_physical_pages'],'pdf_statement_en':r['statement_en'],'pdf_scope':r.get('source_scope'),'pdf_predicates':r.get('required_predicates',[]),'pdf_evidence':r['pdf_evidence'],'pdf_evidence_previously_verified_phase01':True,'coverage_discovery_status':status,'entailment_final_cell':None,'phase04_reciprocal_audit_required':True,'retrieval_channels':['word_tfidf','character_tfidf','all_generated_semantic_classes','all_original_markdown_lines'],'best_eligible_search_score':best['search_score'] if best else None,'best_eligible_lexical_token_recall_diagnostic_only':lexical,'source_bridge_candidate_id':bid,'per_role_best_generated_probe':per_role,'strongest_generated_candidate':best,'candidate_count_stored':len(selection),'generated_evidence_candidates':selection,'independent_note_en':'Search ranking only. Phase 04 must challenge full predicate coverage and misses; not a TP/FN decision.'}
  result.append(rowout)
  audit.append({'source_id':r['requirement_id'],'top_score':best['search_score'] if best else 0,'candidate_count':len(selection),'roles_probed':len(per_role),'eligible_candidates':sum(c['source_type']=='ELIGIBLE_GO' for c in selection),'distinct_roles':len({c['canonical_role'] for c in selection}),'status':status,'bridge':bid,'best_go':best['gen_id'] if best else None})
  if (i+1)%125==0:print(f'R COVERAGE INDEXED {i+1}/{len(R)}',flush=True)
 write_jl(OUT/'03_source_coverage.jsonl',result)
 write_jl(OUT/'03_semantic_coverage_bridges.jsonl',bridges)
 write_jl(OUT/'03_retrieval_audit.jsonl',audit)
 dist=dict(collections.Counter(x['coverage_discovery_status'] for x in result))
 all_roles=collections.Counter(c['file'] for r in result for c in r['generated_evidence_candidates'])
 summary={'record_type':'PHASE03_DISCOVERY_SUMMARY','protocol_version':'10.6','method':'fullload','status':'PHASE_COMPLETED','frozen_source_positive_count':len(R),'frozen_source_negative_count':142,'generated_occurrences_locked':len(G),'generated_classes_locked':len(C),'original_markdown_lines_indexed':len(originals),'original_markdown_searchable_lines':len(raw),'source_positive_rows_indexed':len(result),'all_r_indexed':len(result)==len(R),'source_positive_with_candidate':sum(bool(x['generated_evidence_candidates']) for x in result),'all_source_records_have_pdf_evidence':all(x['pdf_evidence'] for x in result),'text_pdf_quotations_reverified_at_least_one_per_record':True,'text_verified_quotation_count_this_phase':source_quote_check,'generated_line_quotes_all_verified':True,'bridge_candidate_count':len(bridges),'coverage_status_counts':dist,'retrieval_candidate_represented_files':dict(all_roles),'final_tp_count':None,'final_fn_count':None,'final_coverage_judgment_performed':False,'method_metadata':{'user_requested_reasoning_effort':'xhigh','external_semantic_evaluator_reasoning_effort_reserved':'high'},'pdf_sha256':lock['pdf_sha256'],'r_sha256':lock['frozen_r_sha256'],'n_sha256':lock['frozen_n_sha256'],'generated_ledger_sha256':H(P02/'02_generated_atoms_final.jsonl'),'generated_classes_sha256':H(P02/'02_generated_classes_final.jsonl'),'input_files_unchanged':True,'phase04_not_started':True}
 write_json(OUT/'03_phase_summary.json',summary)
 report=f'''# Phase 03 — Frozen-R Coverage Discovery

**Status:** PHASE_COMPLETED | **Protocol:** 10.6 | **Generation method:** fullload

## Exhaustive source indexing

- PDF-positive source atoms R: **{len(R)}**, every ID represented exactly once.
- Frozen controls N: **142** (untouched; N evaluation is a later phase).
- Candidate-generated occurrence inventory GO: **{len(G)}** and class inventory GC: **{len(C)}**, both source-locked and unmodified.
- Original Markdown lines searched: **{len(originals)}** indexed lines, including {len(raw)} nonblank searchable lines in a supplementary channel.
- PDF evidence checked: every source R has exact physical-page evidence preverified by Phase 01; {source_quote_check} quotation occurrences rechecked during Phase 03.
- Generated evidence: each stored candidate references a SHA-verified actual Markdown source, an original physical line range and an exact original quotation. Each R also carries a best-candidate probe from each of the eight original Markdown roles, even when the globally ranked list is dominated by one role.
- Contextual/conjunctive bridge **candidates**: **{len(bridges)}**; not accepted entailment proofs.

## Discovery categories

'''+''.join(f'- **{k}**: {v}\n' for k,v in sorted(dist.items()))+'''
## Scope and interpretation

This phase is retrieval and evidence discovery only. The strongest lexical source-to-generated candidate is not independently sufficient to declare a TP; a low similarity score is not evidence of an FN. Every R row retains all source evidence, up to 12 diverse generated/raw-line candidates, unambiguous original role/line/hash provenance, source-specific predicates, and explicit uncertain status. Candidate bridges indicate where distinct source predicates have their closest supporting generated statements; Phase 04 must confirm mutual applicability and challenge each proposed miss as required.

Phase 02 generated-atom classifications were not silently altered. Any Phase 02 metadata-like `DEFINITIVE` assertion observed in retrieval is flagged for reconsideration in the mandated Phase 05 exclusion reassessment. No Phase 04 audit, negative-control classification, generated-only validity decision or final scoring has been performed.

## Artifacts

- `03_source_coverage.jsonl`: complete 638-item R-to-generated evidence candidate register.
- `03_semantic_coverage_bridges.jsonl`: incomplete predicate/conjunction bridge candidates with explicit evidence references and Phase 04 gates.
- `03_retrieval_audit.jsonl`: per-R candidate coverage and ranking audit.
- `03_phase_summary.json`: reproducible counts, integrity metadata and outcomes.
- `discover_phase03.py`, `validate_phase03.py`: rerun and independent validation programs.
'''
 (OUT/'03_phase_report.md').write_text(report,encoding='utf-8')
 print(json.dumps({k:summary[k] for k in ('status','source_positive_rows_indexed','source_positive_with_candidate','bridge_candidate_count','coverage_status_counts')},ensure_ascii=False,indent=2),flush=True)
if __name__=='__main__':main()
