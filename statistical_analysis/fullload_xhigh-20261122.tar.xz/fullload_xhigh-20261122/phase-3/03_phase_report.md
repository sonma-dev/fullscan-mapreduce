# Phase 03 — Frozen-R Coverage Discovery

**Status:** PHASE_COMPLETED | **Protocol:** 10.6 | **Generation method:** fullload

## Exhaustive source indexing

- PDF-positive source atoms R: **638**, every ID represented exactly once.
- Frozen controls N: **142** (untouched; N evaluation is a later phase).
- Candidate-generated occurrence inventory GO: **5046** and class inventory GC: **4861**, both source-locked and unmodified.
- Original Markdown lines searched: **8330** indexed lines, including 5483 nonblank searchable lines in a supplementary channel.
- PDF evidence checked: every source R has exact physical-page evidence preverified by Phase 01; 1856 quotation occurrences rechecked during Phase 03.
- Generated evidence: each stored candidate references a SHA-verified actual Markdown source, an original physical line range and an exact original quotation. Each R also carries a best-candidate probe from each of the eight original Markdown roles, even when the globally ranked list is dominated by one role.
- Contextual/conjunctive bridge **candidates**: **102**; not accepted entailment proofs.

## Discovery categories

- **CONTEXTUAL_OR_PARTIAL_CANDIDATE**: 369
- **NO_UNCONTESTED_ELIGIBLE_CANDIDATE**: 1
- **STRONG_TEXTUAL_COVERAGE_CANDIDATE**: 69
- **UNCERTAIN_LOW_SIMILARITY**: 199

## Scope and interpretation

This phase is retrieval and evidence discovery only. The strongest lexical source-to-generated candidate is not independently sufficient to declare a TP; a low similarity score is not evidence of an FN. Every R row retains all source evidence, up to 12 diverse generated/raw-line candidates, unambiguous original role/line/hash provenance, source-specific predicates, and explicit uncertain status. Candidate bridges indicate where distinct source predicates have their closest supporting generated statements; Phase 04 must confirm mutual applicability and challenge each proposed miss as required.

Phase 02 generated-atom classifications were not silently altered. Any Phase 02 metadata-like `DEFINITIVE` assertion observed in retrieval is flagged for reconsideration in the mandated Phase 05 exclusion reassessment. No Phase 04 audit, negative-control classification, generated-only validity decision or final scoring has been performed.

## Artifacts

- `03_source_coverage.jsonl`: complete 638-item R-to-generated evidence candidate register.
- `03_semantic_coverage_bridges.jsonl`: incomplete predicate/conjunction bridge candidates with explicit evidence references and Phase 04 gates.
- `03_retrieval_audit.jsonl`: per-R candidate coverage and ranking audit.
- `03_phase_summary.json`: reproducible counts, integrity metadata and outcomes.
- `discover_phase03.py`, `validate_phase03.py`: rerun and independent validation programs.
