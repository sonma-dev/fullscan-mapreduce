#!/usr/bin/env python3
"""Independent artifact and source integrity validation for Phase 03.
No semantic-cell decisions or external calls. The validation must be reread
against the actual original bytes and fixed reference IDs.
"""
import hashlib,json,collections,sys
from pathlib import Path
ROOT=Path('/mnt/data');RUN=ROOT/'oriondesk_fullload_v10_6';D=RUN/'phase03'
J=lambda p:json.loads(Path(p).read_text(encoding='utf-8'))
JL=lambda p:[json.loads(z) for z in open(p,encoding='utf-8') if z.strip()]
H=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
N=lambda x:' '.join(str(x).split())
def verify():
 lock=J(RUN/'phase01/01_reference_lock.json'); s=J(D/'03_phase_summary.json');
 assert lock['protocol_version']==s['protocol_version']=='10.6'
 assert s['method']=='fullload' and s['phase04_not_started'] and not s['final_coverage_judgment_performed']
 roles=lock['source_roles_ordered']; lines={x['actual_filename']:Path(x['original_path']).read_text(encoding='utf-8').splitlines() for x in roles};digests={x['actual_filename']:x['sha256'] for x in roles}
 for x in roles:assert H(x['original_path'])==x['sha256']
 assert H(ROOT/'OrionDesk_AI_Detailed_Design_Specification(4).pdf')==lock['pdf_sha256']==s['pdf_sha256']
 assert H(ROOT/'common_atomic_reqs(4).jsonl')==lock['frozen_r_sha256']==s['r_sha256']
 assert H(ROOT/'common_negative_controls(4).jsonl')==lock['frozen_n_sha256']==s['n_sha256']
 assert H(ROOT/'reference_freeze(4).json')==lock['reference_freeze_sha256']
 assert H(RUN/'phase02/02_generated_atoms_final.jsonl')==s['generated_ledger_sha256']
 assert H(RUN/'phase02/02_generated_classes_final.jsonl')==s['generated_classes_sha256']
 sr=JL(ROOT/'common_atomic_reqs(4).jsonl');rows=JL(D/'03_source_coverage.jsonl'); bridges=JL(D/'03_semantic_coverage_bridges.jsonl');audit=JL(D/'03_retrieval_audit.jsonl');gos=JL(RUN/'phase02/02_generated_atoms_final.jsonl');classes=JL(RUN/'phase02/02_generated_classes_final.jsonl')
 assert len(sr)==len(rows)==len(audit)==638
 assert len(gos)==5046 and len(classes)==4861
 srcids=[r['requirement_id'] for r in sr]
 assert [r['source_id'] for r in rows]==[x['source_id'] for x in audit]==srcids and len(set(srcids))==638
 bridge_map={b['bridge_id']:b for b in bridges}; assert len(bridge_map)==len(bridges)
 go={g['gen_id']:g for g in gos}; cl={c['class_id']:c for c in classes}
 checked=0; allrole=0
 for source,r in zip(sr,rows):
  assert r['pdf_statement_en']==source['statement_en'] and r['pdf_evidence']==source['pdf_evidence']
  assert r['pdf_physical_pages']==source['source_physical_pages']
  assert r['pdf_evidence_previously_verified_phase01'] and r['entailment_final_cell'] is None and r['phase04_reciprocal_audit_required']
  assert r['generated_evidence_candidates'] and 0<len(r['generated_evidence_candidates'])<=12
  assert len(r['per_role_best_generated_probe'])==8
  assert {t['role'] for t in r['per_role_best_generated_probe']}=={t['role'] for t in roles}
  for y in r['per_role_best_generated_probe']:
   g=go[y['best_candidate_gen_id']];assert y['best_candidate_class_id']==g['class_id']
   assert y['actual_filename']==g['actual_filename'] and y['role']==g['canonical_role']
   assert y['sha256']==digests[y['actual_filename']]
   assert y['line_start']==g['line_start'] and y['line_end']==g['line_end']
   assert N(y['quote_en']) in N(' '.join(lines[y['actual_filename']][y['line_start']-1:y['line_end']]))
   allrole+=1
  for x in r['generated_evidence_candidates']:
   assert x['source_type'] in ('ELIGIBLE_GO','ORIGINAL_LINE_FALLBACK')
   assert x['file_sha256']==digests[x['file']] and x['source_hash_verified'] and x['quote_verified_original']
   assert 1<=x['line_start']<=x['line_end']<=len(lines[x['file']])
   assert N(x['quote_en']) in N(' '.join(lines[x['file']][x['line_start']-1:x['line_end']]))
   if x['source_type']=='ELIGIBLE_GO':
    g=go[x['gen_id']];assert g['class_id']==x['class_id'] in cl
    assert g['actual_filename']==x['file'] and g['line_start']==x['line_start'] and g['line_end']==x['line_end']
   else:assert x['gen_id'] is None and x['class_id'] is None
   checked+=1
  if r['strongest_generated_candidate'] is not None:
   assert r['strongest_generated_candidate'] in r['generated_evidence_candidates']
  if r['source_bridge_candidate_id']:
   b=bridge_map[r['source_bridge_candidate_id']];assert b['source_id']==r['source_id']
   assert b['bridge_status']=='CONTEXTUAL_OR_CONJUNCTIVE_CANDIDATE_NOT_PROVEN'
   assert len(b['candidate_gen_ids'])>=2
   for v in b['predicate_support_candidates']:
    g=go[v['candidate_gen_id']]
    assert g['class_id']==v['candidate_class_id']
    assert g['actual_filename']==v['candidate_file'] and g['line_start']==v['candidate_line_start']
 assert len(set(b['source_id'] for b in bridges))==len(bridges)==s['bridge_candidate_count']
 assert s['source_positive_rows_indexed']==s['source_positive_with_candidate']==638
 assert sum(s['coverage_status_counts'].values())==638
 assert collections.Counter(x['coverage_discovery_status'] for x in rows)==s['coverage_status_counts']
 assert all(a['roles_probed']==8 for a in audit)
 out={'status':'PASS','phase':'03','source_R':638,'frozen_N':142,'locked_GO':len(gos),'locked_GC':len(classes),'stored_generated_candidates_checked':checked,'all_role_probes_verified':allrole,'contextual_bridge_candidates_checked':len(bridges),'no_canonical_tp_fn_committed':True,'no_original_mutation_detected':True}
 (D/'03_validation_results.json').write_text(json.dumps(out,indent=2,sort_keys=True)+'\n',encoding='utf-8')
 return out
if __name__=='__main__':
 try:print(json.dumps(verify(),indent=2))
 except Exception as e:
  print(f'FAILED: {e}',file=sys.stderr);raise
