# Phase 08 — Independent Semantic Reconciliation Audit (Version 10.6)

## Status: INCOMPLETE

Phase 08 stopped at the semantic-consistency gate under §8.1. It did not replace Phase 07 item decisions and did not create a fabricated canonical FP count. The required `08_final_ledger.jsonl` and `08_binary_counts.json` are intentionally withheld until the recorded Phase 07 contradictions are superseded and verified.

## Verified immutable inputs

- PDF: 90 pages, SHA-256 `b71541e74564559d2cc0a84e9827086946998fbc6c627488fb9e7a7f9b0137c3`.
- Frozen R: 638; N: 142, both original SHA-256 verified.
- Queue: 5,156 unique IDs, SHA-256 `f0ee6dac19a32e41c2a83c1030bff2ddcf904d1e7a516b609853e22599d4981a`.
- External evaluator: 323 complete hash-verified batch journals containing 5,156 matching original item results; no current failed batch.
- Final Phase 07: R TP=484, FN=154; N FP=0, TN=142; G supported diagnostic TP=3398, unsupported diagnostic FP candidates=217; excluded nondefinitive=761.
- Each source ID, control ID and effective generated class is represented exactly once in the Phase 07 population.

## Blocking Phase 07 semantic contradictions

1. **P08-CONFLICT-001**: `GCLASS-0002386` is **FP**, while `GCLASS-0004356` is **TP**. Both describe the outbox publisher validating the mandatory event envelope with the same nine properties. Source PDF page 48 states those nine fields. An explicit Phase 07 superseding decision must reconcile the differing applicability findings.
2. **P08-CONFLICT-002**: `GCLASS-0002250` is **FP**, while `GCLASS-0004199` is **TP**. Both prohibit a classifier retry/replay from overwriting a later user classification correction. Their generated statements describe the same actor, target and action. Source PDF page 12 confirms user corrections with reason codes and pages 17/48 define replay/stale event controls. An explicit Phase 07 superseding decision must resolve the support judgment.

These are competing *Phase 07 item-level* classifications, not a Phase 08 license to decide a different label. The original Phase 07 records remain unchanged.

## Additional experimental configuration deviation

The supplied external run records model `gpt-6.2-sol`, while Protocol 10.6 §4.2 specifies `gpt-6.1-sol`. This must be tracked as a cross-method comparability deviation; no deployment identity was rewritten. The run used 16-item batches, which are an approved protocol size.

## Prepared but non-scoring artifacts

- `08_population_crosswalk_non_scoring.jsonl`: full queue-to-Phase07 ID correspondence.
- `08_generated_fp_candidates_unreconciled.jsonl`: all 217 candidate unsupported classes, preserving their Phase 07 records.
- `08_residual_near_duplicate_review.jsonl`: lexical candidate pairs for future semantic deduplication; similarity does not assert equivalence.
- `08_reconciliation_audit.jsonl`: mechanical provenance audit, two Phase 07 contradictions, and configuration deviation.
- `08_return_to_phase07.jsonl`: exact IDs requiring explicit source-grounded superseding adjudication.

## Completion gate

Phase 08 remains **INCOMPLETE**. Produce explicit Phase 07 superseding adjudications for the contradictory pairs, preserve all prior files, and rerun independent Phase 08 validation and N/F semantic consolidation. Do not compute final canonical FP or Precision/Recall/F1 from this incomplete ledger. No Phase 09 operations were performed.
