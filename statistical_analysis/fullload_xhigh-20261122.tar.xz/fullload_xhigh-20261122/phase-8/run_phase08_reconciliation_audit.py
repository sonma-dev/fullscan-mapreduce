#!/usr/bin/env python3
"""Phase 08 provenance and contradiction audit; fail closed on Phase 07 semantic conflicts.

Does not reclassify Phase 07 cells and does not create a canonical score on an inconsistent input.
"""
from __future__ import annotations
import json,hashlib,zipfile,collections,re,pathlib,datetime,sys,math
import fitz

ROOT=pathlib.Path('/mnt/data')
BASE=ROOT/'oriondesk_fullload_v10_6'
OUT=BASE/'phase08';OUT.mkdir(exist_ok=True)

def load(path):
    return json.loads(pathlib.Path(path).read_text(encoding='utf-8'))
def jrows(path):
    return [json.loads(x) for x in pathlib.Path(path).read_text(encoding='utf-8').splitlines() if x.strip()]
def js(o):
    return json.dumps(o, ensure_ascii=False, sort_keys=True,separators=(',',':'))
def sha(path):
    return hashlib.sha256(pathlib.Path(path).read_bytes()).hexdigest()
def hashtext(s):
    return hashlib.sha256(s.encode('utf-8')).hexdigest()
def outputj(path, rows):
    pathlib.Path(path).write_text(''.join(js(x)+'\n' for x in rows),encoding='utf-8')
def output(path,obj):
    pathlib.Path(path).write_text(json.dumps(obj,ensure_ascii=False,sort_keys=True,indent=2)+'\n',encoding='utf-8')

checks={};issues=[]
def test(k, ok, detail=None):
    checks[k]=bool(ok)
    if not ok: issues.append({'check':k,'detail':detail})

lock=load(BASE/'phase01/01_reference_lock.json')
selection=load(BASE/'phase06/06_queue_selection.json')
p7sum=load(BASE/'phase07/07_adjudication_summary.json')
run=load(ROOT/'run_state(1).json')
summary=load(ROOT/'semantic_summary(1).json')
queue=jrows(BASE/'phase06/06_llm_queue_v10.6.jsonl')
external=jrows(ROOT/'semantic_decisions(2).jsonl')
source=jrows(ROOT/'common_atomic_reqs(4).jsonl')
control=jrows(ROOT/'common_negative_controls(4).jsonl')
p7=jrows(BASE/'phase07/07_assistant_adjudications.jsonl')
excluded=jrows(BASE/'phase07/07_eligibility_exclusions.jsonl')
pop=jrows(BASE/'phase07/07_phase07_population_index.jsonl')

pdf=ROOT/'OrionDesk_AI_Detailed_Design_Specification(4).pdf'
role_map={x['canonical_name']:x for x in lock['source_roles_ordered']}
test('pdf_sha_and_ninety_pages',sha(pdf)==lock['pdf_sha256'] and len(fitz.open(pdf))==90)
test('source_8_roles_original_hashes',len(role_map)==8 and all(sha(ROOT/x['actual_filename'])==x['sha256']==run['file_sha256'][x['canonical_name']] for x in role_map.values()))
test('frozen_R_and_N_bytes',sha(ROOT/'common_atomic_reqs(4).jsonl')==lock['frozen_r_sha256'] and sha(ROOT/'common_negative_controls(4).jsonl')==lock['frozen_n_sha256'])
test('fixed_reference_counts',len(source)==638 and len(control)==142)
test('queue_sha_unchanged',sha(BASE/'phase06/06_llm_queue_v10.6.jsonl')==run['queue_sha256']==summary['queue_sha256']==selection['queue_sha256'])
test('queue_5156_unique',len(queue)==5156 and len(set(x['item_id'] for x in queue))==5156)
test('external_5156_unique',len(external)==5156 and len(set(x['item_id'] for x in external))==5156)
test('external_order_matches_queue', [x['item_id'] for x in queue]==[x['item_id'] for x in external])
test('external_completion_metadata',summary['status']=='COMPLETE' and summary['completed_items']==5156 and summary['completed_batches']==323 and summary['failed_batches']==0)
test('external_v5_frozen_model_json',all(x['model_json']['item_id']==x['item_id'] and x['model_json']['direction']==x['direction'] for x in external))
test('phase7_selected_complete_and_disjoint',len(p7)==4395 and len(excluded)==761 and len(pop)==5156 and len({x['item_id'] for x in p7})==4395 and len({x['item_id'] for x in excluded})==761 and not ({x['item_id'] for x in p7} & {x['item_id'] for x in excluded} ) and ({x['item_id'] for x in p7}|{x['item_id'] for x in excluded})=={x['item_id'] for x in queue})
test('phase7_source_counts',collections.Counter((x['direction'],x['final_cell']) for x in p7)=={('R','TP'):484,('R','FN'):154,('N','TN'):142,('G','TP'):3398,('G','FP'):217})
test('phase7_no_unresolved',all(x['final_cell'] in {'TP','FN','TN','FP'} for x in p7))
test('phase7_population_index_matches', all(x['item_id'] in {v['item_id'] for v in queue} for x in pop) and {x['item_id'] for x in pop}=={x['item_id'] for x in queue})
test('phase7_source_sha',all(x['source_pdf_sha256']==lock['pdf_sha256'] and x['source_reference_unchanged'] for x in p7))
test('run_state_consistent',run['item_count']==5156 and run['batch_size']==16 and run['pdf_sha256']==lock['pdf_sha256'] and run['queue_sha256']==selection['queue_sha256'])
test('external_sha_in_phase7_summary', sha(ROOT/'semantic_decisions(2).jsonl')==p7sum['external_decisions_sha256'])

# Batch journal checks: JSON content digest, ordered membership, per-item exact raw records.
zip_path=ROOT/'batch_journals(1).zip'
with zipfile.ZipFile(zip_path) as z:
    test('archive_all_members_crc',z.testzip() is None)
    journal_names=sorted([x for x in z.namelist() if re.fullmatch(r'batch_journals/B10\.6-\d{5}\.json',x)])
    test('exactly_323_journal_files',len(journal_names)==323)
    by_item={}
    journal_hash_verified=0
    journal_errors=[]
    for i in range(323):
        name=f'batch_journals/B10.6-{i+1:05d}.json'
        try:
            j=json.loads(z.read(name))
            batch=queue[i*16:(i+1)*16]
            sig=hashtext(js({'raw_model_json':j.get('raw_model_json'),'item_records':j.get('item_records')}))
            valid=(j['batch_id']==f'B10.6-{i+1:05d}' and j['batch_index']==i and j['batch_size']==len(batch) and j['queue_sha256']==run['queue_sha256'] and j['pdf_sha256']==lock['pdf_sha256'] and j['input_digest']==hashtext(js(batch)) and j['content_sha256']==sig and len(j['item_records'])==len(batch) and [x['item_id'] for x in j['item_records']]==[x['item_id'] for x in batch] and [x['item_id'] for x in j['raw_model_json']['results']]==[x['item_id'] for x in batch])
            if not valid:journal_errors.append(name)
            else:journal_hash_verified+=1
            for x in j['item_records']:
                if x['item_id'] in by_item:journal_errors.append('duplicate:'+x['item_id'])
                by_item[x['item_id']]=x
        except Exception as e:
            journal_errors.append(name+':'+str(e))
    test('all_323_journals_content_identity', journal_hash_verified==323, journal_errors[:8])
    test('journal_5156_item_id_set',len(by_item)==5156 and set(by_item)=={x['item_id'] for x in queue})
    ext_mismatch=[x['item_id'] for x in external if js(x)!=js(by_item.get(x['item_id']))]
    test('external_journals_exact_json_items',not ext_mismatch,ext_mismatch[:8])

# Every R and N, eligible G and nondefinitive exclusion is accounted for.
active={x['item_id']:x for x in p7}
qmap={x['item_id']:x for x in queue}
test('all_r_ids_frozen', {x['item_id'] for x in p7 if x['direction']=='R'}=={x['requirement_id'] if 'requirement_id' in x else x['source_id'] for x in source})
test('all_n_ids_frozen', {x['item_id'] for x in p7 if x['direction']=='N'}=={x['control_id'] if 'control_id' in x else x['negative_control_id'] for x in control})
test('all_phase7_r_n_g_versus_queue',all(x['direction']==qmap[x['item_id']]['direction'] for x in p7+excluded))

# Trace original decision identities, preserve exact history.
v5={x['item_id']:x for x in external}
test('phase7_v5_record_hashes', all(x.get('v5_record_sha256')==hashtext(js(v5[x['item_id']])) for x in p7))
test('phase7_v5_model_json_hashes', all(x.get('v5_original_model_json_sha256')==hashtext(js(v5[x['item_id']]['model_json'])) for x in p7))

# Annotation of source-backed item-level disagreements; do not change Phase07 decisions.
conflict_pairs=[
 {'id':'P08-CONFLICT-001','a':'GCLASS-0002386','b':'GCLASS-0004356','subject':'Outbox event-envelope validation at publisher/dispatch boundary','original_pdf_page':48,'pdf_quote':'All events contain event_id, type, schema_version, tenant_id, aggregate_id, aggregate_revision, occurred_at, trace_id and payload.','reason':'BAT-010 step 2 and FLOW-012 step 2 describe validation of the same mandatory envelope at the outbox publishing boundary. The former has diagnostic FP and the latter diagnostic TP. Scope and complete proposition must be reconciled by an explicit Phase 07 superseding decision.'},
 {'id':'P08-CONFLICT-002','a':'GCLASS-0002250','b':'GCLASS-0004199','subject':'Classifier replay must not overwrite a later user label correction','original_pdf_page':12,'pdf_quote':'the user can correct labels with a reason code.','reason':'BAT-001 OQ-BAT-010 and FLOW-002-S06 prohibit overwrite of later user corrections by unresolved classifier rerun/replay policies. Their action, actor, object and exception scope are materially equivalent, but Phase 07 labels the first FP and the second TP. A source-grounded Phase 07 supersession must establish one consistent supportedness judgment.'}
]
for c in conflict_pairs:
    a,b=active[c['a']],active[c['b']]
    c['current_phase07_cells']={c['a']:a['final_cell'],c['b']:b['final_cell']}
    c['generated_evidence']={item['item_id']:[{'file':e['file'],'line_start':e['line_start'],'line_end':e['line_end'],'quote_en':e['quote_en']} for e in item['generated_evidence'][:2]] for item in [a,b]}
    c['pdf_page_quote_verifiable']= ' '.join(c['pdf_quote'].split()) in ' '.join(fitz.open(pdf)[c['original_pdf_page']-1].get_text().split())
    c['required_action']='PHASE07_EXPLICIT_SUPERSEDING_ADJUDICATION'
    c['phase08_cell_changed']=False
    c['record_type']='PHASE08_ITEM_LEVEL_SEMANTIC_CONTRADICTION'
    c['protocol_version']='10.6'
test('reported_contradictions_real_and_provenance_valid',all(c['pdf_page_quote_verifiable'] and c['current_phase07_cells'][c['a']]!=c['current_phase07_cells'][c['b']] for c in conflict_pairs))

# Track all 217 diagnostic generated-only FP candidates without prematurely assigning canonical FP.
residuals=[]
for i,x in enumerate(p7):
    if x['direction']!='G' or x['final_cell']!='FP': continue
    item=qmap[x['item_id']]
    residuals.append({'record_type':'PHASE08_GENERATED_FP_RESIDUAL_PENDING_RECONCILIATION','item_id':x['item_id'],'direction':'G','method':'fullload','phase07_diagnostic_cell':'FP','candidate_statement_en':item['statement_en'],'phase07_unmet_predicates_en':x['unmet_predicates_en'],'phase07_reason_en':x['decision_reason_en'],'generated_evidence':x['generated_evidence'][:2],'pdf_evidence':x['pdf_evidence'][:4],'source_pdf_sha256':lock['pdf_sha256'],'canonical_fp_counted':False,'reconciliation_state':'BLOCKED_BY_PHASE07_CONTRADICTIONS' if x['item_id'] in {c[k] for c in conflict_pairs for k in ('a','b')} else 'PENDING_SEMANTIC_UNIFICATION','protocol_version':'10.6'})
outputj(OUT/'08_generated_fp_candidates_unreconciled.jsonl',residuals)

# Candidate duplicate edges are audit leads rather than semantic merge authority.
pairs=load(ROOT/'_phase08_pairs.json') if (ROOT/'_phase08_pairs.json').exists() else []
cross=load(ROOT/'_phase08_cross_status_pairs.json') if (ROOT/'_phase08_cross_status_pairs.json').exists() else []
near=[]
for p in pairs[:160]:
    if p['similarity']>=0.20:
        near.append({'record_type':'PHASE08_NONBINDING_NEAR_DUPLICATE_REVIEW','a':p['a'],'b':p['b'],'similarity_diagnostic_only':p['similarity'],'potential_semantic_equivalence_not_proven':True,'a_text':p['a_text'],'b_text':p['b_text']})
outputj(OUT/'08_residual_near_duplicate_review.jsonl',near)

# Phase 07 population copy with no Phase08 label change, not an official FINAL_* ledger.
provisional=[]
for x in queue:
    a=active.get(x['item_id']);p= {'record_type':'PHASE08_POPULATION_CROSSWALK_NONSCORING','item_id':x['item_id'],'direction':x['direction'],'source_queue_position':len(provisional)+1,'method':'fullload','phase07_original_status':'DEFINITIVE' if a else 'EXCLUDED_NONDEFINITIVE','phase07_cell':a['final_cell'] if a else None,'phase08_canonical_cell_committed':False,'phase08_diagnostic_fp_consolidated':False if a and a['direction']=='G' and a['final_cell']=='FP' else None,'original_v5_batch_id':v5[x['item_id']]['batch_id'],'source_pdf_sha256':lock['pdf_sha256']}
    provisional.append(p)
outputj(OUT/'08_population_crosswalk_non_scoring.jsonl',provisional)

# Canonical source and N counts are mechanically reconcilable, but FP cannot be released.
source_counts=collections.Counter(x['final_cell'] for x in p7 if x['direction']=='R')
neg_counts=collections.Counter(x['final_cell'] for x in p7 if x['direction']=='N')
g_counts=collections.Counter(x['final_cell'] for x in p7 if x['direction']=='G')
model_mismatch=run['model']!='gpt-6.1-sol'
outputj(OUT/'08_reconciliation_audit.jsonl',[
 {'record_type':'PHASE08_INTEGRITY_AUDIT','status':'PASS' if all(checks.values()) else 'FAILED','protocol_version':'10.6','checks':checks,'source_sha256':lock['pdf_sha256'],'queue_sha256':run['queue_sha256'],'external_model':run['model'],'protocol_required_model':'gpt-6.1-sol','comparability_warning':model_mismatch},
 *conflict_pairs,
 {'record_type':'PHASE08_EXTERNAL_MODEL_DEVIATION','protocol_version':'10.6','observed_deployment':run['model'],'specified_deployment':'gpt-6.1-sol','effect':'NONCOMPARABLE_WITH_CONFORMING_RUNS_UNLESS_EXPLICIT_CROSS_METHOD_INVARIANCE_IS_REESTABLISHED','phase07_cells_changed':False},
 {'record_type':'PHASE08_DEDUP_HALTED','protocol_version':'10.6','raw_G_FP_candidates':len(residuals),'canonical_generated_only_FP':None,'R_TP':source_counts['TP'],'R_FN':source_counts['FN'],'N_FP':neg_counts['FP'],'N_TN':neg_counts['TN'],'blocking_contradiction_ids':[c['id'] for c in conflict_pairs],'reason':'The governing protocol prohibits Phase 08 from overwriting contradictory Phase 07 item-level decisions. Residual semantic classes and final binary counts are not committed.'}
])
outputj(OUT/'08_return_to_phase07.jsonl',[{'record_type':'PHASE08_REQUIRED_PHASE07_SUPERSESSION','protocol_version':'10.6','contradiction_id':c['id'],'item_ids':[c['a'],c['b']],'old_phase07_cells':c['current_phase07_cells'],'source_pdf_page':c['original_pdf_page'],'source_pdf_quote_en':c['pdf_quote'],'source_generated_evidence':c['generated_evidence'],'original_phase07_records_must_remain_immutable':True,'required_work_en':c['reason'],'phase08_must_resume_only_after_supersession_and_revalidation':True} for c in conflict_pairs])

can_report_complete = all(checks.values()) and not conflict_pairs and not issues
status='PHASE_COMPLETED' if can_report_complete else 'INCOMPLETE'
count_summary={'frozen_R':len(source),'frozen_N':len(control),'GO_original':5046,'GC_phase02':4861,'GC_effective_queue':4376,'GC_eligible_after_phase07':g_counts['TP']+g_counts['FP'],'GC_excluded_nondefinitive':len(excluded),'R_TP_phase07':source_counts['TP'],'R_FN_phase07':source_counts['FN'],'N_FP_phase07':neg_counts['FP'],'N_TN_phase07':neg_counts['TN'],'G_diagnostic_TP_phase07':g_counts['TP'],'G_diagnostic_FP_candidates_phase07':g_counts['FP'],'external_completed_batches':323,'external_completed_items':5156,'journal_digest_validated':journal_hash_verified,'phase08_confirmed_residual_fp':None,'phase08_final_TP_FP_TN_FN':None,'semantic_contradictions':len(conflict_pairs),'model_mismatch':model_mismatch}
validation={'record_type':'PHASE08_VALIDATION','protocol_version':'10.6','method':'fullload','status':status,'mechanical_checks':checks,'failed_mechanical_checks':issues,'counts':count_summary,'semantic_blockers':[c['id'] for c in conflict_pairs],'model_conformance_warning':'gpt-6.2-sol supplied; protocol requires gpt-6.1-sol' if model_mismatch else None,'no_phase07_item_cells_modified':True,'phase08_final_ledger_withheld':not can_report_complete,'phase08_binary_counts_withheld':not can_report_complete,'phase09_not_started':True}
output(OUT/'08_validation_results.json',validation)
report=f'''# Phase 08 — Independent Semantic Reconciliation Audit (Version 10.6)\n\n## Status: {status}\n\nPhase 08 stopped at the semantic-consistency gate under §8.1. It did not replace Phase 07 item decisions and did not create a fabricated canonical FP count. The required `08_final_ledger.jsonl` and `08_binary_counts.json` are intentionally withheld until the recorded Phase 07 contradictions are superseded and verified.\n\n## Verified immutable inputs\n\n- PDF: 90 pages, SHA-256 `{lock['pdf_sha256']}`.\n- Frozen R: 638; N: 142, both original SHA-256 verified.\n- Queue: 5,156 unique IDs, SHA-256 `{run['queue_sha256']}`.\n- External evaluator: 323 complete hash-verified batch journals containing 5,156 matching original item results; no current failed batch.\n- Final Phase 07: R TP={source_counts['TP']}, FN={source_counts['FN']}; N FP={neg_counts['FP']}, TN={neg_counts['TN']}; G supported diagnostic TP={g_counts['TP']}, unsupported diagnostic FP candidates={g_counts['FP']}; excluded nondefinitive={len(excluded)}.\n- Each source ID, control ID and effective generated class is represented exactly once in the Phase 07 population.\n\n## Blocking Phase 07 semantic contradictions\n\n1. **P08-CONFLICT-001**: `GCLASS-0002386` is **FP**, while `GCLASS-0004356` is **TP**. Both describe the outbox publisher validating the mandatory event envelope with the same nine properties. Source PDF page 48 states those nine fields. An explicit Phase 07 superseding decision must reconcile the differing applicability findings.\n2. **P08-CONFLICT-002**: `GCLASS-0002250` is **FP**, while `GCLASS-0004199` is **TP**. Both prohibit a classifier retry/replay from overwriting a later user classification correction. Their generated statements describe the same actor, target and action. Source PDF page 12 confirms user corrections with reason codes and pages 17/48 define replay/stale event controls. An explicit Phase 07 superseding decision must resolve the support judgment.\n\nThese are competing *Phase 07 item-level* classifications, not a Phase 08 license to decide a different label. The original Phase 07 records remain unchanged.\n\n## Additional experimental configuration deviation\n\nThe supplied external run records model `gpt-6.2-sol`, while Protocol 10.6 §4.2 specifies `gpt-6.1-sol`. This must be tracked as a cross-method comparability deviation; no deployment identity was rewritten. The run used 16-item batches, which are an approved protocol size.\n\n## Prepared but non-scoring artifacts\n\n- `08_population_crosswalk_non_scoring.jsonl`: full queue-to-Phase07 ID correspondence.\n- `08_generated_fp_candidates_unreconciled.jsonl`: all 217 candidate unsupported classes, preserving their Phase 07 records.\n- `08_residual_near_duplicate_review.jsonl`: lexical candidate pairs for future semantic deduplication; similarity does not assert equivalence.\n- `08_reconciliation_audit.jsonl`: mechanical provenance audit, two Phase 07 contradictions, and configuration deviation.\n- `08_return_to_phase07.jsonl`: exact IDs requiring explicit source-grounded superseding adjudication.\n\n## Completion gate\n\nPhase 08 remains **INCOMPLETE**. Produce explicit Phase 07 superseding adjudications for the contradictory pairs, preserve all prior files, and rerun independent Phase 08 validation and N/F semantic consolidation. Do not compute final canonical FP or Precision/Recall/F1 from this incomplete ledger. No Phase 09 operations were performed.\n'''
(OUT/'08_phase_report.md').write_text(report,encoding='utf-8')
files=[p for p in OUT.iterdir() if p.is_file() and p.name not in {'08_output_manifest.json','run_phase08_reconciliation_audit.py'}]
manifest={'record_type':'PHASE08_OUTPUT_MANIFEST','protocol_version':'10.6','status':status,'files':{p.name:{'sha256':sha(p),'size_bytes':p.stat().st_size} for p in sorted(files)},'no_phase07_mutations':True,'canonical_counts_not_committed':True}
output(OUT/'08_output_manifest.json',manifest)
print(json.dumps({'status':status,'counts':count_summary,'mechanical_checks_passed':sum(checks.values()),'mechanical_checks_failed':[k for k,v in checks.items() if not v], 'semantic_blockers':[c['id'] for c in conflict_pairs], 'files':[p.name for p in sorted(files)]},ensure_ascii=False,indent=2))
