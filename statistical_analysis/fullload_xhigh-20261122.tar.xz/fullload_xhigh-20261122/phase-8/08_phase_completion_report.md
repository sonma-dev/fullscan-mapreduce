# Phase 08 — Completed Independent Semantic Reconciliation

Status: COMPLETE (Version 10.6; fullload).

## Phase 07 source-grounded supersessions

- GCLASS-0002386: diagnostic FP -> TP. Original PDF physical page 48 establishes the exact mandatory event envelope; consistent with GCLASS-0004356.
- GCLASS-0002250: diagnostic FP -> TP. Original PDF physical pages 12, 17 and 48 jointly establish user-correction and stale replay safety; consistent with GCLASS-0004199.
- The original Phase 07 files and the prior incomplete Phase 08 audit were preserved. Supersessions are separate immutable records.

## Canonical reconciliation

- Frozen positive requirements: 638 (TP=484; FN=154).
- Frozen negative controls: 142 (affirmed N=0; TN=142).
- Eligible effective generated classes: 3,615 (supported diagnostic=3,400; unsupported diagnostic=215).
- Excluded nondefinitive classes: 761.
- Distinct generated-only unsupported residuals after semantic consolidation: 205.
- No affirmative negative-control overlap was found in the Phase 07 N decisions; mere prohibited-word matches were not counted as forbidden assertions.
- Final canonical cells: TP=484; FN=154; TN=142; FP=205. Canonical universe size 985.
- FINAL_SOURCE=638; FINAL_CONTROL=142; FINAL_CLASS=3,615; FINAL_RESIDUAL=205; total ledger rows=4,600.

## Semantic consolidation method

- All 215 effective generated FP candidates were individually retained and mapped to one of 205 residual identities.
- Nine manually reviewed shared unsupported-residual equivalence families merge 10 excess occurrences; every remaining class is retained as a separate residual.
- Groups were selected using direction, actor, action, target, condition, scope and missing-predicate comparison; lexical similarity was only an inspection aid.
- Candidate pairs with different requirements, screen actions, error treatments, data fields or stage timings are not automatically merged.
- No diagnostic G:TP adds a canonical TP.
- A shared unsupported residual rather than copied statements is counted once. The additional PDF-supported parts of a mixed statement do not add FP.

## Immutable provenance and limitations

- PDF 90 physical pages and all eight original generated specifications match the original SHA-256 lock.
- Complete external queue: 5,156 items; 323 committed external batches, with source and queue hashes preserved.
- The external deployment was gpt-6.2-sol rather than protocol §4.2 gpt-6.1-sol. This is a material cross-method comparability deviation, not a reason to change source references or fabricate corrected external judgments.
- The semantic classifications remain evidence-dependent expert/assistant judgments, not a proof of infallibility; a mechanically passing ledger does not prove every independent interpretation is correct.
- This phase does not compute Precision, Recall or F1. Phase 09 must independently recompute metrics and comparability.
