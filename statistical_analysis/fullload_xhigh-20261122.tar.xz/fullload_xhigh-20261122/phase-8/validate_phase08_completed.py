#!/usr/bin/env python3
"""Independent read-only integrity and conservation validator for completed Phase 08."""
import collections,hashlib,json,pathlib,zipfile,re,unicodedata
import fitz
R=pathlib.Path('/mnt/data');B=R/'oriondesk_fullload_v10_6';O=B/'phase08'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def J(p):return json.loads(p.read_text(encoding='utf-8'))
def L(p):return [json.loads(x) for x in p.read_text(encoding='utf-8').splitlines() if x.strip()]
def js(d):return json.dumps(d,ensure_ascii=False,sort_keys=True,separators=(',',':'))
def norm(s):return ' '.join(unicodedata.normalize('NFKC',s).split())
T={};bad=[]
def ck(k,cond,detail=''):
 T[k]=bool(cond)
 if not cond:bad.append({'test':k,'detail':detail})
lock=J(B/'phase01/01_reference_lock.json');run=J(R/'run_state(1).json')
summary=J(R/'semantic_summary(1).json');cnt=J(O/'08_binary_counts.json')
q=L(B/'phase06/06_llm_queue_v10.6.jsonl')
p7=L(B/'phase07/07_assistant_adjudications.jsonl');ex=L(B/'phase07/07_eligibility_exclusions.jsonl')
sup=L(B/'phase07/07_phase08_return_superseding_adjudications.jsonl');led=L(O/'08_final_ledger.jsonl')
cross=L(O/'08_effective_population_crosswalk.jsonl');au=L(O/'08_reconciliation_audit_completion.jsonl')
N=L(R/'common_negative_controls(4).jsonl');Sr=L(R/'common_atomic_reqs(4).jsonl')
ck('protocol_and_method',cnt['protocol_version']=='10.6' and cnt['method']=='fullload' and cnt['status']=='COMPLETE')
ck('source_pdf_digest',sha(R/'OrionDesk_AI_Detailed_Design_Specification(4).pdf')==lock['pdf_sha256']==run['pdf_sha256'])
with fitz.open(R/'OrionDesk_AI_Detailed_Design_Specification(4).pdf') as pdf:
 ck('source_pdf_90_pages',len(pdf)==90)
 pdfpages=[p.get_text(sort=True) for p in pdf]
ck('frozen_r_digest',sha(R/'common_atomic_reqs(4).jsonl')==lock['frozen_r_sha256'])
ck('frozen_n_digest',sha(R/'common_negative_controls(4).jsonl')==lock['frozen_n_sha256'])
ck('r_n_population',len(Sr)==638 and len(N)==142)
roles={r['canonical_name']:r for r in lock['source_roles_ordered']}
ck('source8_role_count',len(roles)==8)
ck('source8_roles_digest',all(sha(R/v['actual_filename'])==v['sha256']==run['file_sha256'][k] for k,v in roles.items()))
ck('source_queue_digest',sha(B/'phase06/06_llm_queue_v10.6.jsonl')==run['queue_sha256']==cnt['queue_sha256'])
ck('source_queue_unique_5156',len(q)==5156 and len({r['item_id'] for r in q})==5156)
ck('phase7_original_immutable',sha(B/'phase07/07_assistant_adjudications.jsonl')==cnt['phase07_original_sha256'])
ck('phase7_original_4395',len(p7)==4395 and len({r['item_id'] for r in p7})==4395)
ck('phase7_exclusions_761',len(ex)==761 and len({r['item_id'] for r in ex})==761)
ck('phase7_full_queue_coverage', {r['item_id'] for r in q}==({r['item_id'] for r in p7}|{r['item_id'] for r in ex}) and not {r['item_id'] for r in p7}.intersection({r['item_id'] for r in ex}))
ck('supplemental_phase7_supersession_count',len(sup)==2 and {s['item_id'] for s in sup}=={'GCLASS-0002386','GCLASS-0002250'})
old={r['item_id']:r for r in p7}
ck('supersessions_on_prior_fp_only',all(old[s['item_id']]['final_cell']=='FP' and s['prior_final_cell']=='FP' and s['new_final_cell']=='TP' and s['new_decision_rule_id']=='P7-G-SUPPORTED' for s in sup))
ck('phase7_new_sup_digest',sha(B/'phase07/07_phase08_return_superseding_adjudications.jsonl')==cnt['phase07_new_supersession_sha256'])
ck('p7_sup_original_evidence_verification',all(all(0<e['physical_page']<=90 and norm(e['quote_en']).casefold() in norm(pdfpages[e['physical_page']-1]).casefold() for e in s['pdf_evidence']) for s in sup))
actual_lines={k:(R/v['actual_filename']).read_text().splitlines() for k,v in roles.items()}
ck('p7_sup_generated_lines_verification',all(all(1<=e['line_start']<=e['line_end']<=len(actual_lines[e['file']]) and norm(e['quote_en']) in norm(' '.join(actual_lines[e['file']][e['line_start']-1:e['line_end']])) and e['sha256']==roles[e['file']]['sha256'] for e in s['generated_evidence']) for s in sup))
# Check the actual JSON journal identities independently of the generator.
failed=[]; seen=set(); jcount=0
with zipfile.ZipFile(R/'batch_journals(1).zip') as zip:
 names=[n for n in zip.namelist() if re.fullmatch(r'batch_journals/B10\.6-\d{5}\.json',n)]
 ck('journal_exactly_323',len(names)==323)
 for i in range(323):
  name=f'batch_journals/B10.6-{i+1:05d}.json'
  try:
   j=json.loads(zip.read(name));seg=q[i*16:(i+1)*16]; ids=[v['item_id'] for v in seg]
   sig=hashlib.sha256(js({'raw_model_json':j['raw_model_json'],'item_records':j['item_records']}).encode('utf-8')).hexdigest()
   inp=hashlib.sha256(js(seg).encode('utf-8')).hexdigest()
   ok=(j['batch_index']==i and j['batch_id']==name.rsplit('/',1)[-1][:-5] and j['batch_size']==len(seg) and
       j['content_sha256']==sig and j['input_digest']==inp and j['pdf_sha256']==lock['pdf_sha256'] and
       j['queue_sha256']==run['queue_sha256'] and [v['item_id'] for v in j['item_records']]==ids and
       [v['item_id'] for v in j['raw_model_json']['results']]==ids)
   if not ok:failed.append(name)
   else:jcount+=1
   if any(v in seen for v in ids):failed.append('repeated ID '+name)
   seen.update(ids)
  except Exception as e:failed.append(name+':'+str(e))
ck('all_323_journals_verified',jcount==323 and not failed,repr(failed[:3]))
ck('journal_items_cover_full_queue',seen=={r['item_id'] for r in q})
ck('external_summary_323_complete',summary['status']=='COMPLETE' and summary['completed_batches']==323 and summary['completed_items']==5156 and summary['failed_batches']==0)
# One old-model item remains one corresponding item, no invented submissions.
ext=L(R/'semantic_decisions(2).jsonl')
ck('external_jsonl_item_population',len(ext)==5156 and [v['item_id'] for v in ext]==[v['item_id'] for v in q])
ck('final_ledger_kind_cardinalities',collections.Counter(x['record_type'] for x in led)=={'FINAL_SOURCE':638,'FINAL_CONTROL':142,'FINAL_CLASS':3615,'FINAL_RESIDUAL':205})
Fs=[x for x in led if x['record_type']=='FINAL_SOURCE'];Ns=[x for x in led if x['record_type']=='FINAL_CONTROL'];Gs=[x for x in led if x['record_type']=='FINAL_CLASS'];Fs_only=[x for x in led if x['record_type']=='FINAL_RESIDUAL']
ck('source_ids_exact',set(x['source_id'] for x in Fs)==set(x['requirement_id'] for x in Sr) and len(set(x['source_id'] for x in Fs))==638)
ck('control_ids_exact',set(x['control_id'] for x in Ns)==set(x['control_id'] for x in N) and len(set(x['control_id'] for x in Ns))==142)
ck('final_class_ids_exact',set(x['gclass_id'] for x in Gs)=={x['item_id'] for x in p7 if x['direction']=='G'})
ck('G_supported_unsupported_classes',collections.Counter(x['diagnostic_cell'] for x in Gs)=={'TP':3400,'FP':215})
ck('canonical_R_cells',collections.Counter(x['scoring_cell'] for x in Fs)=={'TP':484,'FN':154})
ck('canonical_N_cells',collections.Counter(x['scoring_cell'] for x in Ns)=={'TN':142})
ck('all_negative_polarities_preserved',all(x['affirmative_prohibited_assertion_found']==False for x in Ns))
ck('residual_id_unique',len({r['residual_id'] for r in Fs_only})==205)
ck('residual_positive_FP_only',all(r['scoring_cell']=='FP' and r['counted_fp_units']==1 for r in Fs_only))
ck('fp_membership_partition_215',len([id for r in Fs_only for id in r['member_gclass_ids']])==215 and len({id for r in Fs_only for id in r['member_gclass_ids']})==215 and {id for r in Fs_only for id in r['member_gclass_ids']}=={g['gclass_id'] for g in Gs if g['diagnostic_cell']=='FP'})
resmap={id:r['residual_id'] for r in Fs_only for id in r['member_gclass_ids']}
ck('class_to_fp_residual_links',all((g['final_residual_id']==resmap[g['gclass_id']]) if g['diagnostic_cell']=='FP' else (g['final_residual_id'] is None) for g in Gs))
ck('class_diagnostic_tp_never_canonical',all(g['canonical_tp_contribution']==0 and g['canonical_fp_contribution']==0 for g in Gs))
ck('fp_n_overlaps_none',all(not r['source_negative_control_overlap_ids'] for r in Fs_only) and cnt['N_F_overlap_removed']==0)
ck('crosswalk_full_5156',len(cross)==5156 and [x['item_id'] for x in cross]==[q1['item_id'] for q1 in q])
ck('crosswalk_excluded_count',sum(x['eligibility']=='EXCLUDED_NONDEFINITIVE' for x in cross)==761)
ck('crosswalk_supersessions_exact', {x['item_id'] for x in cross if x['phase07_supersession']}=={s['item_id'] for s in sup})
ck('all_final_pdf_digests',all(x['source_pdf_sha256']==lock['pdf_sha256'] for x in led))
ck('FP_positive_universe_sums',cnt['TP']+cnt['FN']==638 and cnt['TN']+cnt['N_FP']==142 and cnt['FP']==cnt['N_FP']+cnt['F'] and cnt['TP']+cnt['TN']+cnt['FP']+cnt['FN']==cnt['canonical_universe_size']==985)
ck('all_originals_still_frozen',all(sha(R/roles[k]['actual_filename'])==v['sha256'] for k,v in roles.items()))
ck('no_phase09_metrics_in_phase08',cnt['do_not_compute_metrics_in_phase08'] and all(k not in cnt for k in ('Precision','Recall','F1')))
ck('method_mismatch_reported',run['model']=='gpt-6.2-sol' and cnt['cross_method_comparable'] is False and cnt['protocol_model_requirement']=='gpt-6.1-sol')
ck('no_final_unresolved',cnt['unresolved_final']==0 and all(g['diagnostic_cell'] in ('TP','FP') for g in Gs))
ck('no_duplicate_integration_records',len(set(x['source_id'] for x in Fs))==638 and len(set(x['control_id'] for x in Ns))==142 and len(set(x['gclass_id'] for x in Gs))==3615)
ck('new_completion_manifest_shas',all(sha(B/k)==v for k,v in J(O/'08_completion_output_manifest.json')['output_sha256'].items()))
check={'record_type':'PHASE08_COMPLETION_INDEPENDENT_VALIDATION','protocol_version':'10.6','status':'PASS' if not bad else 'FAIL',
       'checks_total':len(T),'checks_passed':sum(T.values()),'checks':T,'failures':bad,'source_pdf_sha256':lock['pdf_sha256'],
       'final_ledger_sha256':sha(O/'08_final_ledger.jsonl'),'binary_counts_sha256':sha(O/'08_binary_counts.json')}
(O/'08_completion_independent_validation.json').write_text(json.dumps(check,ensure_ascii=False,sort_keys=True,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'status':check['status'],'checks_passed':check['checks_passed'],'checks_total':len(T),'failures':bad},ensure_ascii=False))
if bad:raise SystemExit(1)
