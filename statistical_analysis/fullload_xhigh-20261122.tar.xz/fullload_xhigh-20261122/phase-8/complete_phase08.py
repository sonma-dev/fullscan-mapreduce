#!/usr/bin/env python3
"""Phase 07 explicit supersession + Phase 08 non-rejudging consolidation, v10.6.

Preserves prior source, evaluator, Phase 07 and incomplete Phase 08 artifacts byte-for-byte.
The independently authored equivalence families below consolidate only shared
unsupported affirmative residuals, never model-score or lexical similarity alone.
"""
from __future__ import annotations
import collections, copy, hashlib, json, pathlib, unicodedata, re
from datetime import datetime, timezone
import fitz

ROOT=pathlib.Path('/mnt/data')
BASE=ROOT/'oriondesk_fullload_v10_6'
P7=BASE/'phase07'; P8=BASE/'phase08'

def load(p):return json.loads(p.read_text(encoding='utf-8'))
def jl(p):return [json.loads(x) for x in p.read_text(encoding='utf-8').splitlines() if x.strip()]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def sha_str(s):return hashlib.sha256(s.encode('utf-8')).hexdigest()
def js(v):return json.dumps(v,sort_keys=True,ensure_ascii=False,separators=(',',':'))
def write_json(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2,sort_keys=True)+'\n',encoding='utf-8')
def write_jsonl(p,arr):p.write_text(''.join(js(x)+'\n' for x in arr),encoding='utf-8')
def norm(s):return ' '.join(unicodedata.normalize('NFKC',s).split())

pdf_path=ROOT/'OrionDesk_AI_Detailed_Design_Specification(4).pdf'
lock=load(BASE/'phase01/01_reference_lock.json')
run=load(ROOT/'run_state(1).json')
sel=load(BASE/'phase06/06_queue_selection.json')
queue=jl(BASE/'phase06/06_llm_queue_v10.6.jsonl')
source=jl(ROOT/'common_atomic_reqs(4).jsonl')
negative=jl(ROOT/'common_negative_controls(4).jsonl')
phase7=jl(P7/'07_assistant_adjudications.jsonl')
exclusions=jl(P7/'07_eligibility_exclusions.jsonl')
fp_old=jl(P8/'08_generated_fp_candidates_unreconciled.jsonl')
external=jl(ROOT/'semantic_decisions(2).jsonl')
assert sha(pdf_path)==lock['pdf_sha256']==run['pdf_sha256']
assert sha(ROOT/'common_atomic_reqs(4).jsonl')==lock['frozen_r_sha256']
assert sha(ROOT/'common_negative_controls(4).jsonl')==lock['frozen_n_sha256']
assert sha(BASE/'phase06/06_llm_queue_v10.6.jsonl')==run['queue_sha256']==sel['queue_sha256']
roles={r['canonical_name']:r for r in lock['source_roles_ordered']}
assert len(roles)==8
for role,r in roles.items():assert sha(ROOT/r['actual_filename'])==r['sha256']==run['file_sha256'][role]
assert len(queue)==5156 and len(source)==638 and len(negative)==142 and len(phase7)==4395 and len(exclusions)==761
assert len(external)==5156 and [r['item_id'] for r in queue]==[r['item_id'] for r in external]
assert len({r['item_id'] for r in phase7})==len(phase7)
assert {r['item_id'] for r in phase7}.isdisjoint({r['item_id'] for r in exclusions})
assert {r['item_id'] for r in phase7}|{r['item_id'] for r in exclusions}=={r['item_id'] for r in queue}
with fitz.open(pdf_path) as doc:
 assert len(doc)==90
 pdf_text=[doc[i].get_text(sort=True) for i in range(90)]
# Validate original source quotations and context for the returned contradictions.
by_id={x['item_id']:x for x in phase7}
original_lines={k:(ROOT/v['actual_filename']).read_text(encoding='utf-8').splitlines() for k,v in roles.items()}

def evidence(file, ln, exact):
 lines=original_lines[file]; assert 1<=ln<=len(lines) and norm(exact) in norm(lines[ln-1]),(file,ln,exact)
 return {'file':file,'actual_filename':roles[file]['actual_filename'],'line_start':ln,'line_end':ln,
         'quote_en':exact,'sha256':roles[file]['sha256'],'verified_original':True}

def original_pdf_evidence(page,quote):
 assert 1<=page<=90 and norm(quote).casefold() in norm(pdf_text[page-1]).casefold(),(page,quote)
 return {'physical_page':page,'quote_en':quote,'source_pdf_sha256':lock['pdf_sha256'],'verified_original':True}

corrections=[
 {'item_id':'GCLASS-0002386','match':'GCLASS-0004356','file':'04_batch_functions.md','line':452,
  'quote':'Validate the mandatory envelope: `event_id`, `type`, `schema_version`, `tenant_id`, `aggregate_id`, `aggregate_revision`, `occurred_at`, `trace_id`, `payload`.',
  'pdf':[(48,'All events contain event_id, type, schema_version, tenant_id, aggregate_id, aggregate_revision, occurred_at, trace_id and\npayload.'),
         (48,'At-least-once delivery is assumed; consumers deduplicate event IDs and detect stale aggregate revisions.')],
  'reason':'The event publisher validates an envelope which, under the PDF event contract, must contain all nine exact named attributes. The universal contract applies to all events, including outbox-published events. BAT-010 and FLOW-012 do not require competing or extra envelope attributes. Full scope-valid source entailment is established; the previous FP diagnosis omitted the applicable universal event contract.'},
 {'item_id':'GCLASS-0002250','match':'GCLASS-0004199','file':'04_batch_functions.md','line':193,
  'quote':'Do not overwrite a later user correction through an unresolved rerun policy.',
  'pdf':[(12,'the user can correct labels with a reason\ncode.'),
         (12,'stateful components must reject stale or unauthorized writes before publishing CaseCreated'),
         (17,'Consumers deduplicate by event ID and operation key.'),
         (48,'consumers deduplicate event IDs and detect stale aggregate revisions.')],
  'reason':'A classification replay based on a pre-correction revision is a stale mutation. A later authorized label correction is the current accepted state, and PDF stale-revision and duplicate-event controls prohibit the earlier job from reapplying an obsolete state. The generated guard is limited to later user corrections and unresolved replay/rerun behavior, not a global unprovided precedence rule. The same complete obligation is supported for the corresponding FLOW-002 statement.'}
]
sup=[]
for c in corrections:
 old=by_id[c['item_id']]; assert old['direction']=='G' and old['final_cell']=='FP'
 assert by_id[c['match']]['final_cell']=='TP'
 gen=evidence(c['file'],c['line'],c['quote'])
 pev=[original_pdf_evidence(page,quote) for page,quote in c['pdf']]
 sup.append({'record_type':'PHASE07_SUPERSEDING_ADJUDICATION','protocol_version':'10.6','execution_version':'10.6',
  'item_id':c['item_id'],'direction':'G','method':'fullload','prior_final_cell':'FP','new_final_cell':'TP',
  'prior_decision_rule_id':old['decision_rule_id'],'new_decision_rule_id':'P7-G-SUPPORTED',
  'canonical_counting_scope':'G_DIAGNOSTIC_NOT_CANONICAL_TP','decision_origin':'PHASE07_ASSISTANT',
  'referred_from_phase08':True,'peer_id':c['match'],'superseded_phase07_record_sha256':sha_str(js(old)),
  'source_pdf_sha256':lock['pdf_sha256'],'generated_file_sha256':old['generated_file_sha256'],
  'source_reference_unchanged':True,'generated_evidence':[gen],'pdf_evidence':pev,
  'examined_candidate_ids':[c['item_id'],c['match']],'support_bridge_ids':[],
  'unmet_predicates_en':[],'decision_reason_en':c['reason'],
  'prior_v5_suggested_decision':old.get('prior_v5_suggested_decision'),
  'prior_v5_decision_status':old.get('prior_v5_decision_status'),
  'v5_record_sha256':old.get('v5_record_sha256'),
  'was_external_llm_selected':old.get('was_external_llm_selected',True)})
write_jsonl(P7/'07_phase08_return_superseding_adjudications.jsonl',sup)
# Immutable Phase07 originals are not touched; this effective in-memory view is from separately identified supersessions.
effective={id:copy.copy(r) for id,r in by_id.items()}
for s in sup:
 r=copy.deepcopy(effective[s['item_id']]);r['final_cell']='TP';r['decision_rule_id']='P7-G-SUPPORTED';
 r['canonical_counting_scope']='G_DIAGNOSTIC_NOT_CANONICAL_TP';
 r['phase07_supersession_file']='07_phase08_return_superseding_adjudications.jsonl';
 r['phase07_supersession_record_sha256']=sha_str(js(s));
 r['decision_reason_en']=s['decision_reason_en'];r['pdf_evidence']=s['pdf_evidence'];
 effective[s['item_id']]=r

counts=collections.Counter((r['direction'],r['final_cell']) for r in effective.values())
assert counts=={('R','TP'):484,('R','FN'):154,('N','TN'):142,('G','TP'):3400,('G','FP'):215},counts
unsupported={id for id,r in effective.items() if r['direction']=='G' and r['final_cell']=='FP'}
assert unsupported=={r['item_id'] for r in fp_old}-{c['item_id'] for c in corrections}

# Manually checked, scope-valid shared unsupported residual equivalences. A member
# is merged only on the identical *unsupported residual*, not on a shared heading.
# Generated wording, missing predicate, and scoped original citations are preserved.
families=[
 (['GCLASS-0000249','GCLASS-0004219'],
  'Binding current attachment/document status, extraction-quality flags and provenance to the attachment-status display.',
  'Same case-document status display; one cross-file source-to-screen projection requirement.'),
 (['GCLASS-0000310','GCLASS-0000400','GCLASS-0004237'],
  'Bind evidence/citation click-through to GET /v1/evidence/{evidenceId} and resolve the opaque clicked citation identifier.',
  'One cross-screen citation-to-API binding choice; review inherits the Evidence Viewer action and the flow references both.'),
 (['GCLASS-0001270','GCLASS-0003924'],
  'Require an explicitly resolved interface contract before clarification or human routing for insufficient evidence.',
  'The additional no-blind-generation restriction follows the PDF unsupported-evidence gate; shared residual is the missing routing contract prerequisite.'),
 (['GCLASS-0001713','GCLASS-0002713'],
  'Retain correction-level label provenance together with reason code and durable actor/revision attribution.',
  'The data-field rule and its batch acceptance case require the same correction-level provenance beyond general attribution.'),
 (['GCLASS-0002226','GCLASS-0002570'],
  'Require a committed accepted internal notification/event to be eligible for the optional subscribed webhook delivery.',
  'The webhook predecessor row and processing input row express the same optional-subscription event-eligibility predicate.'),
 (['GCLASS-0003776','GCLASS-0004425'],
  'Do not represent an audit-chain integrity or export failure as positively verified audit evidence.',
  'Same verified-evidence disclosure prohibition for integrity/export failure; immutable-ledger non-rewriting is separately source supported.'),
 (['GCLASS-0004330','GCLASS-0004591'],
  'Do not defer ACL revocation processing behind unrelated file work.',
  'Same source ACL revocation scheduling independence; the additional ordinary-TTL prohibition is PDF-supported and not separately counted as unsupported.'),
 (['GCLASS-0003795','GCLASS-0004647'],
  'Do not mark missing or late-source daily usage reporting as complete or zero-valued without authoritative source data.',
  'Same missing-usage completeness representation; the separate idempotent accounting effects are not included in this residual.'),
 (['GCLASS-0002278','GCLASS-0002724'],
  'Preserve headings as structured headings and preserve original reading order in extracted derivatives.',
  'The batch processing requirement and its layout-rich PDF acceptance case have the same unsupported heading/reading-order preservation residual.')
]
parent={id:id for id in unsupported}
def find(x):
 while parent[x]!=x:parent[x]=parent[parent[x]];x=parent[x]
 return x
pair_audit=[]; paired=set()
for ids,residual,why in families:
 assert len(set(ids))==len(ids) and all(x in unsupported for x in ids)
 assert not paired.intersection(ids)
 paired.update(ids)
 for x in ids[1:]:parent[x]=ids[0]
 pair_audit.append({'record_type':'PHASE08_SEMANTIC_RESIDUAL_EQUIVALENCE','protocol_version':'10.6',
  'member_gclass_ids':ids,'shared_unsupported_residual_en':residual,'mutual_entailment_scope_en':why,
  'all_original_generated_evidence':[{'item_id':k,'generated_evidence':effective[k].get('generated_evidence',[]),
  'unmet_predicates_en':effective[k].get('unmet_predicates_en',[])} for k in ids],
  'counted_once':True})

# Group by explicit supported equivalent families; singleton assertions retained once.
family_lookup={g[0][0]:g for g in families}
for ids,_,_ in families:
 for x in ids:assert find(x)==ids[0]
clusters=collections.defaultdict(list)
for id in unsupported:clusters[find(id)].append(id)
order={r['item_id']:i for i,r in enumerate(queue)}
cluster_list=sorted((sorted(members,key=order.__getitem__) for members in clusters.values()), key=lambda x:min(order[y] for y in x))
assert len(cluster_list)==205 and sum(map(len,cluster_list))==215

# All N were independently TN; a generated assertion affirming a fixed N would contradict
# Phase07 N:TN. Check source-negative polarity explicitly and retain an N/F nonoverlap audit.
N_map={r['item_id']:r for r in effective.values() if r['direction']=='N'}
assert len(N_map)==142 and all(x['final_cell']=='TN' for x in N_map.values())
neg_audit=[]
for n in negative:
 nid=n['control_id'];r=N_map[nid]
 neg_audit.append({'record_type':'PHASE08_NEGATIVE_CONTROL_POLARITY','control_id':nid,
  'affirmative_counterfactual_en':n['counterfactual_en'],'phase07_cell':r['final_cell'],
  'phase07_generated_evidence':r.get('generated_evidence',[]),
  'affirmative_generated_assertion_found':False,'counted_in_N_FP':False,
  'interpretation_en':'A generated prohibition of this counterfactual is not its affirmative assertion; accepted Phase07 N:TN has no N-positive overlap with a generated-only residual.'})

# Final ledger includes all source rows, controls, diagnostic classes and counted unique FP residuals.
source_byid={r['requirement_id']:r for r in source}
negative_byid={r['control_id']:r for r in negative}
ledger=[]
for s in source:
 id=s['requirement_id'];r=effective[id]
 assert r['direction']=='R' and r['final_cell'] in ('TP','FN')
 ledger.append({'record_type':'FINAL_SOURCE','protocol_version':'10.6','method':'fullload','source_id':id,
  'original_source_statement_en':s['statement_en'],'scoring_cell':r['final_cell'],'llm_item_id':id,
  'source_pdf_sha256':lock['pdf_sha256'],'original_pdf_evidence':s['pdf_evidence'],
  'pdf_evidence':r['pdf_evidence'],'generated_evidence':r['generated_evidence'],
  'phase07_decision_rule_id':r['decision_rule_id'],'decision_origin':'PHASE07_ASSISTANT',
  'phase07_evidence_ledger_sha256':sha(P7/'07_assistant_adjudications.jsonl'),
  'decision_reason_en':r['decision_reason_en'],'unmet_predicates_en':r.get('unmet_predicates_en',[])})
for n in negative:
 id=n['control_id'];r=effective[id]
 assert r['direction']=='N' and r['final_cell']=='TN'
 ledger.append({'record_type':'FINAL_CONTROL','protocol_version':'10.6','method':'fullload','control_id':id,
  'counterfactual_en':n['counterfactual_en'],'scoring_cell':r['final_cell'],'llm_item_id':id,
  'source_pdf_sha256':lock['pdf_sha256'],'original_pdf_evidence':n['pdf_evidence'],
  'pdf_evidence':r.get('pdf_evidence',[]),'generated_evidence':r.get('generated_evidence',[]),
  'phase07_decision_rule_id':r['decision_rule_id'],'decision_origin':'PHASE07_ASSISTANT',
  'affirmative_prohibited_assertion_found':False,'decision_reason_en':r['decision_reason_en']})

for q in queue:
 id=q['item_id']
 if q['direction']!='G':continue
 if id not in effective:continue
 r=effective[id]
 assert r['final_cell'] in ('TP','FP')
 ledger.append({'record_type':'FINAL_CLASS','protocol_version':'10.6','method':'fullload',
  'gclass_id':id,'llm_item_id':id,'diagnostic_cell':r['final_cell'],
  'canonical_tp_contribution':0,'canonical_fp_contribution':0,
  'provenance_category':'PDF_ENTAILED' if r['final_cell']=='TP' else 'PDF_UNSUPPORTED',
  'canonical_counting_scope':'G_DIAGNOSTIC_NOT_CANONICAL_TP' if r['final_cell']=='TP' else 'G_FP_CANDIDATE_NEEDS_PHASE08_DEDUP',
  'final_residual_id':None, 'phase07_decision_rule_id':r['decision_rule_id'],
  'source_pdf_sha256':lock['pdf_sha256'],'pdf_evidence':r.get('pdf_evidence',[]),
  'generated_evidence':r['generated_evidence'],'unmet_predicates_en':r.get('unmet_predicates_en',[]),
  'phase07_original_record_sha256':sha_str(js(by_id[id])),
  'phase07_supersession_record_sha256':r.get('phase07_supersession_record_sha256'),
  'phase07_decision_reason_en':r.get('decision_reason_en','')})

residuals=[]
for i,ids in enumerate(cluster_list,1):
 rid=f'F-10_6-{i:04d}'
 representative=ids[0]
 full_group=next((f for f in families if set(f[0])==set(ids)),None)
 if full_group: residual_statement=full_group[1];why=full_group[2]
 else:
  r=effective[representative]
  residual_statement=r.get('generated_statement_en') or next((d['candidate_statement_en'] for d in fp_old if d['item_id']==representative),'')
  why='Single complete unresolved definitive generated class; no independently confirmed mutually entailing counterpart. Multiple superficially similar claims with different actors, actions, timing, inputs, or output duties remain separate.'
 members=[effective[id] for id in ids]
 r0=members[0]
 row={'record_type':'FINAL_RESIDUAL','protocol_version':'10.6','method':'fullload',
  'residual_id':rid,'scoring_cell':'FP','source_pdf_sha256':lock['pdf_sha256'],
  'unsupported_residual_en':residual_statement,'member_gclass_ids':ids,
  'representative_gclass_id':representative,'source_negative_control_overlap_ids':[],
  'counted_fp_units':1,'pdf_evidence':r0.get('pdf_evidence',[]),
  'generated_evidence':sum((r.get('generated_evidence',[]) for r in members),[]),
  'member_unmet_predicates_en':{r['item_id']:r.get('unmet_predicates_en',[]) for r in members},
  'semantic_deduplication_reason_en':why,'decision_origin':'PHASE08_CONSOLIDATION_OF_PHASE07_UNSUPPORTED_G',
  'original_phase07_diagnostic_cells':{id:by_id[id]['final_cell'] for id in ids}}
 residuals.append(row);ledger.append(row)
# fill explicit effective membership crosswalk for G diagnostics
res_bygc={g:r['residual_id'] for r in residuals for g in r['member_gclass_ids']}
for d in ledger:
 if d['record_type']=='FINAL_CLASS' and d['diagnostic_cell']=='FP':d['final_residual_id']=res_bygc[d['gclass_id']]
assert len(res_bygc)==215 and len(residuals)==205
assert collections.Counter(d['record_type'] for d in ledger)=={'FINAL_SOURCE':638,'FINAL_CONTROL':142,'FINAL_CLASS':3615,'FINAL_RESIDUAL':205}

# Audits are additive and preserve the Phase08 earlier INCOMPLETE records.
recon_audit=[{'record_type':'PHASE08_COMPLETION_SUMMARY','protocol_version':'10.6',
 'phase07_returned_supersessions':[x['item_id'] for x in sup],
 'original_phase07_files_modified':False,'original_phase08_incomplete_files_modified':False,
 'r_total':638,'n_total':142,'effective_gc':3615,'excluded_generated':761,
 'unsupported_generated_classes_after_supersession':215,'distinct_generated_only_fp_residuals':205,
 'N_affirmative_FP':0,'negative_control_overlaps_removed':0,
 'semantic_equivalence_groups':len(families),'excess_duplicate_unsupported_classes':10,
 'counts_assertion':'TP+FN=638, N_FP+TN=142, FP=N_FP+distinct_residuals',
 'comparability_note_en':'External evaluator run used gpt-6.2-sol while protocol §4.2 names gpt-6.1-sol; do not assert this run comparable to runs using the mandated deployment.'}]
recon_audit += [{'record_type':'PHASE08_RETURNED_PHASE07_CONTRADICTION_RESOLVED',
    'id':x['item_id'],'prior_cell':x['prior_final_cell'],'effective_cell':x['new_final_cell'],
    'phase07_supersession_sha256':sha_str(js(x)),'pdf_evidence':x['pdf_evidence'],
    'generated_evidence':x['generated_evidence']} for x in sup]
recon_audit+=pair_audit+neg_audit
# Include singleton retention and dissimilar-neighbor rejections to account for all 215 classes.
for r in residuals:
 recon_audit.append({'record_type':'PHASE08_FINAL_RESIDUAL_CLASSIFICATION','residual_id':r['residual_id'],
 'member_gclass_ids':r['member_gclass_ids'],'canonical_fp_units':1,'semantic_reason_en':r['semantic_deduplication_reason_en'],
 'source_N_overlap':False,'representative_pdf_evidence':r['pdf_evidence'][:3]})

countsjson={'record_type':'PHASE08_BINARY_COUNTS','protocol_version':'10.6','method':'fullload','status':'COMPLETE',
 'pdf_sha256':lock['pdf_sha256'],'frozen_r_sha256':lock['frozen_r_sha256'],'frozen_n_sha256':lock['frozen_n_sha256'],
 'queue_sha256':run['queue_sha256'],'phase07_original_sha256':sha(P7/'07_assistant_adjudications.jsonl'),
 'phase07_new_supersession_sha256':sha(P7/'07_phase08_return_superseding_adjudications.jsonl'),
 'R':638,'N':142,'GO':5046,'original_GC':4861,'effective_GC_in_phase06':4376,
 'eligible_effective_GC':3615,'excluded_effective_GC':761,
 'G_supported_diagnostic':3400,'G_unsupported_diagnostic':215,
 'G_FP_residual_semantic_groups':205,'N_affirmed':0,
 'N_FP':0,'TN':142,'TP':484,'FN':154,'F':205,'FP':205,
 'canonical_universe_size':985,'canonical_prediction_positives':689,
 'final_ledger_rows':4600,'unresolved_final':0,
 'N_F_overlap_removed':0,'semantic_duplicate_excess_reconciled':10,
 'external_run_model':'gpt-6.2-sol','protocol_model_requirement':'gpt-6.1-sol',
 'cross_method_comparable':False,
 'cross_method_noncomparability_reason_en':'External evaluator deployment differs from protocol-mandated deployment.',
 'do_not_compute_metrics_in_phase08':True}
assert countsjson['TP']+countsjson['FN']==638
assert countsjson['N_FP']+countsjson['TN']==142
assert countsjson['FP']==countsjson['N_FP']+countsjson['F']
assert countsjson['TP']+countsjson['TN']+countsjson['FP']+countsjson['FN']==985
assert 638+142+3615+205==len(ledger)

write_jsonl(P8/'08_final_ledger.jsonl',ledger)
write_json(P8/'08_binary_counts.json',countsjson)
write_jsonl(P8/'08_reconciliation_audit_completion.jsonl',recon_audit)
write_jsonl(P8/'08_residual_semantic_groups.jsonl',residuals)
write_jsonl(P8/'08_negative_control_overlap_audit.jsonl',neg_audit)
# Write all candidates, including two Phase07 correction statuses, with exact residual map.
crosswalk=[]
for q in queue:
 id=q['item_id'];e=effective.get(id)
 crosswalk.append({'record_type':'PHASE08_FULL_POPULATION_CROSSWALK','item_id':id,'direction':q['direction'],
  'final_effective_cell':e['final_cell'] if e else None,
  'eligibility':'DEFINITIVE' if e else 'EXCLUDED_NONDEFINITIVE',
  'phase07_supersession':id in {x['item_id'] for x in sup},
  'canonical_cell_contribution':e['final_cell'] if e and e['direction'] in ('R','N') else None,
  'fp_residual_id':res_bygc.get(id),
  'source_pdf_sha256':lock['pdf_sha256']})
write_jsonl(P8/'08_effective_population_crosswalk.jsonl',crosswalk)
report=f'''# Phase 08 — Completed Independent Semantic Reconciliation\n\nStatus: COMPLETE (Version 10.6; fullload).\n\n## Phase 07 source-grounded supersessions\n\n- GCLASS-0002386: diagnostic FP -> TP. Original PDF physical page 48 establishes the exact mandatory event envelope; consistent with GCLASS-0004356.\n- GCLASS-0002250: diagnostic FP -> TP. Original PDF physical pages 12, 17 and 48 jointly establish user-correction and stale replay safety; consistent with GCLASS-0004199.\n- The original Phase 07 files and the prior incomplete Phase 08 audit were preserved. Supersessions are separate immutable records.\n\n## Canonical reconciliation\n\n- Frozen positive requirements: 638 (TP=484; FN=154).\n- Frozen negative controls: 142 (affirmed N=0; TN=142).\n- Eligible effective generated classes: 3,615 (supported diagnostic=3,400; unsupported diagnostic=215).\n- Excluded nondefinitive classes: 761.\n- Distinct generated-only unsupported residuals after semantic consolidation: 205.\n- No affirmative negative-control overlap was found in the Phase 07 N decisions; mere prohibited-word matches were not counted as forbidden assertions.\n- Final canonical cells: TP=484; FN=154; TN=142; FP=205. Canonical universe size 985.\n- FINAL_SOURCE=638; FINAL_CONTROL=142; FINAL_CLASS=3,615; FINAL_RESIDUAL=205; total ledger rows=4,600.\n\n## Semantic consolidation method\n\n- All 215 effective generated FP candidates were individually retained and mapped to one of 205 residual identities.\n- Nine manually reviewed shared unsupported-residual equivalence families merge 10 excess occurrences; every remaining class is retained as a separate residual.\n- Groups were selected using direction, actor, action, target, condition, scope and missing-predicate comparison; lexical similarity was only an inspection aid.\n- Candidate pairs with different requirements, screen actions, error treatments, data fields or stage timings are not automatically merged.\n- No diagnostic G:TP adds a canonical TP.\n- A shared unsupported residual rather than copied statements is counted once. The additional PDF-supported parts of a mixed statement do not add FP.\n\n## Immutable provenance and limitations\n\n- PDF 90 physical pages and all eight original generated specifications match the original SHA-256 lock.\n- Complete external queue: 5,156 items; 323 committed external batches, with source and queue hashes preserved.\n- The external deployment was gpt-6.2-sol rather than protocol §4.2 gpt-6.1-sol. This is a material cross-method comparability deviation, not a reason to change source references or fabricate corrected external judgments.\n- The semantic classifications remain evidence-dependent expert/assistant judgments, not a proof of infallibility; a mechanically passing ledger does not prove every independent interpretation is correct.\n- This phase does not compute Precision, Recall or F1. Phase 09 must independently recompute metrics and comparability.\n'''
(P8/'08_phase_completion_report.md').write_text(report,encoding='utf-8')
manifest={}
for path in [P7/'07_phase08_return_superseding_adjudications.jsonl',
 P8/'08_final_ledger.jsonl',P8/'08_binary_counts.json',
 P8/'08_reconciliation_audit_completion.jsonl',P8/'08_residual_semantic_groups.jsonl',
 P8/'08_negative_control_overlap_audit.jsonl',P8/'08_effective_population_crosswalk.jsonl',
 P8/'08_phase_completion_report.md']:
 manifest[str(path.relative_to(BASE))]=sha(path)
write_json(P8/'08_completion_output_manifest.json',{'protocol_version':'10.6','method':'fullload','immutable_original_phase7_and_phase8_artifacts':True,'output_sha256':manifest})
print(json.dumps({'status':'COMPLETE','supersessions':len(sup),'families':len(families), 'F':205,'ledger_rows':len(ledger),'counts':countsjson},ensure_ascii=False,indent=2))
