#!/usr/bin/env python3
"""Independent check of partial Phase08 provenance and contradiction outputs."""
import json, pathlib, hashlib, collections
base=pathlib.Path('/mnt/data/oriondesk_fullload_v10_6/phase08')
def readl(name):return [json.loads(x) for x in (base/name).read_text().splitlines() if x.strip()]
def h(p):return hashlib.sha256(p.read_bytes()).hexdigest()
v=json.loads((base/'08_validation_results.json').read_text()); c=readl('08_reconciliation_audit.jsonl');r=readl('08_generated_fp_candidates_unreconciled.jsonl');p=readl('08_population_crosswalk_non_scoring.jsonl');s=readl('08_return_to_phase07.jsonl');m=json.loads((base/'08_output_manifest.json').read_text())
check={
 'blocked_semantic_conflicts_remain':len(s)==2 and {x['contradiction_id'] for x in s}=={'P08-CONFLICT-001','P08-CONFLICT-002'},
 'phase08_correctly_incomplete':v['status']=='INCOMPLETE' and m['status']=='INCOMPLETE',
 'phase08_all_mechanical_checks_pass':len(v['failed_mechanical_checks'])==0 and all(v['mechanical_checks'].values()),
 'all_5156_ids_in_non_scoring_index':len(p)==5156 and len(set(x['item_id'] for x in p))==5156,
 'all_217_fp_candidates_retained':len(r)==217 and len(set(x['item_id'] for x in r))==217,
 'no_phase8_relabelling':all(not x['phase08_canonical_cell_committed'] for x in p),
 'no_false_final_ledger':not (base/'08_final_ledger.jsonl').exists(),
 'no_false_binary_counts':not (base/'08_binary_counts.json').exists(),
 'canonical_fp_not_fabricated':v['counts']['phase08_confirmed_residual_fp'] is None and v['counts']['phase08_final_TP_FP_TN_FN'] is None,
 'manifest_hashes_match':all(h(base/name)==meta['sha256'] for name,meta in m['files'].items()),
 'two_conflict_claims_have_evidence':all(len(x['source_generated_evidence'])==2 and x['source_pdf_quote_en'] for x in s),
 'no_phase09_started':v['phase09_not_started'],
}
(base/'08_independent_validation.json').write_text(json.dumps({'record_type':'PHASE08_INDEPENDENT_VALIDATION','status':'PASS' if all(check.values()) else 'FAIL','checks':check,'checks_passed':sum(check.values()),'checks_failed':[k for k,b in check.items() if not b]},indent=2,sort_keys=True)+'\n')
print(json.dumps({'status':'PASS' if all(check.values()) else 'FAIL','checks':check},indent=2))
