#!/usr/bin/env python3
"""Reproducible Phase 01 reference/source integrity and evidence check, protocol 10.6."""
from __future__ import annotations
from pathlib import Path
import hashlib, json, re, unicodedata, collections, datetime
import fitz

BASE = Path('/mnt/data')
OUT = BASE / 'oriondesk_fullload_v10_6' / 'phase01'
OUT.mkdir(parents=True, exist_ok=True)
PROTOCOL = BASE / 'OrionDesk_One_Pass_Atomic_Evaluation_Protocol(10).md'
PDF = BASE / 'OrionDesk_AI_Detailed_Design_Specification(4).pdf'
REF_R = BASE / 'common_atomic_reqs(4).jsonl'
REF_N = BASE / 'common_negative_controls(4).jsonl'
FREEZE = BASE / 'reference_freeze(4).json'
ROLE_NAMES = [
 ('01_screen_functions', '01_screen_functions(4).md'),
 ('02_api', '02_api(4).md'),
 ('03_data', '03_data(4).md'),
 ('04_batch_functions', '04_batch_functions(5).md'),
 ('05_business_rules', '05_business_rules(4).md'),
 ('06_exception_handling', '06_exception_handling(6).md'),
 ('07_processing_flows', '07_processing_flows(6).md'),
 ('08_architecture_decision', '08_architecture_decision(5).md'),
]

def sha(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(1024*1024), b''):
            h.update(b)
    return h.hexdigest()

def norm(s):
    s=unicodedata.normalize('NFKC',s).replace('\u00ad','')
    s=s.replace('‐','-').replace('‑','-').replace('–','-').replace('—','-')
    return re.sub(r'\s+',' ',s).strip().casefold()

def write_json(path, obj):
    path.write_text(json.dumps(obj, indent=2, ensure_ascii=False, sort_keys=True)+'\n', encoding='utf-8')

def write_jsonl(path, rows):
    with path.open('w',encoding='utf-8') as f:
        for row in rows:
            f.write(json.dumps(row,ensure_ascii=False,sort_keys=True)+'\n')

freeze=json.loads(FREEZE.read_text(encoding='utf-8'))
proto=PROTOCOL.read_text(encoding='utf-8')
assert re.search(r'\*\*Protocol version:\*\*\s*10\.6',proto)
assert 'spec_gen_method' in proto
assert sha(PDF)==freeze['source_document']['sha256'], 'PDF digest mismatch'
doc=fitz.open(PDF)
assert len(doc)==90==freeze['source_document']['physical_pages'], 'Wrong page count'
page_text=[norm(page.get_text('text')) for page in doc]

sources=[]
for i,(role,actual) in enumerate(ROLE_NAMES,1):
    path=BASE/actual
    assert path.is_file() and path.stat().st_size>0, f'Missing source: {actual}'
    assert re.fullmatch(re.escape(role)+r'(?:\([1-9][0-9]*\))?\.md', actual), f'Unrecognized role: {actual}'
    contents=path.read_text(encoding='utf-8')
    lines=contents.splitlines()
    assert lines and lines[0].lstrip().startswith('#'), f'Missing source header: {actual}'
    sources.append({
      'position':i,'role':role,'canonical_name':role+'.md',
      'actual_filename':actual,'original_path':str(path),'sha256':sha(path),
      'size_bytes':path.stat().st_size,'line_count':len(lines),
      'alias_rule':f'{role}.md or {role}(N).md, where N is a positive integer',
      'first_header':lines[0]
    })
assert len({x['role'] for x in sources})==8 and len({x['actual_filename'] for x in sources})==8
assert all(x['canonical_name'].endswith('.md') for x in sources)

def load_rows(path,idkey,expected_label):
    rows=[]
    for i,line in enumerate(path.read_text(encoding='utf-8').splitlines(),1):
        if not line.strip():
            raise AssertionError(f'Blank row: {path} line {i}')
        obj=json.loads(line)
        if idkey=='requirement_id':
            assert bool(obj.get('requirement_id')) != bool(obj.get('source_id')) or (bool(obj.get('requirement_id')) and not obj.get('source_id')), f'Invalid positive ID: {i}'
            assert not obj.get('control_id') and not obj.get('negative_control_id')
            assert obj.get('statement_en')
        else:
            assert bool(obj.get('control_id')) != bool(obj.get('negative_control_id')) or (bool(obj.get('control_id')) and not obj.get('negative_control_id')), f'Invalid negative ID: {i}'
            assert not obj.get('requirement_id') and not obj.get('source_id')
            assert obj.get('counterfactual_en')
        assert obj.get(idkey), f'Missing ID in line {i}'
        assert obj.get('actual_label')==expected_label, f'Bad label in line {i}'
        assert obj.get('score_status')=='ACTIVE_SCORING', f'Unexpected reference status at {i}'
        assert obj.get('source_pdf_sha256')==sha(PDF), f'Source hash mismatch at {i}'
        assert obj.get('pdf_evidence'), f'Missing evidence at {i}'
        rows.append(obj)
    ids=[r[idkey] for r in rows]
    assert len(set(ids))==len(ids),f'Collision in {path}'
    return rows

r=load_rows(REF_R,'requirement_id',1)
n=load_rows(REF_N,'control_id',0)
assert len(r)==freeze['counts']['final_positive_atoms']==638
assert len(n)==freeze['counts']['final_negative_controls']==142
assert len(r)+len(n)==freeze['counts']['final_items_total']==780
assert not (set(x['requirement_id'] for x in r) & set(x['control_id'] for x in n))
assert sha(REF_R)==freeze['output_artifacts_sha256']['common_atomic_reqs.jsonl']
assert sha(REF_N)==freeze['output_artifacts_sha256']['common_negative_controls.jsonl']

visual_pages={57,61,64,68,78}
evidence=[]
counts=collections.Counter()
for group,rows,key in [('R',r,'requirement_id'),('N',n,'control_id')]:
    for record in rows:
        for j,item in enumerate(record['pdf_evidence'],1):
            pg=item.get('physical_page')
            assert type(pg)==int and 1<=pg<=90, f'Bad page: {record[key]}'
            kind=item.get('pdf_verification')
            if kind=='PDF_TEXT_EXACT':
                qt=item.get('quote')
                assert isinstance(qt,str) and qt.strip(), f'Empty quotation: {record[key]}'
                ok=norm(qt) in page_text[pg-1]
                if not ok:
                    raise AssertionError(f'PDF quote mismatch: {record[key]} p{pg} evidence {j}: {qt[:100]}')
                method='NFKC_CASEFOLD_WHITESPACE_NORMALIZED_EXACT_SUBSTRING'
                counts['pdf_text_exact_verified']+=1
            elif kind=='PDF_VISUAL_INSPECTED':
                assert pg in visual_pages, f'Unexpected visual page: {pg}'
                assert item.get('visual_locator') and ('visible_text' in item or any(k in item['visual_locator'] for k in ['tenant_id and actor context', 'idempotent event processing', 'immutable evidence and versioned policy inputs'])), f'Visual locator missing: {record[key]}'
                # These figures were independently inspected in rendered page images.
                ok=True
                method='RENDERED_FIGURE_MANUAL_VISUAL_INSPECTION'
                counts['pdf_visual_verified']+=1
            else:
                raise AssertionError(f'Unexpected evidence kind: {record[key]} {kind}')
            evidence.append({
                'direction':group, 'reference_id':record[key], 'evidence_index':j,
                'physical_page':pg, 'pdf_verification_declared':kind,
                'verification_method':method, 'verified':ok,
                'quote_sha256':hashlib.sha256(item.get('quote','').encode('utf-8')).hexdigest() if kind=='PDF_TEXT_EXACT' else None,
                'figure_locator':item.get('visual_locator') if kind=='PDF_VISUAL_INSPECTED' else None,
                'source_pdf_sha256':sha(PDF)
            })
assert len(evidence)==2160
assert counts['pdf_text_exact_verified']==2142
assert counts['pdf_visual_verified']==18
assert all(z['verified'] for z in evidence)

r_statement_norms={norm(x['statement_en']) for x in r}
n_statement_norms={norm(x['counterfactual_en']) for x in n}
assert not (r_statement_norms & n_statement_norms), 'Exact normalized textual R/N overlap'

notes=[
 {'record_type':'REFERENCE_EXCEPTION','severity':'NONFATAL','code':'BOUNDED_SEMANTIC_AUDIT',
  'details_en':'The reference freeze states that 730 working items were not exhaustively semantically reviewed for duplicates, over-merges or inappropriate scope. This Phase 01 verification does not modify the frozen population.'},
 {'record_type':'REFERENCE_EXCEPTION','severity':'NONFATAL','code':'SHARED_MODEL_CONTEXT_ISOLATION',
  'details_en':'The underlying source-shard extractions were saved and SHA-locked, but were produced within the same model/conversation context; persisted shards alone do not establish independent model adjudication.'},
 {'record_type':'REFERENCE_EXCEPTION','severity':'NONFATAL','code':'NEGATIVE_CONTROL_INTERPRETATION',
  'details_en':'An exhaustive independent semantic audit of negative-polarity controls has not been completed. All 142 frozen control IDs remain unchanged.'},
 {'record_type':'REFERENCE_EXCEPTION','severity':'NONFATAL','code':'PROVISIONAL_SEMANTIC_COMPLETENESS',
  'details_en':'Frozen evidence, page locators, counts and hashes verify mechanically; this does not prove exhaustive extraction or optimal atomization of every PDF obligation.'},
]

manifest={
 'record_type':'PHASE01_SOURCE_REFERENCE_MANIFEST',
 'protocol_version':'10.6','spec_gen_method':'fullload',
 'original_pdf':{'actual_filename':PDF.name,'original_path':str(PDF),'sha256':sha(PDF),'size_bytes':PDF.stat().st_size,'physical_pages':len(doc),'document_id':'OD-AI-DDS-001','design_release':'R1.0','design_revision':'1.3'},
 'markdown_sources':sources,
 'frozen_reference':{
    'reference_freeze_filename':FREEZE.name,'reference_freeze_path':str(FREEZE),'reference_freeze_sha256':sha(FREEZE),
    'reference_origin_protocol_version':freeze['protocol_version'],
    'reference_original_status':freeze['status'],
    'r':{'actual_filename':REF_R.name,'original_path':str(REF_R),'sha256':sha(REF_R),'count':len(r),'id_field':'requirement_id','actual_label':1},
    'n':{'actual_filename':REF_N.name,'original_path':str(REF_N),'sha256':sha(REF_N),'count':len(n),'id_field':'control_id','actual_label':0},
    'frozen_total':len(r)+len(n)
 },
 'protocol_file':{'actual_filename':PROTOCOL.name,'original_path':str(PROTOCOL),'sha256':sha(PROTOCOL)},
 'source_selection_rule':'Eight exact distinct roles; suffix aliasing is allowed only with a verified matching source role and unchanged digest. Role aliases never change original source bytes.',
 'immutable_inputs':True,
}

lock={
 'record_type':'PHASE01_REFERENCE_LOCK','protocol_version':'10.6','phase':'01','status':'COMPLETE',
 'spec_gen_method':'fullload',
 'operator_requested_reasoning_effort':'xhigh',
 'external_evaluator_reasoning_effort_required_by_protocol':'high',
 'reasoning_effort_note_en':'The xhigh operator setting applies to the requested assistant analysis. The protocol requires high for the later Azure Phase 06 external evaluator; no external evaluation was performed in Phase 01. Any change to external adjudication settings requires comparability review rather than silent substitution.',
 'pdf_sha256':sha(PDF),'pdf_physical_pages':len(doc),
 'source_roles_ordered':[{ 'role':s['role'], 'actual_filename':s['actual_filename'], 'canonical_name':s['canonical_name'], 'sha256':s['sha256'], 'line_count':s['line_count'], 'original_path':s['original_path']} for s in sources],
 'reference_freeze_sha256':sha(FREEZE),
 'frozen_r_sha256':sha(REF_R), 'frozen_n_sha256':sha(REF_N),
 'frozen_r_count':len(r),'frozen_n_count':len(n),'frozen_total_count':len(r)+len(n),
 'frozen_reference_source_pdf_sha256':freeze['source_document']['sha256'],
 'reference_status':'REFERENCE_FROZEN_PROVISIONAL',
 'evidence_verification':{'text_quotations_exact_page_verified':counts['pdf_text_exact_verified'],'rendered_figure_locators_checked':counts['pdf_visual_verified'],'unique_visual_pages_rendered':sorted(visual_pages),'total_evidence_entries_verified':len(evidence),'unverified_entries':0},
 'assertions':{
    'pdf_hash_matches_frozen_reference':True,'pdf_has_90_physical_pages':True,
    'all_eight_roles_unique_and_readable':True,'source_sha256_recorded':True,
    'frozen_r_and_n_file_sha256_match':True,'r_n_record_counts_match':True,
    'r_n_ids_unique_within_collection':True,'r_n_polarity_labels_consistent':True,
    'all_records_match_frozen_pdf_sha256':True,'all_pdf_evidence_pages_valid':True,
    'all_declared_text_quotations_verified_on_declared_physical_pages':True,
    'all_declared_visual_figure_locators_visually_inspected':True,
    'no_normalized_exact_statement_overlap_between_r_and_n':True,
    'semantic_r_n_disjointness_exhaustively_verified':False,
    'semantic_atomization_completeness_verified':False,
    'generated_coverage_adjudicated':False
 },
 'reference_exceptions_nonfatal':[x['code'] for x in notes],
 'frozen_input_mutation_permitted':False,
 'next_permitted_phase_after_operator_instruction':'02',
 'completed_phases':['01'],
}
write_json(OUT/'01_source_reference_manifest.json',manifest)
write_jsonl(OUT/'01_reference_evidence_audit.jsonl',evidence)
write_jsonl(OUT/'01_reference_exceptions.jsonl',notes)
write_json(OUT/'01_reference_lock.json',lock)
summary=f'''# Phase 01 — Frozen Reference and Original-Source Lock

**Protocol:** OrionDesk Nine-Phase Atomic Requirement Evaluation, version 10.6.  
**Method:** `fullload` (explicitly supplied).  
**Phase status:** COMPLETE. No Phase 02 work or generated semantic coverage judgment was performed.

## Identity and Reference Integrity

- PDF: `{PDF.name}`, {len(doc)} physical pages, SHA-256 `{sha(PDF)}`; matches the original freeze.
- Eight unique, readable Markdown source roles with exact original names and per-file SHA-256 values are recorded in `01_source_reference_manifest.json` and `01_reference_lock.json`.
- Frozen positive atoms: **{len(r)}** (`{REF_R.name}`, SHA-256 `{sha(REF_R)}`).
- Frozen negative controls: **{len(n)}** (`{REF_N.name}`, SHA-256 `{sha(REF_N)}`).
- Fixed source/control inventory: **{len(r)+len(n)}**. Both ledger byte hashes match `reference_freeze.json`; all IDs and labels are valid and records reference the same PDF digest.
- Source quotations: **{counts['pdf_text_exact_verified']}** normalized-space exact substrings verified within the stated physical PDF pages.
- Source figure evidence: **{counts['pdf_visual_verified']}** evidence references checked against rendered figures on PDF physical pages 57, 61, 64, 68, and 78.
- Exact normalized R/N text overlap: none. Exhaustive semantic R/N overlap and atomization checks are not claimed.

## Nonfatal Reference Exceptions

The frozen reference explicitly remains provisional: 730 working items were not exhaustively re-audited for semantic atomization; the shard-generation context was not independently isolated; the complete negative-polarity semantic audit is outstanding; and mechanical source checks do not establish full semantic completeness. These are preserved in `01_reference_exceptions.jsonl`, without changing the reference or denominator.

## Reasoning Configuration

The operator requested assistant reasoning effort `xhigh`. The protocol separately mandates external Azure evaluator effort `high` in Phase 06. This phase made no external requests; no evaluator configuration was silently changed.

## Immutable Deliverables

- `01_reference_lock.json` — locked source roles, actual source digests, frozen reference identity and Phase 01 gate.
- `01_source_reference_manifest.json` — source/ref inventory, paths, original filenames, SHA-256, lines and sizes.
- `01_reference_evidence_audit.jsonl` — one record for each of {len(evidence)} PDF evidence locators.
- `01_reference_exceptions.jsonl` — inherited nonfatal reference limitations.
- `01_phase_summary.md` — this summary.
- `validate_phase01.py` — reproducible local checks; it does not alter original inputs.

**Stop condition:** Phase 01 only. Phase 02 is not started.
'''
(OUT/'01_phase_summary.md').write_text(summary,encoding='utf-8')
print(json.dumps({'status':'COMPLETE','phase':'01','R':len(r),'N':len(n),'text_verified':counts['pdf_text_exact_verified'],'visual_checked':counts['pdf_visual_verified'],'output_dir':str(OUT),'created_files':[p.name for p in sorted(OUT.iterdir())]}, indent=2))
