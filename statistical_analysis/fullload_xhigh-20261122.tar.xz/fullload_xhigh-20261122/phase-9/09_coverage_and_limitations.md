# Phase 09 — Coverage and Limitations

## Covered populations

- R: 638 unique frozen positive atoms with one TP/FN each; N: 142 unique frozen controls with one FP/TN each.
- Effective Phase 06 G: 4376; final definitive G: 3615; Phase 07 nondefinitive exclusions: 761.
- Every Phase 06 external queue ID was covered by exactly one Phase 07 decision or exclusion; Phase 08 used the two appended Phase 07 superseding records without rewriting the old judgments.
- Every diagnostic unsupported G is mapped to exactly one of 205 semantic FP residual groups.
- No negative-control affirmative predictions, and therefore no N/F overlap, are recorded.

## Source and decision risks

- No claim of independent human expert verification of all semantic judgments. Source quotations were matched mechanically and by previous targeted visual review; this does not prove complete semantic entailment.
- The reference creation manifest reports a provisional frozen Gold Set with limited semantic completeness review. This evaluation correctly keeps its denominator fixed, but it does not independently prove a complete benchmark.
- The Phase 02 duplicate metric is the source-recorded original occurrence metric. Later eligibility filtering changes the set of eligible classes. The reconstructed intermediate GO/GC figures before filtering are not presented as a new final eligible-duplicate metric.
- Error-analysis labels such as `TRUE_MISSING`, `PARTIAL_ENTAILMENT`, `CORRECTED_MATCHER_MISS` have not been independently exhaustively recoded in the source ledgers; do not fabricate category counts from free-form explanations. The R FN population is 154, with record-level evidence and unmet predicates in Phase 08.
- The received per-method outputs do not include the other two methods' complete frozen ledgers, so full cross-method audit remains unavailable here. Model equality is operator-attested, not an independent source comparison.

## Documented runtime discrepancies

- Protocol §4.2 names `gpt-6.1-sol`; actual run used `gpt-6.2-sol` (the operator states this was uniform across all methods).
- Phase 06 selection manifest plans 645 batches of eight; execution used 323 batches of sixteen. This variance is documented in `09_independent_validation.json` and does not alter item IDs or canonical metric equations.

## Validation scope

- 62 of 65 independent checks passed; 3 nonfatal observations, no blocking item-identity or accounting failure.
- All 323 saved journals verified against original ordered queue segments and immutable content digests, including 5,156 item results.
- Raw v5 suggestion, Phase 07 assistant decision, Phase 07 supersessions, Phase 08 residual consolidation and Phase 09 arithmetic are distinct provenance layers.
