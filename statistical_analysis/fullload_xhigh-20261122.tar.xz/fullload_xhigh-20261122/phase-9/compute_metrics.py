#!/usr/bin/env python3
"""Independent, read-only OrionDesk v10.6 Phase 09 arithmetic and integrity review.

Usage: python compute_metrics.py [--root /mnt/data/oriondesk_fullload_v10_6]
The script never edits Phase 01--08 or external-evaluator originals.
A mandatory integrity failure emits a blocked validation and does not emit a
numeric 09_metrics.json. Cross-method metadata not provided is recorded as
unverified, not silently assumed equivalent.
"""
from __future__ import annotations
import argparse
import ast
from collections import Counter, defaultdict
from datetime import datetime, timezone
import hashlib
import json
import math
import importlib.util
import tempfile
from pathlib import Path
import unicodedata
import zipfile

import fitz


def sha(p: Path) -> str:
    h = hashlib.sha256()
    with p.open('rb') as f:
        for block in iter(lambda: f.read(1 << 20), b''):
            h.update(block)
    return h.hexdigest()


def stable_json(x) -> str:
    return json.dumps(x, ensure_ascii=False, sort_keys=True, separators=(',', ':'))


def content_hash(x) -> str:
    return hashlib.sha256(stable_json(x).encode('utf-8')).hexdigest()


def j(p: Path):
    return json.loads(p.read_text(encoding='utf-8'))


def jl(p: Path):
    with p.open('r', encoding='utf-8-sig') as f:
        return [json.loads(s) for s in f if s.strip()]


def normal(s: str) -> str:
    return ' '.join(unicodedata.normalize('NFKC',str(s)).split()).casefold()


def source_ast(source_path: Path, name: str):
    t=ast.parse(source_path.read_text(encoding='utf-8'))
    for node in t.body:
        if isinstance(node, (ast.FunctionDef,ast.AsyncFunctionDef)) and node.name==name:
            return ast.dump(node,include_attributes=False)
        if isinstance(node, ast.Assign) and any(isinstance(x,ast.Name) and x.id==name for x in node.targets):
            return ast.dump(node.value,include_attributes=False)
    raise ValueError(f'Missing parser node {name}: {source_path}')


def main(root: Path):
    mnt=root.parent; out=root/'phase09';out.mkdir(exist_ok=True)
    checks={}; blockers=[]; observations=[]
    def ck(name,cond,detail=None,critical=True):
        checks[name]=bool(cond)
        if not cond:
            row={'check':name,'detail_en':str(detail or name),'severity':'BLOCKER' if critical else 'OBSERVATION'}
            (blockers if critical else observations).append(row)
    P=root/'phase01';P2=root/'phase02';P5=root/'phase05';P6=root/'phase06';P7=root/'phase07';P8=root/'phase08'
    lock=j(P/'01_reference_lock.json'); run=j(mnt/'run_state(1).json');ext_summary=j(mnt/'semantic_summary(1).json')
    counts=j(P8/'08_binary_counts.json'); p2=j(P2/'02_phase_summary.json'); select=j(P6/'06_queue_selection.json')
    reference=j(mnt/'reference_freeze(4).json')
    frozen_r=jl(mnt/'common_atomic_reqs(4).jsonl');frozen_n=jl(mnt/'common_negative_controls(4).jsonl')
    ck('protocol_method',all(z=='10.6' for z in [lock['protocol_version'],run['protocol_version'],counts['protocol_version'],select['protocol_version']]) and lock['spec_gen_method']==counts['method']==select['method']=='fullload')
    pdf=mnt/'OrionDesk_AI_Detailed_Design_Specification(4).pdf';pdfsha=sha(pdf)
    ck('source_pdf_sha256',pdfsha==lock['pdf_sha256']==run['pdf_sha256']==counts['pdf_sha256']==reference['source_document']['sha256'])
    with fitz.open(pdf) as d: physical_pages=len(d)
    ck('pdf_page_count',physical_pages==lock['pdf_physical_pages']==90)
    Rsha=sha(mnt/'common_atomic_reqs(4).jsonl');Nsha=sha(mnt/'common_negative_controls(4).jsonl')
    ck('reference_shas',Rsha==lock['frozen_r_sha256']==counts['frozen_r_sha256']==reference['output_artifacts_sha256']['common_atomic_reqs.jsonl'] and Nsha==lock['frozen_n_sha256']==counts['frozen_n_sha256']==reference['output_artifacts_sha256']['common_negative_controls.jsonl'])
    R_ids=[x.get('requirement_id') or x.get('source_id') for x in frozen_r]; N_ids=[x.get('control_id') or x.get('negative_control_id') for x in frozen_n]
    ck('reference_frozen_ids',len(frozen_r)==638 and len(frozen_n)==142 and None not in R_ids and None not in N_ids and len(set(R_ids))==638 and len(set(N_ids))==142 and not set(R_ids)&set(N_ids))
    roles={x['canonical_name']:x for x in lock['source_roles_ordered']}
    ck('eight_unique_roles',len(roles)==8)
    source_digests={k:sha(mnt/v['actual_filename']) for k,v in roles.items()}
    ck('eight_original_md_hashes',all(source_digests[k]==v['sha256']==run['file_sha256'][k] for k,v in roles.items()))
    source_lines={k:(mnt/v['actual_filename']).read_text(encoding='utf-8').splitlines() for k,v in roles.items()}
    # Validate the input 8-role source names and recover all scored generated atoms.
    go=jl(P2/'02_generated_atoms_final.jsonl');gc0=jl(P2/'02_generated_classes_final.jsonl')
    goids=[x['gen_id'] for x in go];gcids=[x['class_id'] for x in gc0]
    gcounts=Counter(x['class_id'] for x in go)
    ck('raw_go_gc_id_partition',len(go)==5046 and len(gc0)==4861 and len(set(goids))==len(go) and len(set(gcids))==len(gc0) and set(gcounts)==set(gcids))
    ck('raw_go_gc_membership',all(sorted(x['member_gen_ids'])==sorted(y['gen_id'] for y in go if y['class_id']==x['class_id']) for x in gc0))
    ck('raw_duplicate_counts',Counter(x['duplicate_position'] for x in go)=={'representative':4861,'within_file':15,'across_file':170})
    ck('raw_class_coverage',sum(x['occurrence_count'] for x in gc0)==len(go) and sum(x['occurrence_count']>1 for x in gc0)==p2['repeated_class_count'])
    ck('generated_origins_traceable',all(x['original_file_sha256']==source_digests[next(k for k,v in roles.items() if v['actual_filename']==x['actual_filename'])] and 1<=x['line_start']<=x['line_end']<=len(source_lines[next(k for k,v in roles.items() if v['actual_filename']==x['actual_filename'])]) for x in go))
    recovered=jl(P5/'05_recovered_definitive_assertions.jsonl');p5claims=jl(P5/'05_generated_claim_validity.jsonl');merge=jl(P6/'06_class_supersession_audit.jsonl')
    merge_yes=[x for x in merge if x['decision']=='MERGE_VERIFIED_BIDIRECTIONAL_CLAUSE_EQUIVALENCE']
    merge_no=[x for x in merge if x['decision']=='DO_NOT_MERGE']
    ck('phase05_and_06_id_entities',len(recovered)==7 and len(p5claims)==len(gc0)+7 and len(merge_yes)==16 and len(merge_no)==9 and len({x['superseded_class_id'] for x in merge_yes})==16)
    p5cls=Counter(x['phase05_eligibility'] for x in p5claims)
    ck('phase05_nondef_and_effective_count',p5cls=={'RETAIN_DEFINITIVE':4209,'EXCLUDED_NONDEFINITIVE':476,'ELIGIBILITY_REVIEW_REQUIRED':176,'RETAIN_RECOVERED_CANDIDATE':7})
    eligible_stage6=(set(gcids)|{x['class_id'] for x in recovered})-{x['class_id'] for x in p5claims if x['phase05_eligibility']=='EXCLUDED_NONDEFINITIVE'}-{x['superseded_class_id'] for x in merge_yes}
    ck('effective_gc_phase06_identity',len(eligible_stage6)==4376)
    q=jl(P6/'06_llm_queue_v10.6.jsonl');qids=[x['item_id'] for x in q];qsha=sha(P6/'06_llm_queue_v10.6.jsonl')
    ck('phase06_queue_sha_and_C_equal_K',qsha==select['queue_sha256']==run['queue_sha256']==counts['queue_sha256'] and len(q)==select['selected_K']==select['pending_C']['total']==5156 and select['all_numeric_cap_omissions']==0 and select['assert_K_equals_C'])
    ck('queue_distinct_and_complete',len(set(qids))==5156 and Counter(x['direction'] for x in q)=={'R':638,'N':142,'G':4376} and set(qids)==set(R_ids)|set(N_ids)|eligible_stage6)
    ck('queue_v5_format',all(x['record_type']=='UNRELIABLE_ITEM' and x['unreliable'] is True for x in q))
    ck('queue_order_R_N_G', [x['direction'] for x in q]==['R']*638+['N']*142+['G']*4376)
    ck('run_batch_valid_allowed',run['batch_size']==ext_summary['batch_size']==16 and run['confidence_threshold']==0.9 and ext_summary['completed_batches']==math.ceil(len(q)/run['batch_size'])==323 and ext_summary['completed_items']==len(q) and ext_summary['failed_batches']==0)
    # Difference between early planning batch contract and executed 16-item contract:
    ck('phase06_planned_vs_executed_batch_size', select['batch_size']==run['batch_size'], f"Phase 06 selection specified {select['batch_size']} / {select['batch_count']} batches; external run used {run['batch_size']} / {ext_summary['completed_batches']}; both protocol-permitted sizes; item order and full queue unchanged", critical=False)
    original=mnt/'_evaluator_sources/semantic_decision_evaluator(3).py'
    evaluator=P6/'semantic_decision_evaluator_v10.6_unlimited.py'
    if original.exists():
        ck('v5_judgment_code_unchanged',all(source_ast(original,name)==source_ast(evaluator,name) for name in ('suggest','RESULT_SCHEMA','SYSTEM_PROMPT')))
    else:
        ck('v5_original_script_available',False,f'Missing original v5 comparison source {original}')
    ck('external_model_and_effort',run['model']=='gpt-6.2-sol' and run['filename_alias_policy']=='unique-role-verified-sha256-v1' and all(x=='10.6' for x in [run['execution_version'],ext_summary['execution_version']]))
    ext=jl(mnt/'semantic_decisions(2).jsonl'); ext_byid={x['item_id']:x for x in ext}
    ck('external_complete_unique_and_order',len(ext)==len(q) and len(ext_byid)==len(q) and [x['item_id'] for x in ext]==qids and all(x['reasoning_effort']=='high' and x['model']==run['model'] for x in ext))
    ck('external_suggestions_manifest',Counter(str(x['suggested_decision']) for x in ext)=={str(k):v for k,v in ext_summary['suggested_decision_counts'].items()})
    # Re-run unchanged original v5 suggest() independently for each original model result.
    spec=importlib.util.spec_from_file_location('oriondesk_v5_checked_for_phase09', evaluator)
    mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
    v5_issues=[]
    for queued,record in zip(q,ext):
        got,unresolved,reason=mod.suggest(queued,record['model_json'],record['evidence_checks'],0.9,True)
        if (got!=record['suggested_decision'] or ('UNRESOLVED' if unresolved else 'PROPOSED')!=record['decision_status'] or reason!=record['review_reason_code']):
            v5_issues.append(record['item_id'])
    ck('v5_all_5156_suggestions_recomputed_unchanged',not v5_issues,v5_issues[:5])
    # Independent execution-layer alias and quotation regression (not cosmetic filename equality).
    specs=mod.resolve_specs(mnt,[str(mnt/v['actual_filename']) for v in lock['source_roles_ordered']])
    alias_trials=[]
    def case(name,expected,observed):alias_trials.append({'name':name,'expected_pass':bool(expected),'observed_pass':bool(observed),'pass':bool(expected)==bool(observed)})
    for role,stem in mod.ROLE_STEMS.items():
        for style,alias in [('canonical',stem+'.md'),('copy',specs[role]['file'])]:
            resolver=mod.resolve_generated_evidence_filename(alias,specs)
            case(style+'_'+role,True,resolver['digest_verified'] and resolver['resolved_role']==role)
    case('02_api_legacy_spelling',True,mod.resolve_generated_evidence_filename('02_api_.md',specs)['digest_verified'])
    case('path_traversal_rejected',False,mod.resolve_generated_evidence_filename('../03_data.md',specs)['digest_verified'])
    case('wrong_role_rejected',False,mod.resolve_generated_evidence_filename('03_api.md',specs)['digest_verified'])
    sample={'pdf_evidence':[], 'generated_evidence':[{'file':'01_screen_functions.md','line_start':21,'line_end':21,'quote_en':source_lines['01_screen_functions.md'][20].strip()}]}
    case('exact_original_line_verified',True,mod.check_evidence(sample,[],specs)['all_generated_verified'])
    trial=json.loads(json.dumps(sample));trial['generated_evidence'][0]['line_start']=22;trial['generated_evidence'][0]['line_end']=22
    case('wrong_line_rejected',False,mod.check_evidence(trial,[],specs)['all_generated_verified'])
    trial=json.loads(json.dumps(sample));trial['generated_evidence'][0]['quote_en']='THIS CLAIM WAS NOT PRESENT AT THAT ORIGINAL LINE'
    case('altered_quotation_rejected',False,mod.check_evidence(trial,[],specs)['all_generated_verified'])
    changed=dict(specs);changed['01']=dict(specs['01']);changed['01']['sha256']='0'*64
    case('changed_original_sha_rejected',False,mod.resolve_generated_evidence_filename('01_screen_functions.md',changed)['digest_verified'])
    with tempfile.TemporaryDirectory(prefix='p09_alias_') as directory:
        temp=Path(directory)
        import shutil
        actual=temp/specs['01']['file'];shutil.copyfile(specs['01']['path'],actual)
        impostor=temp/'01_screen_functions.md';impostor.write_text('This is an unrelated file.\n',encoding='utf-8')
        copy=dict(specs);copy['01']=dict(specs['01']);copy['01']['path']=actual
        case('conflicting_file_alias_digest_rejected',False,mod.resolve_generated_evidence_filename(impostor.name,copy)['digest_verified'])
    ck('filename_alias_and_original_quotation_regression',all(x['pass'] for x in alias_trials),[x for x in alias_trials if not x['pass']])
    (out/'09_alias_regression.json').write_text(json.dumps({'record_type':'PHASE09_FILENAME_ALIAS_REGRESSION','protocol_version':'10.6','checks_total':len(alias_trials),'passed':sum(x['pass'] for x in alias_trials),'checks':alias_trials},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    accepted=0;journal_issues=[]; ext_data_mismatch=0
    with zipfile.ZipFile(mnt/'batch_journals(1).zip') as archive:
        names=[x for x in archive.namelist() if x.startswith('batch_journals/B10.6-') and x.endswith('.json')]
        ck('journal_file_count_323',len(names)==323)
        for i in range(323):
            name=f'batch_journals/B10.6-{i+1:05d}.json'
            try:
                a=json.loads(archive.read(name)); part=q[i*16:(i+1)*16];ids=[x['item_id'] for x in part]
                valid=(a['batch_id']==name.rsplit('/',1)[-1][:-5] and a['batch_index']==i and a['batch_size']==len(part) and a['pdf_sha256']==pdfsha and a['queue_sha256']==qsha and a['input_digest']==content_hash(part) and a['content_sha256']==content_hash({'raw_model_json':a['raw_model_json'],'item_records':a['item_records']}) and [x['item_id'] for x in a['item_records']]==ids and [x['item_id'] for x in a['raw_model_json']['results']]==ids and len(a['raw_model_json']['results'])==len(part))
                if not valid: journal_issues.append(name+': integrity or order failed')
                else:accepted+=len(part)
                if any(ext_byid[k] != x for k,x in zip(ids,a['item_records'])):ext_data_mismatch+=1
            except Exception as e:journal_issues.append(name+':'+str(e))
    ck('all_journals_hash_order_and_size',not journal_issues and accepted==len(q),journal_issues[:5])
    ck('external_aggregate_from_journals',ext_data_mismatch==0,f'{ext_data_mismatch} batch records differ')
    attempt_rows=run['attempts'];sends=Counter(x['batch_id'] for x in attempt_rows)
    completed_attempts=Counter(x['batch_id'] for x in attempt_rows if x['status']=='COMPLETED')
    ck('attempts_failure_retries_bounded',len(attempt_rows)==ext_summary['attempts']==325 and len(sends)==323 and max(sends.values())<=4 and all(completed_attempts[b]==1 for b in sends) and len([x for x in attempt_rows if x['status']=='FAILED'])==2 and ext_summary['historical_failed_records']==1)
    ck('explicit_ambiguous_retry_recorded',any(x.get('ambiguous_retry_authorized') for x in attempt_rows) and run.get('recovery_rounds')=={'B10.6-00286':1})
    ck('external_queue_uses_single_judgment_policy',all(x['final_cell_not_committed'] is True and x['protocol_version']=='10.6' and isinstance(x['model_json']['confidence_estimate'],(float,int)) for x in ext))
    # Independently rebuild the complete canonical universe from the four Phase 08 record kinds.
    led=jl(P8/'08_final_ledger.jsonl'); grouped=defaultdict(list)
    for x in led:grouped[x['record_type']].append(x)
    source=grouped['FINAL_SOURCE'];control=grouped['FINAL_CONTROL'];classes=grouped['FINAL_CLASS'];residual=grouped['FINAL_RESIDUAL']
    ck('phase08_ledger_kind_count',len(led)==4600 and {k:len(v) for k,v in grouped.items()}=={'FINAL_SOURCE':638,'FINAL_CONTROL':142,'FINAL_CLASS':3615,'FINAL_RESIDUAL':205})
    ck('r_ids_ledger_exact',set(x['source_id'] for x in source)==set(R_ids) and len({x['source_id'] for x in source})==638)
    ck('n_ids_ledger_exact',set(x['control_id'] for x in control)==set(N_ids) and len({x['control_id'] for x in control})==142)
    ck('phase08_ledger_source_digests',all(x['source_pdf_sha256']==pdfsha and x['method']=='fullload' and x['protocol_version']=='10.6' for x in led))
    ck('all_final_ledger_evidence_trails',all(x.get('pdf_evidence') and x.get('generated_evidence') for x in led))
    ck('source_N_binary_labels',all(x['scoring_cell'] in ('TP','FN') for x in source) and all(x['scoring_cell'] in ('FP','TN') for x in control) and all(x['scoring_cell']=='FP' for x in residual))
    ck('control_polarity',all(x['affirmative_prohibited_assertion_found']==(x['scoring_cell']=='FP') for x in control))
    gcids_final=[x['gclass_id'] for x in classes];ck('eligible_gc_3615_unique',len(gcids_final)==len(set(gcids_final))==3615 and set(gcids_final).issubset(eligible_stage6))
    ck('diagnostic_gc_noncanonical',all(x['diagnostic_cell'] in ('TP','FP') and x['canonical_tp_contribution']==0 and x['canonical_fp_contribution']==0 for x in classes))
    ck('gclass_provenance_categories',all(x['provenance_category'] in ('PDF_ENTAILED','SUPPORTED_NONCOVERING','PDF_UNSUPPORTED') and (x['diagnostic_cell']=='FP')==(x['provenance_category']=='PDF_UNSUPPORTED') for x in classes))
    fp_member=[id for x in residual for id in x['member_gclass_ids']]
    diag_fp={x['gclass_id'] for x in classes if x['diagnostic_cell']=='FP'}
    ck('unsupported_gc_exactly_one_residual',len(fp_member)==215 and len(set(fp_member))==215 and set(fp_member)==diag_fp)
    resid_ids=[x['residual_id'] for x in residual]
    ck('all_residuals_single_unique_units',len(resid_ids)==len(set(resid_ids))==205 and all(x['counted_fp_units']==1 and not x['source_negative_control_overlap_ids'] for x in residual))
    member_to_resid={id:x['residual_id'] for x in residual for id in x['member_gclass_ids']}
    ck('diag_fp_links_reconciled',all((x['final_residual_id']==member_to_resid[x['gclass_id']]) if x['diagnostic_cell']=='FP' else (x['final_residual_id'] is None) for x in classes))
    ck('final_residual_groups_original_rows',len(jl(P8/'08_residual_semantic_groups.jsonl'))==205 and [x['residual_id'] for x in residual]==[x['residual_id'] for x in jl(P8/'08_residual_semantic_groups.jsonl')])
    cross=jl(P8/'08_effective_population_crosswalk.jsonl');p7=jl(P7/'07_assistant_adjudications.jsonl');excl=jl(P7/'07_eligibility_exclusions.jsonl');sup=jl(P7/'07_phase08_return_superseding_adjudications.jsonl')
    ck('phase07_all_selected_accounted',len(p7)==4395 and len(excl)==761 and set(qids)=={x['item_id'] for x in p7}|{x['item_id'] for x in excl} and not {x['item_id'] for x in p7}&{x['item_id'] for x in excl})
    ck('phase07_two_immutable_supersessions',len(sup)==2 and {x['item_id'] for x in sup}=={'GCLASS-0002386','GCLASS-0002250'} and all(x['prior_final_cell']=='FP' and x['new_final_cell']=='TP' for x in sup) and sha(P7/'07_phase08_return_superseding_adjudications.jsonl')==counts['phase07_new_supersession_sha256'])
    ck('phase07_original_immutable',sha(P7/'07_assistant_adjudications.jsonl')==counts['phase07_original_sha256'])
    ck('crosswalk_full_5156_exact',len(cross)==5156 and [x['item_id'] for x in cross]==qids and sum(x['eligibility']=='EXCLUDED_NONDEFINITIVE' for x in cross)==761)
    active_byid={x['item_id']:x['final_cell'] for x in p7};active_byid.update({x['item_id']:x['new_final_cell'] for x in sup})
    ck('crosswalk_equals_phase07_final',all(x['final_effective_cell']==active_byid[x['item_id']] for x in cross if x['eligibility']=='DEFINITIVE') and all(x['final_effective_cell'] is None for x in cross if x['eligibility']=='EXCLUDED_NONDEFINITIVE'))
    for t,source_key,cell in [('FINAL_SOURCE','source_id','scoring_cell'),('FINAL_CONTROL','control_id','scoring_cell'),('FINAL_CLASS','gclass_id','diagnostic_cell')]:
        ck('ledger_phase07_cells_'+t, all(x[cell]==active_byid[x[source_key]] for x in grouped[t]))
    ck('fully_resolved_binary_items',len(active_byid)==4395 and counts['unresolved_final']==0)
    TP=sum(x['scoring_cell']=='TP' for x in source);FN=sum(x['scoring_cell']=='FN' for x in source)
    FP_N=sum(x['scoring_cell']=='FP' for x in control);TN=sum(x['scoring_cell']=='TN' for x in control)
    F=len(residual);FP=FP_N+F
    G_supported=sum(x['diagnostic_cell']=='TP' for x in classes);G_unsupported=sum(x['diagnostic_cell']=='FP' for x in classes)
    ck('canonical_equations',TP+FN==len(R_ids) and FP_N+TN==len(N_ids) and FP==FP_N+F and (TP+TN+FN+FP)==(len(R_ids)+len(N_ids)+F))
    ck('all_phase08_counts_independently_match',all(counts[k]==v for k,v in {'TP':TP,'FN':FN,'FP':FP,'TN':TN,'R':len(R_ids),'N':len(N_ids),'F':F,'N_FP':FP_N,'G_supported_diagnostic':G_supported,'G_unsupported_diagnostic':G_unsupported,'eligible_effective_GC':len(classes),'excluded_effective_GC':len(excl),'final_ledger_rows':len(led)}.items()))
    ck('raw_go_gc_counts_match',counts['GO']==len(go) and counts['original_GC']==len(gc0))
    ck('N_F_zero_overlap',counts['N_F_overlap_removed']==0 and all(not x['source_negative_control_overlap_ids'] for x in residual))
    ck('old_phase08_output_manifest_complete',all(sha(root/k)==v for k,v in j(P8/'08_completion_output_manifest.json')['output_sha256'].items()))
    # The original v5 suggestions are not authoritative final cells. Preserve the pre-P07 uncertainty distribution.
    uncertain=[x for x in ext if x['decision_status']=='UNRESOLVED' or x['suggested_decision'] is None]
    uncertain_by_dir=dict(Counter(x['direction'] for x in uncertain))
    ck('pre_phase07_uncertain_count',len(uncertain)==720 and uncertain_by_dir=={'R':236,'N':142,'G':342})
    # Compare true semantic classes and their nondefinitive exclusions separately from fixed R/N score units.
    confirmed_duplicate_occurrences=len(go)-len(gc0)
    raw_duplicate_rate=(len(go)-len(gc0))/len(go)
    later_effective_go=len(go)+len(recovered)
    later_effective_gc=len(gc0)+len(recovered)-len(merge_yes)
    later_total_excess=later_effective_go-later_effective_gc
    # The latter is a staging diagnostic, NOT an eligible-only duplicate metric.
    ck('duplicate_identity_raw',(confirmed_duplicate_occurrences==185 and p2['within_file_excess']+p2['across_file_excess']==confirmed_duplicate_occurrences and math.isclose(raw_duplicate_rate,p2['raw_duplicate_rate'])))
    # Compare method model parity only to evidence actually available: the user attests gpt-6.2-sol for all methods.
    user_model_attestation='All three evaluated methods used gpt-6.2-sol (operator statement in current conversation).'
    # Two other independent method hashes, queue files and run-state objects were not supplied for independent comparison.
    ck('independent_cross_method_run_manifests_available',False,'One-Level and Two-Level independent run configuration/digest/selection ledgers are not supplied. Operator attested model equality; cannot verify the other experiment controls.',critical=False)
    ck('protocol_declared_model_matches_actual',run['model']=='gpt-6.1-sol','Protocol §4.2 specifies gpt-6.1-sol, whereas actual run used gpt-6.2-sol. The operator says all three methods share gpt-6.2-sol; document/profile discrepancy is not by itself an inter-method mismatch.',critical=False)
    # The final scoring gate does not silently erase recorded deviations; those are disclosed separately.
    d= {'record_type':'PHASE09_INDEPENDENT_VALIDATION','protocol_version':'10.6','method':'fullload','status':'PASS' if not blockers else 'BLOCKED', 'checks_total':len(checks),'checks_passed':sum(checks.values()),'mandatory_blockers':blockers,'nonfatal_observations':observations,'checks':checks, 'original_pdf_sha256':pdfsha,'phase08_final_ledger_sha256':sha(P8/'08_final_ledger.jsonl'),'phase08_binary_counts_sha256':sha(P8/'08_binary_counts.json')}
    (out/'09_independent_validation.json').write_text(json.dumps(d,indent=2,ensure_ascii=False,sort_keys=True)+'\n',encoding='utf-8')
    if blockers:
        (out/'09_blockers.json').write_text(json.dumps({'status':'INCOMPLETE','blockers':blockers,'no_metrics_published':True},indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
        print(json.dumps({'status':'BLOCKED','blockers':blockers,'observations':observations},ensure_ascii=False)[:5000]);return 1
    # Remove a stale blocker artifact from an earlier failed local validation run.
    if (out/'09_blockers.json').exists():
        (out/'09_blockers.json').unlink()
    # Arithmetic is performed *only* here, after all mandatory checks.
    precision=TP/(TP+FP) if TP+FP else None
    recall=TP/(TP+FN) if TP+FN else None
    f1=2*TP/(2*TP+FP+FN) if (2*TP+FP+FN) else None
    tnpass=TN/len(N_ids) if N_ids else None
    gvalidity=G_supported/len(classes) if classes else None
    view={'record_type':'PHASE09_METRICS','protocol_version':'10.6','method':'fullload','status':'PHASE_COMPLETED','evaluation_reference':'OD-AI-DDS-001 R1.0 revision 1.3','pdf_pages':physical_pages,'source_sha256':{'pdf':pdfsha,'positive_reference':Rsha,'negative_reference':Nsha,'generated_markdown_canonical_roles':source_digests},'queue':{'queue_sha256':qsha,'K':len(q),'C':len(q),'all_numeric_cap_omissions':select['all_numeric_cap_omissions'],'planned_phase06_batch_size':select['batch_size'],'actual_batch_size':run['batch_size'],'committed_batches':ext_summary['completed_batches'],'final_actual_batch_size':len(q)%run['batch_size'] or run['batch_size'],'concurrency':run['concurrency'],'batch_retries_additional':run['batch_retries'],'actual_submissions':len(attempt_rows),'actual_committed_batches':ext_summary['completed_batches'],'failed_historical_attempts':2,'unresolved_script_suggestion_items':len(uncertain),'pre_phase07_unresolved_by_direction':uncertain_by_dir,'external_v5_original_suggestion_counts':ext_summary['suggested_decision_counts'],'v5_confidence_threshold':run['confidence_threshold'],'v5_prompt_sha256':run['prompt_sha256'],'v5_result_schema_sha256':run['result_schema_sha256'],'v5_evidence_alias_policy':run['filename_alias_policy'],'actual_reasoning_effort':'high','actual_external_model':run['model']},'canonical_counts':{'TP':TP,'FN':FN,'FP':FP,'TN':TN,'R':len(R_ids),'N':len(N_ids),'B_affirmed_negative_controls':FP_N,'F_unique_generated_only_unsupported_residuals':F,'U_canonical_universe':len(R_ids)+len(N_ids)+F,'P_canonical_prediction_positives':TP+FP,'diagnostic_supported_G':G_supported,'diagnostic_unsupported_G':G_unsupported,'G_nondefinitive_exclusions':len(excl)},'generation_inventory':{'phase02_GO_raw':len(go),'phase02_GC_raw':len(gc0),'phase02_duplicate_excess':confirmed_duplicate_occurrences,'phase02_repeated_classes':p2['repeated_class_count'],'phase02_cross_file_repeated_classes':p2['cross_file_repeated_class_count'],'phase02_within_file_excess':p2['within_file_excess'],'phase02_across_file_excess':p2['across_file_excess'],'phase02_raw_duplicate_rate':raw_duplicate_rate,'phase05_recovered_occurrences':len(recovered),'phase06_crossclass_supersessions':len(merge_yes),'reconstructed_stage6_GO_total_before_eligibility_filter':later_effective_go,'reconstructed_stage6_GC_total_before_eligibility_filter':later_effective_gc,'reconstructed_stage6_excess_before_eligibility_filter':later_total_excess,'phase05_excluded_classes':476,'phase06_queue_effective_GC':len(eligible_stage6),'phase07_excluded_classes':len(excl),'phase08_eligible_final_GC':len(classes),'G_supported_noncovering_count':sum(x['provenance_category']=='SUPPORTED_NONCOVERING' for x in classes),'semantic_fp_classes_before_dedup':G_unsupported,'semantic_fp_distinct_residual_groups':F,'semantic_fp_excess_deduplicated':G_unsupported-F,'semantic_fp_equivalence_groups':sum(len(x['member_gclass_ids'])>1 for x in residual),'N_F_overlap_removed':0},'metrics':{'precision':precision,'recall':recall,'f1':f1,'negative_control_pass_rate':tnpass,'gc_validity_rate':gvalidity,'duplicate_rate_original_phase02_raw':raw_duplicate_rate},'equations_verified':{'TP_plus_FN_equals_R':TP+FN==len(R_ids),'FP_N_plus_TN_equals_N':FP_N+TN==len(N_ids),'FP_equals_FP_N_plus_F':FP==FP_N+F,'total_equals_R_plus_N_plus_F':TP+TN+FN+FP==len(R_ids)+len(N_ids)+F,'no_unresolved_eligible':True},'evidence_and_limitations':{'pdf_and_markdown_origins_hashed':True,'phase07_two_supersessions_preserved':True,'phase08_dedup_evidence_accounted':True,'cross_method_model_parity':'OPERATOR_ATTESTED_ALL_GPT_6_2_SOL','cross_method_full_comparability':'NOT_INDEPENDENTLY_VERIFIED_WITH_OTHER_METHOD_INPUTS','protocol_model_reference_discrepancy':'DOCUMENTED:gpt-6.1-sol versus actual gpt-6.2-sol','phase06_batch_boundary_plan_vs_execution':'DOCUMENTED:phase06 planned 8, actual permitted 16','semantic_certification':'EVIDENCE_LEDGER_AND_MECHANICAL_INTEGRITY_VERIFIED_NOT_INDEPENDENT_EXPERT_CERTIFICATION'}}
    (out/'09_metrics.json').write_text(json.dumps(view,indent=2,ensure_ascii=False,sort_keys=True)+'\n',encoding='utf-8')
    pct=lambda f:'n/a' if f is None else f'{f*100:.4f}%'
    report=f'''# OrionDesk AI — Phase 09 Independent Metric Report\n\nProtocol: 10.6  \nMethod: `fullload`  \nStatus: **PHASE_COMPLETED** (single-method accounting)\n\n## Frozen evaluation universe\n\n- PDF: 90 physical pages; SHA-256 `{pdfsha}`\n- Positive R: **{len(R_ids)}**; SHA-256 `{Rsha}`\n- Negative N: **{len(N_ids)}**; SHA-256 `{Nsha}`\n- Phase 08 canonical final ledger: **{len(led)}** rows; SHA-256 `{sha(P8/'08_final_ledger.jsonl')}`\n- Phase 08 item-level G classes: {len(classes)} eligible, {len(excl)} nondefinitive exclusions. These classes are diagnostic, not additional R true positives.\n\n## Canonical counts and metrics\n\n| Quantity | Result |\n|---|---:|\n| TP | {TP} |\n| FN | {FN} |\n| FP — affirmed frozen N | {FP_N} |\n| FP — distinct generated-only residuals F | {F} |\n| FP — total | {FP} |\n| TN | {TN} |\n| Canonical universe R+N+F | {len(R_ids)+len(N_ids)+F} |\n| Precision = TP/(TP+FP) | {pct(precision)} |\n| Recall = TP/(TP+FN) | {pct(recall)} |\n| F1 = 2TP/(2TP+FP+FN) | {pct(f1)} |\n| Frozen negative-control pass = TN/N | {pct(tnpass)} |\n| Eligible G-class validity (diagnostic) | {pct(gvalidity)} |\n\nRaw machine-precision values are in `09_metrics.json`. All equations were verified against original Phase 08 item-level rows, rather than trusting `08_binary_counts.json` alone.\n\n## Generated inventory and semantic deduplication\n\n- Phase 02 GO = {len(go)} occurrences; GC = {len(gc0)} unique classes.\n- Excess within-file duplicates = {p2['within_file_excess']}; across-file = {p2['across_file_excess']}; raw duplicate rate = {pct(raw_duplicate_rate)}.\n- Phase 05 recovered seven candidate occurrences; Phase 06 recorded sixteen mutually entailed class supersessions.\n- After Phase 05 eligibility exclusions, the Phase 06 evaluation queue included {len(eligible_stage6)} candidate G classes. Phase 07 excluded {len(excl)} more as nondefinitive; {len(classes)} classes remain definitive.\n- Of {G_unsupported} unsupported diagnostic G classes, {G_unsupported-F} repeat unsupported residual obligations; they form {F} distinct residual units in the Phase 08 ledger. Negative-control overlap removed: 0.\n- `SUPPORTED_NONCOVERING` classes recorded: {sum(x['provenance_category']=='SUPPORTED_NONCOVERING' for x in classes)}. No generated-class diagnostic TP adds a new canonical source-TP.\n\n## External evaluator and independent Phase 07\n\n- Queue hash: `{qsha}`; K=C={len(q)} and numeric cap omissions 0.\n- Actual Azure model: `{run['model']}`; actual reasoning effort `high`; confidence threshold {run['confidence_threshold']}.\n- Actual batching: {ext_summary['completed_batches']} committed batches of up to {run['batch_size']} records, concurrency {run['concurrency']}, {len(attempt_rows)} submission attempts including bounded retries.\n- Original v5 suggestion distribution: `{json.dumps(ext_summary['suggested_decision_counts'], sort_keys=True)}`.\n- {len(uncertain)} originally undecided/review-candidate v5 suggestions (R {uncertain_by_dir.get('R',0)}, N {uncertain_by_dir.get('N',0)}, G {uncertain_by_dir.get('G',0)}) were covered by the Phase 07 final population. Do not treat v5 abstention as an FN/FP.\n- Both Phase 07 returned supersessions and all original 323 external batch journals were retained and verified.\n\n## Comparability and traceability cautions\n\n1. The operator explicitly states that all three generation methods used `gpt-6.2-sol`; therefore model *selection* is attested uniform across methods. The v10.6 protocol text still names `gpt-6.1-sol`, a documentation mismatch.\n2. Phase 06 planning metadata specifies size-8 batches, but the execution's committed batches use size 16 (also an allowed v10.6 batch size). Entire frozen queue ID/order, run-state, and 323 journal digests match. This is a documented planning-versus-execution discrepancy, not a hidden change to the scored R/N/GC population.\n3. The other methods' run-state, queue hashes, and ledgers were not supplied here; full cross-method invariance (batching, all classification policies, reference, exclusions, duplicate rules) is **not independently verified**.\n4. `xhigh` is the operator's ChatGPT analysis request; the external v5 evaluator's actual `high` effort is a separate runtime setting.\n5. Evidence hashes and journal integrity cannot establish the absence of semantic-judgment errors. The frozen Gold Set is also marked provisional by its creation audit.\n6. No one-level or two-level Precision/Recall/F1 values were inferred or fabricated.\n\n## Reproduction\n\nExecute `python compute_metrics.py --root {root}`. The source files and earlier phase artifacts are read-only inputs. A required identity or accounting failure blocks metric publication.\n'''
    (out/'09_report.md').write_text(report,encoding='utf-8')
    limitations=f'''# Phase 09 — Coverage and Limitations\n\n## Covered populations\n\n- R: {len(R_ids)} unique frozen positive atoms with one TP/FN each; N: {len(N_ids)} unique frozen controls with one FP/TN each.\n- Effective Phase 06 G: {len(eligible_stage6)}; final definitive G: {len(classes)}; Phase 07 nondefinitive exclusions: {len(excl)}.\n- Every Phase 06 external queue ID was covered by exactly one Phase 07 decision or exclusion; Phase 08 used the two appended Phase 07 superseding records without rewriting the old judgments.\n- Every diagnostic unsupported G is mapped to exactly one of {F} semantic FP residual groups.\n- No negative-control affirmative predictions, and therefore no N/F overlap, are recorded.\n\n## Source and decision risks\n\n- No claim of independent human expert verification of all semantic judgments. Source quotations were matched mechanically and by previous targeted visual review; this does not prove complete semantic entailment.\n- The reference creation manifest reports a provisional frozen Gold Set with limited semantic completeness review. This evaluation correctly keeps its denominator fixed, but it does not independently prove a complete benchmark.\n- The Phase 02 duplicate metric is the source-recorded original occurrence metric. Later eligibility filtering changes the set of eligible classes. The reconstructed intermediate GO/GC figures before filtering are not presented as a new final eligible-duplicate metric.\n- Error-analysis labels such as `TRUE_MISSING`, `PARTIAL_ENTAILMENT`, `CORRECTED_MATCHER_MISS` have not been independently exhaustively recoded in the source ledgers; do not fabricate category counts from free-form explanations. The R FN population is {FN}, with record-level evidence and unmet predicates in Phase 08.\n- The received per-method outputs do not include the other two methods' complete frozen ledgers, so full cross-method audit remains unavailable here. Model equality is operator-attested, not an independent source comparison.\n\n## Documented runtime discrepancies\n\n- Protocol §4.2 names `gpt-6.1-sol`; actual run used `gpt-6.2-sol` (the operator states this was uniform across all methods).\n- Phase 06 selection manifest plans 645 batches of eight; execution used 323 batches of sixteen. This variance is documented in `09_independent_validation.json` and does not alter item IDs or canonical metric equations.\n\n## Validation scope\n\n- {sum(checks.values())} of {len(checks)} independent checks passed; {len(observations)} nonfatal observations, no blocking item-identity or accounting failure.\n- All 323 saved journals verified against original ordered queue segments and immutable content digests, including 5,156 item results.\n- Raw v5 suggestion, Phase 07 assistant decision, Phase 07 supersessions, Phase 08 residual consolidation and Phase 09 arithmetic are distinct provenance layers.\n'''
    (out/'09_coverage_and_limitations.md').write_text(limitations,encoding='utf-8')
    manifest={'record_type':'PHASE09_OUTPUT_MANIFEST','protocol_version':'10.6','method':'fullload','status':'PHASE_COMPLETED','output_sha256':{p.name:sha(p) for p in sorted(out.iterdir()) if p.is_file() and p.name!='09_output_manifest.json'}}
    (out/'09_output_manifest.json').write_text(json.dumps(manifest,indent=2,sort_keys=True,ensure_ascii=False)+'\n',encoding='utf-8')
    print(json.dumps({'status':'PHASE_COMPLETED','TP':TP,'FN':FN,'FP':FP,'TN':TN,'precision':precision,'recall':recall,'f1':f1,'checks':len(checks),'passed':sum(checks.values()),'blockers':len(blockers),'observations':observations,'file_count':len(manifest['output_sha256'])+1},ensure_ascii=False))
    return 0


if __name__=='__main__':
    ap=argparse.ArgumentParser()
    ap.add_argument('--root',type=Path,default=Path('/mnt/data/oriondesk_fullload_v10_6'))
    args=ap.parse_args()
    raise SystemExit(main(args.root))
