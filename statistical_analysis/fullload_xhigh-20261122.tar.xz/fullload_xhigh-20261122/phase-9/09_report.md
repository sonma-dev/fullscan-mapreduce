# OrionDesk AI — Phase 09 Independent Metric Report

Protocol: 10.6  
Method: `fullload`  
Status: **PHASE_COMPLETED** (single-method accounting)

## Frozen evaluation universe

- PDF: 90 physical pages; SHA-256 `b71541e74564559d2cc0a84e9827086946998fbc6c627488fb9e7a7f9b0137c3`
- Positive R: **638**; SHA-256 `072ffe9c50001a0a9605f1ce00aef97c30f329e25e0c16c540a59dbc0eafc427`
- Negative N: **142**; SHA-256 `0d2481530218ae6a8ebd010bf259233a56f141a03a3562dfca50ada5a024524e`
- Phase 08 canonical final ledger: **4600** rows; SHA-256 `796a77fa414dc12b3a5e2ebc7052207ddc0d6d089519471c6dfca80ff97c22aa`
- Phase 08 item-level G classes: 3615 eligible, 761 nondefinitive exclusions. These classes are diagnostic, not additional R true positives.

## Canonical counts and metrics

| Quantity | Result |
|---|---:|
| TP | 484 |
| FN | 154 |
| FP — affirmed frozen N | 0 |
| FP — distinct generated-only residuals F | 205 |
| FP — total | 205 |
| TN | 142 |
| Canonical universe R+N+F | 985 |
| Precision = TP/(TP+FP) | 70.2467% |
| Recall = TP/(TP+FN) | 75.8621% |
| F1 = 2TP/(2TP+FP+FN) | 72.9465% |
| Frozen negative-control pass = TN/N | 100.0000% |
| Eligible G-class validity (diagnostic) | 94.0526% |

Raw machine-precision values are in `09_metrics.json`. All equations were verified against original Phase 08 item-level rows, rather than trusting `08_binary_counts.json` alone.

## Generated inventory and semantic deduplication

- Phase 02 GO = 5046 occurrences; GC = 4861 unique classes.
- Excess within-file duplicates = 15; across-file = 170; raw duplicate rate = 3.6663%.
- Phase 05 recovered seven candidate occurrences; Phase 06 recorded sixteen mutually entailed class supersessions.
- After Phase 05 eligibility exclusions, the Phase 06 evaluation queue included 4376 candidate G classes. Phase 07 excluded 761 more as nondefinitive; 3615 classes remain definitive.
- Of 215 unsupported diagnostic G classes, 10 repeat unsupported residual obligations; they form 205 distinct residual units in the Phase 08 ledger. Negative-control overlap removed: 0.
- `SUPPORTED_NONCOVERING` classes recorded: 0. No generated-class diagnostic TP adds a new canonical source-TP.

## External evaluator and independent Phase 07

- Queue hash: `f0ee6dac19a32e41c2a83c1030bff2ddcf904d1e7a516b609853e22599d4981a`; K=C=5156 and numeric cap omissions 0.
- Actual Azure model: `gpt-6.2-sol`; actual reasoning effort `high`; confidence threshold 0.9.
- Actual batching: 323 committed batches of up to 16 records, concurrency 4, 325 submission attempts including bounded retries.
- Original v5 suggestion distribution: `{"EXCLUDED_NONDEFINITIVE": 733, "FN": 19, "NOT_FP": 3301, "None": 700, "TN": 1, "TP": 402}`.
- 720 originally undecided/review-candidate v5 suggestions (R 236, N 142, G 342) were covered by the Phase 07 final population. Do not treat v5 abstention as an FN/FP.
- Both Phase 07 returned supersessions and all original 323 external batch journals were retained and verified.

## Comparability and traceability cautions

1. The operator explicitly states that all three generation methods used `gpt-6.2-sol`; therefore model *selection* is attested uniform across methods. The v10.6 protocol text still names `gpt-6.1-sol`, a documentation mismatch.
2. Phase 06 planning metadata specifies size-8 batches, but the execution's committed batches use size 16 (also an allowed v10.6 batch size). Entire frozen queue ID/order, run-state, and 323 journal digests match. This is a documented planning-versus-execution discrepancy, not a hidden change to the scored R/N/GC population.
3. The other methods' run-state, queue hashes, and ledgers were not supplied here; full cross-method invariance (batching, all classification policies, reference, exclusions, duplicate rules) is **not independently verified**.
4. `xhigh` is the operator's ChatGPT analysis request; the external v5 evaluator's actual `high` effort is a separate runtime setting.
5. Evidence hashes and journal integrity cannot establish the absence of semantic-judgment errors. The frozen Gold Set is also marked provisional by its creation audit.
6. No one-level or two-level Precision/Recall/F1 values were inferred or fabricated.

## Reproduction

Execute `python compute_metrics.py --root /mnt/data/oriondesk_fullload_v10_6`. The source files and earlier phase artifacts are read-only inputs. A required identity or accounting failure blocks metric publication.
