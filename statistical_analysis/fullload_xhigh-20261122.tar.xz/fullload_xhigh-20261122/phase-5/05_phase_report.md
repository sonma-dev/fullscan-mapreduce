# Phase 05 — Generated Validity and Exclusion Reassessment

Protocol: 10.6 | Method: fullload | Result: COMPLETE_CANDIDATE_VALIDITY_AUDIT_WITH_UNRESOLVED_SEMANTIC_ITEMS

## Frozen inputs
- PDF: 90 physical pages, SHA-256 b71541e74564559d2cc0a84e9827086946998fbc6c627488fb9e7a7f9b0137c3.
- R: 638 unchanged; N: 142 unchanged.
- Original Phase 02: GO 5,046, GC 4,861, exclusions 10,219.
- All eight generated Markdown originals: SHA-256 checked unchanged.

## Full claim/exclusion inventory audit
- Original classes examined: 4861.
- Additional recovered definitive-candidate assertions (no previous output rewritten): 7.
- Total Phase05 claim-validity records: 4868.
- Exclusion reassessment rows: 10219; unresolved mixed/duplicate/fragment cases: 74.
- Phase04 reciprocal R coverage remains indexed for all 638 frozen source atoms.
- Original GC validity candidates: {'LOW_EVIDENCE_PENDING_REVIEW': 1329, 'PARTIAL_OR_CONTEXTUAL_PDF_CANDIDATE': 2601, 'STRONG_PDF_CONTEXT_CANDIDATE': 891, 'DIRECT_PDF_QUOTE_CANDIDATE': 47}.
- Original class eligibility: {'EXCLUDED_NONDEFINITIVE': 476, 'RETAIN_DEFINITIVE': 4209, 'ELIGIBILITY_REVIEW_REQUIRED': 176}.

## Evidence and judgment boundary
The full PDF was searched for each prior or recovered class, retaining exact PDF page passages and real generated-line quotations. A direct quotation is a candidate proof of quotation existence, not an automatic semantic entailment decision. All source-generated claims remain subject to source scope, condition and exception checking; no evidence-grade lexical score establishes canonical FP/TP.

Phase05 recovered claims and original-GC eligibility corrections are recorded only as Phase05 sidecars; Phase02 originals were not modified. Phase06 must resolve effective population and negative-control overlaps without using arbitrary sampling budgets. Phase07 independently decides any unresolved semantic item.

## Carryover limitation
The released Phase02 validator attempts to open missing `02_similarity_review_candidates.jsonl`; the actual existing file is `02_near_duplicate_review.jsonl`. The original validator is unchanged. The Phase05 runner independently verifies all GO membership, unique GC ownership, exclusions and exact original-line citations and records this issue.

## Outputs
- `05_generated_claim_validity.jsonl`
- `05_exclusion_reassessment.jsonl`
- `05_recovered_definitive_assertions.jsonl`
- `05_r_gc_reciprocal_crosswalk.jsonl`
- `05_mixed_exclusion_review_queue.jsonl`
- `05_near_duplicate_carryforward.jsonl`
- `05_phase_summary.json`
- `run_phase05.py` and `validate_phase05.py`

No Phase06 external queue or Phase07/08/09 final decisions were produced.
