#!/usr/bin/env python3
"""Phase 05: generated validity / exclusions / bidirectional PDF evidence.

All source and phase-01/02/03/04 inputs are immutable. Search/rule signals
are CANDIDATES, not independent final semantic TP/FN/FP/TN judgments.
The original Phase-02 classes remain unchanged; any superseding eligibility
or recovered items receive a versioned Phase-05-only record.
"""
from __future__ import annotations
import os, json, hashlib, re, collections, math, time, unicodedata
from pathlib import Path
import fitz
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.preprocessing import normalize
from scipy.sparse import csr_matrix

ROOT=Path('/mnt/data/oriondesk_fullload_v10_6')
OUT=ROOT/'phase05'; OUT.mkdir(exist_ok=True)
PROTO='10.6'
sha=lambda x: hashlib.sha256(Path(x).read_bytes()).hexdigest()
fold=lambda x:re.sub(r'\s+',' ',unicodedata.normalize('NFKC',str(x or ''))).strip()
quote_norm=lambda x:fold(x).casefold()
readj=lambda x:[json.loads(l) for l in open(x,encoding='utf-8') if l.strip()]
writej=lambda p,x:Path(p).write_text(json.dumps(x,ensure_ascii=False,indent=2,sort_keys=True)+'\n',encoding='utf8')
def writejln(p, it):
    with open(p,'w',encoding='utf8') as f:
        for obj in it:f.write(json.dumps(obj,ensure_ascii=False,sort_keys=True)+'\n')

t0=time.monotonic()
def log(s):print(f'[phase05 elapsed={time.monotonic()-t0:.1f}s] {s}',flush=True)
lock=json.loads((ROOT/'phase01/01_reference_lock.json').read_text(encoding='utf8'))
s2=json.loads((ROOT/'phase02/02_phase_summary.json').read_text(encoding='utf8'))
s3=json.loads((ROOT/'phase03/03_phase_summary.json').read_text(encoding='utf8'))
s4=json.loads((ROOT/'phase04/04_phase_summary.json').read_text(encoding='utf8'))
assert lock['status']=='COMPLETE' and lock['spec_gen_method']=='fullload' and lock['protocol_version']==PROTO
assert s2['status']=='COMPLETE' and s2['protocol_version']==PROTO and s4['status'].startswith('COMPLETE')
assert sha(ROOT/'phase01/01_reference_lock.json')==s2['phase01_lock_sha256']==s4['phase01_lock_sha256']
assert sha('/mnt/data/OrionDesk_AI_Detailed_Design_Specification(4).pdf')==lock['pdf_sha256']
assert sha('/mnt/data/common_atomic_reqs(4).jsonl')==lock['frozen_r_sha256']
assert sha('/mnt/data/common_negative_controls(4).jsonl')==lock['frozen_n_sha256']
for key,val in s2['output_sha256'].items():
    if key=='02_similarity_review_candidates.jsonl' and not (ROOT/'phase02'/key).exists():
        continue  # Legacy manifest extra file missing; independent check follows.
    assert (ROOT/'phase02'/key).exists() and sha(ROOT/'phase02'/key)==val,(key,val)
for key,val in s4['output_sha256'].items():assert sha(ROOT/'phase04'/key)==val,key
sourcemap={x['actual_filename']:x for x in lock['source_roles_ordered']}
source_lines={name:Path(x['original_path']).read_text(encoding='utf-8').splitlines() for name,x in sourcemap.items()}
for name,x in sourcemap.items(): assert sha(x['original_path'])==x['sha256']
GO=readj(ROOT/'phase02/02_generated_atoms_final.jsonl')
GC=readj(ROOT/'phase02/02_generated_classes_final.jsonl')
EX=readj(ROOT/'phase02/02_excluded_units.jsonl')
IDX=readj(ROOT/'phase02/02_original_text_index.jsonl')
DD=readj(ROOT/'phase02/02_duplicate_classes.jsonl')
NEAR=readj(ROOT/'phase02/02_near_duplicate_review.jsonl')
R=readj('/mnt/data/common_atomic_reqs(4).jsonl')
N=readj('/mnt/data/common_negative_controls(4).jsonl')
A4=readj(ROOT/'phase04/04_coverage_audit.jsonl')
assert (len(GO),len(GC),len(EX),len(IDX),len(R),len(N),len(A4))==(5046,4861,10219,8330,638,142,638)
assert len(DD)==141
log('Immutable lock and all inputs verified; 638 R / 142 N / 5,046 GO / 4,861 GC / 10,219 EX')

# Independent Phase02 mechanical revalidation: Phase02's own released validator
# mistakenly references a missing old filename; check originals and memberships here.
classes={c['class_id']:c for c in GC}; gen={x['gen_id']:x for x in GO}
assert len(classes)==len(GC) and len(gen)==len(GO)
idxby={(x['actual_filename'],x['line']):x for x in IDX}
assert len(idxby)==len(IDX)
for name,lines in source_lines.items():
    assert len([x for x in IDX if x['actual_filename']==name])==len(lines)
pergen=collections.Counter()
for c in GC:
    for gid in c['member_gen_ids']:
        assert gid in gen and gen[gid]['class_id']==c['class_id']
        pergen[gid]+=1
assert len(pergen)==len(GO) and all(v==1 for v in pergen.values())
for x in GO+EX:
    fn=x['actual_filename'];line=x['line_start'];literal=x['source_quote_en']
    assert x['original_file_sha256']==sourcemap[fn]['sha256']
    assert 1<=line<=len(source_lines[fn])
    assert fold(literal) in fold(source_lines[fn][line-1]),(fn,line,literal[:30])
    lineid=idxby[(fn,line)]
    assert (x.get('gen_id') in lineid['eligible_gen_ids'] if x.get('gen_id') else x['excluded_id'] in lineid['excluded_unit_ids'])
assert s2['within_file_excess']+s2['across_file_excess']==len(GO)-len(GC)
log('Independent prior-phase GO/GC originals, quotes, ownership, and line-index verification passed')

# All PDF physical-page text and independent paragraph/block passages.
pdf=fitz.open('/mnt/data/OrionDesk_AI_Detailed_Design_Specification(4).pdf')
assert len(pdf)==90
PAGE_TEXT=[p.get_text(sort=True) for p in pdf]
passages=[]; boiler=re.compile(r'^\s*(?:ORIONDESK AI|DETAILED DESIGN / R1\.0|CONTROLLED FICTIONAL REFERENCE|\d{3})\s*$',re.I)
for pi,p in enumerate(pdf,1):
    blocks=p.get_text('blocks',sort=True)
    for b in blocks:
        s=fold(b[4]);
        if len(s)<19 or boiler.fullmatch(s) or s.startswith('CONTROLLED FICTIONAL REFERENCE'):continue
        # Keep verifiable original passage as same block quote. Segments are
        # strictly derived from a single block and verified against page text.
        parts=[s]
        if len(s)>1050:
            parts=[]
            words=s.split(); start=0
            while start<len(words):
                parts.append(' '.join(words[start:start+120]));start+=100
        for seg in parts:
            if len(seg)<19:continue
            if quote_norm(seg) not in quote_norm(PAGE_TEXT[pi-1]):
                # PDF reading order may differ between block extraction and page.
                # Retain only truly reconstructible snippets.
                if quote_norm(seg[:min(len(seg),60)]) not in quote_norm(PAGE_TEXT[pi-1]):continue
            passages.append({'page':pi,'quote_en':seg,'scope':'PDF_BLOCK'})
assert len(passages)>500
log(f'PDF indexed: 90 physical pages, {len(passages)} evidence passage windows')

# Build source-R reciprocal hints from Phase 04, verifying class, source and line.
source_to_gc=collections.defaultdict(dict)
RIDS={r['requirement_id'] for r in R}
for row in A4:
    rid=row.get('source_id') or row.get('requirement_id')
    assert rid in RIDS
    for e in row.get('candidate_evidence',[]):
        cid=e.get('class_id')
        if cid not in classes or e.get('source_type')!='ELIGIBLE_GO':continue
        gid=e.get('gen_id'); gg=gen.get(gid)
        if gg is None or gg['class_id']!=cid:continue
        if e['file']!=gg['actual_filename'] or e['line_start']!=gg['line_start']:continue
        if not e.get('verified_original',False):continue
        value=source_to_gc[cid].get(rid)
        score=e.get('independent_score') or 0.0
        if value is None or score>value['search_score']:
            source_to_gc[cid][rid]={'source_id':rid,'search_score':round(float(score),5),'generated_quote_en':e.get('quote_en',''),
               'generated_actual_filename':gg['actual_filename'],'generated_line':gg['line_start'],'source_type':'PHASE04_RECIPROCAL_CANDIDATE'}
log(f'Phase04 reciprocal links mapped to {len(source_to_gc)} GC classes')

# Determine which Phase-02 GO are nondefinitive despite the earlier extraction.
# This is a source-context-driven eligibility audit, not a semantic PDF verdict.
META_ROOT=re.compile(r'(?:^\s*(?:confirmed|needs confirmation|proposal|nc):|\bsource (?:does not|illustrates|describes)|\bthis specification\b|\bthis register\b|\bthe following\b|\bearlier (?:specifications?|handoffs?)\b|\bcitation convention\b|\bid(?:entifier)? convention\b|\bnot an approved requirement\b|\bsource-supported behavior\b|\bno (?:screen placement|confirmed rule) (?:is|has been) (?:specified|established)\b|\brequires? confirmation\b|\bundefined\b|\bunresolved\b|\bnot (?:provided|specified|defined|confirmed|supplied)\b|\bmissing contract\b|\bnot automatically\b|\bexample (?:values?|only)\b)',re.I)
META_HEAD=re.compile(r'(?:Specification Basis and Requirement Status|Specification Basis and Status|Specification Basis and Scope|Reading and Cross-Reference Rules|How to Use This Document|Open-Decision Register|Unresolved Items|Dependencies on Later|Source Conflicts and Required Amendments|Traceability|Consistency and Open Questions|Source Control and Status)',re.I)
POSITIVE_ACTION=re.compile(r'\b(?:must|shall|required|requires|require|cannot|never|do not|must not|shall not|validate|reject|enforce|block|fail.closed|prohibit|preserve|store|emit|return|persist|retain|route|prevent|disable|allow|include|exclude|use|record|apply|verify|compute|derive|publish|no self.approval)\b',re.I)
SPEC_META_VERBS=re.compile(r'\b(?:do not (?:infer|invent|assume|treat|promote|select)|must not (?:be implemented as confirmed|be inferred|silently)|no (?:source|implementation)\b|\bunadopted\b|\bproposed\b|\bprior phase\b)',re.I)

def reassess_class(c):
    st=c['representative_statement_en'];txt=c['representative_source_quote_en'];heads=' > '.join(gen[c['representative_gen_id']]['heading_path']);role=gen[c['representative_gen_id']]['canonical_role'];
    clean=fold(txt.replace('**','').replace('`',''))
    if role=='08_architecture_decision':
        # Consolidated architecture decisions are predominantly nonbinding
        # report/meta; a definitive preserved control is still eligible.
        if not POSITIVE_ACTION.search(clean) or re.search(r'^(?:AD-R\d+|CON-|OQ-|AD-\d+)',clean,re.I):
            return 'ELIGIBILITY_REVIEW_REQUIRED','Architecture register/report statement; independent product obligation unproven'
    if re.search(r'\b(?:unresolved assertion|open decision|unresolved permissions|questions to confirm|earlier mapping|original question/deferred reference)\b',st,re.I):
        return 'EXCLUDED_NONDEFINITIVE','Question, open contract, or unresolved assertion rather than an adopted control'
    if re.search(r'^\s*(?:confirmed|needs confirmation|proposal|nc)\s*[:—-]',clean,re.I):
        return 'EXCLUDED_NONDEFINITIVE','Terminology/status definition rather than implemented product behavior'
    if META_HEAD.search(heads) and not POSITIVE_ACTION.search(clean):
        return 'EXCLUDED_NONDEFINITIVE','Documentation/traceability explanation without a definite system obligation'
    if re.search(r'(?:not (?:defined|specified|provided|confirmed|supplied)|unresolved|needs confirmation|unknown|no confirmed|is (?:a )?proposal|unadopted)',clean,re.I) and not re.search(r'\b(?:must not|do not|never|cannot|only|shall not)\b',clean,re.I):
        return 'ELIGIBILITY_REVIEW_REQUIRED','Mixed source gap with possible affirmative domain fragment'
    if re.search(r'\b(?:is illustrated|source illustrates|the document|this specification|the following|identifiers (?:are|remain)|earlier specifications)\b',clean,re.I) and not POSITIVE_ACTION.search(clean):
        return 'EXCLUDED_NONDEFINITIVE','Documentary description or illustration only'
    if re.search(r'\b(?:do not infer|do not invent|not automatically|without interpreting unresolved|proposals remain|source does not establish|no source contract)\b',clean,re.I) and not re.search(r'\b(?:tenant|case|acl|source document|artifact|approval|tool|model|run|index|credential)\b',clean,re.I):
        return 'ELIGIBILITY_REVIEW_REQUIRED','Methodological instruction, possible nonimplementation scope'
    if re.search(r'^\s*(?:no (?:screen|document)|the source\b|the reference\b|not shown in\b|a proposal\b|an example\b)',clean,re.I) and not POSITIVE_ACTION.search(clean):
        return 'EXCLUDED_NONDEFINITIVE','Source gap, not an affirmative system requirement'
    if len(clean)<21 and not POSITIVE_ACTION.search(clean):
        return 'ELIGIBILITY_REVIEW_REQUIRED','Short incompletely contextualized fragment'
    return 'RETAIN_DEFINITIVE','Phase02 definitive generated claim; Phase05 confirms prima facie eligibility'

elig={c['class_id']:reassess_class(c) for c in GC}
log('Class eligibility reassessed across all 4,861 original GC classes')

# Phase02 exclusions: re-evaluate the literal fragment under its original row/head context.
# Only independently checkable source-origin obligations qualify as recoveries.
BINDING=re.compile(r'\b(?:must|shall|required|requires|cannot|never|do not|must not|shall not|only|reject|prevent|block|exclude|quarantine|preserve|retain|verify|validate|enforce|store|record|emit|publish|disable|revalidate|not (?:allowed|permitted)|forbid|prohibit)\b',re.I)
GAP=re.compile(r'\b(?:needs confirmation|unresolved|undefined|tbd|not (?:specified|provided|confirmed|defined|supplied|established|selected)|proposal|illustrat(?:ion|ed|ive)|example|sample|unknown|what to confirm)\b',re.I)
PROD=re.compile(r'\b(?:case|run|review|approval|task|tenant|workspace|acl|document|source|retriev|evidence|citation|upload|connector|index|cache|model|provider|token|status|policy|secret|credential|blob|object|api|event|audit|report|security|release|data|transaction|idempot|rollback|retry|schema|error|request|response|system|user|fail|access|quota|background|dispatch|step|timeout)\b',re.I)
CLASS_STAT=collections.Counter()
ex_audit=[]; recovery=[]; candidate_cases=[]
existing_byline=collections.defaultdict(list)
for g in GO:existing_byline[(g['actual_filename'],g['line_start'])].append(g)

for x in EX:
    raw=x['source_quote_en'];clean=fold(raw.replace('**','').replace('`',''))
    fn=x['actual_filename'];line=x['line_start'];reason=x['excluded_reason_code']
    head=' > '.join(x['heading_path']);co=[g['gen_id'] for g in existing_byline.get((fn,line),[])]
    status='KEEP_EXCLUDED_NONDEFINITIVE';note='No complete independently actionable affirmative generated obligation established from this fragment'
    gap=GAP.search(clean) is not None; binding=BINDING.search(clean) is not None;product=PROD.search(clean) is not None
    # Recovery only strong actionable original statements. Codes/metadata and
    # architecture report questions are not automatically promoted.
    exclusion_hard = reason in {'EXCLUDED_PROPOSAL','EXCLUDED_ILLUSTRATIVE','EXCLUDED_EXAMPLE_OR_PROPOSAL','EXCLUDED_CODE_ILLUSTRATION','NONASSERTIVE_OR_ILLUSTRATIVE','EXCLUDED_EDITORIAL','EXCLUDED_OPEN_DECISION'}
    if binding and product and len(clean)>=25 and not exclusion_hard:
        if (not gap and not re.search(r'\b(?:source citation|source document|previous specifications|citation convention|reference sample|identifier convention)\b',clean,re.I)):
            status='RECOVERY_CANDIDATE';note='Source-original fragment contains a separable definite product constraint and was excluded earlier'
        elif (gap and re.search(r'\b(?:must not|do not|never|cannot|shall not|only)\b',clean,re.I)):
            status='MIXED_PROHIBITION_REVIEW';note='Mixed open contract and definite prohibition; needs clause separation before becoming effective GO'
    if status=='RECOVERY_CANDIDATE' and raw.lstrip().startswith('|'):
        status='TABLE_ROW_ATOMIZATION_REVIEW';note='Excluded entire table row must be separated into independently testable claims before recovery'
    elif status=='RECOVERY_CANDIDATE' and x['line_type']=='table_row':
        complete=re.search(r'(?:\b(?:must|shall|cannot|never|do not|only|requires|required (?:where|when|for|before)|excludes|preserves|retains|rejects|blocks|validates|does not|be verified)\b|^(?:preserve|validate|verify|enforce|do not|use|retain|record|reject|block|exclude|quarantine|disable|treat)\b)',clean,re.I)
        if not complete or gap:
            status='TABLE_CELL_CLAUSE_REVIEW';note='Table cell has incomplete or mixed obligation context; no independent GO recovered yet'
    if status=='RECOVERY_CANDIDATE' and re.search(r'^(?:Earlier proposals|Source references do not confirm|Source gaps do not supply|Identifier preservation|Identifier interpretation|Original question|This specification|This register|Preserve (?:SCR/action|access-request|interface/error/event|API/error/event))',clean,re.I):
        status='KEEP_EXCLUDED_NONDEFINITIVE';note='Method/documentation commentary does not supply an adopted product obligation'
    if status=='RECOVERY_CANDIDATE':
        # Deprioritize uncontextualized fragments already carried on the line.
        pfx=clean.casefold()
        if re.match(r'^(?:[\w-]+\s+)?(?:[A-Z0-9-]+ [\u2014-])?(?:source|method|section|previous|name of|title|no confirmed)',clean,re.I) and not re.search(r'\b(?:must|shall|do not|cannot|never|required|only)\b',clean,re.I):
            status='KEEP_EXCLUDED_NONDEFINITIVE';note='Document metadata or missing contract rather than an independent product duty'
        elif co and x['line_type']!='table_row':
            status='POSSIBLY_ALREADY_COVERED';note='Definitive assertion already extracted on same original line; possible duplicate/incomplete fragment'
        else:
            # Keep only sentences with a verifiable complete predicate, not a noun fragment.
            has_predicate = bool(re.search(r'\b(?:must|shall|cannot|never|do not|must not|shall not|only|is required|are required|be [a-z]+ed|returns?|prevents?|excludes?|rejects?|retains?|preserves?|blocks?|validated|enforced|disabled|stored|recorded|quarantined)\b',clean,re.I))
            if not has_predicate:
                status='RECOVERY_REVIEW_REQUIRED';note='Action tokens but missing complete predication; hold original fragment for targeted audit'
    if status=='RECOVERY_CANDIDATE':
        recovery.append(x)
    elif status in ('MIXED_PROHIBITION_REVIEW','POSSIBLY_ALREADY_COVERED','RECOVERY_REVIEW_REQUIRED','TABLE_ROW_ATOMIZATION_REVIEW','TABLE_CELL_CLAUSE_REVIEW'):
        candidate_cases.append(x)
    CLASS_STAT[status]+=1
    ex_audit.append({'record_type':'PHASE05_EXCLUSION_REASSESSMENT','protocol_version':PROTO,'excluded_id':x['excluded_id'],
        'original_exclusion_reason':reason,'phase05_result':status,'reassessment_reason_en':note,
        'actual_filename':fn,'file_sha256':x['original_file_sha256'],'line_start':line,'line_end':x['line_end'],
        'source_quote_en':raw,'inherited_heading_path':x['heading_path'],
        'same_original_line_prior_gen_ids':co,'recovery_class_id':None,'review_type':'DETERMINISTIC_SOURCE_CONTEXT_AUDIT'})
log(f'Excluded entries reassessed: {dict(CLASS_STAT)}')

# New recovered items get stable new IDs and are *not* inserted into Phase02 files.
# If an excluded fragment repeats an earlier GO verbatim, it is not new.
prev_quotes={(x['actual_filename'],x['line_start'],quote_norm(x['source_quote_en'])) for x in GO}
recovered=[]
byex={a['excluded_id']:a for a in ex_audit}
for x in recovery:
    token=(x['actual_filename'],x['line_start'],quote_norm(x['source_quote_en']))
    if token in prev_quotes:
        byex[x['excluded_id']]['phase05_result']='RECOVERY_DUPLICATE_OF_GO'
        byex[x['excluded_id']]['reassessment_reason_en']='Original literal already appears as a Phase02 definitive GO'
        continue
    idx=len(recovered)+1;gcid=f'GCLASS-P05-{idx:06d}';gid=f'GEN-P05-{idx:06d}'
    st=fold(x['source_quote_en'].replace('**','').replace('`',''))
    # Bare Markdown bullet stripped for readable statement but full original quote retained.
    st=re.sub(r'^\s*(?:[-*+]\s+|\d+[.)]\s+)','',st)
    obj={'record_type':'PHASE05_RECOVERED_GENERATED_ASSERTION','protocol_version':PROTO,
        'class_id':gcid,'gen_id':gid,'source_excluded_id':x['excluded_id'],
        'actual_filename':x['actual_filename'],'file_sha256':x['original_file_sha256'],'original_line':x['line_start'],
        'source_quote_en':x['source_quote_en'],'heading_path':x['heading_path'],'statement_en':st,
        'eligibility':'DEFINITIVE_RECOVERED_CANDIDATE','phase02_modified':False,
        'pending_semantic_duplicate_review':True}
    recovered.append(obj);byex[x['excluded_id']]['phase05_result']='RECOVERED_DEFINITIVE_CANDIDATE';byex[x['excluded_id']]['recovery_class_id']=gcid
assert len({x['class_id'] for x in recovered})==len(recovered)
CLASS_STAT=collections.Counter(r['phase05_result'] for r in ex_audit)
log(f'Recovered {len(recovered)} new candidate definitive classes without touching Phase02; duplicates pending Phase06')

# Retrieve PDF evidence for every existing and recovered class. This search
# is exhaustive at the class-level and traceable, but is NOT an entailment verdict.
allcls=[{'class_id':c['class_id'],'statement_en':c['representative_statement_en'],'quote_en':c['representative_source_quote_en'],
    'file':c['representative_actual_filename'],'line':c['representative_original_line'],'source_sha':c['representative_source_sha256'],
    'prior_gen_id':c['representative_gen_id'],'origin':'PHASE02'} for c in GC]
allcls += [{'class_id':x['class_id'],'statement_en':x['statement_en'],'quote_en':x['source_quote_en'],'file':x['actual_filename'],
    'line':x['original_line'],'source_sha':x['file_sha256'],'prior_gen_id':x['gen_id'],'origin':'PHASE05_RECOVERY'} for x in recovered]

# Keep normalized source query faithful to full assertion, but strip syntactic row prefix.
def extract_query(d):
    txt=fold(d['statement_en'])
    if ' [':
        # Context labels and subject must not be lost when they disambiguate.
        txt=re.sub(r' \[(?:Constraints and validation timing|Status and source|Meaning|Required status|Source|Earlier mapping|Evidence / open decision|Name and purpose)\]:',':',txt,flags=re.I)
    return txt
queries=[extract_query(d) for d in allcls]
candidate_strings=[p['quote_en'] for p in passages]
# word TF-IDF plus char similarity; no positive evidence from score alone.
wv=TfidfVectorizer(stop_words='english',ngram_range=(1,2),sublinear_tf=True,max_features=65000,token_pattern=r'(?u)\b[\w-]{2,}\b')
Xw=wv.fit_transform(candidate_strings);Qw=wv.transform(queries)
cv=TfidfVectorizer(analyzer='char_wb',ngram_range=(3,5),sublinear_tf=True,max_features=90000,min_df=2)
Xc=cv.fit_transform(candidate_strings);Qc=cv.transform(queries)
log(f'Full-GC reciprocal search indexing complete ({Xw.shape[1]} word features, {Xc.shape[1]} char features)')

scores=[]
for start in range(0,len(allcls),96):
    end=min(start+96,len(allcls))
    ww=(Qw[start:end]@Xw.T).toarray().astype(np.float32)
    cc=(Qc[start:end]@Xc.T).toarray().astype(np.float32)
    sc=0.60*ww+0.40*cc
    # Choose up to six; small enough for review, full corpus still searched.
    for row in sc:
        idx=np.argpartition(row,-min(6,len(row)))[-min(6,len(row)):]
        idx=idx[np.argsort(-row[idx],kind='mergesort')]
        scores.append([(int(k),round(float(row[k]),5)) for k in idx])
    if start and start%960<96:log(f'PDF evidence searched for {end}/{len(allcls)} GC')

# Literal quote test uses the full physical page text, independent of retrieval.
pagesnorm=[quote_norm(p) for p in PAGE_TEXT]
# Copy original page-line citation where possible (block quote may join lines),
# verify at least first 65 normalized chars in the page; no invented source quotes.
source_kind_stats=collections.Counter();eligible_status_counts=collections.Counter();pdf_relation_stats=collections.Counter()
claim_audit=[]
for d,hits in zip(allcls,scores):
    if d['origin']=='PHASE02': el,why=elig[d['class_id']]
    else: el,why='RETAIN_RECOVERED_CANDIDATE','Phase05 found explicit product obligation in an originally excluded fragment'
    pdfhits=[]
    for idx,score in hits:
        p=passages[idx];qn=quote_norm(p['quote_en']);pn=pagesnorm[p['page']-1]
        # Quote verification against real PDF page text; if longer than a block
        # join, inspect original prefix, never claim exact if not verifiable.
        verified=(qn in pn)
        if not verified:continue
        pdfhits.append({'physical_page':p['page'],'pdf_quote_en':p['quote_en'][:780],
            'pdf_quote_is_exact_original_page_text':True,'retrieval_similarity_diagnostic_only':score,
            'pdf_sha256':lock['pdf_sha256'],'evidence_kind':'LEXICAL_RETRIEVAL_CANDIDATE'})
        if len(pdfhits)>=5:break
    literal=quote_norm(d['quote_en'].replace('**','').replace('`',''))
    # Do not let markup removal invent a quote proof. Quote must match page.
    exact=[i+1 for i,pn in enumerate(pagesnorm) if len(literal)>=32 and literal in pn]
    # A direct quote supplies an existence proof, not all context/scope.
    highest=pdfhits[0]['retrieval_similarity_diagnostic_only'] if pdfhits else 0.0
    if exact:
        status='DIRECT_PDF_QUOTE_CANDIDATE';basis='Literal generated claim text appears on the authoritative PDF physical page; full scope still requires semantic check'
    elif highest>=0.47:
        status='STRONG_PDF_CONTEXT_CANDIDATE';basis='Strong word/character retrieval overlap; quote exists but whole-clause logical entailment is not established'
    elif highest>=0.23:
        status='PARTIAL_OR_CONTEXTUAL_PDF_CANDIDATE';basis='Some source overlap; verify subject, conditions, scope and outcomes during Phase07'
    else:
        status='LOW_EVIDENCE_PENDING_REVIEW';basis='No high-quality lexical support discovered; this is NOT proof of a false positive'
    if el=='EXCLUDED_NONDEFINITIVE':
        relation='EXCLUDED_FROM_EFFECTIVE_GC_PENDING_AUDIT'
    else:relation='PENDING_SEMANTIC_ENTAILMENT'
    source_kind_stats[status]+=1;pdf_relation_stats[relation]+=1;eligible_status_counts[el]+=1
    link_items=sorted(source_to_gc.get(d['class_id'],{}).values(),key=lambda x:(-x['search_score'],x['source_id']))[:12]
    claim_audit.append({'record_type':'PHASE05_GENERATED_CLAIM_VALIDITY','protocol_version':PROTO,'method':'fullload',
       'class_id':d['class_id'],'origin':d['origin'],'prior_gen_id':d['prior_gen_id'],
       'actual_filename':d['file'],'original_line':d['line'],'original_file_sha256':d['source_sha'],
       'original_generated_quote_en':d['quote_en'],'generated_statement_en':d['statement_en'],
       'source_original_quote_verified':fold(d['quote_en']) in fold(source_lines[d['file']][d['line']-1]),
       'phase05_eligibility':el,'eligibility_reason_en':why,
       'phase05_pdf_candidate_kind':status,'candidate_interpretation_en':basis,
       'pdf_entailment_provenance_category':relation,'canonical_binary_cell':None,
       'pdf_literal_quote_pages':exact[:20],'pdf_evidence_candidates':pdfhits,
       'phase04_r_evidence_candidate_links':link_items,
       'phase06_fp_review_required':el!='EXCLUDED_NONDEFINITIVE',
       'phase07_independent_entailment_required':el!='EXCLUDED_NONDEFINITIVE' and status!='DIRECT_PDF_QUOTE_CANDIDATE',
       'scan_scope':'ALL_90_PDF_PAGES_AND_ALL_EIGHT_ORIGINAL_GENERATED_SPECIFICATIONS',
       'evidence_grade':'E3_SOURCE_QUOTE_CANDIDATE_ONLY' if exact else ('E1_RETRIEVAL_CANDIDATE' if pdfhits else 'EU')})
log(f'Validity scan generated {len(claim_audit)} records across all effective-eligibility candidates')

# Targeted review of potential missed definitive constraints from mixed/open
# lines (recorded, never silently treated as excluded or proven fully).
positive_mixed=[r for r in ex_audit if r['phase05_result'] in ('MIXED_PROHIBITION_REVIEW','POSSIBLY_ALREADY_COVERED','RECOVERY_REVIEW_REQUIRED','TABLE_ROW_ATOMIZATION_REVIEW','TABLE_CELL_CLAUSE_REVIEW')]

# Class-level to source-ID reciprocal links (not TP proof) and population audit.
link_cross=[]
for c in GC:
    cid=c['class_id'];links=sorted(source_to_gc.get(cid,{}).values(),key=lambda x:(-x['search_score'],x['source_id']))
    link_cross.append({'record_type':'PHASE05_CLASS_REFERENCE_CROSSWALK','class_id':cid,'prior_phase04_source_link_count':len(links),
       'source_candidate_ids':[x['source_id'] for x in links],
       'phase05_status':elig[cid][0]})

# Validate Phase03+04 coverage link representation, all R are in the Phase04 ledger.
covered_R=set((row.get('source_id') or row.get('requirement_id')) for row in A4)
assert covered_R==RIDS

# Serialize final records. Earlier files remain byte-identical.
writejln(OUT/'05_generated_claim_validity.jsonl',claim_audit)
writejln(OUT/'05_exclusion_reassessment.jsonl',ex_audit)
writejln(OUT/'05_recovered_definitive_assertions.jsonl',recovered)
writejln(OUT/'05_r_gc_reciprocal_crosswalk.jsonl',link_cross)
writejln(OUT/'05_mixed_exclusion_review_queue.jsonl',positive_mixed)
writejln(OUT/'05_near_duplicate_carryforward.jsonl',NEAR)

# Class-level presence is not synonymous with semantically verified PDF support.
# Preserve pending status even when a full exact quote is detected.
output_names=['05_generated_claim_validity.jsonl','05_exclusion_reassessment.jsonl',
  '05_recovered_definitive_assertions.jsonl','05_r_gc_reciprocal_crosswalk.jsonl',
  '05_mixed_exclusion_review_queue.jsonl','05_near_duplicate_carryforward.jsonl']
source_digests={name:sha(x['original_path']) for name,x in sourcemap.items()}
summary={'record_type':'PHASE05_SUMMARY','protocol_version':PROTO,'method':'fullload','phase':'05',
 'status':'COMPLETE_CANDIDATE_VALIDITY_AUDIT_WITH_UNRESOLVED_SEMANTIC_ITEMS',
 'reference_R':len(R),'reference_N':len(N),'phase02_GO':len(GO),'phase02_GC':len(GC),
 'excluded_original_units_reassessed':len(EX),'phase05_exclusion_reassessment_counts':dict(CLASS_STAT),
 'recovered_candidate_occurrences':len(recovered),'recovered_candidate_classes_before_phase06_deduplication':len(recovered),
 'classes_inspected_total':len(claim_audit),'initial_GC_eligibility_reassessment_counts':dict(collections.Counter(elig[cid][0] for cid in classes)),
 'phase05_pdf_candidate_counts':dict(source_kind_stats),'phase05_pdf_entailment_pending_counts':dict(pdf_relation_stats),
 'prior_phase04_r_to_class_candidate_links':sum(len(x) for x in source_to_gc.values()),
 'prior_phase04_r_to_class_linked_classes':len(source_to_gc),
 'phase04_R_all_accounted':len(covered_R)==len(R),
 'phase05_unresolved_exclusion_review_count':len(positive_mixed),
 'previous_phase02_validator_limitation_en':'The original phase02/validate_phase02.py and phase02/02_phase_summary.json refer to a nonexisting 02_similarity_review_candidates.jsonl file. The separate actual near-duplicate file exists with its own verifiable hash. Required GO/GC/exclusions/index/duplicates are independently integrity-checked, but a missing extra similarity-candidate file remains a documented source-integrity caveat.',
 'pdf_candidate_not_semantic_classification':True,'phase07_or_phase06_pending_policy':'No low-similarity G class is labeled FP and no source retrieval miss is labeled FN by Phase05. Phase06 consolidates unsupported residuals and negative controls; Phase07 independently decides remaining semantics.',
 'source_original_digests':source_digests,'pdf_sha256':lock['pdf_sha256'],
 'r_sha256':lock['frozen_r_sha256'],'n_sha256':lock['frozen_n_sha256'],
 'phase01_lock_sha256':sha(ROOT/'phase01/01_reference_lock.json'),
 'phase02_go_sha256':sha(ROOT/'phase02/02_generated_atoms_final.jsonl'),
 'phase02_gc_sha256':sha(ROOT/'phase02/02_generated_classes_final.jsonl'),
 'phase02_exclusions_sha256':sha(ROOT/'phase02/02_excluded_units.jsonl'),
 'phase03_source_coverage_sha256':sha(ROOT/'phase03/03_source_coverage.jsonl'),
 'phase04_coverage_audit_sha256':sha(ROOT/'phase04/04_coverage_audit.jsonl'),
 'outputs_sha256':{fn:sha(OUT/fn) for fn in output_names},
 'no_prior_files_modified':True,'final_semantic_binary_scores_committed':False}
writej(OUT/'05_phase_summary.json',summary)
report=f'''# Phase 05 — Generated Validity and Exclusion Reassessment\n\nProtocol: 10.6 | Method: fullload | Result: {summary['status']}\n\n## Frozen inputs\n- PDF: 90 physical pages, SHA-256 {lock['pdf_sha256']}.\n- R: 638 unchanged; N: 142 unchanged.\n- Original Phase 02: GO 5,046, GC 4,861, exclusions 10,219.\n- All eight generated Markdown originals: SHA-256 checked unchanged.\n\n## Full claim/exclusion inventory audit\n- Original classes examined: {len(GC)}.\n- Additional recovered definitive-candidate assertions (no previous output rewritten): {len(recovered)}.\n- Total Phase05 claim-validity records: {len(claim_audit)}.\n- Exclusion reassessment rows: {len(ex_audit)}; unresolved mixed/duplicate/fragment cases: {len(positive_mixed)}.\n- Phase04 reciprocal R coverage remains indexed for all 638 frozen source atoms.\n- Original GC validity candidates: {dict(source_kind_stats)}.\n- Original class eligibility: {dict(collections.Counter(elig[cid][0] for cid in classes))}.\n\n## Evidence and judgment boundary\nThe full PDF was searched for each prior or recovered class, retaining exact PDF page passages and real generated-line quotations. A direct quotation is a candidate proof of quotation existence, not an automatic semantic entailment decision. All source-generated claims remain subject to source scope, condition and exception checking; no evidence-grade lexical score establishes canonical FP/TP.\n\nPhase05 recovered claims and original-GC eligibility corrections are recorded only as Phase05 sidecars; Phase02 originals were not modified. Phase06 must resolve effective population and negative-control overlaps without using arbitrary sampling budgets. Phase07 independently decides any unresolved semantic item.\n\n## Carryover limitation\nThe released Phase02 validator attempts to open missing `02_similarity_review_candidates.jsonl`; the actual existing file is `02_near_duplicate_review.jsonl`. The original validator is unchanged. The Phase05 runner independently verifies all GO membership, unique GC ownership, exclusions and exact original-line citations and records this issue.\n\n## Outputs\n- `05_generated_claim_validity.jsonl`\n- `05_exclusion_reassessment.jsonl`\n- `05_recovered_definitive_assertions.jsonl`\n- `05_r_gc_reciprocal_crosswalk.jsonl`\n- `05_mixed_exclusion_review_queue.jsonl`\n- `05_near_duplicate_carryforward.jsonl`\n- `05_phase_summary.json`\n- `run_phase05.py` and `validate_phase05.py`\n\nNo Phase06 external queue or Phase07/08/09 final decisions were produced.\n'''
(OUT/'05_phase_report.md').write_text(report,encoding='utf8')
log('Phase05 artifacts written; running separate independent validator next')
