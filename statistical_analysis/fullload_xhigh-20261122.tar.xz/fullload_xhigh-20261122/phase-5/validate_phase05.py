#!/usr/bin/env python3
"""Independent Phase05 validation: counts, evidence, locks and class trace."""
from pathlib import Path
import json,hashlib,collections,re,unicodedata
import fitz
root=Path('/mnt/data/oriondesk_fullload_v10_6');p=root/'phase05'
J=lambda file:[json.loads(l) for l in open(file,encoding='utf8') if l.strip()]
S=lambda file:hashlib.sha256(Path(file).read_bytes()).hexdigest()
F=lambda z:re.sub(r'\s+',' ',unicodedata.normalize('NFKC',str(z))).strip()
sm=json.loads((p/'05_phase_summary.json').read_text())
lock=json.loads((root/'phase01/01_reference_lock.json').read_text())
prior=json.loads((root/'phase02/02_phase_summary.json').read_text())
cl=J(root/'phase02/02_generated_classes_final.jsonl')
go=J(root/'phase02/02_generated_atoms_final.jsonl')
ex=J(root/'phase02/02_excluded_units.jsonl')
rev=J(p/'05_exclusion_reassessment.jsonl')
claims=J(p/'05_generated_claim_validity.jsonl')
rec=J(p/'05_recovered_definitive_assertions.jsonl')
xwalk=J(p/'05_r_gc_reciprocal_crosswalk.jsonl')
mixed=J(p/'05_mixed_exclusion_review_queue.jsonl')
near=J(p/'05_near_duplicate_carryforward.jsonl')
assert sm['protocol_version']=='10.6' and sm['method']=='fullload' and sm['phase']=='05'
assert len(cl)==4861 and len(go)==5046 and len(ex)==len(rev)==10219
assert len(rec)==sm['recovered_candidate_classes_before_phase06_deduplication']
assert len(claims)==4861+len(rec)==sm['classes_inspected_total']
assert len(mixed)==sm['phase05_unresolved_exclusion_review_count']
assert len(xwalk)==4861
assert len(near)==len(J(root/'phase02/02_near_duplicate_review.jsonl'))
assert len({x['class_id'] for x in claims})==len(claims)
assert {x['class_id'] for x in claims}==({c['class_id'] for c in cl}|{g['class_id'] for g in rec})
assert {x['class_id'] for x in xwalk}=={c['class_id'] for c in cl}
assert {r['excluded_id'] for r in rev}=={r['excluded_id'] for r in ex}
assert len({g['source_excluded_id'] for g in rec})==len(rec)
for name,expected in sm['outputs_sha256'].items(): assert S(p/name)==expected,name
assert S(root/'phase01/01_reference_lock.json')==sm['phase01_lock_sha256']
for name,path in [('pdf_sha256','/mnt/data/OrionDesk_AI_Detailed_Design_Specification(4).pdf'),('r_sha256','/mnt/data/common_atomic_reqs(4).jsonl'),('n_sha256','/mnt/data/common_negative_controls(4).jsonl')]:assert S(path)==sm[name]==lock[{'r_sha256':'frozen_r_sha256','n_sha256':'frozen_n_sha256','pdf_sha256':'pdf_sha256'}[name]]
for name,val in sm['source_original_digests'].items():
 src=next(x for x in lock['source_roles_ordered'] if x['actual_filename']==name)
 assert S(src['original_path'])==val==src['sha256']
source_lines={x['actual_filename']:Path(x['original_path']).read_text(encoding='utf8').splitlines() for x in lock['source_roles_ordered']}
for row in claims:
 fn=row['actual_filename'];n=row['original_line'];txt=row['original_generated_quote_en']
 assert row['original_file_sha256']==sm['source_original_digests'][fn]
 assert 1<=n<=len(source_lines[fn])
 assert F(txt) in F(source_lines[fn][n-1])
 assert row['source_original_quote_verified']
 assert row['canonical_binary_cell'] is None
 assert row['pdf_entailment_provenance_category'] in ('EXCLUDED_FROM_EFFECTIVE_GC_PENDING_AUDIT','PENDING_SEMANTIC_ENTAILMENT')
 assert len(row['pdf_literal_quote_pages'])<=20
 assert len(row['pdf_evidence_candidates'])<=5
for row in rev:
 fn=row['actual_filename'];n=row['line_start']
 assert row['file_sha256']==sm['source_original_digests'][fn]
 assert F(row['source_quote_en']) in F(source_lines[fn][n-1])
for row in rec:
 assert next(x for x in rev if x['excluded_id']==row['source_excluded_id'])['recovery_class_id']==row['class_id']
 assert not row['phase02_modified'] and row['pending_semantic_duplicate_review']
assert collections.Counter(r['phase05_result'] for r in rev)==collections.Counter(sm['phase05_exclusion_reassessment_counts'])
assert dict(collections.Counter(r['phase05_result'] for r in rev))==sm['phase05_exclusion_reassessment_counts']
assert dict(collections.Counter(c['phase05_pdf_candidate_kind'] for c in claims))==sm['phase05_pdf_candidate_counts']
assert dict(collections.Counter(c['phase05_eligibility'] for c in claims if c['origin']=='PHASE02'))==sm['initial_GC_eligibility_reassessment_counts']
source_ids={x['requirement_id'] for x in J('/mnt/data/common_atomic_reqs(4).jsonl')}
assert len(source_ids)==638
for row in xwalk: assert set(row['source_candidate_ids'])<=source_ids and row['prior_phase04_source_link_count']==len(row['source_candidate_ids'])
links_in_classes={r['class_id']:set(x['source_id'] for x in r['phase04_r_evidence_candidate_links']) for r in claims}
for row in xwalk:assert links_in_classes[row['class_id']]<=set(row['source_candidate_ids'])
# Verify all PDF quote candidates on the actual physical PDF page.
doc=fitz.open('/mnt/data/OrionDesk_AI_Detailed_Design_Specification(4).pdf')
assert len(doc)==90
PAGE=[F(doc[i].get_text(sort=True)).casefold() for i in range(90)]
quote_count=0;direct_count=0
for r in claims:
 for ev in r['pdf_evidence_candidates']:
  assert ev['pdf_sha256']==sm['pdf_sha256']
  assert 1<=ev['physical_page']<=90
  assert F(ev['pdf_quote_en']).casefold() in PAGE[ev['physical_page']-1],(r['class_id'],ev['physical_page'])
  quote_count+=1
 for pp in r['pdf_literal_quote_pages']:
  q=F(r['original_generated_quote_en'].replace('**','').replace('`','')).casefold()
  assert len(q)>=32 and q in PAGE[pp-1],(r['class_id'],pp)
  direct_count+=1
for pth,hashv in sm['source_original_digests'].items():assert next(x['sha256'] for x in lock['source_roles_ordered'] if x['actual_filename']==pth)==hashv
out={'status':'PASS_WITH_DOCUMENTED_PRIOR_PHASE02_VALIDATOR_FILE_MISMATCH',
     'phase':'05','protocol_version':'10.6','method':'fullload',
     'prior_phase02_mismatched_expected_file':'02_similarity_review_candidates.jsonl',
     'original_classes_checked':len(cl),'new_candidate_classes_checked':len(rec),
     'excluded_fragments_checked':len(rev),'original_go_checked':len(go),
     'pdf_evidence_quotes_verified':quote_count,'direct_literal_page_refs_verified':direct_count,
     'all_recovered_origin_links_valid':True,'full_reference_R':638,'frozen_negative_N':142,
     'pdf_and_eight_markdown_source_digests_unchanged':True,
     'binary_cells_created':0,'all_phase05_output_hashes_verified':True}
(p/'05_validation_results.json').write_text(json.dumps(out,indent=2,ensure_ascii=False)+'\n',encoding='utf8')
print(json.dumps(out,indent=2))
