# OrionDesk AI — Eight-Phase Evidence-Grounded Atomic Requirement Evaluation Protocol

**Protocol version:** 10.5  
**Purpose:** Evaluate eight generated design specifications against one authoritative PDF using a frozen benchmark, complete bidirectional evidence accounting, confidence-guided verification, and **mandatory, uncapped item-level external LLM adjudication attempts for EVERY R, N, and effective GC whose complete TP/TN/FP/FN classification has not already been independently verified**, transmitted in batches of at most **8 items** with at most **4 concurrent LLM requests**. The generation method never limits the number of uncertain items sent to the evaluator. The mandatory Phase 07 outcome, after a valid external handoff, is one deterministic best-effort TP/FP/FN/TN disposition for every canonical unit, with a separately recorded verification quality; Phase 08 reports one full-population arithmetic score, never a statistical sample estimate.  
**Method:** Evidence-first differential evaluation with full-population ledgers, verified proof-family reuse, confidence-guided adjudication priority, exhaustive original-file LLM review of each individually unverified unit, and **automatic deterministic four-cell TP/TN/FP/FN closure in `semantic_decision_evaluator_10.5.py`**, with item-specific best-effort fallback only for failed/unresolved individual derivations after an actual attempt. Phase 08 independently recomputes canonical metrics.  
**Supported methods:** `fullload`, `onelevel`, `twolevel`.  
**Required operator input:** `spec_gen_method` must be explicitly supplied as exactly one of `fullload`, `onelevel`, or `twolevel`. Never infer or default this value.  
**Execution:** Exactly eight ordered phases; one phase per operator request and response. Finish the current phase before advancing.  
**Language:** Follow the operator's language for conversation. **All authored artifacts, script text, record values written as prose, and reports must be in English.**  
**Delivery:** Individual phase outputs. No archive or separate revision-history artifact unless explicitly requested.

## 1. Governing rules

1. **Source authority.** The original 90-physical-page *OrionDesk AI Detailed Application Design Specification* PDF alone determines source requirements, exclusions, and meaning. Generated specifications, model answers, historical scores, and prior ledgers are evidence or candidate predictions, not independent PDF authority. Inspect all pages, figures, tables, appendices, captions, and substantive generated text.
2. **Frozen reference.** When `common_atomic_reqs.jsonl`, `common_negative_controls.jsonl`, and `reference_freeze.json` are supplied, frozen-benchmark mode is mandatory. Verify identity, pages, SHA-256, ID uniqueness, references, and readable evidence; do not alter the reference bytes or denominator. In the absence of a frozen reference, construct and freeze `R` and `N` independently from the PDF in Phase 01 before any generated inspection. Never silently replace an invalid supplied benchmark.
3. **Complete populations, mandatory per-item LLM for every unverified unit, mandatory closure.** Process every source-positive requirement `R`, fixed negative control `N`, substantive generated occurrence `GO`, and generated semantic class `GC` through reproducible extraction, indexing, evidence matching, and item-level verification. **EVERY effective R/N/GC lacking independently verified full-predicate resolution MUST appear exactly once in the newly frozen external LLM queue; there is NO method-specific numerical selection cap, sampling, truncation, or unselected uncertain population.** The evaluator MUST attempt one independent item-level judgment for EACH queued ID, including when eight IDs share one API request. An unsuccessful individual external derivation (service unavailability, malformed/refused response, invalid evidence, or semantically inconclusive output) MUST be recorded with its attempt/failure proof and MUST then receive a documented deterministic BEST_EFFORT TP/FN (R), FP/TN (N), or diagnostic TP/FP/TN (GC) result under §3.6. Never use a direct best-effort shortcut in place of an unattempted required LLM item. After every queued item has either a validated result or an evidenced failed attempt, close the full canonical matrix and distinguish `VERIFIED` from `BEST_EFFORT` without statistical weights.
4. **Actual logical entailment.** Full coverage requires all relevant actor, target, action, modality, scope, conditions, exceptions, time, limits, version, and outcome. A single applicable universal rule or an explicit cross-file conjunction may satisfy several independent source requirements, but produces neither duplicated generated occurrences nor additional raw classes. Exact identifiers and similarity alone are insufficient.
5. **Two distinct directions.** `R → generated` measures source coverage. `generated → PDF` measures validity of definitive generated claims. A generated statement absent from frozen `R` is not automatically unsupported; a missing retrieval hit is not a verified FN.
6. **Conservative unsupportedness.** A generated commitment is an FP candidate only when the original PDF does not normatively support its full affirmative content and the unsupported predicate is specifically identified. Search the full PDF, including governing common rules and contextual tables, before this finding. Record supporting narrower content separately.
7. **Definitive statements only.** Unadopted proposals, `TBD`, `Needs confirmation`, unresolved alternatives, examples without normative adoption, headings, bare references, and purely explanatory text are not final positive predictions. Preserve any separable definitive claim within a mixed passage, with its actual inherited context.
8. **No artificial atom multiplication.** Split only independently testable complete obligations. Never create stand-alone claims from an isolated table cell, field label, HTTP code, ID, or citation. Merge semantic duplicates only with full mutual entailment; differences in API path, role, conditions, status, version, or consequence can make claims distinct.
9. **Evidence is inspectable and proof quality is explicit.** Every **verified** TP needs complete PDF/generated-original evidence and full-predicate proof; verified FN needs a reciprocal search and specific missing predicate; verified FP needs its exact unsupported residual and PDF countercheck; verified TN needs an audited generated nonassertion. A **best-effort** cell instead requires the strongest available original evidence, source/corpus search receipts, the precise unverified dimensions or unsupported predicate, and a deterministic decision-rule ID; it must never be mislabeled verified. Original filename, PDF physical page, Markdown line/row/cell and contextual scope must be recoverable wherever present.
10. **Mandatory deterministic best-effort adjudication.** Each R/N and effective GC record carries three distinct measures: `model_confidence_estimate`, `evidence_strength`, and `verified_confidence_level`, plus `decision_basis`, `verification_status`, `unreliable`, and `unreliable_reason_en` (§§3.4–3.6). Confidence is not a calibrated probability of correctness. **When every required queued item has a validated individual result or a recorded, actually attempted and unsuccessful individual derivation, the evaluator MUST invoke the deterministic full-population closure with non-null TP/FN for every R, FP/TN for every N, and a four-cell diagnostic classification for every GC; `G` counts contribute canonical FP only through deduplicated `FINAL_RESIDUAL` records. Phase 07 validates that committed closure, and Phase 08 independently recomputes the arithmetic.** `scoring_cell: null` is permissible in Phases 01–06. In Phase 07, missing/corrupt authoritative input blocks completion, but an actually attempted yet individually unsuccessful LLM item MUST instead receive an explicitly unreliable BEST_EFFORT four-cell classification and a failure ledger entry.
11. **No prior-result presumption.** Revisit earlier TP, TN, FP, FN and exclusions when evidence warrants. Inherited completed files are reusable as indexed evidence only after their source hashes, line locators, and relevant predicates are reverified. Earlier v10.1/v10.2/v10.3/v10.4 labels are not v10.5 verification. Existing earlier phase artifacts, batch journals, and queues remain immutable. A revised queue is independently SHA-256-identified; previously committed journals are reusable only when their original queue and evidence hashes remain identical.
12. **Immutable, reproducible history.** Original scored documents, frozen `R/N`, and delivered phase files are immutable. Later corrections are appended as item-level supersession/adjudication records in the subsequent phase ledger. Preserve the prior ID and the effective replacement without rewriting earlier bytes. Do not create a separate revision-history document.
13. **One full-population score, never statistical estimation.** Structural checks, a high-confidence model claim, or a high rate of `FULL` results do not prove correctness. After the evaluator performs mandatory deterministic best-effort closure and Phase 07 checks it, Phase 08 computes **one** Precision, Recall, and F1 directly from the exhaustive canonical unit ledger, with mandatory `VERIFIED` versus `DETERMINISTIC_BEST_EFFORT` status and decision-quality counts. These are arithmetic rates of the recorded classifications, **not statistically estimated population metrics and not guaranteed ground truth when some classifications are best effort**. Never generate a second estimate, extrapolated counts, model-confidence-weighted rate, or confidence interval; never describe `DETERMINISTIC_BEST_EFFORT` rates as independently verified.
14. **One response, one phase.** Complete all records belonging to the requested phase or report a genuine input/platform blocker as `INCOMPLETE`. A fully enumerated phase with individually marked semantic uncertainty may be `PHASE_COMPLETED_BEST_EFFORT`. Do not start the next phase in the same turn.
15. **Manually specified generation method.** The operator must explicitly provide `spec_gen_method` as exactly one of `fullload`, `onelevel`, or `twolevel` for the eight specifications being evaluated. Do not infer it from filenames, document content, previous results, or the presence of method-specific artifacts. Validate and record the supplied value in Phase 01, and preserve it unchanged in subsequent phase outputs. If the value is missing, invalid, or ambiguous, report Phase 01 as `INCOMPLETE` and do not proceed.

## 2. Inputs, identity, and extraction

### 2.1 Required materials

- The original, readable 90-page English PDF (authoritative source).
- An explicit operator-supplied `spec_gen_method` value: `fullload`, `onelevel`, or `twolevel` (exactly one; no inferred/default value).
- Exactly eight original Markdown roles, mapped unambiguously: `01_screen_functions.md`, `02_api.md` (also `02_api_.md`), `03_data.md`, `04_batch_functions.md`, `05_business_rules.md`, `06_exception_handling.md`, `07_processing_flows.md`, and `08_architecture_decision.md`.
- In frozen mode: `common_atomic_reqs.jsonl`, `common_negative_controls.jsonl`, and `reference_freeze.json` (upload-copy suffixes accepted).
- For external adjudication: operator-maintained `semantic_decision_evaluator_10.5.py`, a SHA-256-identifiable variable-length JSONL queue with one `PHASE_SUMMARY` and individually unique `LLM_QUEUE_ITEM` records, item-level `semantic_decisions.jsonl`, successful batch journals, individual failed-attempt records, and the submission-attempt ledger. The evaluator accepts any valid queue item count. Full-population metrics additionally require evidence that the queue and independently verified items cover the entire effective R/N/GC population. The evaluator supports per-item failure fallback, source-identity checks and bounded retries.

Recognizable method prefixes and copy suffixes are permitted only with unique role mapping. Preserve actual input filenames and bytes in every evidence ledger. A normalized role name is a lookup alias, not an alteration of the source. The protocol, earlier phase ledgers, and any aggregate JSON are not ninth scored Markdown inputs.

### 2.2 Frozen checks and source-atom rules

Read each frozen JSONL record and validate the declared positive key (`requirement_id` or `source_id`) and negative key (`control_id` or `negative_control_id`), no mixed keys or duplicates, original PDF SHA-256, expected reference hashes, physical page count, and evidence quotation availability. Fail on incompatible identity/hash or inaccessible required material. Record nonfatal benchmark atomization doubts as `REFERENCE_EXCEPTION`, leaving IDs and bytes unchanged.

`R` comprises smallest independently meaningful PDF-positive normative obligations; a PDF prohibition is itself a positive duty to enforce. General obligations must not be repeated arbitrarily for each endpoint. An endpoint with a distinct method, actor, response, condition, or timing can have independent atoms. Preserve original page, quote, actor, target, condition, constraint, version, outcome, and additional supporting locations.

`N` is a fixed bounded inventory of affirmative counterfactuals explicitly prohibited, excluded, or deferred in the PDF. It is not the set of every possible absent feature. Keep `R ∩ N = ∅`. Never add method-specific controls during scoring.

### 2.3 Generated inventories

`GO` is the set of complete, eligible definitive assertion occurrences, with stable `GEN-*` ID and actual Markdown file, line, row, cell, heading, and full inherited context. `GC` is the set of unique within-method semantic classes, with stable `GCLASS-*` ID and exactly one class assignment per eligible `GO`. Every substantive source line/row must be accounted for by eligible assertions, exclusions, or inherited context; excluded prose is indexed and re-examined in Phase 05. Recovered assertions use new stable IDs and original locators without altering prior files.

## 3. Evidence-first matching and semantic judgment

### 3.1 Reusable indexing, never similarity verdicts

Index original PDF pages, all eight Markdown lines and table rows, IDs, methods/paths, event names, data fields, numeric bounds, scope terms, negation, headings, exceptions, and universal-rule subjects. Use exact and alias lookup plus optional semantic retrieval to *discover* candidates. Preserve original context and a reciprocal generated-to-PDF index. **Before LLM selection, build a proof-family ledger** linking related R, N, and GC items to a canonical proposition and evidence. Store verified original PDF/generated hashes, the complete predicate, applicability and exception boundaries, and each potential transfer recipient. Reuse a validated full-predicate proof only after individually checking the recipient's actor, target, action, modality, scope, conditions, exceptions, time, limits, version, and outcome. A shared subject, high similarity, or repeated wording is not enough. Record a specific rejection reason for unsafe proof transfers; never replicate one G class into extra TP or FP units.

A filename-alias validator must resolve an LLM-provided filename by the uniquely identified eight-file role and verified SHA-256 source mapping, then verify the quoted text in the indicated actual original line range. For example, `03_data.md` and an unambiguous uploaded `03_data(1).md` may map to the same verified role. **Do not reject an accurate quotation solely because the model used a canonical versus uploaded copy suffix.** Reject an ambiguous role, inconsistent digest, wrong original line, or mismatched quotation. Log both reported and resolved names; never silently accept a quotation from a different file.

### 3.2 Bidirectional coverage decisions

For every `r ∈ R`:

1. Reconstruct the whole normative proposition from its PDF page, section and table context.
2. Search full generated text, eligible GO/GC, common clauses, and exclusions using direct wording, synonyms, identifiers, literal values, and reverse links.
3. Test direct equivalence, logically applicable universal rules, inherited context, and explicit conjunctions across files.
4. For every proposed TP, check the whole source predicate; cite a complete proof. For a provisional FN, challenge the strongest actual nearby candidate, document precisely what is missing, and revisit it from the generated-to-source direction.
5. Before Phase 07, label a `VERIFIED` TP only after complete `E3` direct or `E2` contextual/conjunctive entailment, and a `VERIFIED` FN only after demonstrating `TRUE_MISSING` or `PARTIAL_ENTAILMENT` in a reciprocal audit. Unverified items remain null **during earlier phases**, then receive the mandatory best-effort Phase 07 classification under §3.6 without falsely inheriting verified proof status.

For every definitive `g ∈ GC`, independently inspect whether the PDF supports its **entire** generated commitment; label `PDF_ENTAILED`, `SUPPORTED_NONCOVERING`, `PDF_UNSUPPORTED` with exact residual, or explicit unresolved. A statement supported by the PDF but not matched to a frozen source atom is `SUPPORTED_NONCOVERING`, not FP. A generated claim may entail several R atoms without being replicated as several GCs. After all K batches commit, the evaluator must close each GC to a deterministic binary diagnostic cell under §3.6 and preserve its source-support provenance separately; Phase 07 checks this classification against the complete source corpus.

For every `n ∈ N`, determine whether an eligible definitive generated assertion actually affirms the forbidden counterfactual. Affirmed means `FP` in the fixed N row; documented nonaffirmation means `TN`; evidence uncertainty means `UN` before Phase 07; under Phase 07 deterministic closure, apply §3.6 and retain uncertainty as `unreliable=true` rather than an unscored control. An explicit prohibition of the forbidden behavior is not its affirmation.

### 3.3 Entailment evidence grades

| Grade | Standard | Permissible conclusion |
|---|---|---|
| `E3` | Complete direct equivalence with verified original-file proof | Full entailment |
| `E2` | Complete universal/contextual/conjunctive logical proof with verified scope | Full entailment |
| `E1` | Relevant but materially incomplete predicates | Partial only; FN or FP solely with further defensible source/corpus review |
| `E0` | Explicit contradiction or evidenced complete nonentailment | Negative finding if scope and full review are verified |
| `EU` | Important evidence/meaning unresolved | Phases 01–06: `scoring_cell=null`; completed Phase 07: non-null §3.6 best-effort cell, `unreliable=true`, and explicit evidence limitations |

`E2` is as valid as `E3` for a **verified** TP. Neither `E1` nor a low retrieval score automatically proves a **verified** FN/FP; §3.6 may nonetheless assign a documented **best-effort** cell after the mandatory full search and deterministic tie-break. Direct-match exclusions, partial table rows, competing clauses, and source-atom overlap are mandatory audit flags.

### 3.4 Three distinct confidence measures (mandatory classification inputs)

Every effective R/N/GC item must retain **all three** measures, independently auditable in Phase 07:

- **Model confidence — `model_confidence_estimate`:** the external model's self-reported confidence in its own proposed judgment, numeric `[0,1]` or JSON `null` when absent. It is **not** `Pr(TP)` and applies equally to a `FULL`, `PARTIAL`, `NOT_FOUND` or contradiction judgment. Preserve `model_judgment` and original JSON. Never substitute a confidence from another item or a historical sample.
- **Evidence strength — `evidence_strength`:** ordinal `E3`, `E2`, `E1`, `E0`, `EU`, according to §3.3, with original-page/line locators, dimension-by-dimension support and any contrary evidence. `E3` is complete direct support, `E2` complete verified contextual/conjunctive support, `E1` relevant incomplete support, `E0` evidenced contradiction/complete nonentailment, and `EU` unresolved evidence. E0 means strong **negative** evidence, not low confidence by itself. Do not convert the ordinal grade into an invented probability.
- **Verified confidence — `verified_confidence_level`:** `HIGH`, `MEDIUM`, or `LOW`, independently derived from *original-file verification and audit completeness*, not from the model's confidence. `HIGH` requires hash-valid original quotations and a fully inspected eleven-dimension proof or complete contrary/nonassertion search; `MEDIUM` requires verified relevant quotations, inspected critical scope and no unresolved direct contradiction but some incomplete dimensions; `LOW` is retrieval-only, unverified, contradictory, or materially ambiguous. Record `verified_confidence_reason_en` and the exact checks passed/failed. Preserve legacy `evidence_confidence_level` as an alias only where necessary; it does not replace these three separate fields.

Confidence **directs** the order of review and contributes only through the fixed Phase 07 decision priority in §3.6. Higher model confidence never overrides a verified E2/E3 proof or verified E0 contradiction. A reported 0.99 for `PARTIAL` means confidence in a *partial* judgment, not a high likelihood of TP. Do not extrapolate the observed `FULL` fraction to the rest of the corpus or infer statistical probabilities. The fixed model-confidence threshold for an unverified tie-break is **`>= 0.80`**, and is a declared operational best-effort rule, **not a calibrated accuracy claim**.

### 3.5 Full-population closure and proof reuse

Before constructing the external queue, and again after the Phase 07 attempted handoff, walk **every** R, N and effective GC. Every unverified item remains individually mandatory for external review; there is no unselected uncertain subset. Challenge the best original-file proof; check universal clauses, explicit cross-file conjunctions, permissions, negative wording, exceptions and exact PDF/Markdown locators. Re-examine exclusions, mixed table rows and original source context. Use a proof-family transfer only when the recipient's **eleven** dimensions have been individually checked and the proof is actually applicable. Preserve rejected transfers and reasons. Group unsupported residuals by mutually entailed affirmative meaning, and crosswalk affirmed N controls to prevent double counting.

First close only items with independently verified E3/E2 positive proof or fully audited E0/nonassertion proof. **Queue every other R/N/GC for an actual independent LLM adjudication attempt. The evaluator MUST invoke §3.6 for individual model failures and inconclusive results only AFTER an actual attempt is evidenced, and for non-verified successful model results when their semantic proof remains insufficient. Phase 07 verifies attempted coverage and the final binary outcomes.** Record the candidate searched, missing/contested dimensions, proof ID if any, model confidence, evidence strength, verified confidence, decision-rule ID and `unreliable=true`. A best-effort FN is a decision under uncertainty, not a proven semantic absence. Distinguish an unresolved *proof* from an unresolved *classification*: the former may remain explicitly recorded even after the latter has been assigned a required best-effort cell.


### 3.6 Mandatory Phase 07 deterministic best-effort decision policy

**Precondition:** all original inputs/hash/role mappings and frozen Phase 01–06 ledgers are valid; the newly frozen queue is proven to equal the ENTIRE not-independently-verified R/N/GC population; every queued item has exactly one successful independently validated LLM result OR at least one journaled real unsuccessful submission, with an explicit item-level failure reason; full PDF and all eight Markdown roles have been searched in both directions; §3.5 proof transfers and duplicate checks have been attempted. Missing originals, changed hashes, corrupted source evidence, missing queue members or any queued item without either a valid response or a recorded actual attempt remain `INCOMPLETE` and MUST NOT be scored. An actually attempted LLM failure is different: it REQUIRES deterministic BEST_EFFORT closure for that item with the failed attempt linked in the final ledger.

**Fixed priority (higher rows win, no stochastic selection):**

1. `D7-01_VERIFIED`: Complete original E3/E2 full predicate, or validated E0/fully audited nonassertion, wins regardless of model output. Assign the logically supported cell/category with `verification_status=VERIFIED`, `verified_confidence_level=HIGH`, `unreliable=false`.
2. `D7-02_MODEL_SUPPORTED`: Otherwise, if a valid *individually attempted, item-specific* LLM judgment has `model_confidence_estimate >= 0.80`, verified original quotations, `verified_confidence_level` at least `MEDIUM`, and no stronger contradictory original evidence, use that judgment **only for the proposition it actually evaluates**, with `verification_status=BEST_EFFORT` and `unreliable=true`. `FULL` maps to positive full coverage/affirmation for the item direction; `PARTIAL`, `CONTRADICTED` and `NOT_FOUND` are not full coverage. A model's `UNRESOLVED` never becomes `FULL` by threshold alone.
3. `D7-03_ORIGINAL_EVIDENCE`: Otherwise, **only after a real attempt for this queued item has been journaled** (including an unsuccessful attempt), use the best available independently inspected E1 original evidence and complete eleven-dimension comparison (including cross-file contextual candidates); select the **most substantively supported** branch in the direction-specific rules below. State exactly which dimensions remain unverified. Mark `BEST_EFFORT`, `unreliable=true`.
4. `D7-04_CONSERVATIVE_FALLBACK`: **Only after an item-specific real LLM attempt** has failed or returned unusable/inconclusive evidence, if all applicable evidence remains EU, the item has no reliable model judgment, or competing candidates cannot be ordered by preceding rules, apply the direction-specific defaults below. Mark `verified_confidence_level=LOW`, `verification_status=BEST_EFFORT`, `unreliable=true`, and name the missing/contradictory predicates. **Never treat absent lexical retrieval alone as verified nonentailment.**

**Exhaustive, direction-specific decisions (no unresolved scoring cells):**

| Canonical unit | Verified or inspected positive criterion | Deterministic best-effort tie-break / fallback | Required final form |
|---|---|---|---|
| `R` | Source obligation fully entailed by applicable generated definitive content (`E3/E2`), or qualified `D7-02_MODEL_SUPPORTED` `FULL` with consistent inspected context | Otherwise `FN` after complete reciprocal search and predicate challenge; `PARTIAL`, `NOT_FOUND` or an unresolved conflict is **not** automatically a verified absence | Exactly one `TP` or `FN` per R; if fallback, `BEST_EFFORT` and specific uncertain predicates |
| `N` | Generated definitive affirmative statement **actually affirms** the forbidden counterfactual (`E3/E2`), or directionally qualified `D7-02_MODEL_SUPPORTED` affirmative `FULL` | Otherwise `TN` after corpus-wide polarity check. Prohibition of a counterfactual is **not** its affirmation; absence only supports a **best-effort** TN, not a verified one | Exactly one `FP` (asserted N / `B`) or `TN` per frozen N |
| Effective `GC` | PDF fully supports the complete definitive assertion (`PDF_ENTAILED`) or supports it outside frozen R (`SUPPORTED_NONCOVERING`); use original proof and directional qualified model `FULL` if applicable | If definitive content contains an identified unsupported affirmative residual after original-PDF countercheck, classify `PDF_UNSUPPORTED`. Under EU, examine the entire affirmative claim as the *candidate* residual; after the full original review, classify it **FP** as deterministic best-effort if PDF support cannot be substantiated, while preserving incomplete contrary checks. Pure nondefinitive text becomes `NONDEFINITIVE`, not FP | Every effective GC has exactly one four-cell diagnostic decision (supported claim `TP`, unsupported claim `FP`, nondefinitive abstention `TN`); do not count GC `TP/TN` as additional canonical R/N cells |

**Canonical FP consolidation:** An affirmative `PDF_UNSUPPORTED` residual is entered into `F` **once** per mutually entailed semantic predicate, unless its affirmative meaning is already counted as a frozen asserted N in `B`. A provisional candidate must have exact generated-original text and the identified unsupported clause (the **entire original assertion** may serve as the candidate clause if no narrower separable residual is defensible). E1/EU insufficient PDF proof means `BEST_EFFORT` support status, **not** a fabricated `E0` certificate. For unresolved semantic similarity, do **not** merge by score alone; preserve separate explicit predicates in deterministic original-file/line/cell order, with `merge_verification_status=BEST_EFFORT` and an overcount-risk warning. Distinct scope, API path, permission or outcome prevents merging without proven mutual entailment.

**Determinism and traceability:** Before evaluation freeze the code/rule version, original file hashes, source/GO/GC IDs, model results and source-locator sort order. Select candidate original quotes by: (i) proof grade E3/E2/E1/E0/EU as applicable to the proposed **direction**, (ii) number of inspected matching dimensions (descending), (iii) verified-confidence tier HIGH > MEDIUM > LOW, (iv) usable model confidence (descending; null last), (v) physical PDF page, original file-role order, Markdown line, table-cell index and stable item ID (ascending). If equal-strength positive and negative candidates conflict without complete proof, choose the conservative direction-specific fallback; record both. No random tie-breaks or unrecorded analyst discretion.

After validating proof of one successful adjudication or one actually attempted failure per required queued item, the **evaluator MUST emit** one closed, deterministic TP/FN disposition for each R, FP/TN for each N, and one four-cell diagnostic classification per GC; it MUST consolidate F, and Phase 07 must independently audit these outputs: `UR=UN=UG=0` at the **classification** level. Evidence verification may still be incomplete; count and disclose all `BEST_EFFORT` classifications. Never label them `VERIFIED` merely to close the ledger. A structural/input failure remains `INCOMPLETE` rather than a fabricated success. The resulting single Phase 08 score is an arithmetic **deterministic best-effort** full-ledger score when any `BEST_EFFORT` classification is present, not an independent factual certificate.

## 4. Variable-length individual LLM adjudication in batches of eight (concurrency four)

**Queue-length neutrality:** Accept an input queue based on version, source identity, required evidence, item IDs, per-item schema and its single `PHASE_SUMMARY`—not on a numerical item count, a filename suffix or a selection-policy label. Full-population metrics have a separate, independently verified coverage gate. A queue-only run may adjudicate its records without that gate; it must clearly report that canonical population metrics have not been produced.

### 4.1 Variable-length queue construction and completeness

After Phases 03–06 search every original PDF page and generated specification in both directions, classify an item as **INDEPENDENTLY_VERIFIED** only with an actual complete original-file E3/E2 proof or a fully audited E0/nonassertion proof covering all eleven predicate dimensions. A validated universal/conjunctive proof family may cover an item only when its specific actor, target, action, modality, scope, preconditions, exceptions, timing, limits, version and outcome are all checked. Similarity, a preliminary `FULL`, an earlier model answer, and a shared proof-family name NEVER exempt an individual unit from the LLM queue.

Define `V` as the set of distinct effective R, N and GC IDs independently verified before Phase 06 queue freeze. Let `C = (R ∪ N ∪ GC) \ V` and **K = |C|**, without a truncation operation. **Every one of the K IDs MUST be sent for an actual independent LLM adjudication attempt.** No generation-method item cap, stratified sample, risk quota, selective review count, token-based skipping, or residual unselected bucket is permitted. `spec_gen_method` continues to identify the generation method and does not impose any limit. For `K=0`, record the independently verified full universe and use no Azure submissions. Risk, confidence, family and SHA-256 may determine stable **queue order**, never eligibility or inclusion. Any historical Phase 01/06 `max_selected_external_atomic_items`, `L_m`, or old attempt maximum is superseded for this revised policy without altering the old artifact bytes.

The canonical Phase 06 artifact is `06_llm_queue_v10.5.jsonl` with one independent `LLM_QUEUE_ITEM` per externally adjudicated R/N/GC ID and **exactly one non-scoring `PHASE_SUMMARY`**, whether the queue contains zero, one, or any larger number of items. The queue filename, number of items, a `selection_policy` tag, or historical resemblance to an earlier queue MUST NOT be an admission or rejection condition. Each item contains `item_id`, `queue_id`, `direction` (`R`, `N`, `G`), its complete original proposition, exact evidence locators and source digests, eleven predicate checks, distinct confidence fields, proof-family IDs, `spec_gen_method`, `sequence_index`, `unreliable: true` and pending status. The `PHASE_SUMMARY` records the actual item count, direction counts, method and source identities; it never counts as an adjudication item. An optional manifest such as `06_queue_selection.json` may record verified omitted IDs, proof IDs, item sequence and hashes. `06_fp_controls.jsonl` contains the N control audit; prior versions of those artifacts remain immutable unless the operator explicitly creates a revised file. For a **complete evaluation**, verify by set equality that queued IDs are exactly `(R ∪ N ∪ GC) \ V`; verified omissions must have proof and no unverified canonical ID may be omitted. For an **item-level queue-only run**, any internally valid subset may be adjudicated, but it must not produce full-population Precision, Recall or F1. This distinction is checked against actual frozen ledgers, never inferred from the queue length.

**Required prompt evidence:** R entries provide `original_pdf_evidence`, `required_source_predicates`, `original_generated_evidence_candidates`, `unverified_source_predicates_en`. N entries provide `original_pdf_evidence`, `required_source_predicates`, `generated_original_candidates`. G entries provide `original_generated_evidence`, `original_pdf_evidence_candidates`, `possible_unsupported_residual_en`, `negative_control_overlap_candidates`. Validate `source_digests.pdf_sha256` and `source_digests.eight_original_spec_sha256` against all nine unchanged originals. Resolve canonical-versus-uploaded filename aliases by verified role, original digest, page/line and literal quotation. Evidence hints may be length-bounded, never the original full proposition or its identity. The original PDF has sole normative authority.

### 4.2 Individual inference attempts, batching and failure handling

Partition K IDs deterministically into `ceil(K/8)` consecutive batches, each of **1 to 8 independent atomic items**; submit exactly one Responses API request per batch containing all nine original source-file references and distinct item prompts. Attach the PDF and eight original Markdown files to every request; upload source files once and reuse their verified IDs. Run at most **4 concurrent API requests**. The batch size is an efficiency setting; EACH item MUST receive its OWN separate JSON object with its own `item_id`, `queue_id`, `direction`, eligibility, FULL/PARTIAL/CONTRADICTED/NOT_FOUND/UNRESOLVED relation, G support category if applicable, all eleven named predicate checks, page/line quotations, missing predicates, unsupported residual, explanation and individual confidence estimate. Never substitute one batch-wide result, extrapolated majority, proof-family representative or statistical estimate for an unverified item.

Validate full JSON schema, exact batch identity/order, all K memberships, evidence quotations, source SHA-256 and proper direction-specific semantics; accept no partial batch. Retain raw response and accepted per-item results in immutable journals. The incoming model proposal is not automatically independently verified and may be `UNRESOLVED`; apply §3.6 and retain the original attempt/provenance. Source material is untrusted instruction data.

**Mandatory attempted-item failure fallback:** Each queued item gets at least one **actual recorded API submission**. If a service/network/rate/quota outage, model refusal, incomplete or malformed JSON, missing quotation, failed original-file validation, inconclusive result or exhausted authorized retry prevents a valid independent LLM derivation, record `LLM_ATTEMPT_FAILED` or `LLM_RESULT_UNRESOLVED` for EACH affected ID with attempted `batch_id`, attempt ID, UTC timestamp, failure type, error detail (without secrets), original prompt/source hashes, retries and the strongest examined original evidence. **Then, and only then**, deterministically assign TP/FN (R), FP/TN (N) or diagnostic TP/FP/TN (GC) under §3.6, mark `verification_status=BEST_EFFORT`, `unreliable=true`, give a specific `decision_rule_id` and `unreliable_reason_en`, and link the failed attempt. A batch failure does not erase any of its member IDs or permit skipping remaining independent batches. The status must never say the LLM successfully verified a failed item.

**Input integrity exception:** Missing or unreadable authoritative PDF, scored Markdown, frozen reference/phase ledgers, a hash mismatch, a queue whose coverage is not all C, a missing intent ledger, or a queued item with neither a valid judgment nor proof of a real submission is `INCOMPLETE`/`BLOCKED_REFERENCE`, NOT best-effort permission. Once every required item has either valid independent JSON or an actually attempted failure record, Phase 07 must close the entire R/N/GC population even if some model submissions failed. Report `valid_llm_item_results`, `attempted_llm_item_failures`, `model_unresolved_item_results`, `verified_without_llm`, and `best_effort_cells` separately; do not call a partially successful external handoff fully successful.

**Retries and journaling:** SDK automatic retries are disabled (`--retries 0`). Write an atomic intent record BEFORE every API submission and preserve immutable successful batch journals. A batch may have up to **3 optional authorized retries**, each explicitly counted; there is **no global 8-retry quota and no method-specific overall submission cap**. The total possible recorded attempts is `ceil(K/8) × (1 + configured_batch_retries)`. Default `--batch-retries 0`; only known invalid completed responses may retry automatically when `--auto-retry-invalid-response` is explicitly set. Network-ambiguous uncommitted submissions must not be retried without `--resume --retry-ambiguous`. Exhaustion does not cancel processing of other batches: it yields item-specific failure fallback as above. Never resubmit a committed batch. Preserve committed previous attempts and use a fresh output directory whenever the queue digest or decision-rule version changes.

**Offline preflight:** Before uploading or invoking Azure, verify the complete queue membership set, nine source digests, exact original prompt field mapping in each of the three directions, first/last batch sizes and all item identifiers. The supplied evaluator uses Azure Foundry `gpt-6.1-sol` with medium reasoning effort if supported by the actual deployment. Do not run a live LLM merely because the operator requests editing of the protocol.

Example:

```text
python semantic_decision_evaluator_10.5.py \
  --pdf <authoritative-original.pdf> \
  --spec-dir <eight-original-markdown-directory> \
  --queue 06_llm_queue_v10.5.jsonl \
  --phase-dir <immutable-phase-ledgers-directory> \
  --scope auto \
  --out-dir <fresh-v10.5-results-directory> \
  --retries 0
```

### 4.3 Complete-population disposition, not selective extrapolation

For complete-population scoring, the evaluator reconciles `V ∪ queue = R ∪ N ∪ GC` before finalization. Queue-only adjudication does not require this equality and is never scored as the whole population. The `--scope full` option enforces completeness before any Azure request; the default `--scope auto` accepts the input queue and computes full-population metrics only when independently complete, while `--scope queue` always records individual results only. For each queued ID, the final individual disposition derives from its verified original-file proof if independently complete; otherwise from its OWN successful JSON evaluation and independently checked evidence under `D7-02`, `D7-03`, or `D7-04`; **if the model could not derive that item, `D7-03/04` requires that item's recorded failed/inconclusive LLM attempt.** Never reuse a different item's LLM response as if it were independent. Proof-family transfer may assist original evidence checking, but cannot silently replace a required queued attempt.

The output `semantic_decisions.jsonl` contains **one per-queue-ID record regardless of success/failure**, distinguished by `LLM_RESULT_VALID`, `LLM_RESULT_UNRESOLVED`, or `LLM_ATTEMPT_FAILED`. Successful batch journals are authoritative for successful results; failed batch/attempt journals and `llm_failed_items.jsonl` are authoritative for actual attempts without usable results. Every such record has a four-cell proposed/final disposition, its quality and provenance; do not invent a model JSON envelope for a failure. All R/N/GC IDs eventually appear in `07_final_ledger.jsonl` with one four-cell classification (GC TP/TN diagnostic only). Each confirmed unsupported residual is consolidated into canonical F exactly once, excluding overlaps with asserted frozen N.

The evaluator must complete **every queued item**, even if its batch returns an error. An item with no attempt is `INCOMPLETE`, never eligible for fallback. If any unattempted queued ID remains because execution was interrupted, resume processing from committed journals, with authorized ambiguous-attempt handling. Phase 07 verifies item-level attempt coverage, per-item semantic quality, failed-attempt fallback and the source-wide reciprocal checks before approving the binary ledger.

### 4.4 Deterministic four-cell output and reporting

**For every R, output exactly one TP or FN; for every frozen N, exactly one FP or TN. For every effective GC, output a diagnostic TP, FP or TN, never an additional canonical TP/TN.** An affirmative unsupported GC contributes only through a semantically consolidated, nonoverlapping `FINAL_RESIDUAL` FP. Preserve original source and generated quotation locations, all eleven dimensions, separate model/evidence/verified confidence measures, `verification_status`, `decision_basis`, `decision_rule_id`, `unreliable`, `unreliable_reason_en`, and, whenever applicable, `llm_attempt_id` and `llm_failure_reason_en`.

`D7-01_VERIFIED` prevails only with independently proved complete evidence. `D7-02_MODEL_SUPPORTED` may give a **BEST_EFFORT** substantive conclusion from an item-specific qualified model result and checked quotations; it does not certify correctness. `D7-03_ORIGINAL_EVIDENCE` and `D7-04_CONSERVATIVE_FALLBACK` decide remaining individual cases after an attempted model judgment. For a failed model item, never set `model_confidence_estimate` to a fabricated number: use null. For a nondefinitive GC, diagnostic TN requires evidence of its nonassertive context; for an unsubstantiated definitive positive GC, diagnostic FP is best effort and the exact candidate affirmative residual must be preserved. Do not merge distinct residuals by similarity alone. The canonical confusion matrix includes only R, N and unique F; repeated GO/GC occurrences do not multiply TP/FP.

The evaluator writes `semantic_decisions.jsonl`, `llm_failed_items.jsonl` (possibly empty), `07_final_ledger.jsonl`, `07_binary_counts.json`, batch and intent journals, and prints one canonical TP/TN/FP/FN quartet. Phase 07 checks the result; Phase 08 independently calculates **one** full-population Precision/Recall/F1 set. When any conclusion is best effort, label it `METRICS_DETERMINISTIC_BEST_EFFORT`, not `METRICS_VERIFIED` and not a sample estimate. Keep both completed JSON and failed-attempt evidence accessible; do not call a deterministic fallback an LLM confirmation.

**Artifact identity:** Retain previous queue/journal/freeze/output bytes unchanged. Resume only when the exact input SHA-256, queued IDs and order, prompt digests, model configuration and binary-rule version match the committed run state. Version string remains **10.5**; decision-rule version `10.5-EXHAUSTIVE-ATTEMPT-1` distinguishes the current judgment semantics. Do not initiate Azure requests simply to edit these instructions.

## 5. Canonical scoring universe and independently computed metrics

### 5.1 Scoring units (one consistent binary universe)

For each evaluated method `m`, define:

```text
R_m = R  : fixed PDF-positive normative source atoms
N_m = N  : fixed predeclared PDF-negative counterfactual controls
GO_m     : eligible definitive generated occurrences
GC_m     : raw distinct definitive generated semantic classes
A_m      : {r in R : the entire generated corpus fully entails r}
B_m      : {n in N : the definitive generated corpus affirms n}
F_m      : mutually distinct unsupported generated-only affirmative propositions,
           after exact residual separation and semantic consolidation, excluding
           every proposition already counted as an asserted N control in B_m
U_m      : R disjoint_union N disjoint_union F_m
P_m      : A_m union B_m union F_m
```

Source-positive atoms are the actual-positive units. Fixed N controls and unique generated-only unsupported residuals are actual-negative units. A genuine unsupported G residual has predicted positive and counts once as FP; a supported generated class does **not** create an additional TP unless its evidence covers a previously retained R atom. A generated class can cover multiple distinct R atoms through proven applicability. Raw `|GC|` is therefore **not** the canonical predicted-positive count.

Each `r` in R has one `FINAL_SOURCE` record with **exactly one** TP (actual=1, predicted=1) or FN (actual=1, predicted=0), and each `n` in N has one `FINAL_CONTROL` record with **exactly one** FP (actual=0, predicted=1) or TN (actual=0, predicted=0) after a completed Phase 07. These classifications can be `VERIFIED` or `BEST_EFFORT`, but never null after a valid handoff. Each distinct f in F has one `FINAL_RESIDUAL` record (actual=0, predicted=1), linked back to all supporting GCs. Every effective GC has exactly one `FINAL_CLASS` classification; supported classes are validity ledger rows, not extra canonical score units. Before Phase 07, unresolved candidate residuals are **not** counted as known F or zero F. After a valid Phase 07, §3.6 deterministically closes all eligible generated-only residuals and their N/F crosswalk, with `BEST_EFFORT` flagged when proof remains incomplete.

### 5.2 Confirmed four-cell definitions and equations

| Cell | Actual | Predicted | Evidence-grounded meaning |
|---|---:|---:|---|
| `TP` | 1 | 1 | Complete PDF-positive obligation covered by definitive generated commitments |
| `FN` | 1 | 0 | PDF-positive obligation demonstrably missing or only partially covered after reciprocal challenge |
| `FP` | 0 | 1 | Affirmed fixed PDF-negative control or one unique PDF-unsupported generated-only residual |
| `TN` | 0 | 0 | Fixed PDF-negative counterfactual not affirmed by definitive generated commitments |

For a **fully classified canonical universe** (verification quality is separately audited):

```text
TP = |A_m|
FN = |R| - |A_m|
TN = |N| - |B_m|
FP = |B_m| + |F_m|

|U_m| = |R| + |N| + |F_m|
|P_m| = |A_m| + |B_m| + |F_m| = TP + FP
TP + FN = |R|
TN + |B_m| = |N|
FP - |B_m| = |F_m|
TP + TN + FP + FN = |U_m|
TP + FP != |GC_m| in general; no equality is required.
```

**Never add a generated assertion of an N counterfactual to F as well.** An unsupported generated residual shared by seven or eight files still contributes one F after full semantic consolidation, not seven or eight FPs. Different independently testable unauthorized permissions or outcomes remain distinct residuals.

### 5.3 Precision, Recall, F1, and diagnostic rates

Compute one set of full-population metrics from **all enumerated final canonical decisions** after Phase 07, never from manually supplied totals, raw GO/GC counts, retrieval candidates or model votes alone. Report `VERIFIED` only if all contributing decisions are verified; otherwise attach `METRICS_DETERMINISTIC_BEST_EFFORT` and the exact number of best-effort units. These are **not** statistical estimates or ground-truth guarantees:

```text
Precision = TP / (TP + FP)
Recall    = TP / (TP + FN) = TP / |R|
F1        = 2 * TP / (2 * TP + FP + FN)

R_coverage_rate           = TP / |R|                   # equals Recall when fully resolved
negative_control_pass_rate = TN / |N|                  # bounded diagnostic only
GC_validity_rate          = PDF_supported_GC / definitive_GC
raw_duplicate_rate        = (|GO_m| - |GC_m|) / |GO_m|
```

`PDF_supported_GC` includes definitive classes classified `PDF_ENTAILED` and `SUPPORTED_NONCOVERING` under the same final decision-quality rules; nondefinitive and unsupported classes are excluded from its numerator. Interim rates in Phases 01–06 are `null` while source/control/classification populations remain unresolved. After valid Phase 07 deterministic closure, all units have one final category and a documented decision-quality tier, so full-ledger metrics are numeric subject only to zero-denominator rules. Clearly identify the denominator of every diagnostic rate. `negative_control_pass_rate` is **not** true-negative population accuracy and does not enter Precision/Recall/F1 other than through the genuine FP count when a negative control is affirmed. Do not derive per-file source Recall by copying globally satisfied R atoms to each file; any file attribution is separately defined evidence contribution, not overall coverage.

Zero-denominator handling: return JSON `null` for Precision when `TP+FP=0`, Recall when `|R|=0`, the negative-control rate when `|N|=0`, GC-validity rate when its definitive denominator is zero, and duplicate rate when `|GO|=0`. Return F1 as `null` when `2TP+FP+FN=0`, otherwise its exact fraction (including `0` where appropriate). Store native numeric values, not rounded strings; reports may format a separately specified number of decimal places without changing underlying values.

### 5.4 Interim unresolved units and mandatory Phase 07 classification closure

Before Phase 07, retain `UR`, `UN`, `UG` as explicitly unresolved R, N and GC populations and enforce the partial-state invariants:

```text
TP_verified + FN_verified + UR = |R|
TN_verified + B_verified + UN = |N|
FP_verified = B_verified + F_verified
UG is unresolved, not assumed zero or FP before Phase 07.
```

After the **valid Phase 07 external handoff** and all-population reciprocal audit, **apply §3.6 without exception to each remaining semantic uncertainty**. `UR = UN = UG = 0` is then mandatory for **classification** (not a claim of unanimous verified proof). Every R belongs to TP/FN, every N belongs to asserted-N FP/TN, every definitive GC has a supported/unsupported category and every unsupported residual has a unique, deduplicated `F` identity. If original inputs, queue results, digests or batch journals are invalid/missing, report `INCOMPLETE` rather than fabricate a score.

All final decisions have `decision_quality = VERIFIED | BEST_EFFORT`. Record `model_confidence_estimate`, `evidence_strength`, `verified_confidence_level`, the rule ID, supported/unsupported clause, original locators and specific unresolved proof dimensions. A best-effort item is **classified** even though evidence uncertainty is preserved in `unreliable=true`. The canonical arithmetic equations in §5.2 must reconcile over **every** final classification. Confidence is **never** a score weight or an accuracy estimate.

**One metric set:** Phase 08 always computes numeric Precision/Recall/F1 from the closed deterministic ledger (except mathematically undefined zero denominators). If all contributing cells and residual merges are independently verified, status is `METRICS_VERIFIED`; otherwise status is `METRICS_DETERMINISTIC_BEST_EFFORT`. The latter is a complete arithmetic score over best-effort labels, **not a statistically estimated score, confidence bound, or claim of verified correctness**. Report the count of `BEST_EFFORT` decisions and evidence defects. Never issue a second estimated score or pretend a model confidence value is a measured accuracy probability.

### 5.5 Duplicate metrics, independent of correctness

For raw within-method semantic classes:

```text
eligible_occurrences = |GO_m|
unique_classes = |GC_m|
excess_duplicate_occurrences = eligible_occurrences - unique_classes
Duplicate = excess_duplicate_occurrences / eligible_occurrences
repeated_class_count = number of classes with >= 2 original occurrences
```

Choose each class's representative by original input-file order, physical line, then table cell. Label every excess occurrence `within_file` if a preceding occurrence of the same class is in that file; otherwise label `across_file`. Check:

```text
within_file_excess + across_file_excess = excess_duplicate_occurrences
```

Report cross-file repeated-class count separately. Keep `EXPECTED_REUSE` (legitimate parallel coverage) distinct from `REDUNDANT_DUPLICATE` (unnecessary repetition); both are excess occurrences for the raw duplication metric. Do not multiply TP or FP by repeated occurrences. Never use the source-matched count, evidence-bridge count, or unsupported residual count as the raw GC denominator.

### 5.6 Required metric views and error analysis

`08_metrics.json` and the report must separately present:

1. Source reference counts `|R|`, `|N|`, their SHA-256 and freeze status; generated `|GO|`, `|GC|`, raw duplicates, and all recovered occurrences/classes.
2. Final deterministic `TP`, `FN`, `TN`, asserted-N `B`, unique generated-only `F`, and `FP`, with `VERIFIED` versus `BEST_EFFORT` counts; pre-Phase-07 `UR`, `UN`, `UG` and final zero-classification-unresolved check.
3. A **single** numeric full-ledger Precision/Recall/F1 set after valid Phase 07 deterministic closure, with `METRICS_VERIFIED` or `METRICS_DETERMINISTIC_BEST_EFFORT`, plus raw Duplicate, GC validity and bounded N-pass rate; do not produce a statistical estimate.
4. FN-root-cause counts `TRUE_MISSING`, `PARTIAL_ENTAILMENT`, `MATCHER_FALSE_NEGATIVE_CORRECTED`, and `CONSERVATIVE_UNRESOLVED`, with cited strongest generated candidates.
5. TP evidence quality: counts of `E3`, `E2`, incomplete proof, direct-identifier exceptions, and verified universal/conditional/conjunctive bridges; reference exceptions do not silently reduce R.
6. FP provenance: asserted N controls, distinct generated-only residual classes, all original G evidence locators, scope differences, duplicate-cluster decisions and PDF contrary checks. Include a separate list of `SUPPORTED_NONCOVERING` GCs.
7. LLM audit: exactly **K = all individually unverified R/N/GC IDs**, with NO numerical cap for any method; the independently verified excluded-by-proof IDs and their original evidence; full queue SHA-256; `ceil(K/8)` batches (maximum concurrency 4); per-item valid model results, unresolved model results, failed-attempt fallbacks, individual model/evidence/verified-confidence measures, original quotations, batch and attempt journals, disagreements, and exact proof-family transfer checks. Show `valid_llm_item_results + attempted_llm_item_failures = K` with no unattempted IDs; configured optional retries are auditable, not a sampling limit.
8. Per-file descriptive GO/GC occurrence and duplication totals (counting each original occurrence once), optional chapter/requirement-family coverage diagnostics with exact denominators, and cross-method comparisons only over identically frozen R/N.
9. Input/evidence validity flags, three separate confidence measures (not estimated accuracy), original proof reuse and rejection counts, unsupported residual ambiguities, benchmark atomization exceptions, high-risk `BEST_EFFORT` items, and limitations of the final arithmetic scores.

Never call a high Recall, a low FP count, or a structurally balanced confusion matrix proof of specification correctness without corresponding semantic evidence.

## 6. Eight ordered phases

Each phase must finish its entire specified non-LLM population within the current response. Only the mandatory exhaustive external K-item/ceiling(K/8)-batch attempt and recorded failure handoff is performed between Phase 06 and Phase 07; it is not a ninth phase. Each principal JSONL includes one `PHASE_SUMMARY` record (excluded from item counts) with totals, status, reliability counts, evidence problems, exact input digests, and unresolved limits.

| Phase | Required work | Output artifacts | Completion gate |
|---|---|---|---|
| **01 — Reference lock** | Validate and record the explicitly operator-supplied `spec_gen_method` (`fullload`, `onelevel`, or `twolevel`); verify original PDF identity, 90 pages, evidence images/tables, frozen R/N hashes and IDs; if no frozen reference, independently construct and lock before generated inspection. Record immutable source digests and reference exceptions. | `01_reference_lock.json`; construction-mode R/N files only when necessary | Exactly one valid manual `spec_gen_method`, stable verified benchmark, and all eight scored inputs identified; missing/invalid method or reference blockers cannot advance |
| **02 — Complete GO/GC extraction** | Scan every substantive Markdown paragraph/table row and all actual cells with inherited context. Produce definitive complete GO, GC, exclusions, duplicate classification, and original-text index. | `02_generated_atoms_final.jsonl`, `02_generated_classes_final.jsonl`, `02_excluded_units.jsonl`, `02_duplicate_classes.jsonl`, `02_original_text_index.jsonl` | All substantive regions accounted for; every GO in exactly one GC; duplicate arithmetic reconciles |
| **03 — Full R initial coverage** | For every R, use direct/contextual/universal/conjunctive search across the full corpus, record actual PDF/Markdown candidates and complete predicates, and flag extraction gaps. | `03_source_coverage.jsonl`, `03_semantic_coverage_bridges.jsonl` | Exactly one provisional, evidence-linked R status per source atom |
| **04 — Reciprocal FN and TP audit** | Challenge **every** initial FN using both directions; audit **every** provisional TP predicate-by-predicate; identify false misses, partial obligations, reference exceptions and recovery opportunities. Preserve earlier records; add effective audited states. | `04_fn_root_cause_audit.jsonl`, `04_tp_evidence_audit.jsonl`, `04_coverage_audit.jsonl` | Entire R partition reconciled, all preliminary TP proofs inspected, no FN from retrieval absence alone |
| **05 — Full generated validity** | Re-examine **all substantive exclusions** for missed assertions; recover valid GO/GC; evaluate every effective definitive GC against original PDF, including supported-noncovering claims, unsupported residuals and explicit uncertainty. | `05_generated_claim_validity.jsonl`, `05_exclusion_reassessment.jsonl` | Every exclusion and effective GC accounted for; no unmatched-GC-to-FP shortcut |
| **06 — N controls, FP consolidation, and complete variable-length LLM queue** | Audit every N/GC residual, independently verify complete evidence, and freeze **K = the number of remaining unverified R/N/GC items**, without a numeric cap. Record each queued item and its original evidence; include one non-scoring `PHASE_SUMMARY`. | `06_fp_controls.jsonl`, `06_llm_queue_v10.5.jsonl`, `06_queue_selection.json` | For a full score, every unverified ID appears once; independently verified omissions have proofs, and SHA-256/queue order remain immutable |
| **07 — Four-cell closure and evidence audit** | Verify one individually valid result OR one evidenced actual attempted LLM failure for **every** Phase 06 queued R/N/GC; audit deterministic fallback for failures and inconclusive responses; challenge all original proofs and semantic F/N duplicates; preserve final binary labels. | **Evaluator:** `semantic_decisions.jsonl`, `llm_failed_items.jsonl`, successful/failed batch and attempt journals, `07_final_ledger.jsonl`, `07_binary_counts.json`. **Phase:** `07_llm_review.jsonl`, `07_duplicate_metrics.json` | No unattempted required item; source and input integrity valid; each canonical cell non-null with `VERIFIED` or reasoned `BEST_EFFORT`; attempts/failures independently auditable |
| **08 — Deterministic canonical metrics and delivery** | Reconstruct effective Phase 01–07 classifications, verify R/N/GC/F and duplicate accounting; compute **one numeric** full-ledger Precision, Recall and F1 from Phase 07 closed labels, assigning `METRICS_VERIFIED` only when all proofs are verified and otherwise `METRICS_DETERMINISTIC_BEST_EFFORT`. No statistical substitutes or confidence weighting. | `compute_metrics.py`, `08_metrics.json`, `08_report.md`, `08_coverage_and_limitations.md` | Independent arithmetic passes, all valid Phase 07 labels are non-null, all best-effort evidence limits are disclosed, and no fabricated verified claim or duplicate count appears |

**Operational handoff:** The SHA-256-identified Phase 06 queue contains all R/N/GC items requiring external derivation for a full evaluation, without a numeric cap. The evaluator also accepts standalone item-level queues of arbitrary length under the same source, evidence, identity and `PHASE_SUMMARY` rules. It attempts each queued item individually (up to eight per request, at most four concurrent requests), commits a valid model judgment or a traceable actual failed attempt, and deterministically classifies unsuccessful/inconclusive items as `BEST_EFFORT`. An unattempted queued item cannot be treated as a successful result. Full-population metrics are produced only when R/N/GC ledger membership and proof-verified omissions reconcile exactly. Queue-only outputs are not whole-population metrics. Earlier frozen artifacts are not overwritten.**

## 7. Item-level record and validation contracts

### 7.1 Required final record kinds

The evaluator-generated `07_final_ledger.jsonl` must contain exactly one `FINAL_SOURCE` per frozen R ID, one `FINAL_CONTROL` per frozen N ID, one diagnostic `FINAL_CLASS` per raw GC ID (including recovered/nondefinitive classes), and one canonical `FINAL_RESIDUAL` per unique generated-only unsupported proposition. Before Phase 07 any unresolved potential residual is a `RESIDUAL_CANDIDATE`; completed Phase 07 **must resolve it into a final supported/unsupported/nondefinitive category**, with explicit `BEST_EFFORT` quality if unsupportedness remains incompletely proven, rather than leaving an unclassified scoring unit. Each record carries stable ID, method, original input digests, PDF and generated locators, non-null final classification, `decision_quality`, `decision_rule_id`, `model_confidence_estimate`, `evidence_strength`, `verified_confidence_level`, `unreliable`, `unreliable_reason_en`, adjudication provenance, and links to prior superseded records if relevant. `PHASE_SUMMARY` is excluded from canonical counts.

Verified TP records must include a complete predicate-check map and source-to-generated evidence bridge with a `TP_AUDIT` reference. Best-effort TP records must instead document the examined predicate dimensions, verified original locator(s), the §3.6 rule ID and the specific unverified parts; they cannot masquerade as fully proved TP. Every FN includes an inspected strongest candidate, exact missing or uncertain predicates, reciprocal search receipt, and `fn_review_disposition`; a best-effort FN must not be labeled `TRUE_MISSING` without proof. Confirmed FP residuals include the exact unsupported affirmative predicate and PDF search/contrary evidence; TN records identify the frozen negative control, relevant generated evidence checks, and nonassertion justification. Each effective GC records one **final** four-cell diagnostic status `TP`, `TN`, or `FP` (never extra R TP / N TN); PDF-support categories are retained only as explanatory provenance; for ambiguous mixed claims split only independently meaningful parts and retain links.

A model result is linked by selected queue ID and source digest, with reported and resolved filename aliases, verified page/line quotations, final reviewer decision, exact residual/bridge, and `REVIEW_PENDING` if incomplete. Prior cells in an external evaluator's `current_cell` field may be null and are provisional labels only, **never** final outcomes or metric inputs. `REVIEW_PENDING_EXTERNAL_SEQUENTIAL_LLM` and `unreliable: true` both denote eligible pending model-review items; neither is a scoring cell. Every queued final item links to its `batch_id` and either its own validated per-item JSON result or its own recorded unsuccessful/inconclusive attempted-derivation evidence and deterministic fallback rule.

### 7.2 Example final source unit (schema illustration only)

```json
{
  "record_type": "FINAL_SOURCE",
  "source_id": "PDF-EXAMPLE",
  "method": "fullload",
  "scoring_cell": "FN",
  "decision_quality": "BEST_EFFORT",
  "decision_rule_id": "D7-04_CONSERVATIVE_FALLBACK",
  "model_confidence_estimate": null,
  "evidence_strength": "EU",
  "verified_confidence_level": "LOW",
  "verification_status": "BEST_EFFORT",
  "unreliable": true,
  "unreliable_reason_en": "Whole-predicate support remains uncertain after reciprocal search; FN is the deterministic fallback, not verified absence.",
  "entailment_grade": "EU",
  "coverage_mode": null,
  "pdf_evidence": [],
  "generated_evidence": [],
  "predicate_checks": [],
  "adjudication_status": "DETERMINISTIC_BEST_EFFORT_CLASSIFIED",
  "prior_record_ids": [],
  "llm_item_id": null
}
```

This is **a schema illustration, not an actual finding**; all executed IDs, quotations, locators, search receipts and evidence assessments must come from originals. A low-confidence best-effort FN may be assigned by §3.6, but an empty evidence array in this illustration is **not** sufficient production audit evidence or verified nonentailment.

### 7.3 LLM-result acceptance

Accept each external decision only after checking: selected queue membership and uniqueness; batch ID and exact 1–8 per-item result count/order; expected direction and exact PDF/input digests; individual response completeness; original PDF page and literal quote; actual Markdown original line range and literal quote under unambiguous filename normalization; independently supported/contradicted predicate checks for each item; committed batch-journal identity; and an explicit documented final disposition. Store raw model JSON unchanged alongside the reviewer's evidence-grounded final assessment. Do not equate a model's numeric confidence to a probability of correctness. After validating each individual JSON result OR its failed attempt and fallback, Phase 07 **MUST** apply §3.6 across the complete R/N/GC universe; no unselected unresolved ID is permitted. Every best-effort item must identify which attempted derivation failed or which full-predicate proof remained inconclusive.

## 8. Independent metric recomputation (mandatory Phase 08 implementation)

`compute_metrics.py` must implement and **fail fast** on the following in order:

1. **Load sources:** Open frozen R/N/reference manifest, original PDF identity record, original scored file digests, and every required Phase 01–07 JSON/JSONL artifact. Strictly parse each row; exclude summaries and non-scoring audit markers from units.
2. **Recheck identity:** SHA-256 of frozen R/N/PDF and the eight source files, 90 physical pages, exact role mapping, version, the unchanged operator-supplied `spec_gen_method` validated in Phase 01, and all fixed evidence locators. Mismatch is fatal; missing mandatory evidence is not E0.
3. **Reconstruct effective IDs:** Apply recorded item-level supersession in chronological phase order without editing immutable files. Check there is one current R, N, GC and supported residual-candidate status. No missing/duplicate IDs; all recovered GO map to exactly one effective GC.
4. **Check extraction scope:** Verify every substantive Markdown region and Phase 02 exclusion was assessed, with original source/line/table context and Phase 05 disposition. Verify all recovered assertions and class merges retain actual original passages.
5. **Check coverage:** All final R have non-null TP/FN; verified TP claims have full PDF/generated evidence and eleven dimensions; verified FN claims have full-corpus reciprocal proof and exact `TRUE_MISSING` or `PARTIAL_ENTAILMENT`. Best-effort R decisions instead carry §3.6 rule IDs, original locators, challenged candidates, missing dimensions and `unreliable=true`; never assert verified absence from a weak search. Direct, complete verified TP mismarked FN is a hard error.
6. **Check generated validity:** Every effective GC has exactly one non-`UNRESOLVED` final category. Verified `PDF_UNSUPPORTED` cites proven residual; **best-effort** `PDF_UNSUPPORTED` cites the exact candidate affirmative residual and full-PDF countercheck attempt with uncertainties, marked `unreliable=true` rather than invented E0. Supported-noncovering claims require a traceable PDF connection. Exclusions remain audited; do not silently suppress definitive assertions.
7. **Check negative controls:** Exactly one non-null FP/TN for each frozen N, verified or best effort. Asserted N controls contribute one FP each. Validate polarity, full original search receipts, N-to-F crosswalk, and no duplicate between B/F; count unsupported residual classes once using §3.6 deterministic merge policy with any uncertain separation flagged.
8. **Check external audit:** For a completed full-population evaluation, verify queue equality with the complete individually unverified R/N/GC ID set and independently verified proof IDs for every omission. Queue-only item judgment does not imply that full-population equality has been satisfied. Require `ceil(K/8)` attempted batches, at most four requests concurrently and **one valid JSON result OR one documented actual failed attempt for each queued ID**. Validate source digests, exact original quotations/eleven dimensions for valid results, raw successful journals, `llm_failed_items.jsonl`, and durable intent/failed-attempt logs for all failures. Require item-level deterministic fallback for every failed/inconclusive derivation. No result/attempt for a required item is a structural `INCOMPLETE` blocker. The maximum attempts are `ceil(K/8) * (1 + configured_batch_retries)` with no method-specific or global eight-retry cap. Prior journals remain immutable and are reusable only when the full run identity is unchanged.
9. **Check mandatory deterministic closure:** After full reassessment, require non-null final TP/FN for every R and FP/TN for every N, and one final GC category with complete F grouping. Assert `UR=UN=UG=0` **for classification** after a valid handoff; distinguish `BEST_EFFORT` evidence uncertainty from an unclassified cell. Check each `D7-*` branch, priority and deterministic tie-break, the three separate confidence values, every proof transfer, and all §5.2 identities including `|U|=TP+TN+FP+FN`. Confidence is not a metric weight.
10. **Calculate one set of counts and rates:** Enumerate all final canonical IDs; calculate Precision, Recall, F1, raw Duplicate, per-file duplicates, GC validity and bounded N-pass with §5.3 denominators and zero-denominator rules. Set `METRICS_VERIFIED` only if all contributing proof/merges are verified; otherwise set `METRICS_DETERMINISTIC_BEST_EFFORT`, reporting best-effort counts and no second or statistical score. Never force `TP+FP=|GC|`.
11. **Cross-check report:** Compare all JSON totals/rates to the Markdown report. Require correct final metric status, unresolved counts, risk/source anomalies, supported-noncovering claims, FP canonicalization evidence, and transparent distinction between structural and semantic certification.
12. **Cross-method fairness:** When evaluating multiple methods, require same original PDF, R/N bytes, eligibility and adjudication policy. Recompute each method's independent GO/GC/F and canonical cells. Compare only like-named and like-defined metrics, not raw GC and canonical predicted positives interchangeably.

`compute_metrics.py` must fail fast on structural/input integrity violations or missing required item attempts; an actually attempted LLM derivation that failed is not itself an incomplete handoff once its per-item deterministic fallback and failure evidence are recorded. It must not fabricate **verified** Precision, Recall or F1. With a valid Phase 07 closure, **compute one numerical full-ledger Precision/Recall/F1** from required best-effort canonical cells even when some proof uncertainties remain; use `METRICS_DETERMINISTIC_BEST_EFFORT` and disclose those units. No statistical sample estimate, confidence-weighted score, multiple competing scores or hidden omission is permitted. If an original/hash/queue-equality gate fails, or any required item lacks even an actual recorded LLM attempt, report `INCOMPLETE` without a finished score. Attempted failures with duly recorded BEST_EFFORT cells do not block the single best-effort score.

## 9. Completion statuses and reporting boundaries

- `PHASE_COMPLETED_VERIFIED`: the phase's input, population, integrity and mandated evidence checks are complete; this does not assert independent semantic certification.
- `PHASE_COMPLETED_BEST_EFFORT`: complete per-item processing, with specified unresolved semantic judgments and evidence limits.
- `INCOMPLETE`: required phase records or original file are invalid/missing, the exhaustive queue omits an unverified R/N/GC, a queued item has neither an individually valid result nor a recorded actual attempt, an intent/journal is corrupt, or another essential integrity step fails. An item-level LLM refusal/failure with a traceable real attempt and deterministic BEST_EFFORT decision is **not** by itself `INCOMPLETE`.
- `BLOCKED_REFERENCE` / `INVALID_REFERENCE_CHANGED`: original source or required frozen benchmark identity/checksum failure; cannot advance or silently replace it.
- `FINAL_VERIFIED`: all eight phases complete, exact canonical unit accounting, full evidence, independent recomputation, no unresolved scored units or material known evidence defect.
- `FINAL_BEST_EFFORT`: required inputs and all exhaustive per-item attempt checks valid; **every R/N/GC and residual is deterministically classified**, all canonical identities reconcile, but some individual model derivations failed, were inconclusive or did not independently prove the predicate. One arithmetic Precision/Recall/F1 set is reported with `METRICS_DETERMINISTIC_BEST_EFFORT` and detailed uncertainty, **not null and not mislabeled verified**.

The final report must state that measures evaluate generated design specifications against the fictional PDF baseline, not implementation correctness, operational performance or generalized model accuracy. The K individually attempted unresolved items support `METRICS_VERIFIED` **only when** every scored item and F residual is independently verified. Merely submitting each item to an LLM is not verified proof. Unselected uncertain R/N/GC IDs prevent full-population metrics but do not invalidate completed queue-only item judgments. Otherwise, after valid Phase 07 §3.6 deterministic closure, the **one** reported arithmetic score has `METRICS_DETERMINISTIC_BEST_EFFORT` status and explicit item-level low-confidence limitations. Preserve frozen R/N, original evidence, separate model/evidence confidence, canonical TP/FN/FP/TN accounting and semantic duplicates. Never report statistical estimates of these metrics.
