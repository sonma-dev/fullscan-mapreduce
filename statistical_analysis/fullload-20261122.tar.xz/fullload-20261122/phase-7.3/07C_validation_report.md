# Phase 07-C — Integrated Assistant Adjudication Report

Protocol version: 10.6  
Method: `fullload`  
Status: **PHASE_COMPLETED**

## Purpose

Merge two independent Phase 07 adjudication shards without changing the frozen R/N reference, the Phase 05 raw GC ledger, the external model JSON or either original shard decision. This is an append-only Phase 07 integration, **not** the Phase 08 unique-residual/N-overlap consolidation and not Phase 09 metric calculation.

## Frozen external result

- Model actually recorded: `gpt-6.2-sol`
- Reasoning effort actually recorded: `high`
- Batch size actually recorded: `16`
- Complete item results: 2,438 / 2,438
- The protocol text's `medium` default must not overwrite this observed execution metadata.

## Complete Phase 07 item-level decisions

| Item kind | Outcome | Count |
|---|---|---:|
| R | TP | 466 |
| R | FN | 172 |
| N | FP | 0 |
| N | TN | 142 |
| G | PDF supported (diagnostic TP) | 1473 |
| G | PDF unsupported (diagnostic FP candidate) | 63 |
| G | Excluded nondefinitive (no scoring cell) | 122 |

- Total items: 2,438, no duplicate IDs and no omitted IDs.
- Eligible unresolved: 0.
- Frozen R and N counting checks: TP + FN = 638; N-FP + TN = 142.
- Effective eligible generated classes: 1,536. These diagnostics do not add extra canonical TP units.
- Do **not** count the 63 G diagnostic-FP candidates as final FP without Phase 08 semantic residual consolidation and N/F overlap removal.

## Append-only integration corrections

1. 11 Phase07A definitive-fragment records lacked matching standalone eligibility supersession events, although the completed A item records already held that eligibility. Added explicit provenance-linked supersession completions without changing the original semantic decisions.
2. 150 annotations were normalized: 63 Phase07A and 59 Phase07B excluded G rows lacked an explicit `final_cell: null`, and 28 Phase07B unsupported G rows were labeled with the supported-G counting scope. The Phase07C derivative records the correct scope and explicit null while retaining old values and original record hashes. This is a **metadata correction**, not an automatic semantic cell reassignment.
3. Evidence check: 4164 generated quotations verified against exact original file lines; 5641 PDF quotations verified against physical-page text; 31 evidence entries were explicitly flagged as figure/table witnesses rather than falsely claimed as exact extracted-text matches. All page/line references retain the source SHA-256.
4. Cross-shard exact-proposition conflicting labels: 0. Keyword/character similarity was treated as a search lead only. 67 lexical near-neighbor pairs with different targets, actions, endpoints or qualifiers are documented for audit; they are not automatically merged or relabeled.

## Immutable-input checks

- Original R: 638; N: 142; Phase05 GC: 1,658. The Phase07 corrections remove 122 nondefinitive GC from the active eligible population without overwriting Phase05.
- The original Phase07A, Phase07B, external `semantic_decisions.jsonl` and all upstream files remain byte-unchanged.
- Integrity checks passed: 5140 / 5140.
- Fatal blockers: 0.

## Scope boundary

Phase 07 is closed at the item-level. Phase 08 must independently reconcile R/N/G, apply semantic consolidation to the 63 generated unsupported candidates, remove N/F overlaps and check any remaining inconsistency without silently replacing the Phase07 decision. Phase 09 alone computes Precision, Recall and F1 from a fully reconciled canonical ledger.
