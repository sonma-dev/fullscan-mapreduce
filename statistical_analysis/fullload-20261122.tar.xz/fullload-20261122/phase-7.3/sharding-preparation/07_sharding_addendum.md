# OrionDesk AI — Version 10.6 Phase 07 Three-Shard Execution Addendum

## Scope and authority

This operator-approved deviation modifies the execution organization of **Phase 07 only**. It does not change the locked PDF, reference R/N, effective GO/GC population, original v5 suggestion logic, semantic adjudication standards, canonical TP/TN/FP/FN counting units, Phase 08 N/F consolidation, or Phase 09 arithmetic metrics. Maintain the original nine numbered phases, using Phase 07-A, 07-B and 07-C as three sequential substeps. Do not mark Phase 07 complete before all three substeps pass.

## Frozen input and external-model disclosure

The original reference counts are R=638, N=142 and effective GC=1658 (K=2438). The external submission supplied by the operator contains all 2438 original items, in 153 committed journals, with 154 submission attempts: 153 successful and one failed rate-limited attempt that was retried. The *actual recorded external evaluation model* is **gpt-6.2-sol**, reasoning effort **high**, batch size **16**, threshold 0.90. The earlier Phase 06 planning artifact specified batch size **8**; do not rewrite it or claim it was executed with 8. Both 8 and 16 are allowed by v10.6, but reproducible cross-method comparison requires documenting actual settings and auditing other methods separately. The protocol's illustrative deployment string `gpt-6.1-sol` is superseded for this operator-specified run only. The use of gpt-6.2-sol for external suggestions must not be misrepresented as proof that an assistant in this conversation is executing on the same deployment.

The original v5 `SEMANTIC_RESULT` objects, raw model JSON, queue order, journal digests, source hashes, and suggestions are preserved. External status has 556 `UNRESOLVED` and 1882 `PROPOSED` items. `PROPOSED` is not a final Phase 07 finding. A total of 122 G suggestions read `EXCLUDED_NONDEFINITIVE`, although their items currently belong to the effective GC set. Review these eligibility disagreements as explicit potential Phase 05 consistency exceptions; do not delete, reclassify, or invent a canonical cell without actual evidence and an immutable superseding record.

## Phase 07-A — Independent adjudication partition A

Process all 1219 assigned items in `07A_work_items.jsonl`: 319 R, 71 N and 829 G. Among them 278 original v5 results are unresolved. Inspect the full original PDF and *all* eight original generated Markdown files for every item as needed, not only files with the item's own occurrence. Use §7.2–7.4 of governing v10.6. Produce `07A_assistant_adjudications.jsonl`, `07A_decision_audit.jsonl`, `07A_summary.json`, and `07A_input_blockers.jsonl`. No canonical score is computed. Complete the whole subshard before advancing.

## Phase 07-B — Independent adjudication partition B

Process the complementary 1219 IDs in `07B_work_items.jsonl`: 319 R, 71 N and 829 G. Among them 278 original v5 results are unresolved. Apply identical source authority, search, eligibility and decision standards; do not use Phase 07-A's final labels as substitute evidence. Produce `07B_assistant_adjudications.jsonl`, `07B_decision_audit.jsonl`, `07B_summary.json`, and `07B_input_blockers.jsonl`. No canonical score is computed. Complete the whole subshard before advancing.

## Phase 07-C — Integration and targeted supersession

Start only when both A and B are `PHASE_COMPLETED` and their source, queue and work-item digests match the partition manifest. Confirm every assigned ID has exactly one authentic evidence-grounded final record, A union B equals K=2438, and A intersect B is empty. Recheck conflicts in proof-family application, incompatible general/specific claims, R coverage versus G validity, N affirmative polarity, G eligibility challenges, cross-shard apparent duplicates, and unverifiable quotations. Reuse valid evidence without blind labels. When a real conflict requires an individual substantive reversal, issue a new `ASSISTANT_ADJUDICATION_SUPERSESSION` record referencing the previous decision and exact source evidence. Never silently replace or erase an A/B judgment. Phase 07-C itself may adjudicate necessary explicit supersessions because it is still part of Phase 07; Phase 08 may not.

Produce governing `07_assistant_adjudications.jsonl`, `07_decision_audit.jsonl`, `07_adjudication_summary.json`, `07_input_blockers.jsonl` and `07C_reconciliation_provenance.jsonl`. Verify every eligible ID is assigned a final R:TP/FN, N:FP/TN or diagnostic G:TP/FP without semantic null. Verify `TP_R+FN_R=638` and `FP_N+TN_N=142`. Do not remove G:TP from its diagnostic role or count G:FP before Phase 08's unique residual/N-overlap deduplication. Phase 07 is **not completed** if any original is absent, wrong-hash, or an explicit unresolved conflict remains. A source-integrity blocker is recorded as `INCOMPLETE`; a model abstention is not a fifth label.

## Metric model and cross-method comparability

The actual Azure external-evaluator model for this run is recorded as `gpt-6.2-sol`. Claims about `onelevel` or `twolevel` using that deployment require inspection of their own run states and source digests. The final **numeric** Precision, Recall, F1, GC validity and duplicate rates are computed independently and deterministically in **Phase 09** from the finalized Phase 08 canonical ledger—not generated or guessed by an LLM. Identical use of gpt-6.2-sol alone does not guarantee cross-method comparability: the frozen R/N PDF digests, eligibility, evidence rules, source scopes, deduplication policy, reasoning effort, and actual evaluation settings must also agree. If the operator explicitly uses gpt-6.2-sol for subsequent *semantic* adjudication, log the execution identity and method uniformly; do not attribute another model's output to it.

## Hard constraints

- Keep all inputs, earlier phase outputs, external suggestions, and journals byte-identical.
- Never infer a metric from 2438 external suggestions or count each G class as canonical TP/FP.
- Preserve the six fixed Phase 07 rule IDs: `P7-R-TP`, `P7-R-FN`, `P7-N-FP`, `P7-N-TN`, `P7-G-SUPPORTED`, `P7-G-UNSUPPORTED`.
- One subshard per subsequent conversation/answer; finish its entire assigned workload or report a concrete true input blocker without fabricating decisions.
- Phase 08 follows **only after** Phase 07-C completion; Phase 09 follows Phase 08.
