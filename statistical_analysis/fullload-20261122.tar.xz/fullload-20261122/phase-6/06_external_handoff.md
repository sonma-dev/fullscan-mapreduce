# Phase 06 External v5 Evaluator Handoff (Protocol 10.6)

## Status

- Phase 06 candidate discovery, negative-control evidence inventory, residual-candidate inspection, filename-alias regression suite, full queue construction, and independent integrity validation: COMPLETED.
- External Azure Responses submission: NOT STARTED (zero requests, zero Azure token consumption in this phase).
- No `semantic_decisions.jsonl`, Azure batch journals, or original model JSON has been fabricated.
- The Phase 07 assistant adjudicator must run only after the required external handoff, or record the explicit failure/absence of individual external responses as specified by the protocol.
- The supplied evaluator was located as `semantic_decision_evaluator(3).py` in the user's Library. The supplied original is retained byte-identically. A separate `semantic_decision_evaluator_v10.6_unlimited.py` applies operational-only changes.

## Immutable Queue

- `06_llm_queue_v10.6.jsonl`: 2,438 `UNRELIABLE_ITEM` rows, all with `unreliable=true`.
- R: 638; N: 142; G: 1,658. No prior authoritative final semantic judgments were available.
- `K = C = 2438`, with zero omissions due to numeric limits.
- Queue SHA-256: `558e9b1c2deb056697edf3327aa1236370165e65b41979a640aef9be094858b9`.
- Fixed batch size: 8; primary batches: 305; final batch: 6; concurrency: 4; retries: 3 *additional* attempts per batch. Maximum submissions if every batch exhausts all attempts: 1,220.
- Model deployment: `gpt-6.1-sol`; reasoning effort: `medium`; item-level confidence threshold: 0.90.
- All nine original source files (PDF plus eight Markdown files) are attached for every actual request when the evaluator is run. The explicit cache breakpoint is placed only on the ninth file input block; observed cache usage cannot be assumed.

## Validated Dry Run

The actual command was exercised with no Azure requests:

```bash
python semantic_decision_evaluator_v10.6_unlimited.py \
  --pdf "/mnt/data/OrionDesk_AI_Detailed_Design_Specification(1).pdf" \
  --spec-dir "/mnt/data" \
  --source-lock "/mnt/data/oriondesk_fullload_v10_6/phase01/01_reference_lock.json" \
  --queue "/mnt/data/oriondesk_fullload_v10_6/phase06/06_llm_queue_v10.6.jsonl" \
  --batch-size 8 --concurrency 4 --batch-retries 3 --dry-run
```

The dry run loaded 2,438 items, constructed 305 primary batches, recognized the original 90-page PDF and all eight Markdown roles, validated the Phase 01 lock, and issued zero paid requests. See `06_dry_run.log`.

## Live Azure Execution — Not Performed

Only in an explicitly configured and authorized Azure runtime, set `AZURE_OPENAI_ENDPOINT` and `AZURE_OPENAI_API_KEY`; use the approved deployment `gpt-6.1-sol`. Remove `--dry-run` and add an output directory:

```bash
python semantic_decision_evaluator_v10.6_unlimited.py \
  --pdf "/mnt/data/OrionDesk_AI_Detailed_Design_Specification(1).pdf" \
  --spec-dir "/mnt/data" \
  --source-lock "/mnt/data/oriondesk_fullload_v10_6/phase01/01_reference_lock.json" \
  --queue "/mnt/data/oriondesk_fullload_v10_6/phase06/06_llm_queue_v10.6.jsonl" \
  --out-dir "/mnt/data/oriondesk_fullload_v10_6/phase06/azure_semantic_output" \
  --batch-size 8 --concurrency 4 --batch-retries 3 \
  --confidence-threshold 0.90
```

Adjust all paths to the actual original source files and frozen ledgers when running on another computer. Before any paid request, verify deployment support for `prompt_cache_breakpoint={"mode":"explicit"}` on the ninth `input_file` block. The dry run cannot prove that the deployed Azure endpoint supports the request structure or that a specific cache hit rate will occur. Review token costs and provisioning policy before launching the 305-batch handoff.

Do not use `--limit` or change the source files or queue after freezing. Never run or resume from a different source-hash/prompt/schema/alias fingerprint. Ambiguous possibly billed submission outcomes require manual examination and explicit `--resume --retry-ambiguous` authorization, never unattended retry.

## Outcome Boundary

- The 142 negative controls were each checked against the complete effective 1,658-GC search inventory, yielding 235,436 candidate comparisons. PDF quotations for the negative controls (286 cited occurrences) were checked against their original physical pages.
- The resulting ranked candidate evidence is *not* proof of forbidden affirmative assertion or proof of absence. Therefore provisional `TN` input labels are not final TN decisions.
- The 1,658 effective classes remain unadjudicated for whole-predicate PDF support. Therefore provisional `FP` input labels are not final FP decisions, and no generated-only residual count is committed.
- Existing 251 semantic-pair reviews were carried forward. Classes were not merged merely because of lexical similarity. Final unsupported residual consolidation and exclusion of overlap with frozen negative controls occur after evidence-grounded class adjudication, as specified by Phase 08.
- The 638 positive source requirements remain pending final TP/FN adjudication; their provisional input label `FN` is not a metric authority.
- `semantic_decisions.jsonl` and certified metrics do not exist at this stage.
