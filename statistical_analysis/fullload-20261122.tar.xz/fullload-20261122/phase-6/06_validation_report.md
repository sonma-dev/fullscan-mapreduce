# Phase 06 Validation Report

**Protocol version:** 10.6  
**Generation method:** fullload  
**Phase:** 06 — Negative controls, residual candidate deduplication, and exhaustive v5 evaluator queue

## Completion summary

The Phase 06 preparation and validation gate is complete. The external Azure adjudication run remains a separate pending operational handoff.

| Check | Result |
|---|---:|
| Frozen PDF-positive R items | 638 |
| Frozen PDF-negative N controls | 142 |
| Eligible generated occurrences GO | 1,760 |
| Effective generated semantic classes GC | 1,658 |
| Full N x GC candidate comparisons | 235,436 |
| Prior semantic-pair reviews carried forward | 251 |
| Pending eligible decisions C | 2,438 |
| Queued items K | 2,438 |
| Omitted for numerical cap | 0 |
| Fixed batch size | 8 |
| Primary batch count | 305 |
| Last batch size | 6 |
| Extra retries per batch | 3 |
| Alias/evaluator regression checks | 62/62 passed |
| Independent phase integrity checks | 31/31 passed |
| Negative-control PDF citations reverified | 286/286 |
| Azure calls actually submitted | 0 |

## Judgment boundaries

- R, N, GO and GC identities were verified against frozen input files and Phase 01/05 references.
- The entire eligible R/N/GC population was selected for external semantic adjudication. None of the previous Phase 01–05 retrieval-only results supplies a verified final binary semantic cell.
- Every negative control received original PDF evidence and ranked generated-corpus witnesses. Similarity retrieval does not determine whether a counterfactual is actually affirmed; opposite-polarity statements are not false positives.
- Every effective generated class was indexed as a provisional source-support/residual candidate. An unsupported generated-only false-positive count cannot be legitimately committed before evidence-grounded PDF support adjudication.
- Previously accepted GO-to-GC consolidation remains intact. The 251 previously disputed semantic class pairs remain documented rather than being automatically merged.
- No Phase 07 independent semantic decisions or Phase 08/09 canonical confusion matrix calculations were performed.

## Source integrity

The original 90-page PDF, eight Markdown specifications, common positive/negative references and existing Phase 01–05 files were read without modification. The evaluator source was also retained unchanged and a separately named operational derivative was created. Strict filename-to-role attribution, SHA-256 digest matching, original line boundaries and exact original quotation checks passed a 62-case regression suite. A separate 31-check gate validated the Phase 06 produced files.

## External handoff

The Azure Responses API was not invoked in this environment; there are no model results, cached-token usage reports, token charge estimates or batch journals to claim. The run is ready for an authorized Azure environment after verifying credentials and deployment support. See `06_external_handoff.md` for the validated offline command and optional external invocation command.

**Phase 06 preparation status:** COMPLETED  
**External Azure handoff status:** PENDING / NOT SUBMITTED  
**Phase 07:** NOT STARTED
