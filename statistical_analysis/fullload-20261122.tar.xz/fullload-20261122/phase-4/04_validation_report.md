# Phase 04 — Reciprocal TP/FN Evidence Audit

Protocol: 10.6  
Method: fullload  
Status: PHASE_COMPLETED (evidence-audit scope; not final binary adjudication)

## Source integrity

- Frozen positives: 638; frozen negatives (untouched): 142.
- Frozen original Markdown inputs: eight SHA-256-verified files.
- Generated definitive occurrences (GO): 1646; classes (GC): 1549.
- R-to-original-file reciprocal searches: 5104.
- Source PDF quotations verified as text: 1856; pre-inspected visual locators confirmed: 18.
- Phase 01–03 input artifacts were read, verified and not changed.

## Rechallenge results

Initial Phase 03 discovery categories: {'OPEN_UNCERTAINTY_NO_STRONG_GO': 214, 'CONTEXTUAL_OR_PARTIAL_CANDIDATE': 268, 'STRONG_DEFINITIVE_TEXTUAL_CANDIDATE': 156}.

Independent reciprocal textual evidence tiers: {'RECIPROCAL_SEARCH_INCONCLUSIVE_OR_LOW_RELEVANCE': 386, 'RELEVANT_DEFINITIVE_GO_PARTIAL_PROOF_ONLY': 216, 'ALL_FROZEN_PREDICATE_PHRASES_FOUND_BUT_JOINT_SCOPE_REVIEW_REQUIRED': 31, 'COMPLETE_VERBATIM_SOURCE_STATEMENT_FOUND_BUT_SCOPE_REVIEW_REQUIRED': 5}.

Of 214 initial weak candidates, 3 produced additional nontrivial definitive GO textual evidence on the reciprocal search. These are *not* automatically true positives. All of the remaining weakly ranked cases are *not* automatically false negatives.

## Gate and limitations

- Each of the 638 sources has a detailed `04_coverage_audit.jsonl` row, a candidate-TP challenge row and a candidate-FN root-cause challenge row.
- All quoted generated passages are linked to the actual original filename, exact original line range and frozen source digest.
- Numeric constraints, URL/path tokens and negative directive guards are checked as explicit review flags, not silently equated.
- Definite GO evidence is distinguished from raw source-text discovery units. Excluded substantive rows are explicitly carried forward to Phase 05.
- Verified textual proximity does not establish actor, scope, condition, quantifier or entire predicate entailment. `final_cell=null` across Phase 04 by design; no retrieval failure is asserted as FN.
- Eight targeted reciprocal case notes illustrate cross-file conjunction, universal rules and missing-predicate hazards.
- Phase 05 generated-claim validity and excluded-unit reassessment has **not** been executed. Phase 07 performs independent binary semantic closure.

## Outputs

- `04_coverage_audit.jsonl`
- `04_tp_evidence_audit.jsonl`
- `04_fn_root_cause_audit.jsonl`
- `04_targeted_source_review.jsonl`
- `04_reciprocal_audit_summary.json`

No metrics are computed in Phase 04.

## Independent bridge and locator quality gate

- Audited the full inherited Phase 03 set of 67 cross-file/intra-file and universal-rule bridge candidates. None was silently promoted to accepted E2 evidence.
- Independently reverified 7,656 candidate original Markdown quotations against locked source digests and line ranges.
- Confirmed all 638 R IDs occur exactly once in each of the three required Phase 04 ledgers; no source R is dropped or classified FN merely due to retrieval failure.
- Quality gate: **PASS**.
