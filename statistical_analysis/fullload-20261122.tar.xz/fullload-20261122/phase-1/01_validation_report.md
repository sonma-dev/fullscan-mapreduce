# Phase 01 — Reference Lock Validation Report

**Status:** PHASE_COMPLETED  
**Protocol:** 10.6  
**Generation method:** fullload  
**Frozen benchmark origin:** 3.0 (REFERENCE_FROZEN_PROVISIONAL)

## Input and reference integrity

- Authoritative PDF: 90 physical pages; SHA-256 matches the frozen reference.
- Original generated Markdown source roles: eight, each uniquely mapped to an actual uploaded original; hashes and line counts are frozen in the manifest.
- Frozen positive requirements R: **638**; frozen negative controls N: **142**; combined fixed reference items: **780**.
- Both frozen JSONL SHA-256 values match `reference_freeze.json` exactly.
- Every record has an active scoring status, matching PDF digest, correct polarity, distinct stable ID, nonempty assertion and evidence on in-range physical pages.
- **2142** text-evidence quotations match normalized literal text on their cited PDF pages.
- **18** graphical evidence locators refer to the five independently inspected rendered PDF pages: 57, 61, 64, 68, 78.
- All 29 frozen PDF page partitions cover physical pages 1–90 exactly once.

## Nonfatal reference caveats

- The reference remains `REFERENCE_FROZEN_PROVISIONAL`; successful integrity checks are not proof of independent semantic completeness or ideal atomization.
- 56 active reference rows retain existing review flags without modification.
- 4 previously disclosed reference-freeze limitations remain open, including bounded semantic duplicate checking and nonindependent shard judgment context.
- All caveats are recorded as `REFERENCE_EXCEPTION` records in `01_reference_exceptions.jsonl`; no reference rows have been relabeled or edited.

## Phase boundary

Phase 01 validates and locks only input identity and frozen-reference integrity. It makes **no** R-to-generated coverage inferences, generated GO/GC extraction, TP/FN/FP/TN judgments, duplicate conclusions or metric calculations. Phase 02 has not been executed.
