# Phase 08 — Independent Semantic Reconciliation

**Protocol version:** 10.6  
**Method:** fullload  
**Status:** PHASE_COMPLETED

## Immutable inputs and safeguards

The original 90-page PDF, frozen reference R/N, eight generated Markdown originals, Phase 05 effective GO/GC, Phase 07A/B/C adjudication records, 2,438-item external evaluation aggregate and 153 original batch journals were hash-verified. No Phase 07 item-level semantic decision, source file, external model result or journal was edited.

The observed Azure experiment is **gpt-6.2-sol, reasoning effort high, batch size 16**, 153 completed batches, 154 attempts and 2,438 completed item suggestions. This differs from the Phase 06 preparation default of batch size 8; actual execution metadata is preserved and comparability requires matching actual configurations in all methods.

## Canonical population

| Population | Count |
|---|---:|
| Frozen PDF-positive source requirements (R) | 638 |
| Source TP | 466 |
| Source FN | 172 |
| Frozen affirmative negative controls (N) | 142 |
| Negative control FP | 0 |
| Negative control TN | 142 |
| Phase 05 original effective GO | 1,760 |
| Phase 05 original effective GC | 1,658 |
| Phase 07 final nondefinitive GC exclusions | 122 |
| Active eligible GC | 1,536 |
| Diagnostic PDF-supported GC | 1,473 |
| Diagnostic PDF-unsupported GC | 63 |
| Unique unsupported generated-only residuals (F) | **60** |
| Overlap with affirmed negative controls | 0 |
| Canonical FP = N_FP + F | **60** |
| Canonical universe R + N + F | **840** |

After removing the 122 nondefinitive GC classes (one GO each), the eligible duplication universe is **GO=1,638 / GC=1,536**, containing **102 excess occurrences**, 84 repeated classes, 3 within-file excess and 99 across-file excess. The original pre-correction GO=1,760/GC=1,658 numbers remain provenance counts, not the eligible duplicate-rate denominator. Expected reuse versus redundant repetition is **not** inferred merely from a repeat.

The Phase 08 final ledger includes 638 FINAL_SOURCE, 142 FINAL_CONTROL, 1,536 FINAL_CLASS and 60 FINAL_RESIDUAL rows. The 122 nondefinitive classes are maintained in a separate eligibility audit and never assigned a fabricated TN or FP. Supported generated classes add **zero** source TP.

## Distinct residual consolidation

Two complete unsupported-residual equivalence families were accepted:

1. **M08-001**: GCLASS-0000649 and GCLASS-0000797 share the identical additional persistence requirement to record unsupported connector capabilities as lower trust.
2. **M08-002**: GCLASS-0000936, GCLASS-0001194 and GCLASS-0001298 share the same unsupported upstream model-provider Retry-After mandate.

The 63 unsupported GC candidates therefore produce **60** distinct FP residuals after three excess occurrences are consolidated. No affirmative forbidden negative control exists in the final Phase 07 N decisions, so no N/F overlap is counted or omitted. A complete 142 × 63 = 8,946 N/unsupported-GC candidate index is retained separately, distinct from item-level semantic authority.

Close-looking but non-equivalent scopes (for example, a public-response prohibition versus a telemetry prohibition, or two nonidentical lists of mandatory empty-data tests) remain separate. The all-pairs index covers 1,953 candidate pairs; 13 meaningful non-merge challenges carry individual rationale. A shared word or partial predicate is not a sufficient merge.

## Completion and metric boundary

All source/control/class IDs have one active and consistent Phase 07-derived status. TP + FN = R, N_FP + TN = N, FP = N_FP + F, and the canonical-universe equation all pass. No Phase 07 superseding item decision is required by this reconciliation.

**Phase 09 was not executed.** No Precision, Recall, F1 or comparative score is reported here. The frozen reference is still marked provisional in its creation manifest; its original benchmark atomization limitations were not overwritten.
