# Phase 07-A — Final Independent Adjudication

Protocol version: 10.6
Method: fullload
Status: PHASE_COMPLETED (Shard A only)

Assigned: 1219 (R=319, N=71, G=829).
R: TP=236; FN=83.
N: FP=0; TN=71.
G: PDF-supported diagnostic TP=731; PDF-unsupported diagnostic FP=35; excluded nondefinitive=0.
Original v5 UNRESOLVED reviewed: 278. Remaining eligible semantic unresolved: 0.
Eligibility correction records: 114; original Phase 05 bytes unchanged.

## Decision policy
PDF controls original normative meaning. Generated content counts only when it is a definite affirmative implementation or test obligation. R scope is complete only after direct or applicability-checked conjunctive proof. N counts as FP only on an affirmative forbidden assertion. G diagnostic TP does not increase canonical R-TP. G diagnostic FP requires later N/F semantic consolidation.

## Provenance and model invariance
External source used gpt-6.2-sol, reasoning high, batch size 16, 153 committed batches and 2,438 completed items. The external v5 proposals remain unchanged; assistant final decisions are separate. The original PDF, eight source Markdown files, reference R/N and all earlier phase artifacts were not modified.

## Eligibility repair
A total of 63 class entries were found to be nondefinitive document metadata, proposals, examples, or unresolved questions. They are excluded by a separate immutable applicability supersession, not automatically converted into FP, TN or a permanent UNRESOLVED. For mixed claims, only source-backed definite fragments are retained, while unadopted qualifiers are excluded. G corrections retain each original class and GO provenance.

## Evidence limitations
Exact source quotation verification establishes provenance, not semantic entailment by itself. Original model suggestions were challenged against source predicates, cross-file obligations, original Markdown lines and reciprocal line witnesses. A few source figure/table examples use the original page rendering for interpretation. Later integration may discover a conflict; such conflicts must return to a new immutable Phase 07 superseding decision, not be silently relabeled in Phase 08.

## Phase boundary
This output concludes Shard A only. No Shard B, Shard C, Phase 08 or Phase 09 work was performed; no full-run FP deduplication or Precision/Recall/F1 was calculated.
