# Phase 07-A Adjudication and Evidence Review

Status: `INCOMPLETE_DO_NOT_SCORE`  
Protocol: 10.6  
Method: `fullload`  
External execution identity: `gpt-6.2-sol`, effort `high`, 16 items per batch.

## Scope

All 1,219 assigned items were inspected by the evidence reconciliation pipeline (R 319, N 71, G 829). The immutable external records, 90-page PDF and eight generated Markdown source digests were verified against the Phase 01 lock and run metadata. The Phase 06 external journal completeness audit verified all 153 committed batches. The running model and effort are historical external execution metadata; this workspace assistant's local rule audit should not be misrepresented as a second Azure run.

## Provisional evidence dispositions

| Category | Records |
|---|---:|
| R: TP candidate | 217 |
| R: FN candidate | 102 |
| N: TN candidate | 71 |
| G: PDF-supported diagnostic candidate | 715 |
| G: Unsupported/residual diagnostic candidate | 51 |
| G: Nondefinitive effective-inventory conflict, no fabricated binary cell | 63 |

The above are **provisional evidence dispositions**, not verified Phase 07 final cells. The raw v5 evaluator's `FULL`, `PARTIAL`, and `CONTRADICTED` relations were used as hypotheses and supplemented with independent file identity, quotation, and reciprocal-locator checks. Source quotation existence alone is insufficient for semantic entailment.

## Required resolution

- The source eligibility conflict affects 63 pure nondefinitive GC entries. Another 51 entries contain definite and nondefinite fragments requiring separability review. Automatically assigning those to FP would inflate false positives without an eligible affirmative obligation.
- All eventual R/N/G labels require independent, whole-proposition semantic inspection of scoped original evidence, not merely acceptance of a previous model's verdict. Review strong apparent matches against contrary/exception clauses and inspect strongest reciprocal candidates for putative absences.
- Phase 07-C may only reconcile genuinely final A/B decisions; it must not silently upgrade these provisional records. If a previously effective GC is found ineligible, preserve Phase 05 output and record a traceable corrective supersession, applying the same policy to each compared generation method.
- Original references, original run outputs, original batch journals, and earlier phase artifacts remain unchanged.

No final Precision, Recall, F1, negative-control rate, duplicate rate or GC validity rate is authorized from this file.
