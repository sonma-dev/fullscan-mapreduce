# Phase 07-B — Independent Adjudication

Protocol version: 10.6
Generation method: fullload
Status: PHASE_COMPLETED

## Scope and source identity
Frozen PDF: 90 physical pages, SHA-256 b71541e74564559d2cc0a84e9827086946998fbc6c627488fb9e7a7f9b0137c3.
Eight original generated Markdown files: all SHA-256 verified against Phase01 source lock and original external run state.
Assigned items: 1219 (R=319, N=71, G=829); original external UNRESOLVED=278.

## Direction-specific verdicts
R: TP=230, FN=89; N: FP=0, TN=71.
G: supported diagnostic TP=742, unsupported diagnostic FP=28, eligibility-excluded=59.
Generated-class supported TPs do not add canonical R TPs; G unsupported labels are not unique F counts. Phase08 must consolidate N/F and duplicate residuals.

## Evidence procedure
Each item retains authentic frozen PDF evidence or original generated-line evidence with SHA-checked role and location. Reciprocal source searches and explicit cross-file bridges are recorded separately. Mere quotation existence and lexical similarity are not claimed as semantic entailment. Original external v5 relations were challenged, and item-level reasons identify confirmed complete scope, missing predicates, or unsupported additional scope.

## Eligibility corrections
102 immutable eligibility correction records were created. Excluded items are not counted as FP, TN, or new effective source controls; mixed original claims retain their definite implementation fragments only.

## External evaluator identity
The provided external evaluation employed gpt-6.2-sol, high reasoning effort and 16 items per request (153 completed batches). Original v5 JSON and journals remain unchanged. This Phase07 assistant review is distinct from the Azure deployment.

## Phase boundary
Shard A was not used for substantive Phase07-B decisions. Shard C and Phase08/09 are not executed. No Precision, Recall, F1 or fully deduplicated FP count is calculated.

## Input blockers
0 recorded. No mandatory original evidence blockers remain.
