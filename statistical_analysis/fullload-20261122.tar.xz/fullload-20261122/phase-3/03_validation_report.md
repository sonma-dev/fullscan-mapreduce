# Phase 03 - R Coverage Discovery

Protocol version: **10.6**  
Method: **`fullload`**  
Status: **PHASE_COMPLETED**

## Original-source and inventory integrity

- Frozen source positive R: **638** requirements.
- Frozen negative N: **142** controls (not adjudicated in this phase).
- Immutable Phase 02 GO/GC: **1646 / 1549**.
- All eight original Markdown files searched separately for each R: **5104** R-file searches.
- Indexed original substantive text units: **2740**; indexed eligible GO statements: **1646**.
- Validated original PDF textual source quotes: **1856**.
- Additional source PDF visual-evidence locators: **18** from locked Phase 01 visual inspection.
- Original Markdown quote occurrences verified in all discovery/bridge output structures: **21987**.
- Verified Phase 01 identity/source checksums and all Phase 02 artifact checksums; no input bytes modified.

## Evidence discovery

- Strong definitive textual candidates: **156**.
- Contextual or partial textual candidates: **268**.
- No strong eligible GO retrieved: **214**.
- Multi-predicate combination candidates: **58**.
- Universal-rule transfer candidates: **9**.

These categories are **retrieval diagnostics, not TP/FN**. A high score is not a full entailment judgment and a weak or missing candidate is not an established FN. The Phase 03 ledger explicitly retains uncertainty for every R, including independently recheckable original PDF quotations, generated exact-line excerpts, eligible GO/GC IDs and eight-file search traces. Candidate bridges remain unaccepted until source-scope, actor, condition, negation, timing and full-predicate verification.

## Artifacts

- `03_source_coverage.jsonl`: one evidence-backed discovery record for every frozen R, including eight-role summaries and selected original generated citations.
- `03_semantic_coverage_bridges.jsonl`: auditable cross-file/intra-file predicate combination and universal-rule transfer candidates with explicit non-acceptance.
- `03_eight_file_search_trace.jsonl`: one per-original-role search trace per R.
- `03_discovery_audit.json`: source hashes, mechanical checks and item counts.

## Phase boundary

No source-positive coverage verdict, TP, FN, canonical negative-control verdict, external semantic request or numeric metric has been assigned. Phase 04 must challenge proposed misses and all provisional positive candidate evidence. Phase 05 later reassesses excluded generated passages and duplicates. No subsequent phase has been executed.
