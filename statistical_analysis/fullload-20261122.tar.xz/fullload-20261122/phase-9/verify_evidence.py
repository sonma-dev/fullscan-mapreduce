#!/usr/bin/env python3
"""Verify original citation positions without making semantic entailment decisions."""
from pathlib import Path
import json, re, unicodedata, hashlib
import fitz

ROOT=Path('/mnt/data')
BASE=ROOT/'oriondesk_fullload_v10_6'
OUTPUT=BASE/'phase09/09_evidence_integrity.json'
roles={
 '01_screen_functions':'01_screen_functions(1).md','02_api':'02_api(1).md',
 '03_data':'03_data(1).md','04_batch_functions':'04_batch_functions(1).md',
 '05_business_rules':'05_business_rules(1).md','06_exception_handling':'06_exception_handling(3).md',
 '07_processing_flows':'07_processing_flows(2).md','08_architecture_decision':'08_architecture_decision(2).md'}
lines={role:(ROOT/name).read_text(encoding='utf-8').splitlines() for role,name in roles.items()}
with fitz.open(ROOT/'OrionDesk_AI_Detailed_Design_Specification(1).pdf') as pdf:
    pages=[page.get_text(sort=False)+'\n'+page.get_text(sort=True) for page in pdf]
def norm(s):return ' '.join(unicodedata.normalize('NFKC',str(s)).split()).casefold()
md_success=pdf_text_success=pdf_figure_supported=0
figures=[]
for ln in (BASE/'phase08/08_final_ledger.jsonl').open(encoding='utf-8'):
    row=json.loads(ln)
    ident=row.get('source_id') or row.get('control_id') or row.get('gc_id') or row.get('residual_id')
    for e in row.get('generated_evidence',[]):
        fn=e.get('canonical_file',e.get('file',''))
        role=re.sub(r'\([1-9][0-9]*\)$','',fn.removesuffix('.md'))
        if role not in lines:
            raise ValueError(f'Unknown generated citation role: {ident} {fn}')
        a,b=e.get('line_start'),e.get('line_end')
        if not (isinstance(a,int) and isinstance(b,int) and 1<=a<=b<=len(lines[role])):
            raise ValueError(f'Invalid generated citation range {ident} {fn} {a}-{b}')
        if not (norm(e.get('quote_en','')) and norm(e['quote_en']) in norm('\n'.join(lines[role][a-1:b]))):
            raise ValueError(f'Mismatched generated citation: {ident} {fn} {a}-{b}')
        md_success+=1
    for e in row.get('pdf_evidence',[]):
        n=e.get('physical_page');q=e.get('quote_en','')
        if not (isinstance(n,int) and 1<=n<=90):
            raise ValueError(f'PDF citation page missing/bad: {ident}: {n}')
        if norm(q) and norm(q) in norm(pages[n-1]):
            pdf_text_success+=1
        elif e.get('verified_pdf_visual') is True or e.get('figure_or_table_inspected') is True:
            pdf_figure_supported+=1
            figures.append({'item_id':ident,'physical_page':n,'claimed_visual_or_table_witness':True,'quote_en':q})
        else:
            raise ValueError(f'Unverified PDF citation: {ident} page {n}')
result={'record_type':'PHASE09_EVIDENCE_LOCATOR_AUDIT','protocol_version':'10.6',
  'status':'PASS','markdown_original_quoted_ranges_verified':md_success,
  'pdf_original_text_quotes_verified':pdf_text_success,
  'pdf_visual_table_witnesses_inherited_from_phase07_08':pdf_figure_supported,
  'note_en':'Visual and table witnesses were explicitly marked as inspected in Phase 07/08. This program does not newly visually inspect or semantically adjudicate them; it verifies their original-page locators and recorded witness flags.',
  'pdf_visual_table_witnesses':figures,
  'inputs_sha256':{
   'phase08_final_ledger':hashlib.sha256((BASE/'phase08/08_final_ledger.jsonl').read_bytes()).hexdigest(),
   'pdf_original':hashlib.sha256((ROOT/'OrionDesk_AI_Detailed_Design_Specification(1).pdf').read_bytes()).hexdigest()}}
OUTPUT.write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
print('Evidence locator verification',result['status'],md_success,pdf_text_success,pdf_figure_supported)
