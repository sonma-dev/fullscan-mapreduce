#!/usr/bin/env python3
"""Recompute OrionDesk Phase 09 from immutable original Phase 01-08 sources.

This program does not adjudicate semantic items or contact any external service.
It fails closed on missing inputs, inconsistent population/IDs, source hash
mismatches, malformed journals, or incompatible scoring arithmetic.
"""
from __future__ import annotations
from collections import Counter, defaultdict
from fractions import Fraction
from pathlib import Path
import ast
import hashlib
import json
import re
import sys
import unicodedata
import zipfile

BASE = Path('/mnt/data/oriondesk_fullload_v10_6')
ROOT = Path('/mnt/data')
OUT = BASE / 'phase09'
OUT.mkdir(exist_ok=True)
ASSERTIONS = []

def require(condition, name, detail=''):
    if not condition:
        raise ValueError(f'{name}: {detail}')
    ASSERTIONS.append(name)

def sha(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()

def json_file(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))

def jsonl(path):
    p=Path(path)
    require(p.is_file(),'exists:'+p.name)
    with p.open(encoding='utf-8-sig') as f:
        return [json.loads(x) for x in f if x.strip()]

def jdump(v):
    return json.dumps(v,ensure_ascii=False,sort_keys=True,separators=(',',':'))

def digest_text(v): return hashlib.sha256(v.encode('utf-8')).hexdigest()

def indexed(rows, key):
    result={}
    for x in rows:
        name=x.get(key)
        require(isinstance(name,str) and bool(name),'id_present:'+key)
        require(name not in result,'id_unique:'+key,name)
        result[name]=x
    return result

def norm(s):
    return ' '.join(unicodedata.normalize('NFKC',str(s)).split()).casefold()

def verify_hash(file:Path,expected:str,label:str):
    require(file.exists(),'file_available:'+label,str(file))
    actual=sha(file)
    require(actual==expected,'sha256:'+label,f'{actual} != {expected}')
    return actual

def role_name(name):
    b=Path(name).name
    require(b==name,'basename_only',name)
    m=re.fullmatch(r'(0[1-8]_[a-z_]+)(?:\([1-9][0-9]*\))?\.md',b)
    require(m is not None,'generated_source_alias',name)
    s=m.group(1)
    if s=='02_api_': s='02_api'
    require(s in ROLE_FILES,'known_role',s)
    return s

# Authoritative baseline inputs and frozen identities.
freeze=json_file(ROOT/'reference_freeze(1).json')
lock=json_file(BASE/'phase01/01_reference_lock.json')
counts=json_file(BASE/'phase08/08_binary_counts.json')
manifest=json_file(BASE/'phase08/08_artifact_manifest.json')
summary=json_file(ROOT/'semantic_summary(4).json')
state=json_file(ROOT/'run_state(4).json')
require(freeze['record_type']=='REFERENCE_FREEZE','freeze_type')
require(counts['protocol_version']=='10.6' and counts['method']=='fullload','phase08_protocol_method')
require(manifest['status']=='PHASE_COMPLETED','phase08_complete')
ref=counts['frozen_reference_sha256']
PDF=ROOT/'OrionDesk_AI_Detailed_Design_Specification(1).pdf'
RFILE=ROOT/'common_atomic_reqs(1).jsonl'
NFILE=ROOT/'common_negative_controls(1).jsonl'
verify_hash(PDF,freeze['source_document']['sha256'],'original_pdf')
verify_hash(RFILE,freeze['output_artifacts_sha256']['common_atomic_reqs.jsonl'],'reference_R')
verify_hash(NFILE,freeze['output_artifacts_sha256']['common_negative_controls.jsonl'],'reference_N')
verify_hash(ROOT/'reference_freeze(1).json',ref['reference_freeze'],'reference_freeze')
require(freeze['source_document']['physical_pages']==90,'freeze_90_pages')
try:
    import fitz
    with fitz.open(PDF) as document:
        require(document.page_count==90,'actual_pdf_90_pages')
except ImportError:
    raise RuntimeError('PyMuPDF required for PDF page count verification')
for id_, key in [('pdf','pdf'),('R','R'),('N','N')]:
    require(ref[id_]==manifest['input_sha256'][key],'source_digest_matches_phase08:'+id_)

ROLE_FILES={
 '01_screen_functions':'01_screen_functions(1).md',
 '02_api':'02_api(1).md',
 '03_data':'03_data(1).md',
 '04_batch_functions':'04_batch_functions(1).md',
 '05_business_rules':'05_business_rules(1).md',
 '06_exception_handling':'06_exception_handling(3).md',
 '07_processing_flows':'07_processing_flows(2).md',
 '08_architecture_decision':'08_architecture_decision(2).md',
}
ROLE_HASH={}
for role, filename in ROLE_FILES.items():
    ROLE_HASH[role]=verify_hash(ROOT/filename,manifest['input_sha256'][role],'md_'+role)
    require(state['file_sha256'][role+'.md']==ROLE_HASH[role],'external_md_hash:'+role)
require(state['pdf_sha256']==sha(PDF),'external_pdf_sha')
require(state['protocol_version']=='10.6' and state['execution_version']=='10.6','external_version')
require(state['model']=='gpt-6.2-sol','external_model')
require(state['batch_size'] in (8,16),'valid_protocol_batch_size')
require(state['confidence_threshold']==0.90,'confidence_threshold_unchanged')
require(state['filename_alias_policy']=='unique-role-verified-sha256-v1','filename_alias_policy')

# Recreate source populations from the immutable JSONL, not previous numeric reports.
R=indexed(jsonl(RFILE),'requirement_id')
N=indexed(jsonl(NFILE),'control_id')
require(len(R)==638 and len(N)==142,'frozen_counts')
for key, item in list(R.items())+list(N.items()):
    require(item['source_pdf_sha256']==sha(PDF),'frozen_row_pdf_hash:'+key)

# Validate phase histories and all output hashes embedded in previous stage manifest.
for artifact in manifest['outputs']:
    verify_hash(BASE/'phase08'/artifact['file'],artifact['sha256'],'phase08_output_'+artifact['file'])
input_mapping={
 'phase01':'phase01/01_reference_lock.json',
 'gc':'phase05/05_effective_generated_classes.jsonl',
 'membership':'phase05/05_effective_membership.jsonl',
 'go_phase02':'phase02/02_generated_atoms_final.jsonl',
 'go_recovered':'phase05/05_recovered_generated_atoms.jsonl',
 'queue':'phase06/06_llm_queue_v10.6.jsonl',
 'phase07':'phase07C/07_assistant_adjudications.jsonl',
 'phase07A':'phase07A/07A_assistant_adjudications.jsonl',
 'phase07B':'phase07B/07B_assistant_adjudications.jsonl',
 'phase07summary':'phase07C/07_adjudication_summary.json',
 'external':'../semantic_decisions(5).jsonl',
 'state':'../run_state(4).json',
 'semantic_summary':'../semantic_summary(4).json',
}
for label, rel in input_mapping.items():
    path=(BASE/rel).resolve()
    verify_hash(path,manifest['input_sha256'][label],'phase08_input_'+label)

classes=indexed(jsonl(BASE/'phase05/05_effective_generated_classes.jsonl'),'gc_id')
member_rows=jsonl(BASE/'phase05/05_effective_membership.jsonl')
mem={}
for row in member_rows:
    go=row['go_id']; gc=row['gc_id']
    require(go not in mem,'no_duplicate_GO_membership',go)
    require(gc in classes,'GO_member_GC_known',gc)
    mem[go]=gc
GO2=indexed(jsonl(BASE/'phase02/02_generated_atoms_final.jsonl'),'go_id')
GOr=indexed(jsonl(BASE/'phase05/05_recovered_generated_atoms.jsonl'),'go_id')
require(not(set(GO2)&set(GOr)),'phase02_recovered_disjoint')
eligibility_phase05=indexed(jsonl(BASE/'phase05/05_original_go_eligibility_audit.jsonl'),'go_id')
require(set(eligibility_phase05)==set(GO2),'phase05_original_eligibility_complete')
require(sum(row['phase05_eligibility']=='EXCLUDED_NONDEFINITIVE' for row in eligibility_phase05.values())==32,'phase05_removed_initial_GO_32')
GO={**{go:row for go,row in GO2.items() if eligibility_phase05[go]['phase05_eligibility']=='RETAINED_DEFINITIVE'},**GOr}
require(set(mem)==set(GO),'every_GO_unique_GC')
require(len(GO)==1760 and len(classes)==1658,'original_effective_GO_GC')
for gcid,row in classes.items():
    require(set(row['go_ids'])=={go for go in row['go_ids'] if mem.get(go)==gcid},'class_membership_verified',gcid)
require(sum(len(c['go_ids']) for c in classes.values())==len(GO),'class_membership_cardinality')

exclude=indexed(jsonl(BASE/'phase08/08_excluded_nondefinitive_classes.jsonl'),'gc_id')
require(set(exclude)<=set(classes),'excluded_are_original_classes')
require(all(row['effective_eligibility']=='EXCLUDED_NONDEFINITIVE' and row['final_cell'] is None for row in exclude.values()),'explicit_exclusion_no_TN')
G_eligible=set(classes)-set(exclude)
GO_eligible={go for go,gc in mem.items() if gc in G_eligible}
GO_excluded=set(mem)-GO_eligible
require(len(exclude)==122 and len(G_eligible)==1536 and len(GO_eligible)==1638 and len(GO_excluded)==122,'eligibility_population')

# External submitted queue: every original R/N/G ID exactly once.
queue=jsonl(BASE/'phase06/06_llm_queue_v10.6.jsonl')
q_ids=[q['item_id'] for q in queue]
require(len(queue)==2438 and len(set(q_ids))==2438,'queue_distinct_complete')
require(set(q_ids)==set(R)|set(N)|set(classes),'queue_full_population')
require(all(q['record_type']=='UNRELIABLE_ITEM' and q['unreliable'] is True for q in queue),'queue_schema_active')
require(sha(BASE/'phase06/06_llm_queue_v10.6.jsonl')==state['queue_sha256'],'queue_sha')
require(state['item_count']==len(queue),'queue_K_equals_C')
require(summary['requested_items']==len(queue) and summary['completed_items']==len(queue) and summary['remaining_items']==0,'external_all_items_delivered')
require(summary['completed_batches']==summary['expected_batches']==(len(queue)+state['batch_size']-1)//state['batch_size'],'external_batch_count')
require(summary['failed_batches']==0,'external_no_failed_batch')
require(sum(summary['suggested_decision_counts'].values())==len(queue),'external_suggestions_cover_queue')

# Check that the evaluator's unchanged prompt/schema and regression test were used.
reg=json_file(BASE/'phase06/06_evaluator_regression_report.json')
script=BASE/'phase06/semantic_decision_evaluator_v10.6_unlimited.py'
require(reg['status']=='PASS' and reg['checks_passed']==reg['checks_total']==62,'v5_unchanged_regression_suite_pass')
verify_hash(script,reg['derived_sha256'],'evaluator_file_unchanged')
# Execute its pure module declarations in isolated namespace, avoiding network/API calls.
import importlib.util
spec=importlib.util.spec_from_file_location('oriondesk_semantic_evaluator',str(script))
module=importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
require(digest_text(module.SYSTEM_PROMPT)==state['prompt_sha256'],'v5_prompt_sha')
require(digest_text(jdump(module.RESULT_SCHEMA))==state['result_schema_sha256'],'v5_output_schema_sha')

# Independently verify all actual immutable batch journal contents and ordered IDs.
ZIP=ROOT/'batch_journals(4).zip'
require(ZIP.exists(),'external_journal_zip_present')
external=indexed(jsonl(ROOT/'semantic_decisions(5).jsonl'),'item_id')
require(set(external)==set(q_ids),'external_item_ids_exact')
proofs=indexed(jsonl(BASE/'phase08/08_external_batch_journals_verified.jsonl'),'batch_id')
require(len(proofs)==summary['completed_batches'],'phase08_journal_receipts')
actual_results={}
zip_journal_sha=[]
with zipfile.ZipFile(ZIP) as z:
    journal_names=[i.filename for i in z.infolist() if re.fullmatch(r'batch_journals/B10\.6-\d{5}\.json',i.filename)]
    require(len(journal_names)==summary['completed_batches'],'journal_inventory_count')
    for index in range(summary['completed_batches']):
        bn=f'B10.6-{index+1:05d}'
        filename=f'batch_journals/{bn}.json'
        require(filename in journal_names,'journal_exists_'+bn)
        j=json.loads(z.read(filename))
        seg=queue[index*state['batch_size']:(index+1)*state['batch_size']]
        require(j['batch_id']==bn and j['batch_index']==index and j['batch_size']==len(seg),'journal_batch_order_'+bn)
        require(j['queue_sha256']==state['queue_sha256'] and j['pdf_sha256']==sha(PDF),'journal_sources_'+bn)
        require(j['input_digest']==digest_text(jdump(seg)),'journal_input_segment_'+bn)
        require(j['content_sha256']==digest_text(jdump({'raw_model_json':j['raw_model_json'],'item_records':j['item_records']})),'journal_content_hash_'+bn)
        require(proofs[bn]['content_sha256']==j['content_sha256'] and proofs[bn]['item_count']==len(seg),'phase08_receipt_'+bn)
        require(len(j['item_records'])==len(seg),'journal_item_length_'+bn)
        module.validate_batch_response(j['raw_model_json'],seg,bn,index)
        for q, rec, output in zip(seg,j['item_records'],j['raw_model_json']['results']):
            item_id=q['item_id']
            require(rec['item_id']==item_id and output['item_id']==item_id,'journal_item_identical_'+item_id)
            require(rec['model']=='gpt-6.2-sol' and rec['reasoning_effort']=='high','actual_external_effort_'+item_id)
            require(rec['source_reference_unchanged'] and rec['final_cell_not_committed'],'no_fabricated_final_external_'+item_id)
            require(item_id not in actual_results,'unique_external_journal_result_'+item_id)
            require(external[item_id]['suggested_decision']==rec['suggested_decision'] and external[item_id]['decision_status']==rec['decision_status'],'external_aggregate_matches_journal_'+item_id)
            require(external[item_id]['model_json']==rec['model_json'],'external_raw_model_identity_'+item_id)
            actual_results[item_id]=rec
        zip_journal_sha.append((bn,j['content_sha256']))
require(set(actual_results)==set(q_ids),'all_committed_results_verified')
by_batch=defaultdict(list)
for a in state['attempts']:
    by_batch[a['batch_id']].append(a)
require(len(by_batch)==summary['completed_batches'] and len(state['attempts'])==summary['attempts'],'attempt_journal_completeness')
require(all(1<=len(records)<=4 and sum(x.get('status')=='COMPLETED' for x in records)==1 for records in by_batch.values()),'retries_caps_and_one_success')

# Independent Phase 07 classification reconciliation with source/control/GC ledgers.
p7=indexed(jsonl(BASE/'phase07C/07_assistant_adjudications.jsonl'),'item_id')
require(set(p7)==set(q_ids),'phase07_all_items')
require(all(v.get('decision_status') in ('FINAL','EXCLUDED_NONDEFINITIVE_FINAL') for v in p7.values()),'phase07_final_or_exclusion_only')
source_rows={};control_rows={};class_rows={};residual_rows={}
for rec in jsonl(BASE/'phase08/08_final_ledger.jsonl'):
    t=rec['record_type']
    table, key={
      'FINAL_SOURCE':(source_rows,'source_id'),
      'FINAL_CONTROL':(control_rows,'control_id'),
      'FINAL_CLASS':(class_rows,'gc_id'),
      'FINAL_RESIDUAL':(residual_rows,'residual_id'),
    }[t]
    ident=rec[key]
    require(ident not in table,'one_record_per_identity:'+t)
    require(rec['method']=='fullload' and rec['protocol_version']=='10.6','ledger_protocol_method:'+ident)
    table[ident]=rec
require(set(source_rows)==set(R),'canonical_R_identity')
require(set(control_rows)==set(N),'canonical_N_identity')
require(set(class_rows)==G_eligible,'eligible_GC_identity')
require(len(residual_rows)==60,'canonical_distinct_residual_id_count')
for k,rec in source_rows.items():
    require(rec['scoring_cell']==p7[k]['final_cell'] and rec['scoring_cell'] in ('TP','FN'),'source_R_cell_fixed_'+k)
    require(rec['source_original_pdf_sha256']==sha(PDF),'source_pdf_provenance_'+k)
    require(rec.get('pdf_evidence') and isinstance(rec.get('generated_evidence'),list),'source_evidence_present_'+k)
for k,rec in control_rows.items():
    require(rec['scoring_cell']==p7[k]['final_cell'] and rec['scoring_cell'] in ('FP','TN'),'N_cell_fixed_'+k)
    require(rec['source_original_pdf_sha256']==sha(PDF),'control_pdf_provenance_'+k)
for k,rec in class_rows.items():
    require(rec['diagnostic_cell']==p7[k]['final_cell'] and rec['diagnostic_cell'] in ('TP','FP'),'GC_cell_fixed_'+k)
    require(set(rec['member_go_ids'])==set(classes[k]['go_ids']),'GC_member_GO_exact_'+k)
    require(rec['canonical_TP_or_TN_increment']==0,'no_double_count_supported_G_'+k)
    require(rec['source_original_pdf_sha256']==sha(PDF),'class_pdf_provenance_'+k)
for k in exclude:
    require(p7[k]['final_cell'] is None and p7[k]['eligibility_final']=='EXCLUDED_NONDEFINITIVE','nondefinitive_not_binary_'+k)

# Residuals must partition exactly the unsupported eligible classes, with no N overlap.
unsupported={k for k,rec in class_rows.items() if rec['diagnostic_cell']=='FP'}
supported={k for k,rec in class_rows.items() if rec['diagnostic_cell']=='TP'}
require(len(unsupported)==63 and len(supported)==1473,'G_supported_unsupported_counts')
covered_gc=[]
for rid,rec in residual_rows.items():
    ids=rec['member_gc_ids']
    require(bool(ids) and all(g in unsupported for g in ids),'residual_only_unsupported_G_'+rid)
    require(rec['scoring_cell']=='FP' and rec['canonical_FP_increment']==1,'residual_canonical_unit_'+rid)
    require(not rec['overlapping_asserted_frozen_N_control_ids'],'N_F_overlap_none_'+rid)
    require(rec['source_pdf_sha256']==sha(PDF),'residual_source_verified_'+rid)
    covered_gc+=ids
    for g in ids:
        require(class_rows[g]['residual_id']==rid,'class_residual_link_'+g)
require(len(covered_gc)==len(set(covered_gc)) and set(covered_gc)==unsupported,'all_unsupported_partition_once')
require(len(covered_gc)-len(residual_rows)==3,'semantic_consolidation_3_excess')

# Duplication accounting must use only eligible GO and GC (independent of FP).
excess=jsonl(BASE/'phase08/08_duplicate_occurrence_audit.jsonl')
repeated=jsonl(BASE/'phase08/08_duplicate_class_audit.jsonl')
require(len(excess)==len(GO_eligible)-len(G_eligible)==102,'GO_minus_GC_102')
require(len({x['excess_go_id'] for x in excess})==len(excess),'duplicate_excess_unique')
require(all(x['excess_go_id'] in GO_eligible and x['gc_id']==mem[x['excess_go_id']] for x in excess),'duplicate_membership_witness')
require(Counter(x['excess_kind'] for x in excess)=={'within_file':3,'across_file':99},'duplicate_within_across')
require(len(repeated)==84 and sum(x['excess_occurrences'] for x in repeated)==102,'duplicate_repeated_classes')
require(len({x['gc_id'] for x in repeated})==84,'duplicate_classes_unique')

# Source truth is a complete Phase 08 ledger; rebuild all four cells from record rows.
sc=Counter(row['scoring_cell'] for row in source_rows.values())
nc=Counter(row['scoring_cell'] for row in control_rows.values())
TP=sc['TP'];FN=sc['FN'];TN=nc['TN']; B=nc['FP'];F=len(residual_rows);FP=B+F
X=len(R)+len(N)+F
require(TP+FN==len(R),'eq_R')
require(B+TN==len(N),'eq_N')
require(FP==B+F,'eq_FP')
require(TP+TN+FP+FN==X,'eq_X')
require(all(counts[k]==v for k,v in [('TP',TP),('FN',FN),('TN',TN),('FP',FP),('N_FP',B),('generated_only_distinct_F',F),('canonical_universe_R_plus_N_plus_F',X)]),'independent_counts_equal_phase08')
require(len(source_rows)+len(control_rows)+len(class_rows)+len(residual_rows)==2376,'phase08_total_rows')

# Exact rational values, with non-rounded floating numbers in JSON.
def rat(num,den): return None if not den else float(Fraction(num,den))
metrics={
 'Precision':rat(TP,TP+FP),
 'Recall':rat(TP,len(R)),
 'F1':rat(2*TP,2*TP+FP+FN),
 'negative_control_pass_rate':rat(TN,len(N)),
 'GC_validity_rate':rat(len(supported),len(G_eligible)),
 'Duplicate':rat(len(GO_eligible)-len(G_eligible),len(GO_eligible)),
}
pre=Counter(x.get('direction') for x in queue if external[x['item_id']]['decision_status']=='UNRESOLVED')
pre_noncommitted=Counter((x['direction'],external[x['item_id']]['suggested_decision']) for x in queue if external[x['item_id']]['decision_status']=='UNRESOLVED')
# v5 undecided includes cases with null or UNRESOLVED status.
pre_no_suggestion=Counter(x['direction'] for x in queue if external[x['item_id']]['suggested_decision'] is None)
root_causes=Counter()
source_error_rows=[]
for row in source_rows.values():
    source_id=row['source_id']
    cell=row['scoring_cell']
    v5_suggestion=row['external_suggested_decision_unchanged']
    v5_status=row['external_decision_status_unchanged']
    witness_count=len(row.get('generated_evidence',[]))
    unmet=row.get('phase07_unmet_predicates_en') or []
    if cell=='FN':
        category=('FN_NO_GENERATED_WITNESS_RECORDED' if witness_count==0
                  else 'FN_NEARBY_WITNESS_NOT_FULL_ENTAILMENT')
    elif v5_suggestion=='FN':
        category='TP_CORRECTED_FROM_V5_FN_SUGGESTION'
    elif v5_status=='UNRESOLVED' or v5_suggestion is None:
        category='TP_ASSISTANT_CLOSED_V5_UNRESOLVED_OR_NULL'
    else:
        category='TP_SUPPORTED_AFTER_INDEPENDENT_REVIEW'
    root_causes[category]+=1
    source_error_rows.append({
       'record_type':'PHASE09_SOURCE_ERROR_DIAGNOSTIC',
       'source_id':source_id,'final_cell_unchanged':cell,
       'external_suggested_decision_unchanged':v5_suggestion,
       'external_decision_status_unchanged':v5_status,
       'generated_evidence_witness_count':witness_count,
       'missing_predicates_from_phase07':unmet,
       'diagnostic_category':category,
       'category_is_mechanical_not_new_semantic_adjudication':True,
       'source_phase08_record_sha256':digest_text(jdump(row))
    })
# A true-missing/partial-entailment split requires a substantive judgment;
# classify only the narrower mechanical evidence distinctions supported by the ledger.
with (OUT/'09_error_analysis.jsonl').open('w',encoding='utf-8') as f:
    for row in source_error_rows:
        f.write(jdump(row)+'\n')

result={
 'record_type':'PHASE09_METRICS', 'protocol_version':'10.6',
 'spec_gen_method':'fullload','phase':'09','status':'FINAL_COMPLETE',
 'metric_population':'PHASE08_COMPLETE_CANONICAL_UNIVERSE_NOT_EXTERNAL_K',
 'frozen_reference':{'R':len(R),'N':len(N),'pdf_physical_pages':90,'sha256':{'pdf':sha(PDF),'R':sha(RFILE),'N':sha(NFILE),'reference_freeze':sha(ROOT/'reference_freeze(1).json')}},
 'generated_inventory':{
    'GO_before_eligibility':len(GO),'GC_before_eligibility':len(classes),
    'excluded_GO':len(GO_excluded),'excluded_GC':len(exclude),
    'eligible_GO':len(GO_eligible),'eligible_GC':len(G_eligible),
    'excess_duplicate_occurrences':len(excess),'repeated_class_count':len(repeated),
    'within_file_excess':3,'across_file_excess':99,
    'cross_file_repeated_class_count':sum(bool(x['across_file_reuse']) for x in repeated),
    'duplicate_intent_is_not_inferred':True
 },
 'classification':{
   'TP':TP,'FN':FN,'TN':TN,'FP':FP,'N_affirmed_FP':B,
   'generated_only_distinct_F':F,'PDF_supported_GC_diagnostic':len(supported),
   'PDF_unsupported_GC_diagnostic':len(unsupported),'N_F_overlap_excluded':0,
   'residual_GC_excess_consolidated':len(unsupported)-F,
   'canonical_universe_X':X,
   'R_final_unresolved':0,'N_final_unresolved':0,'eligible_GC_final_unresolved':0
 },
 'metrics':metrics,
 'external_evaluation':{
   'model':'gpt-6.2-sol','reasoning_effort_observed':'high',
   'batch_size':state['batch_size'],'batch_count':len(proofs),'item_count':len(queue),
   'attempts':len(state['attempts']), 'completed_items':len(external),
   'original_v5_suggested_decision_counts':summary['suggested_decision_counts'],
   'pre_phase07_UNRESOLVED_by_direction':dict(pre),
   'pre_phase07_null_suggestion_by_direction':dict(pre_no_suggestion),
   'pre_phase07_undecided_status_total':sum(pre.values()),
   'proposed_not_independent_final':True,
   'batch_journal_content_digests_all_verified':True,
   'original_v5_prompt_and_result_schema_hashes_match':True,
   'v5_regression_tests_passed':62,
   'phase06_default_effort_vs_actual':'medium_default_vs_high_actual',
 },
 'diagnostics':{
   'source_error_diagnostic_categories_from_recorded_evidence':dict(root_causes),
   'explicit_supported_noncovering_provenance_classes':sum(rec['pdf_provenance_category']=='SUPPORTED_NONCOVERING' for rec in class_rows.values()),
   'true_missing_vs_partial_entailment_not_independently_reclassified_in_phase09':True,
   'reconciliation_residual_groups':len(residual_rows),
   'duplicate_class_evidence_rows':len(repeated),
   'source_evidence_provenance_inherited_from_phase07_08':True,
   'not_a_new_independent_semantic_re_adjudication':True
 },
 'comparability':{
  'within_this_method_full_population_metrics':'VERIFIED',
  'cross_method_comparability':'NOT_VERIFIED_OTHER_METHOD_EXECUTION_RECORDS_UNAVAILABLE',
  'mandatory_comparable_conditions':['Same frozen R/N/PDF bytes','Same actual model and reasoning effort','Same protocol-approved batch size per comparison','Same v5 suggestion logic and Phase07 independent final adjudication rules','Same GO/GC eligibility and semantic deduplication policy'],
  'note_en':'The external run used gpt-6.2-sol / high / 16. The protocol text lists medium as a default. Other methods require independent actual-run verification; the 8-or-16 batch choice is allowed when standardized.'
 },
 'canonical_equations':{
   'TP+FN=R':TP+FN==len(R),
   'N_FP+TN=N':B+TN==len(N),
   'FP=N_FP+F':FP==B+F,
   'TP+TN+FP+FN=R+N+F':TP+TN+FP+FN==X,
 },
 'input_sha256':{
   'phase08_final_ledger':sha(BASE/'phase08/08_final_ledger.jsonl'),
   'phase08_binary_counts':sha(BASE/'phase08/08_binary_counts.json'),
   'phase08_manifest':sha(BASE/'phase08/08_artifact_manifest.json'),
   'phase07_final':sha(BASE/'phase07C/07_assistant_adjudications.jsonl'),
   'phase06_queue':sha(BASE/'phase06/06_llm_queue_v10.6.jsonl'),
   'external_semantic_results':sha(ROOT/'semantic_decisions(5).jsonl'),
   'external_run_state':sha(ROOT/'run_state(4).json'),
   'external_batch_journals_zip':sha(ZIP),
   'source_role_md':{k+'.md':v for k,v in ROLE_HASH.items()}
 },
 'verification':{'status':'PASS','independent_assertions_passed':len(ASSERTIONS),
                 'unique_external_journals_verified':len(proofs),
                 'unique_external_item_records_verified':len(actual_results),
                 'final_ledger_records_verified':2376}
}

out=OUT/'09_metrics.json'
out.write_text(json.dumps(result,indent=2,ensure_ascii=False,sort_keys=True)+'\n',encoding='utf-8')
report=f'''# Phase 09 — Independent Metric Computation\n\n**Method:** `fullload`  
**Protocol:** 10.6  
**Status:** `FINAL_COMPLETE`\n\n## Single canonical score\n\n| Metric | Exact computation | Result |\n|---|---|---:|\n| Precision | {TP} / ({TP} + {FP}) | {metrics['Precision']:.12%} |\n| Recall | {TP} / ({TP} + {FN}) | {metrics['Recall']:.12%} |\n| F1 | 2 × {TP} / (2 × {TP} + {FP} + {FN}) | {metrics['F1']:.12%} |\n| Negative-control pass rate | {TN} / {len(N)} | {metrics['negative_control_pass_rate']:.12%} |\n| GC validity rate | {len(supported)} / {len(G_eligible)} | {metrics['GC_validity_rate']:.12%} |\n| Duplicate occurrence rate | {len(excess)} / {len(GO_eligible)} | {metrics['Duplicate']:.12%} |\n\nThe JSON file holds unrounded floating-point values. Fractions are authoritative for arithmetic.\n\n## Complete canonical population\n\n- Frozen reference: R={len(R)}, N={len(N)}.\n- Original effective generated population: GO={len(GO)}, GC={len(classes)}.\n- Excluded nondefinitive: GO={len(GO_excluded)}, GC={len(exclude)}.\n- Eligible generated population: GO={len(GO_eligible)}, GC={len(G_eligible)}.\n- Canonical source cells: TP={TP}, FN={FN}. Control cells: TN={TN}, FP_N={B}.\n- Definitive generated class diagnostics: supported={len(supported)}, unsupported={len(unsupported)}; not extra canonical source TP units.\n- Unsupported residual classes consolidate to F={F}, including {len(unsupported)-F} duplicate excess, with N/F overlap count zero.\n- Canonical FP={FP}; canonical universe X={X}.\n- Repeated eligible classes={len(repeated)}, excess occurrences={len(excess)} ({3} within-file, {99} across-file).\n\n## External-v5 evaluation and Phase 07 closure\n\n- Externally evaluated K={len(queue)} unique items in {len(proofs)} verified, ordered journals with {len(state['attempts'])} attempts.\n- Observed external execution: `gpt-6.2-sol`, `high` reasoning effort, batch size {state['batch_size']}, v5 suggestion threshold 0.90.\n- Original v5 suggestions: {json.dumps(summary['suggested_decision_counts'],sort_keys=True)}.\n- Initially unresolved by external status: {dict(pre)} (total {sum(pre.values())}).\n- Original v5 uncertainties were adjudicated in Phase 07; semantic unresolved after Phase 07 and 08: 0.\n- No external v5 suggestion is substituted for a Phase 07 final cell; no diagnostic generated-class TP increases canonical TP.\n\n## Source identity and arithmetic checks\n\n- The original PDF has exactly 90 physical pages; its SHA-256 and the frozen R/N ledgers are unchanged.\n- All eight original generated Markdown sources match their declared source-role SHA-256 values.\n- Phase 08's source/output digests and all final IDs, eligible GO-to-GC memberships, class-to-residual mappings and entire committed external batch journal population were verified.\n- Four canonical population equations passed. {len(ASSERTIONS)} executable assertions passed.\n- `09_error_analysis.jsonl` records one mechanically derived diagnostic for each of the {len(source_error_rows)} R items. Categories: {dict(root_causes)}.\n- Explicit `SUPPORTED_NONCOVERING` provenance records: 0; this does not prove no PDF-supported but non-R-covering generated propositions exist.\n- No fabricated scores, sampled-denominator extrapolation, new external requests or Phase 07 item-level relabeling were used.\n\n## Interpretation\n\nPrecision and recall describe retrieval of the fictional OrionDesk PDF-defined requirements by the `fullload` specification-generation output under the frozen benchmark. They are not measures of implementation or general model correctness. External execution differed from the protocol's medium-effort default: this observed run used high effort. Cross-method comparability is **not independently verified** without the actual other-method execution logs, matching reference digests and shared adjudication/deduplication policy. Either protocol-approved batch size (8 or 16) is valid if consistently applied.\n'''
(OUT/'09_report.md').write_text(report,encoding='utf-8')
limits=f'''# Phase 09 — Coverage and Limitations\n\n## Verified coverage\n\nThe complete canonical population contains {len(R)} R, {len(N)} N and {F} distinct unsupported generated-only residuals, X={X}. All Phase 08 records and committed external journal items are individually accounted for.\n\n## Evidence and method limitations\n\n1. The frozen R/N reference is marked provisional in the original `reference_freeze.json`: its prior creation did not exhaustively review every semantic duplicate or receive an independent second expert review. This does not authorize changing its denominator.\n2. The GO/GC extraction and 122 nondefinitive class exclusions are inherited from Phase 05–08 and carry provenance; Phase 09 mechanically validates their population and identity, **not** an independently repeated semantic analysis of all source propositions.\n3. Phase 07 item-level decisions were independently made in the prior steps; this phase does not change those judgments. Some classification reasons inherit evidence from the original 90-page PDF, eight Markdown originals and the external-model suggestion journal.\n4. A PDF-supported generated claim need not cover a particular frozen R atom. Therefore, 1,473 supported GC classes must not be counted as 1,473 additional TP units.\n5. The 63 unsupported GC candidates reduce to 60 distinct FP residuals only after mutual-entailment and N/F-overlap reconciliation, as recorded in Phase 08. This is one frozen method-specific judgment set, not proof that other methods' FP consolidation would be identical.\n6. The `09_error_analysis.jsonl` groups FN cases into `NO_GENERATED_WITNESS_RECORDED` versus `NEARBY_WITNESS_NOT_FULL_ENTAILMENT`. These are mechanical evidence distinctions, **not** an independently established true-missing versus partial-entailment semantic taxonomy; use Phase 07 per-item reasons for substantive causes.\n7. The current external run had `gpt-6.2-sol` / high / batch size 16, whereas the protocol document describes a medium reasoning default; actual execution metadata is authoritative for this run. No other-method execution record was provided for an independent comparability check.\n8. Quantities are directly counted rather than inferred from a sample. Results depend on the complete frozen reference, semantic entailment criteria, generated eligibility, and duplicate-consolidation policy.\n\n## Metric policy\n\nOnly the complete Phase 08 canonical source/control/residual counts determine Precision, Recall and F1. The 2,438 external-v5 observations are an adjudication evidence population, **not** the scoring denominator. Diagnostic validity and duplication metrics have their own explicitly named denominators.\n'''
(OUT/'09_coverage_and_limitations.md').write_text(limits,encoding='utf-8')
# Machine-readable independent checks: a small manifest with all produced SHA values.
(OUT/'09_quality_gate.json').write_text(json.dumps({
 'record_type':'PHASE09_INDEPENDENT_QUALITY_GATE','protocol_version':'10.6',
 'status':'PASS','passed_assertions':len(ASSERTIONS),
 'source_reference_unchanged':True,'method':'fullload',
 'full_canonical_population_verified':True,
 'external_batch_content_verified':len(proofs),
 'external_item_records_verified':len(actual_results),
 'phase07_item_level_cells_modified':0,
 'metric_arithmetic_verified':result['canonical_equations'],
 'source_files_sha256':result['frozen_reference']['sha256'],
 'outputs_sha256':{f:sha(OUT/f) for f in ('compute_metrics.py','09_metrics.json','09_report.md','09_coverage_and_limitations.md','09_error_analysis.jsonl')},
},ensure_ascii=False,indent=2,sort_keys=True)+'\n',encoding='utf-8')
print(json.dumps({'status':'FINAL_COMPLETE','assertions_passed':len(ASSERTIONS),'records':{'R':len(R),'N':len(N),'GC':len(class_rows),'F':F},'metrics':metrics,'phase09_files':[str(p) for p in OUT.iterdir() if p.is_file()]},ensure_ascii=False,indent=2))
