# Phase 09 — Independent Metric Computation

**Method:** `fullload`  
**Protocol:** 10.6  
**Status:** `FINAL_COMPLETE`

## Single canonical score

| Metric | Exact computation | Result |
|---|---|---:|
| Precision | 466 / (466 + 60) | 88.593155893536% |
| Recall | 466 / (466 + 172) | 73.040752351097% |
| F1 | 2 × 466 / (2 × 466 + 60 + 172) | 80.068728522337% |
| Negative-control pass rate | 142 / 142 | 100.000000000000% |
| GC validity rate | 1473 / 1536 | 95.898437500000% |
| Duplicate occurrence rate | 102 / 1638 | 6.227106227106% |

The JSON file holds unrounded floating-point values. Fractions are authoritative for arithmetic.

## Complete canonical population

- Frozen reference: R=638, N=142.
- Original effective generated population: GO=1760, GC=1658.
- Excluded nondefinitive: GO=122, GC=122.
- Eligible generated population: GO=1638, GC=1536.
- Canonical source cells: TP=466, FN=172. Control cells: TN=142, FP_N=0.
- Definitive generated class diagnostics: supported=1473, unsupported=63; not extra canonical source TP units.
- Unsupported residual classes consolidate to F=60, including 3 duplicate excess, with N/F overlap count zero.
- Canonical FP=60; canonical universe X=840.
- Repeated eligible classes=84, excess occurrences=102 (3 within-file, 99 across-file).

## External-v5 evaluation and Phase 07 closure

- Externally evaluated K=2438 unique items in 153 verified, ordered journals with 154 attempts.
- Observed external execution: `gpt-6.2-sol`, `high` reasoning effort, batch size 16, v5 suggestion threshold 0.90.
- Original v5 suggestions: {"EXCLUDED_NONDEFINITIVE": 122, "FN": 47, "NOT_FP": 1329, "None": 504, "TN": 5, "TP": 431}.
- Initially unresolved by external status: {'R': 207, 'N': 142, 'G': 207} (total 556).
- Original v5 uncertainties were adjudicated in Phase 07; semantic unresolved after Phase 07 and 08: 0.
- No external v5 suggestion is substituted for a Phase 07 final cell; no diagnostic generated-class TP increases canonical TP.

## Source identity and arithmetic checks

- The original PDF has exactly 90 physical pages; its SHA-256 and the frozen R/N ledgers are unchanged.
- All eight original generated Markdown sources match their declared source-role SHA-256 values.
- Phase 08's source/output digests and all final IDs, eligible GO-to-GC memberships, class-to-residual mappings and entire committed external batch journal population were verified.
- Four canonical population equations passed. 57393 executable assertions passed.
- `09_error_analysis.jsonl` records one mechanically derived diagnostic for each of the 638 R items. Categories: {'TP_SUPPORTED_AFTER_INDEPENDENT_REVIEW': 431, 'FN_NEARBY_WITNESS_NOT_FULL_ENTAILMENT': 164, 'TP_ASSISTANT_CLOSED_V5_UNRESOLVED_OR_NULL': 35, 'FN_NO_GENERATED_WITNESS_RECORDED': 8}.
- Explicit `SUPPORTED_NONCOVERING` provenance records: 0; this does not prove no PDF-supported but non-R-covering generated propositions exist.
- No fabricated scores, sampled-denominator extrapolation, new external requests or Phase 07 item-level relabeling were used.

## Interpretation

Precision and recall describe retrieval of the fictional OrionDesk PDF-defined requirements by the `fullload` specification-generation output under the frozen benchmark. They are not measures of implementation or general model correctness. External execution differed from the protocol's medium-effort default: this observed run used high effort. Cross-method comparability is **not independently verified** without the actual other-method execution logs, matching reference digests and shared adjudication/deduplication policy. Either protocol-approved batch size (8 or 16) is valid if consistently applied.
