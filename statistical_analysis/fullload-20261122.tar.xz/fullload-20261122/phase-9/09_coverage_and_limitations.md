# Phase 09 — Coverage and Limitations

## Verified coverage

The complete canonical population contains 638 R, 142 N and 60 distinct unsupported generated-only residuals, X=840. All Phase 08 records and committed external journal items are individually accounted for.

## Evidence and method limitations

1. The frozen R/N reference is marked provisional in the original `reference_freeze.json`: its prior creation did not exhaustively review every semantic duplicate or receive an independent second expert review. This does not authorize changing its denominator.
2. The GO/GC extraction and 122 nondefinitive class exclusions are inherited from Phase 05–08 and carry provenance; Phase 09 mechanically validates their population and identity, **not** an independently repeated semantic analysis of all source propositions.
3. Phase 07 item-level decisions were independently made in the prior steps; this phase does not change those judgments. Some classification reasons inherit evidence from the original 90-page PDF, eight Markdown originals and the external-model suggestion journal.
4. A PDF-supported generated claim need not cover a particular frozen R atom. Therefore, 1,473 supported GC classes must not be counted as 1,473 additional TP units.
5. The 63 unsupported GC candidates reduce to 60 distinct FP residuals only after mutual-entailment and N/F-overlap reconciliation, as recorded in Phase 08. This is one frozen method-specific judgment set, not proof that other methods' FP consolidation would be identical.
6. The `09_error_analysis.jsonl` groups FN cases into `NO_GENERATED_WITNESS_RECORDED` versus `NEARBY_WITNESS_NOT_FULL_ENTAILMENT`. These are mechanical evidence distinctions, **not** an independently established true-missing versus partial-entailment semantic taxonomy; use Phase 07 per-item reasons for substantive causes.
7. The current external run had `gpt-6.2-sol` / high / batch size 16, whereas the protocol document describes a medium reasoning default; actual execution metadata is authoritative for this run. No other-method execution record was provided for an independent comparability check.
8. Quantities are directly counted rather than inferred from a sample. Results depend on the complete frozen reference, semantic entailment criteria, generated eligibility, and duplicate-consolidation policy.

## Metric policy

Only the complete Phase 08 canonical source/control/residual counts determine Precision, Recall and F1. The 2,438 external-v5 observations are an adjudication evidence population, **not** the scoring denominator. Diagnostic validity and duplication metrics have their own explicitly named denominators.
