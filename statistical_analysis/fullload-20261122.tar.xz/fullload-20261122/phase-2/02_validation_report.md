# Phase 02 — Generated Occurrences and Semantic Classes

Protocol version: 10.6  
Method: `fullload`  
Phase status: **PHASE_COMPLETED**  
Phase 01 source lock: unchanged and SHA-256 verified.

## Scope and population

All eight immutable generated Markdown originals were indexed, including headings,
table headers, individual table rows and cells, ordinary paragraphs, list steps,
code/example blocks and nondefinitive passages. Original files were not edited.

- Original physical lines: **3,956**, each covered exactly once.
- Context-preserving original text units: **3,739**.
- Eligible definitive GO occurrences: **1,646**.
- Conservatively consolidated GC classes: **1,549**.
- Confirmed excess duplicate occurrences: **97**.
- Duplicate occurrence ratio in the current conservative ledger: **5.89307412%**.
- Repeated classes: **80**.
- Within-file excess occurrences: **3**.
- Across-file excess occurrences: **94**.
- Excluded or contextual fragments: **4,980** records (not independently scored).
- Explicit reviewed semantic pairs: **74** (accepted and rejected evidence decisions).
- Unmerged, retrieval-similar cross-file candidate pairs retained for Phase 05: **251**.

## Evidence and precedence

Every GO includes the exact original source filename, original SHA-256, physical line
range, paragraph/table cell locator, section heading chain and original text quotation.
Every substantive indexed unit is mapped to its eligible GO IDs or auditable excluded
fragments. Table conditions and source-reference columns are carried as inherited
context; they do not independently become affirmative predictions. Explicitly
unadopted proposals, illustrative values, open questions and unknown contracts are
excluded from scoring, while separable definitive obligations are retained.

Semantic duplicates are merged only where the complete proposition is independently
supported as mutually entailing, including verified technical constraints, source
scope and negation. Notably, separate API operations and distinct physical fields
are **not** merged merely because they share an HTTP status or data type. The
pair-by-pair semantic review and the rejected counterexamples are preserved.

## Important interpretation limit

The current GO/GC count is an auditable conservative extraction **not proof** that
all paraphrastic duplicates have been discovered. Retrieval similarity does not
constitute a semantic-equivalence verdict. The unmerged cross-file candidate queue
has been preserved for the mandatory Phase 05 generated-inventory and exclusion
reassessment. The current conservative ratio must not be represented as the final
or benchmark-wide semantic duplication rate before that verification.

No PDF entailment decisions, TP/FN/FP/TN classifications, external semantic requests,
or Precision/Recall/F1 calculations were performed in Phase 02.

## Mechanical validation

- Source digests and frozen reference digests: **PASS**.
- Unique file/line-to-unit coverage: **PASS**.
- GO-to-GC bijective assignment at the occurrence level: **PASS**.
- Exclusion and source traceability: **PASS**.
- Duplicate counts and within/across-file arithmetic: **PASS**.
- Stored original generated quotations: **PASS**.
- Reviewed semantic pair linkage: **PASS**.
- Independent mechanical error count: **0**.

Only Phase 02 was executed. Phase 03 has not been started.
