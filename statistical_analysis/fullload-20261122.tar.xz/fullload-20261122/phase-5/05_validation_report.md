# Phase 05 - Generated Claim Validity and Eligibility Reassessment

Protocol: 10.6  
Method: fullload  
Status: PHASE_COMPLETED (Phase 05 scope only; no final TP/FN/FP/TN decisions)

## Population and corrections

- fixed_reference_positive_R: 638
- fixed_reference_negative_N: 142
- phase02_original_GO: 1646
- phase02_original_GC: 1549
- original_exclusion_fragments_reexamined: 4980
- phase05_original_GO_reclassified_nondefinitive: 32
- phase05_recovered_GO: 146
- phase05_effective_GO: 1760
- phase05_effective_GC: 1658
- phase05_effective_duplicate_occurrences: 102
- phase02_semantic_pairs_reexamined: 251
- phase05_exact_full_proposition_merges_accepted: 1
- effective_GC_pdf_candidate_audited: 1658
- r_to_go_evidence_links_audited: 638

## PDF Evidence Discovery (not final entailment)

- PDF_RETRIEVAL_CANDIDATE_UNDECIDED: 1651
- LITERAL_PDF_WORD_SEQUENCE_CANDIDATE: 6
- NO_RELATIVE_PDF_EVIDENCE_YET: 1

Source and generated original line/passage quotations were hash and location checked. A high lexical match or an exact consecutive word sequence is only a retrieval candidate; it is not a complete entailment verdict. Each effective generated class has an individual audit row, original location, original-document SHA-256, literal PDF evidence candidates, and an explicit pending substantive conclusion.

## Exclusion and duplication audit

Every excluded fragment was reexamined using its original unit context. Confidently recoverable affirmative requirements were assigned fresh 05-specific occurrence IDs without mutating the original Phase 02 ledger. Only exact complete propositions after purely documentary prefix removal were merged in the Phase 05 overlay. All remaining similarity candidates stay separate. The Phase 05 class and membership files supply the effective within-method GO/GC population for the next phase.

## Governing boundaries

- The original 90-page PDF, R/N ledgers, and Phase 01-04 artifacts were left unchanged.
- No generated assertion absent from frozen R is automatically a false positive.
- No PDF-negative control has been classified at this phase; that work belongs to Phase 06.
- No provisional R coverage or G validity result is a final TP, FN, FP, or TN.
- Phase 07 must independently adjudicate genuinely unresolved item-level semantics after the Phase 06 handoff.
- Automatic exclusion recovery is intentionally conservative and preserves each ambiguous fragment for later inspection.

## Primary artifacts

- 05_generated_claim_validity.jsonl
- 05_exclusion_reassessment.jsonl

## Supporting audit artifacts

- 05_original_go_eligibility_audit.jsonl
- 05_reclassified_nondefinitive_go.jsonl
- 05_recovered_generated_atoms.jsonl
- 05_semantic_recheck_audit.jsonl
- 05_effective_generated_classes.jsonl
- 05_effective_membership.jsonl
- 05_r_reciprocal_recovery_links.jsonl
- 05_validity_audit_summary.json

Phase 06 was not performed.
