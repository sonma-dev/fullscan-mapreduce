# Phase 08 — Independent Semantic Reconciliation

**Protocol:** OrionDesk v10.6; operator-authorized Phase 07 three-shard amendment.  
**Generation method:** `fullload`; operator-specified generation effort `xhigh`.  
**Actual external adjudicator:** `gpt-6.2-sol`, effort `high`, batch size 16, 241 committed batches. The protocol's printed default differs; actual run metadata is preserved.  
**Phase status:** `PHASE_COMPLETED` for immutable-input reconciliation, subject to the explicit semantic-audit limitations below.

## Frozen reference and effective generated population

- Source R: 638, unchanged; N: 142, unchanged.
- Original Phase 05 GO: 3,119; GC: 3,072.
- Phase 07 superseded the eligibility of 521 original G classes to nondefinitive, with an immutable per-ID explanation. No original Phase 05 class was rewritten.
- Effective definitive generated occurrences: 2,598; unique effective classes: 2,551. Excess duplicate occurrences: 47.
- Phase 07 final R: 520 TP and 118 FN. N: 0 affirmative-control FP and 142 TN.
- Phase 07 diagnostic G classes: 2,296 supported, 255 unsupported.
- Semantic residual reconciliation: 8 cross-class repeated-claim families; one composite class contains two distinct unsupported fixture requirements. The resulting **246 unique unsupported generated-only residual FP units** have zero established overlap with an affirmative frozen negative control.
- Canonical count universe: 638 R + 142 N + 246 unique F = 1,026. Canonical FP count: 246.

## Evidence and execution integrity

- The original 90-physical-page PDF, frozen R/N reference files, original eight Markdown roles, Phase 06 queue, and source SHA-256 values match their recorded identities.
- All 3,852 Phase 06 queue IDs have one Phase 07-C disposition; 3,331 eligible binary decisions and 521 individually tracked nondefinitive eligibility supersessions.
- All 241 external batch journals agree with the original 3,852 external item records and preserve original model JSON, order, and per-batch content hashes.
- All 3,852 Phase 07 shard-input digests were independently verified using the respective recorded A/B JSON serializers.
- 6,909 Phase 07 PDF quotations and 4,019 eligible Markdown quotations matched their original physical pages or exact file lines; 523 additional excluded-item Markdown quotations also matched.
- All four canonical counting invariants pass; no unsupported residual is multiplied by the number of source files in which it appears.

## Duplicate and scope discipline

Same-meaning repeated obligations were merged only when their target, applicable condition, and unsupported predicate matched. Different user interface fields, different error actions, and separate test-fixture categories are not collapsed merely because their wording resembles each other. A single composite statement can produce two separate residual units if the additional obligations are independently testable. All 255 unsupported G class IDs map to one or (in one documented case) two canonical residual IDs.

## Limitations and remaining boundary

This phase does not issue competing TP/FN/TN/FP adjudications. Its judgments are inherited from the Phase 07 source-grounded records; the Phase 07 A/B work included machine-assisted decisions and is not a professional independent proof of every natural-language entailment. A few source-supportedness questions remain suitable for a later explicit Phase 07 superseding audit, but are not silently relabeled here. The 521 nondefinitive supersessions are excluded from canonical FP/TN, not converted into a fifth confusion-matrix cell.

**No precision, recall, F1, or cross-method metric comparison is computed in Phase 08.** Phase 09 independently reopens these ledgers, verifies input identities and the residual consolidations, and then performs the arithmetic if the phase gate remains valid.
