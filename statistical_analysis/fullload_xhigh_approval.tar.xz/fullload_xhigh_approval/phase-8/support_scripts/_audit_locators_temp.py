import pathlib,json,re,unicodedata,fitz,collections,hashlib
p=pathlib.Path('/mnt/data'); d=p/'fullload_v10_6'
sources=sorted(p.glob('0?_*.md'))
print('sources',len(sources))
lines={x.name:x.read_text(encoding='utf-8').splitlines() for x in sources}
mp={re.sub(r'\(\d+\)(?=\.md$)','',n):n for n in lines}
PDF=fitz.open(p/'OrionDesk_AI_Detailed_Design_Specification(2).pdf')
def norm(t):return re.sub(r'\s+',' ',unicodedata.normalize('NFKC',t)).strip().casefold()
textpages=[norm(x.get_text(sort=True)) for x in PDF]
def ld(f):return [json.loads(x) for x in (d/f).read_text().splitlines() if x.strip()]
rows=ld('phase07_A_completed/07_assistant_adjudications_A.jsonl')+ld('phase07_B_completed/07_assistant_adjudications_B.jsonl')
ex=ld('phase07_A_completed/07_eligibility_supersessions_A.jsonl')+ld('phase07_B_completed/07_eligibility_supersessions_B.jsonl')
c=collections.Counter();bad=[]
for x in rows+ex:
 for e in x.get('generated_evidence') or []:
  fn=e.get('file') or e.get('original_file')
  if not fn:continue
  if fn not in lines: fn=mp.get(fn,fn)
  a=e.get('line_start'); b=e.get('line_end');quote=e.get('quote_en','')
  if fn not in lines or not isinstance(a,int) or not isinstance(b,int) or a<=0 or b>len(lines[fn]) or a>b:c['gen_bad_locator']+=1;bad.append((x['item_id'],'gen_locator',fn,a,b,quote[:100]));continue
  if norm(quote) not in norm('\n'.join(lines[fn][a-1:b])):
   c['gen_quote_mismatch']+=1;bad.append((x['item_id'],'gen_quote',fn,a,b,quote[:100]));continue
  c['gen_pass']+=1
 for e in x.get('pdf_evidence') or []:
  page=e.get('physical_page');quote=e.get('quote_en','')
  if not page or page not in range(1,91):c['pdf_bad_page']+=1;bad.append((x['item_id'],'pdf_page',page,quote[:100]));continue
  if norm(quote) not in textpages[page-1]:
   c['pdf_quote_mismatch']+=1;bad.append((x['item_id'],'pdf_quote',page,quote[:100]));continue
  c['pdf_pass']+=1
print(c)
for v in bad[:40]:print('BAD',v)
