import json, re, numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
p='/mnt/data/fullload_v10_6/'
rows=[json.loads(l) for l in open(p+'phase07_C_completed/07_assistant_adjudications.jsonl')]
fps=[x for x in rows if x['direction']=='G' and x['final_cell']=='FP']
stmts=[]
for x in fps:
 z=x['generated_evidence'][0]['quote_en'].strip().replace('\n',' ') if x['generated_evidence'] else ''
 z=re.sub(r'^\|?\s*[A-Z]{2,}(?:-\d+[A-Z0-9-]*)?\s*\|','',z)
 stmts.append(z)
vec=TfidfVectorizer(analyzer='char',ngram_range=(3,5),min_df=1)
S=cosine_similarity(vec.fit_transform(stmts));np.fill_diagonal(S,0)
prs=[(S[i,j],i,j) for i in range(len(fps)) for j in range(i+1,len(fps)) if S[i,j]>.55]
prs.sort(reverse=True)
print('pairs >.55',len(prs));print('>0.8',sum(q>.8 for q,i,j in prs));print('>0.7',sum(q>.7 for q,i,j in prs));print('>0.9',sum(q>.9 for q,i,j in prs));
for q,i,j in prs[:120]:print(f'{q:.3f} {fps[i]["item_id"]:<19} {fps[j]["item_id"]:<19} | {stmts[i][:75]} | {stmts[j][:75]}')
