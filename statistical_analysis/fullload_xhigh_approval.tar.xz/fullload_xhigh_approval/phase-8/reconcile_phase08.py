#!/usr/bin/env python3
"""Phase 08: reproduce canonical ledger from immutable Phase 07 records.

This program never changes a Phase 07 adjudication. It verifies immutable
inputs, source attribution and batch journals; it only consolidates supported
or unsupported Phase 07 G classes. A correction to a semantic cell MUST be
made in Phase 07 by a separately appended superseding decision.
"""
from __future__ import annotations
from collections import Counter, defaultdict
from pathlib import Path
import datetime as dt
import hashlib
import json
import re
import unicodedata
import zipfile
import math
import fitz

ROOT=Path('/mnt/data')
BASE=ROOT/'fullload_v10_6'
OUT=BASE/'phase08';OUT.mkdir(exist_ok=True)
ROLE_NAMES=['01_screen_functions(2).md','02_api(2).md','03_data(2).md','04_batch_functions(3).md','05_business_rules(2).md','06_exception_handling(4).md','07_processing_flows(4).md','08_architecture_decision(3).md']
PDF=ROOT/'OrionDesk_AI_Detailed_Design_Specification(2).pdf'
R_PATH=ROOT/'common_atomic_reqs(2).jsonl';N_PATH=ROOT/'common_negative_controls(2).jsonl'
G_PATH=BASE/'phase05/05_effective_generated_classes.jsonl';GO_PATH=BASE/'phase02/02_generated_atoms_final.jsonl'
ADJ_PATH=BASE/'phase07_C_completed/07_assistant_adjudications.jsonl'
EXC_PATH=BASE/'phase07_C_completed/07_eligibility_supersessions.jsonl'
DIS_PATH=BASE/'phase07_C_completed/07_all_original_ids_disposition.jsonl'
QUEUE_PATH=BASE/'phase06/06_llm_queue_v10.6.jsonl'
AGG_PATH=ROOT/'semantic_decisions(4).jsonl';STATE_PATH=ROOT/'run_state(3).json'
ZIP_PATH=ROOT/'batch_journals(3).zip'

def hbytes(b):return hashlib.sha256(b).hexdigest()
def hfile(p):return hbytes(p.read_bytes())
def jd(x):return json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':'))
def shaobj(x):return hbytes(jd(x).encode())
def rows(path):
    with path.open(encoding='utf-8-sig') as f:
        return [json.loads(s) for s in f if s.strip()]
def write_json(path,x):path.write_text(json.dumps(x,indent=2,ensure_ascii=False,sort_keys=True)+'\n',encoding='utf-8')
def write_jsonl(path,x):path.write_text(''.join(jd(k)+'\n' for k in x),encoding='utf-8')
def norm(s):return ' '.join(unicodedata.normalize('NFKC',str(s)).split()).casefold()

errors=[];warnings=[];audit=[]
def check(yes,code,detail=None):
    if not yes:errors.append({'code':code,'detail':detail})

def original_lock_check():
    source_manifest= json.loads((BASE/'phase01/01_source_reference_manifest.json').read_text())
    freeze=json.loads((ROOT/'reference_freeze(2).json').read_text())
    state=json.loads(STATE_PATH.read_text())
    srch=state['file_sha256'];pdfh=hfile(PDF)
    check(pdfh==freeze['source_document']['sha256']==srch['OrionDesk_AI_Detailed_Design_Specification.pdf'],'SOURCE_PDF_HASH',pdfh)
    check(hfile(R_PATH)==freeze['output_artifacts_sha256']['common_atomic_reqs.jsonl'],'SOURCE_R_HASH')
    check(hfile(N_PATH)==freeze['output_artifacts_sha256']['common_negative_controls.jsonl'],'SOURCE_N_HASH')
    src_hashes={}
    for fname in ROLE_NAMES:
        canonical=re.sub(r'\(\d+\)(?=\.md$)','',fname)
        digest=hfile(ROOT/fname)
        src_hashes[canonical]=digest
        check(srch.get(canonical)==digest,'SOURCE_MD_HASH',canonical)
    check(state['model']=='gpt-6.2-sol','EVALUATOR_MODEL')
    check(state['batch_size']==16,'BATCH_SIZE')
    check(state['queue_sha256']==hfile(QUEUE_PATH),'QUEUE_SHA')
    # Generation effort and external adjudicator effort are separate factors.
    return src_hashes,pdfh,state

source_hashes,pdfsha,state=original_lock_check()
ref_r=rows(R_PATH);ref_n=rows(N_PATH);G=rows(G_PATH);Q=rows(QUEUE_PATH)
ass=rows(ADJ_PATH);exclusions=rows(EXC_PATH);disp=rows(DIS_PATH)
original_extern=rows(AGG_PATH)
RID=[x['requirement_id'] for x in ref_r];NID=[x['control_id'] for x in ref_n]
GID=[x['class_id'] for x in G]
AID=[x['item_id'] for x in ass];EID=[x['item_id'] for x in exclusions]
QID=[x['item_id'] for x in Q];V5ID=[x['item_id'] for x in original_extern]
check(len(ref_r)==638 and len(ref_n)==142 and len(G)==3072,'FROZEN_POPULATION',{'R':len(ref_r),'N':len(ref_n),'G':len(G)})
for ids,name in [(RID,'R'),(NID,'N'),(GID,'G'),(AID,'A'),(EID,'E'),(QID,'Q'),(V5ID,'V5')]:check(len(ids)==len(set(ids)),'DUPLICATE_ID_'+name)
check(QID[:len(RID)+len(NID)]==RID+NID and set(QID[len(RID)+len(NID):])==set(GID),'QUEUE_ORDER_AND_G_ROLE_SORT')
check(set(AID).isdisjoint(EID),'PHASE07_ACTIVE_EXCLUDED_OVERLAP')
check(set(AID)|set(EID)==set(QID),'PHASE07_ID_COMPLETENESS')
check(len(ass)==3331 and len(exclusions)==521,'PHASE07_RECORD_COUNTS')
assert len(QID)==3852
rmap={x['requirement_id']:x for x in ref_r};nmap={x['control_id']:x for x in ref_n};gmap={x['class_id']:x for x in G};amap={x['item_id']:x for x in ass};emap={x['item_id']:x for x in exclusions}
qmap={x['item_id']:x for x in Q};v5map={x['item_id']:x for x in original_extern}
check([x['item_id'] for x in disp]==QID,'ALL_DISPOSITIONS_ORDER')
for x in disp:
    item=x['item_id']
    check((item in amap and x['final_cell']==amap[item]['final_cell']) or (item in emap and x['final_cell'] is None),'DISPOSITION_CELL',item)

# Validate original physical-page/line quote existence independently of prior ledgers.
mdtexts={fname:(ROOT/fname).read_text(encoding='utf-8').splitlines() for fname in ROLE_NAMES}
mdver=Counter();pdfver=Counter();source_failures=[]
doc=fitz.open(PDF)
check(len(doc)==90,'PDF_PHYSICAL_PAGE_COUNT')
textpages=[norm(page.get_text()) for page in doc]
for a in ass:
    item=a['item_id'];direc=a['direction'];cell=a['final_cell']
    check(a['source_pdf_sha256']==pdfsha,'ADJ_PDF_SHA',item)
    check(a['method']=='fullload','METHOD_LABEL',item)
    if direc=='R':check(item in rmap and cell in ('TP','FN'),'R_CELL',item)
    elif direc=='N':check(item in nmap and cell in ('TN','FP'),'N_CELL',item)
    else:check(direc=='G' and item in gmap and cell in ('TP','FP'),'G_CELL',item)
    for ev in a.get('generated_evidence',[]):
        fn=ev.get('file');st=ev.get('line_start');en=ev.get('line_end');quote=ev.get('quote_en')
        good=(fn in mdtexts and type(st)==int and type(en)==int and 1<=st<=en<=len(mdtexts[fn]) and norm(quote) in norm('\n'.join(mdtexts[fn][st-1:en])))
        if good:
            mdver['passed']+=1
            canonical=re.sub(r'\(\d+\)(?=\.md$)','',fn)
            if ev.get('source_sha256') and ev['source_sha256']!=source_hashes[canonical]:
                source_failures.append({'id':item,'part':'generated_evidence_sha','file':fn})
        else:source_failures.append({'id':item,'part':'generated_evidence_quote','file':fn,'lines':[st,en]});mdver['failed']+=1
    for ev in a.get('pdf_evidence',[]):
        pg=ev.get('physical_page');qt=ev.get('quote_en',ev.get('quote'))
        if type(pg)==int and 1<=pg<=90 and norm(qt) in textpages[pg-1]:pdfver['passed']+=1
        else:pdfver['failed']+=1;source_failures.append({'id':item,'part':'pdf_evidence_quote','physical_page':pg,'quote_excerpt':str(qt)[:130]})
for a in exclusions:
    check(a.get('source_pdf_sha256',pdfsha)==pdfsha and a.get('source_reference_unchanged',False),'EXCLUSION_PDF_SHA',a['item_id'])
    check(a['direction']=='G' and a['reviewed_eligibility']=='NONDEFINITIVE','EXCLUSION_TYPE',a['item_id'])
    for ev in a.get('generated_evidence',[]):
        fn=ev.get('original_file') or ev.get('file');st=ev.get('line_start');en=ev.get('line_end');qt=ev.get('quote_en')
        if fn in mdtexts and type(st)==int and type(en)==int and 1<=st<=en<=len(mdtexts[fn]) and norm(qt) in norm('\n'.join(mdtexts[fn][st-1:en])):mdver['passed_exclusion']+=1
        else:source_failures.append({'id':a['item_id'],'part':'excluded_generated_evidence_quote','file':fn})
check(len(source_failures)==0,'EVIDENCE_ATTRIBUTION_ERRORS',source_failures[:10])

# Independent 241-journal audit, including actual execution SHA and byte-equivalent aggregate rows.
zip_audit=Counter();bad_batches=[];known={}
with zipfile.ZipFile(ZIP_PATH) as z:
    names=sorted(n for n in z.namelist() if n.endswith('.json'))
    check(len(names)==241,'JOURNAL_COUNT',len(names))
    for index in range(241):
        bname=f'B10.6-{index+1:05d}';fn=f'batch_journals/{bname}.json'
        if fn not in z.namelist():bad_batches.append({'id':bname,'issue':'MISSING'});continue
        j=json.loads(z.read(fn));group=Q[index*16:(index+1)*16]
        if not (j.get('batch_id')==bname and j.get('batch_index')==index and j.get('batch_size')==len(group) and j.get('queue_sha256')==state['queue_sha256'] and j.get('pdf_sha256')==pdfsha):bad_batches.append({'id':bname,'issue':'IDENTITY'});continue
        if j.get('input_digest')!=shaobj(group):bad_batches.append({'id':bname,'issue':'INPUT_DIGEST'});continue
        sub=j['item_records']
        if j.get('content_sha256')!=shaobj({'raw_model_json':j['raw_model_json'],'item_records':sub}):bad_batches.append({'id':bname,'issue':'CONTENT_HASH'});continue
        if len(sub)!=len(group) or len(j['raw_model_json'].get('results',[]))!=len(group):bad_batches.append({'id':bname,'issue':'RESULT_LENGTH'});continue
        expected=[x['item_id'] for x in group]
        if [x['item_id'] for x in sub]!=expected or [x['item_id'] for x in j['raw_model_json']['results']]!=expected:bad_batches.append({'id':bname,'issue':'ORDER'});continue
        for x in sub:
            id=x['item_id'];known[id]=x
            if x!=v5map.get(id):bad_batches.append({'id':bname,'issue':'RESULT_DIFFERENT','item_id':id});break
        zip_audit['validated_journals']+=1;zip_audit['validated_items']+=len(sub)
check(len(bad_batches)==0 and len(known)==3852,'EXTERNAL_JOURNAL_INTEGRITY',bad_batches[:8])

# Check the phase07 item input hashes while allowing the distinct documented A/B encoders.
shinput={x['item_id']:x for fn in ['07_shard_A_input.jsonl','07_shard_B_input.jsonl'] for x in rows(BASE/'phase07_sharded'/fn)}
check(set(shinput)==set(QID),'SHARD_INPUT_UNION')
input_hash=Counter()
for x in ass+exclusions:
    id=x['item_id'];prior=x.get('input_item_hash') or x.get('input_item_sha256')
    if prior is None:
        input_hash['not_recorded_in_original_B_eligibility_row']+=1;continue
    expected={shaobj(shinput[id]),hbytes(json.dumps(shinput[id],ensure_ascii=False,sort_keys=True).encode()),hbytes(json.dumps(shinput[id],sort_keys=True).encode())}
    if prior in expected:input_hash['verified_with_shard_serialization']+=1
    else:input_hash['not_matching_known_serializer']+=1
check(input_hash['not_matching_known_serializer']==0,'SHARD_INPUT_HASH_MISMATCH',dict(input_hash))

# Validate effective eligible generated occurrences; leave Phase 05 inputs unchanged.
active_g=[x for x in G if x['class_id'] not in emap]
check(len(active_g)==2551,'EFFECTIVE_GC_COUNT')
raw_occ=sum(x['effective_occurrence_count'] for x in G)
active_occ=sum(x['effective_occurrence_count'] for x in active_g)
check(raw_occ==3119 and active_occ==2598,'EFFECTIVE_GO_OCCURRENCES')
check(set(g['class_id'] for g in active_g)=={x['item_id'] for x in ass if x['direction']=='G'},'ELIGIBLE_GC_CROSSWALK')

# Conservatively consolidate *proven repeated unsupported residuals* only.
# Equivalent rows use the same underlying target/condition; parallel UI fields
# with identical words but different field identifiers remain separate.
# The mixed-classification and partial-failure fixture residuals are separate.
GROUPS=[
  {'keys':['GCLASS-0000380','GCLASS-0002347'],'residual':'Require the actual evaluation scorecard and confidence to be displayed by the UI upon evaluation completion.','why':'Same Usage & Quality scorecard presentation obligation, differently repeated in screen and exception specifications.'},
  {'keys':['GCLASS-0000890','GCLASS-0002060'],'residual':'Require internal policy/provenance evidence, rather than an invented public classification field, as the mandated verification channel for mixed-class controls.','why':'Both impose the identical acceptance-test oracle restriction.'},
  {'keys':['GCLASS-0001710','GCLASS-0002486'],'residual':'Require fingerprint and negative-access probe verification before resuming affected delayed-indexing/ACL-leak incident work.','why':'Both impose the same pre-resumption verification barrier on the same incident/recovery journey.'},
  {'keys':['GCLASS-0001438','GCLASS-0002665'],'residual':'Require approved region and equal-or-stronger handling for every model fallback, beyond the narrower source-class-specific fallback boundary.','why':'Same globally broadened fallback-routing restriction in two workflow specifications.'},
  {'keys':['GCLASS-0000751','GCLASS-0002136'],'residual':'Require separately appended revision/decision history records to share the mutation/outbox atomic unit throughout the generic shared transaction path.','why':'Same broadened ACID history-boundary obligation across API and processing specifications.'},
  {'keys':['GCLASS-0000589','GCLASS-0001137','GCLASS-0002602'],'residual':'Require a full evidence/approval publication gate on the specific IN_PROGRESS to RESOLVED case transition.','why':'The same SCR-002-T04 source-state edge, applicable guards and extra publication linkage are repeated across three files.'},
  {'keys':['GCLASS-0001139','GCLASS-0002603'],'residual':'Require the PENDING_APPROVAL to IN_PROGRESS transition to be the authorized rework path without automatic transition on every Reject decision.','why':'Same SCR-002-T06 transition and same rework-versus-rejection qualification.'},
  {'keys':['GCLASS-0000859','GCLASS-0001234','GCLASS-0002053'],'residual':'Require mixed-classification fixtures as a mandatory acceptance-test category.','why':'Independent specifications repeat the same unsupported mandatory mixed-classification fixture; the longer GCLASS-0002053 also contains a distinct partial-failure fixture obligation.'},
]
EXTRA={'GCLASS-0002053':{'residual':'Require partial-failure fixtures as a separately mandatory acceptance-test category.','why':'A separate independently testable unsupported fixture requirement inside the composite acceptance criteria; not synonymous with mixed-classification.'}}
all_fp=[x for x in ass if x['direction']=='G' and x['final_cell']=='FP']
fp_map={x['item_id']:x for x in all_fp};check(len(all_fp)==255,'FP_CLASS_COUNT')
member_group={}
for n,group in enumerate(GROUPS):
    for gid in group['keys']:
        check(gid in fp_map,'MERGE_NON_FP_CLASS',gid)
        check(gid not in member_group,'OVERLAPPING_MERGE_FAMILY',gid)
        member_group[gid]=n
# All unlisted FPs remain separate. This is conservative; a high lexical
# similarity alone is insufficient for whole-proposition mutual entailment.
clusters=[];observed=set()
for x in all_fp:
    id=x['item_id']
    if id in member_group:
        n=member_group[id]
        if ('group',n) not in observed:
            group=GROUPS[n]
            clusters.append({'member_ids':group['keys'],'residual':group['residual'],'rule':'VERIFIED_SAME_UNSUPPORTED_PREDICATE_AND_SCOPE','why':group['why'],'source':'PHASE07_UNSUPPORTED_G_CLASS','additional_obligation':False})
            observed.add(('group',n))
    else:
        gap=x.get('unmet_predicates_en') or []
        statement=gmap[id]['statement_en']
        clusters.append({'member_ids':[id],'residual':statement,'rule':'NO_EVIDENCED_COMPLETE_EQUIVALENT','why':'Retained separately because no mutually entailed, scope-identical unsupported residual is established in the available proof-family record.','source':'PHASE07_UNSUPPORTED_G_CLASS','additional_obligation':False,'source_gap':gap})
    if id in EXTRA:
        e=EXTRA[id]
        clusters.append({'member_ids':[id],'residual':e['residual'],'rule':'DISTINCT_COMPONENT_OF_COMPOSITE_G_CLAIM','why':e['why'],'source':'PHASE07_UNSUPPORTED_G_CLASS','additional_obligation':True})
check(set(k for c in clusters for k in c['member_ids'])==set(fp_map),'FP_RESIDUAL_COVERAGE')
# Same original GC can map to >1 F only when separated material predicates exist.
residuals=[];class_to_res=defaultdict(list)
for n,c in enumerate(clusters,1):
    rid=f'F-{n:05d}'
    m=c['member_ids'];source_docs={}
    for k in m:
        for ev in fp_map[k].get('generated_evidence',[]):
            role=ev.get('canonical_role') or re.sub(r'\(\d+\)(?=\.md$)','',ev.get('file',''))
            if role in source_hashes:source_docs[role]=source_hashes[role]
    entry={'record_type':'FINAL_RESIDUAL','residual_id':rid,'scoring_cell':'FP','method':'fullload',
           'unsupported_residual_en':c['residual'],'class_ids':m,'source_spec_sha256':source_docs,
           'pdf_sha256':pdfsha,'decision_origin':'PHASE07_G_FP_WITH_PHASE08_SEMANTIC_CONSOLIDATION',
           'consolidation_rule':c['rule'],'consolidation_reason_en':c['why'],
           'phase07_g_verdicts_unchanged':True,'n_overlap_control_ids':[],
           'pdf_evidence_by_class':{k:fp_map[k]['pdf_evidence'] for k in m},
           'generated_evidence_by_class':{k:fp_map[k]['generated_evidence'] for k in m}}
    if c.get('source_gap'):entry['unmet_pdf_predicates_en']=c['source_gap']
    residuals.append(entry)
    for k in m:class_to_res[k].append(rid)

# Confirm source negative-control polarity is consistent with Phase 07-C N:TN.
# This prevents a generated *prohibition* from becoming an N affirmative FP.
Ncontrols=[amap[n] for n in NID]
B=[n for n in NID if amap[n]['final_cell']=='FP']
check(len(B)==0,'FROZEN_N_FP_COUNT')
# A Phase 07 N:FP would require explicit N/F overlap checks here; no N:FP exists.
neg_cross=rows(BASE/'phase07_C_completed/07_cross_shard_N_G_polarity_leads.jsonl')
check(len(neg_cross)==142,'N_G_CROSSWALK_TOTAL')
negative_cross_by_id={x['item_id']:x for x in neg_cross}
check(set(negative_cross_by_id)==set(NID),'N_G_ALL_FIXED_IDS')

# Build full canonical ledger preserving every Phase07 G decision as diagnostic.
ledger=[]
for ref in ref_r:
    id=ref['requirement_id'];a=amap[id]
    ledger.append({'record_type':'FINAL_SOURCE','method':'fullload','source_id':id,'scoring_cell':a['final_cell'],
                   'source_statement_en':ref['statement_en'],'source_pdf_sha256':pdfsha,
                   'pdf_evidence':a['pdf_evidence'],'generated_evidence':a['generated_evidence'],
                   'decision_origin':a['decision_origin'],'decision_rule_id':a['decision_rule_id'],
                   'phase07_item_id':id,'final_phase07_record_sha256':shaobj(a),
                   'fully_supported_predicates_only_for_TP':a['final_cell']=='TP',
                   'missing_predicates_en':a.get('unmet_predicates_en',[])})
for ref in ref_n:
    id=ref['control_id'];a=amap[id]
    ledger.append({'record_type':'FINAL_CONTROL','method':'fullload','control_id':id,'scoring_cell':a['final_cell'],
                   'counterfactual_en':ref['counterfactual_en'],'source_pdf_sha256':pdfsha,
                   'pdf_evidence':a['pdf_evidence'],'generated_evidence':a['generated_evidence'],
                   'decision_origin':a['decision_origin'],'decision_rule_id':a['decision_rule_id'],
                   'phase07_item_id':id,'final_phase07_record_sha256':shaobj(a),
                   'affirmed_forbidden_counterfactual':a['final_cell']=='FP',
                   'N_G_polarity_crosswalk_present':id in negative_cross_by_id})
for g in G:
    id=g['class_id']
    if id in emap:continue
    a=amap[id]
    ledger.append({'record_type':'FINAL_CLASS','method':'fullload','class_id':id,
                   'diagnostic_cell':a['final_cell'],'provenance_category':'PDF_ENTAILED' if a['final_cell']=='TP' else 'PDF_UNSUPPORTED',
                   'canonical_tp_increment':0,'canonical_fp_residual_ids':class_to_res.get(id,[]),
                   'effective_occurrence_count':g['effective_occurrence_count'],
                   'generated_statement_en':g['statement_en'],'source_pdf_sha256':pdfsha,
                   'pdf_evidence':a['pdf_evidence'],'generated_evidence':a['generated_evidence'],
                   'decision_origin':a['decision_origin'],'phase07_item_id':id,'final_phase07_record_sha256':shaobj(a),
                   'supported_noncovering_R_bridge_not_presumed':True})
ledger.extend(residuals)
# Keep excluded G transparent, without fake fifth canonical cell.
excluded_ledger=[{'record_type':'EXCLUDED_NONDEFINITIVE_CLASS','method':'fullload','class_id':g['class_id'],
                  'prior_phase05_eligibility':'DEFINITIVE','phase07_reviewed_eligibility':'NONDEFINITIVE',
                  'phase07_exclusion_sha256':shaobj(emap[g['class_id']]),'original_GC_sha256':shaobj(g),
                  'effective_occurrence_count':g['effective_occurrence_count'],
                  'statement_en':g['statement_en'],'canonical_scoring_cell':None,
                  'not_counted_as_FP_or_TN':True,'generated_evidence':emap[g['class_id']].get('generated_evidence',[])} for g in G if g['class_id'] in emap]
check(len(excluded_ledger)==521,'EXCLUDED_GC_LEDGER_COUNT')

totals=Counter(x['record_type'] for x in ledger)
TP=sum(amap[k]['final_cell']=='TP' for k in RID)
FN=sum(amap[k]['final_cell']=='FN' for k in RID)
FP_N=sum(amap[k]['final_cell']=='FP' for k in NID)
TN=sum(amap[k]['final_cell']=='TN' for k in NID)
F=len(residuals);FP=FP_N+F
check(TP+FN==638 and FP_N+TN==142 and F>=0,'CONFUSION_INVARIANTS')
check(totals=={'FINAL_SOURCE':638,'FINAL_CONTROL':142,'FINAL_CLASS':2551,'FINAL_RESIDUAL':F},'LEDGER_RECORD_TOTALS',dict(totals))

# Record candidate equivalence choices and negative-control crosschecks.
merge_records=[]
for group in GROUPS:
    merge_records.append({'record_type':'CONFIRMED_RESIDUAL_CONSOLIDATION','group_member_ids':group['keys'],
        'rule':'MUTUAL_ENTAILMENT_OF_SAME_UNSUPPORTED_PREDICATE_WITH_APPLICABLE_SCOPE',
        'unsupported_residual_en':group['residual'],'basis_en':group['why'],
        'all_member_Phase07_cells':'FP','final_residual_ids':sorted(set(r for id in group['keys'] for r in class_to_res[id]))})
merge_records.append({'record_type':'SPLIT_COMPOSITE_UNSUPPORTED_OBLIGATIONS','group_member_ids':['GCLASS-0002053'],
    'unsupported_residuals_en':['Mandatory mixed-classification acceptance-test fixture','Mandatory partial-failure acceptance-test fixture'],
    'reason_en':'These are different independently testable test-input categories; do not overmerge.'})
# A set of high lexical pairs may contain distinct scopes; do not collapse them.
for pair in [
    ('GCLASS-0000372','GCLASS-0000373','Citation precision vs unsupported-claim rate are distinct metric fields.'),
    ('GCLASS-0000373','GCLASS-0000374','Unsupported-claim rate vs policy recall are distinct metric fields.'),
    ('GCLASS-0000103','GCLASS-0000105','Case Queue priority and owner/sensitivity are distinct field contracts.'),
    ('GCLASS-0000303','GCLASS-0000307','Connector sync-run status and retry/throttling metadata are distinct fields.'),
    ('GCLASS-0002371','GCLASS-0002372','Partial purge outcome and force-delete prohibition are distinct obligations in one table row.'),
    ('GCLASS-0001630','GCLASS-0001631','Retaining rejection evidence is not the same as banning silent overwrite or latest-revision retry.'),
    ('GCLASS-0002331','GCLASS-0002332','Verified purge receipt linkage differs from prohibition on unsupported restoration/receipt overwrite.'),
    ('GCLASS-0001703','GCLASS-0001704','Required fault-injection sequence differs from completion-of-provisioning outcome.'),
    ('GCLASS-0002257','GCLASS-0002258','Persistence of a model attempt differs from public-error privacy requirements.'),
    ('GCLASS-0000974','GCLASS-0000977','Immutable technical identity differs from the prohibition against deriving identity from illustrative business references.'),
    ('GCLASS-0003018','GCLASS-0003019','Explicit export/provisioning exclusion differs from positive purpose of the purge event.'),
]:
    u,v,why=pair
    if u in fp_map and v in fp_map:merge_records.append({'record_type':'REJECTED_LEXICAL_DUPLICATE','group_member_ids':[u,v],'basis_en':why,'decision_rule':'NOT_MUTUALLY_ENTAILING_AS_COMPLETE_UNSUPPORTED_OBLIGATIONS'})

# Document potential source-level semantic disputes for future Phase 07 audit,
# without issuing competing semantic verdicts or modifying a Phase 07 cell.
for item in ['GCLASS-0000025','GCLASS-0000528','GCLASS-0000531']:
    if item in fp_map:
        audit.append({'record_type':'PREEXISTING_SEMANTIC_CLASSIFICATION_LIMITATION','item_id':item,
                      'phase07_cell':fp_map[item]['final_cell'],
                      'disposition':'PHASE07_CELL_PRESERVED_NO_NEW_PHASE08_ITEM_JUDGMENT',
                      'reason_en':'Direct wording or a related API in the PDF may warrant later source-grounded review of the extent/scope of this unsupportedness assertion. Phase 08 does not convert this review lead into a replacement cell.'})

# Phase 08 cannot certify semantic certainty beyond the original Phase 07 proof.
audit.extend([
 {'record_type':'INTEGRITY_RECONCILIATION','status':'PASSED' if not errors else 'FAILED','scope_en':'Frozen R/N/source identity, eight original files, full queue, 241 committed v5 journals, all 3,852 original IDs and source quote provenance.','details':{'errors':len(errors),'MD_quote_checks':dict(mdver),'PDF_quote_checks':dict(pdfver),'journal_checks':dict(zip_audit),'input_hash_checks':dict(input_hash)}},
 {'record_type':'ELIGIBILITY_CHANGE_AUDIT','status':'TRACKED_AS_IMMUTABLE_PHASE07_SUPERSESSIONS','change_count':len(exclusions),'excluded_GC':len(excluded_ledger),'source_R_N_unchanged':True,'phase05_original_GC_unchanged':True,'effective_GC':len(active_g),'effective_GO_occurrences':active_occ},
 {'record_type':'N_F_OVERLAP_AUDIT','fixed_N_positives':FP_N,'eligible_G_FP_classes':len(all_fp),
  'overlapping_N_and_F_claims':0,'reason_en':'All 142 frozen negative controls retain evidence-based Phase 07 TN decisions; candidate G statements that prohibit a negative control are not affirmative violations. No matching positive N-counterfactual assertion was established by the original N/G crosswalk.'},
 {'record_type':'PHASE08_COUNT_RECONCILIATION','TP':TP,'FN':FN,'N_FP':FP_N,'TN':TN,'F_unique':F,
  'FP_total':FP,'canonical_U_size':638+142+F,'population_checks':['TP+FN=R','N_FP+TN=N','FP=N_FP+F','TP+TN+FP+FN=R+N+F'],
  'no_Phase09_metric_arithmetic_in_this_phase':True},
 {'record_type':'COMPARABILITY_DEVIATION','actual_external_model':state['model'], 'actual_batch_size':state['batch_size'],
  'actual_reasoning_effort':'high','reported_protocol_default':'gpt-6.1-sol / medium',
  'meaning_en':'The operator used the actual gpt-6.2-sol/high evaluator run for all supplied external judgments. Other-method execution identity remains outside the single-method Phase 08 scope.'},
 {'record_type':'SEMANTIC_LIMITATION','status':'DISCLOSED','detail_en':'Phase07-A/B decisions were machine-assisted. Phase08 mechanically verifies immutable evidence records and consolidates documented residual families; it does not independently recast uncertain semantic judgments as certain or claim that every non-equal paraphrase has been exhaustively proved distinct.'},
])

write_jsonl(OUT/'08_final_ledger.jsonl',ledger)
write_jsonl(OUT/'08_excluded_classes.jsonl',excluded_ledger)
write_jsonl(OUT/'08_residual_consolidation.jsonl',merge_records)
write_jsonl(OUT/'08_reconciliation_audit.jsonl',audit)
write_jsonl(OUT/'08_input_integrity_failures.jsonl',errors+source_failures+bad_batches)
counts={'record_type':'PHASE08_BINARY_COUNTS','protocol_version':'10.6','method':'fullload',
 'phase':'08','status':'PHASE_COMPLETED' if not errors else 'INCOMPLETE','R':638,'N':142,
 'GO_phase05_frozen':raw_occ,'GC_phase05_frozen':len(G),'GC_phase07_nondefinitive_supersessions':len(excluded_ledger),
 'GO_effective_eligible':active_occ,'GC_effective_eligible':len(active_g),
 'GO_excess_duplicate_occurrences':active_occ-len(active_g),
 'R_TP':TP,'R_FN':FN,'N_FP':FP_N,'N_TN':TN,'G_diagnostic_TP':sum(amap[k]['final_cell']=='TP' for k in GID if k in amap),
 'G_diagnostic_FP':len(all_fp),'G_nondefinitive_excluded':len(excluded_ledger),
 'F_unique_residual_units':F,'FP_total':FP,'canonical_population_size':638+142+F,
 'counting_invariants':{'TP_plus_FN_equals_R':TP+FN==638,'N_FP_plus_TN_equals_N':FP_N+TN==142,
                        'FP_equals_N_FP_plus_F':FP==FP_N+F,'population_equals_R_plus_N_plus_F':TP+FN+FP+TN==638+142+F},
 'phase07C_unchanged':True,'phase08_Decision_origin':'PHASE07_C_INTEGRATED_FINAL',
 'external_run':{'model':state['model'],'reasoning_effort':'high','batch_size':state['batch_size'],'batches':241,
                 'queue_SHA256':state['queue_sha256'],'execution_deviation_from_protocol_printed_default':True},
 'metrics_computed_here':False,'precision':None,'recall':None,'F1':None,
 'integrity_errors':errors[:30],'source_quote_errors':source_failures[:30],
 'reconciliation_family_count':len(GROUPS),'unsupported_composite_split_count':len(EXTRA),
 'semantic_audit_limitations':['Machine-assisted Phase 07 cells are not independently guaranteed correct.',
   'Conservative equivalence requires proof; unlike-scoped statements are kept separate even where terminology is similar.',
   'The 521 excluded original GC classes were superseded in Phase 07; original Phase 05 records were not changed.']}
write_json(OUT/'08_binary_counts.json',counts)
files=[x for x in OUT.iterdir() if x.is_file() and x.name not in ('08_delivery_manifest.json','reconcile_phase08.py','08_execution_checks.log')]
manifest={'record_type':'PHASE08_DELIVERY_MANIFEST','protocol_version':'10.6','method':'fullload',
 'status':counts['status'],'artifacts':[{'name':f.name,'bytes':f.stat().st_size,'sha256':hfile(f)} for f in sorted(files)],
 'source_sha256':{'PDF':pdfsha,'R':hfile(R_PATH),'N':hfile(N_PATH),'queue':hfile(QUEUE_PATH),'g_ledger':hfile(G_PATH),
                 'phase07C_adjudications':hfile(ADJ_PATH),'phase07C_exclusions':hfile(EXC_PATH),'external_decisions':hfile(AGG_PATH),'external_journal_zip':hfile(ZIP_PATH)},
 'metric_computation_deferred_to_phase09':True}
write_json(OUT/'08_delivery_manifest.json',manifest)
print(json.dumps({'status':counts['status'],'counts':{k:counts[k] for k in ['R_TP','R_FN','N_FP','N_TN','G_diagnostic_TP','G_diagnostic_FP','G_nondefinitive_excluded','F_unique_residual_units','FP_total','canonical_population_size']},
 'ledger_counts':dict(totals),'integrity_errors':len(errors),'source_failures':len(source_failures),
 'quote_checks':{'markdown':dict(mdver),'PDF':dict(pdfver)},'journals':dict(zip_audit),'input_hash_checks':dict(input_hash)},ensure_ascii=False,indent=2))
if errors:raise SystemExit('Phase08 blocking integrity errors: '+jd(errors[:4]))
