# Phase 09 — Independent Metric Computation

## Scope and authority

- Protocol: **10.6**; generation method: **fullload**.
- Positive/negative reference: frozen R = **638**, N = **142**, with unchanged SHA-256 identities.
- Canonical count authority: independently parsed `08_final_ledger.jsonl` and verified Phase 07 decisions, **not** the Azure evaluator's item-level proposals.
- Input reference status: `REFERENCE_FROZEN_PROVISIONAL`. Full semantic coverage of the PDF was not independently proven by this phase.

## Canonical confusion matrix and metric arithmetic

| Actual population | Predicted requirement present | Predicted requirement absent |
|---|---:|---:|
| PDF-positive R | TP = **520** | FN = **118** |
| Fixed negative controls and unsupported residuals | FP = **246** | TN = **142** |

- `TP + FN = 520 + 118 = 638 = R`.
- `TN + N_FP = 142 + 0 = 142 = N`.
- `FP = N_FP + F = 0 + 246 = 246`.
- `TP + TN + FP + FN = 1026 = R + N + F`.

| Metric | Exact equation | Percentage |
|---|---|---:|
| Precision | `520 / (520 + 246)` | **67.8851%** |
| Recall | `520 / (520 + 118)` | **81.5047%** |
| F1 | `2 * 520 / (2 * 520 + 246 + 118)` | **74.0741%** |
| Negative-control pass rate | `142 / 142` | 100.0000% |
| GC validity | `2296 / 2551` | 90.0039% |
| Duplicate | `(2598 - 2551) / 2598` | 1.8091% |

These scores measure completeness and correctness **relative to the frozen sample reference and this run's adjudication ledger**. They are not independent production performance measurements.

## Generated-population and false-positive reconciliation

- Original Phase 05: GO = **3119**, GC = **3072**.
- Phase 07 excluded **521** classes as nondefinitive, with superseding audit records; effective GO = **2598**, GC = **2551**.
- Eligible GC diagnostic labels: **2296** PDF-supported and **255** PDF-unsupported.
- **255** unsupported GC claims map to **246** unique generated-only residuals. The consolidation log identifies eight merge families and one composite split. No affirmative fixed-negative-control overlap was established; N-derived FP = **0**.
- Raw eligible duplicate excess: **47**, consisting of **4** within-file and **43** across-file excess occurrences. Cross-file repeated class count = **38**. Duplicates do **not** multiply TP or FP.

## Original external review and Phase 07 closure

- Frozen queue: **3852** IDs, SHA-256 `419ccddc7068a6a4a3f5644a0f9617b95e9fcb52de2cdf9ccfe42ab19b6d8eef`.
- Actual external run metadata: **gpt-6.2-sol**, batches of **16**, concurrency **4**, three allowed additional retries, **241** committed batch journals and **242** submission attempts.
- The original Phase 06 preparation manifest fixed 8-item batch boundaries, whereas the actual external execution used 16-item batches. Item/queue identities and journal content validate, but this execution-contract deviation is documented and must be considered before comparing methods.
- Original v5 proposals: {"EXCLUDED_NONDEFINITIVE": 505, "FN": 4, "NOT_FP": 2224, "None": 609, "TN": 2, "TP": 508}.
- Original `decision_status=UNRESOLVED`: **615**; `suggested_decision=null`: **609**. All are linked to the final Phase 07 binary or documented nondefinitive-exclusion disposition; they are not blindly changed to negative cells.
- The file `semantic_decisions(4).jsonl` retains each original confidence estimate and quotation verifier result. Confidence is a model self-report, **not calibrated validity**.
- External model's reasoning effort is reported as **high** in the Phase 07 evidence record, but the supplied `run_state(3).json` does not itself contain a reasoning-effort key; do not call this an independently authenticated request parameter. The original generation setting was operator-specified `xhigh`.

## Independent verification

- 69,186 / 69,186 assertions passed; zero integrity errors.
- PDF physical pages = 90; original Markdown roles = 8.
- Direct PDF-page quotation checks = **6909**; original Markdown-line quotation checks (including exclusions) = **4542**.
- All 241 original batch journals and 3,852 external item rows were checked against the source queue and aggregated records.
- Per-record Phase 07 adjudication hashes, Phase 08 final cell joins, and complete R/N/GC/residual ID population were reconciled.

## Conclusions and qualifications

The arithmetic single-method metrics above are **complete for the supplied Phase 08 ledger**. This does not certify that every machine-assisted Phase 07 semantic verdict is substantively correct. The original Phase 05 eligibility register was superseded in 521 cases without mutating its bytes. The generated-only residual count reflects documented proof-family checks, not an exhaustive mathematical proof of all possible semantic equivalences.

**Cross-method comparability is NOT independently established in this run.** The operator reports use of `gpt-6.2-sol` across methods, while the protocol's printed model/effort defaults were `gpt-6.1-sol / medium`; the recorded external run here used `gpt-6.2-sol` with effort `high` as reported in Phase 07. No onelevel/twolevel execution fingerprints and completed comparison ledgers were supplied for independent matching in Phase 09. The completed fullload metric remains internally calculable; a cross-method ranking must wait for independent configuration equivalence checks.
