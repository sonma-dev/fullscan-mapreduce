OrionDesk AI — Full Load Atomic Evaluation, Protocol 10.6

This archive contains evaluation artifacts organized by stage:
phase-1 through phase-6, phase-7.1 (Shard A), phase-7.2 (Shard B),
phase-7.3 (Shard C), phase-8, and phase-9.

The final Shard A outputs are directly under phase-7.1; its original
incomplete audit and continuation are under phase-7.1/history.
Shard preparation and instructions are retained under setup folders.
The external evaluation inputs/results, including the original batch
journals ZIP, are preserved under phase-6/external_evaluation.
The unmodified source PDF, Markdown files, frozen reference and governing
protocol are preserved under phase-1/input_originals.

The SHA-256 manifest enumerates each archived payload except the manifest
and this README. Files were copied unchanged; no phase data was revised.
