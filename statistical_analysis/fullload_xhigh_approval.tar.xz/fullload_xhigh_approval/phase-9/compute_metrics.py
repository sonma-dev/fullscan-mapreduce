#!/usr/bin/env python3
"""Independent Phase 09 calculation and reproducibility audit for OrionDesk v10.6.

Reads the immutable original inputs and Phase 07/08 outputs. Does not edit an
input, infer an absent semantic judgment, or use external LLM suggestions as
canonical TP/FN/TN/FP cells. Scores are emitted ONLY after integrity gates pass.
"""
from __future__ import annotations

import argparse
from collections import Counter, defaultdict
from fractions import Fraction
from hashlib import sha256
import json
from pathlib import Path
import re
import unicodedata
from zipfile import ZipFile

try:
    import fitz
except ImportError:
    fitz = None

ROLE_NAMES = [
    '01_screen_functions(2).md', '02_api(2).md', '03_data(2).md',
    '04_batch_functions(3).md', '05_business_rules(2).md',
    '06_exception_handling(4).md', '07_processing_flows(4).md',
    '08_architecture_decision(3).md',
]


def jsonl(path):
    with path.open('r', encoding='utf-8-sig') as stream:
        return [json.loads(line) for line in stream if line.strip()]


def read_json(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def digest(path):
    h = sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(2**20), b''):
            h.update(block)
    return h.hexdigest()


def canonical(obj):
    return json.dumps(obj, ensure_ascii=False, sort_keys=True, separators=(',', ':'))


def object_sha(obj):
    return sha256(canonical(obj).encode('utf-8')).hexdigest()


def normalize(text):
    return ' '.join(unicodedata.normalize('NFKC', str(text)).split()).casefold()


def percentage(v):
    return None if v is None else round(100.0 * float(v), 4)


def main(root, base, output):
    errors = []
    observations = []
    checks = Counter()

    def check(statement, label, details=None):
        checks['performed'] += 1
        if statement:
            checks['passed'] += 1
        else:
            errors.append({'code': label, 'detail': details})

    pdf_file = root/'OrionDesk_AI_Detailed_Design_Specification(2).pdf'
    r_file = root/'common_atomic_reqs(2).jsonl'
    n_file = root/'common_negative_controls(2).jsonl'
    freeze_file = root/'reference_freeze(2).json'
    source_lock = read_json(base/'phase01/01_reference_lock.json')
    source_manifest = read_json(base/'phase01/01_source_reference_manifest.json')
    phase05_summary = read_json(base/'phase05/05_validity_summary.json')
    phase06_selection = read_json(base/'phase06/06_queue_selection.json')
    phase07_summary = read_json(base/'phase07_C_completed/07_adjudication_summary.json')
    phase08_counts = read_json(base/'phase08/08_binary_counts.json')
    phase08_manifest = read_json(base/'phase08/08_delivery_manifest.json')
    run = read_json(root/'run_state(3).json')
    external_summary = read_json(root/'semantic_summary(3).json')

    source_hashes = {'PDF': digest(pdf_file), 'R': digest(r_file), 'N': digest(n_file), 'reference_freeze': digest(freeze_file)}
    expected_freeze = read_json(freeze_file)
    check(source_hashes['PDF'] == expected_freeze['source_document']['sha256'] == source_lock['original_pdf_sha256'], 'PDF_DIGEST')
    check(source_hashes['R'] == expected_freeze['output_artifacts_sha256']['common_atomic_reqs.jsonl'] == source_lock['positive_reference_sha256'], 'R_DIGEST')
    check(source_hashes['N'] == expected_freeze['output_artifacts_sha256']['common_negative_controls.jsonl'] == source_lock['negative_reference_sha256'], 'N_DIGEST')
    check(source_hashes['reference_freeze'] == source_lock['reference_freeze_sha256'], 'REFERENCE_FREEZE_DIGEST')
    check(source_lock['spec_gen_method'] == 'fullload' and source_lock['protocol_version'] == '10.6', 'REFERENCE_METHOD_AND_VERSION')
    check(source_manifest['role_count'] == len(ROLE_NAMES) == 8, 'EIGHT_ORIGINAL_MARKDOWN_ROLES')
    original_files = {}
    markdown_lines = {}
    for expected_name, manifest_role in zip(ROLE_NAMES, source_manifest['roles_in_source_order']):
        file_path = root/expected_name
        actual_sha = digest(file_path)
        original_files[re.sub(r'\(\d+\)(?=\.md$)', '', expected_name)] = actual_sha
        markdown_lines[expected_name] = file_path.read_text(encoding='utf-8').splitlines()
        check(manifest_role['actual_filename'] == expected_name and manifest_role['sha256'] == actual_sha, 'MD_ORIGINAL_IDENTITY', expected_name)
        check(run['file_sha256'].get(re.sub(r'\(\d+\)(?=\.md$)', '', expected_name)) == actual_sha, 'EXTERNAL_MD_DIGEST', expected_name)
    check(run['pdf_sha256'] == source_hashes['PDF'], 'EXTERNAL_PDF_DIGEST')
    check(phase07_summary['source_pdf_sha256'] == source_hashes['PDF'], 'PHASE07_PDF_DIGEST')
    check(phase08_counts['method'] == 'fullload' and phase08_counts['status'] == 'PHASE_COMPLETED', 'PHASE08_STATUS')
    check(phase08_manifest['status'] == 'PHASE_COMPLETED', 'PHASE08_MANIFEST_STATUS')
    check(phase08_manifest['source_sha256']['PDF'] == source_hashes['PDF'], 'PHASE08_MANIFEST_PDF')
    check(phase08_manifest['source_sha256']['R'] == source_hashes['R'] and phase08_manifest['source_sha256']['N'] == source_hashes['N'], 'PHASE08_MANIFEST_RN')

    # Verify immutable Phase 08 deliverables, with no recalculation from its claimed totals.
    for artifact in phase08_manifest['artifacts']:
        path = base/'phase08'/artifact['name']
        check(path.is_file() and digest(path) == artifact['sha256'] and path.stat().st_size == artifact['bytes'], 'PHASE08_ARTIFACT_DIGEST', artifact['name'])

    if fitz:
        with fitz.open(pdf_file) as doc:
            physical_pages = len(doc)
            pdf_text = [normalize(page.get_text()) for page in doc]
        check(physical_pages == 90 == expected_freeze['source_document']['physical_pages'], 'PDF_90_PAGES')
    else:
        physical_pages = None
        pdf_text = []
        check(False, 'PDF_PAGE_VERIFIER_UNAVAILABLE', 'Install PyMuPDF to validate the 90-page source.')

    r_rows = jsonl(r_file)
    n_rows = jsonl(n_file)
    g_rows = jsonl(base/'phase05/05_effective_generated_classes.jsonl')
    go_rows = jsonl(base/'phase02/02_generated_atoms_final.jsonl')
    recovered_go = jsonl(base/'phase05/05_recovered_generated_atoms.jsonl')
    phase07_final = jsonl(base/'phase07_C_completed/07_assistant_adjudications.jsonl')
    phase07_excluded = jsonl(base/'phase07_C_completed/07_eligibility_supersessions.jsonl')
    phase07_dispositions = jsonl(base/'phase07_C_completed/07_all_original_ids_disposition.jsonl')
    phase08_rows = jsonl(base/'phase08/08_final_ledger.jsonl')
    phase08_excluded = jsonl(base/'phase08/08_excluded_classes.jsonl')
    residual_audit = jsonl(base/'phase08/08_residual_consolidation.jsonl')
    queue = jsonl(base/'phase06/06_llm_queue_v10.6.jsonl')
    external = jsonl(root/'semantic_decisions(4).jsonl')

    ref_ids = [x['requirement_id'] for x in r_rows]
    neg_ids = [x['control_id'] for x in n_rows]
    gc_ids = [x['class_id'] for x in g_rows]
    qids = [x['item_id'] for x in queue]
    check(len(r_rows) == 638 and len(n_rows) == 142 and len(g_rows) == 3072, 'REFERENCE_COUNTS', [len(r_rows), len(n_rows), len(g_rows)])
    for label, sequence in [('R', ref_ids), ('N', neg_ids), ('GC', gc_ids), ('QUEUE', qids)]:
        check(len(sequence) == len(set(sequence)), 'UNIQUE_IDS_'+label)
    check(len(queue) == len(r_rows)+len(n_rows)+len(g_rows) == 3852, 'UNBOUNDED_QUEUE_FULL_POPULATION')
    check(qids[:len(ref_ids)+len(neg_ids)] == ref_ids + neg_ids and set(qids[len(ref_ids)+len(neg_ids):]) == set(gc_ids), 'QUEUE_REFERENCE_AND_GC_COVERAGE')
    check(digest(base/'phase06/06_llm_queue_v10.6.jsonl') == run['queue_sha256'] == phase06_selection['queue_sha256'], 'QUEUE_DIGEST')
    check(all(x['record_type'] == 'UNRELIABLE_ITEM' and x['unreliable'] is True for x in queue), 'QUEUE_ITEM_SCHEMA')

    phase07_by_id = {x['item_id']: x for x in phase07_final}
    ex_by_id = {x['item_id']: x for x in phase07_excluded}
    check(len(phase07_by_id)==len(phase07_final)==3331, 'PHASE07_UNIQUE_BINARY')
    check(len(ex_by_id)==len(phase07_excluded)==521, 'PHASE07_UNIQUE_EXCLUDED')
    check(set(phase07_by_id).isdisjoint(ex_by_id) and set(phase07_by_id)|set(ex_by_id)==set(qids), 'PHASE07_EXACT_DISPOSITION_PARTITION')
    check([x['item_id'] for x in phase07_dispositions] == qids, 'PHASE07_ORDERED_DISPOSITIONS')
    for row in phase07_dispositions:
        item=row['item_id']
        check((item in phase07_by_id and row['final_cell']==phase07_by_id[item]['final_cell']) or (item in ex_by_id and row['final_cell'] is None), 'PHASE07_DISPOSITION', item)

    phase08_by_kind = defaultdict(list)
    for row in phase08_rows:
        phase08_by_kind[row['record_type']].append(row)
    count_kind = {k:len(v) for k,v in phase08_by_kind.items()}
    check(set(count_kind)=={'FINAL_SOURCE','FINAL_CONTROL','FINAL_CLASS','FINAL_RESIDUAL'}, 'CANONICAL_RECORD_KINDS',count_kind)
    check(count_kind.get('FINAL_SOURCE') == 638 and count_kind.get('FINAL_CONTROL') == 142 and count_kind.get('FINAL_CLASS') == 2551 and count_kind.get('FINAL_RESIDUAL') == 246,'CANONICAL_LEDGER_ENUMERATION',count_kind)

    frozen_lookup = {'R':set(ref_ids),'N':set(neg_ids),'G':set(gc_ids)}
    phase07_codes={'R': {'TP':'P7-R-TP','FN':'P7-R-FN'},'N': {'FP':'P7-N-FP','TN':'P7-N-TN'},'G': {'TP':'P7-G-SUPPORTED','FP':'P7-G-UNSUPPORTED'}}
    for item,row in phase07_by_id.items():
        direc=row['direction'];cell=row['final_cell']
        check(item in frozen_lookup.get(direc,set()) and cell in phase07_codes.get(direc,{}), 'PHASE07_DIRECTIONAL_DOMAIN', item)
        check(row['source_reference_unchanged'] is True and row['source_pdf_sha256'] == source_hashes['PDF'], 'PHASE07_SOURCE_IMMUTABILITY',item)
        check(row['decision_rule_id']==phase07_codes.get(direc,{}).get(cell), 'PHASE07_RULE_ID',item)
    check(set(ex_by_id) <= set(gc_ids) and all(x['direction']=='G' and x['reviewed_eligibility']=='NONDEFINITIVE' for x in phase07_excluded), 'PHASE07_EXCLUSIONS_BELONG_TO_GC')

    source_scoring = Counter()
    control_scoring = Counter()
    g_scoring = Counter()
    provenance = Counter()
    rows_by_id = {}
    reference_index = {'R':{x['requirement_id']:x for x in r_rows},'N':{x['control_id']:x for x in n_rows},'G':{x['class_id']:x for x in g_rows}}
    proof_status = Counter()
    for kind, rows in phase08_by_kind.items():
        if kind == 'FINAL_RESIDUAL': continue
        for row in rows:
            item = row.get('source_id') or row.get('control_id') or row.get('class_id')
            check(item not in rows_by_id, 'PHASE08_UNIQUE_FINAL_ITEM', item)
            rows_by_id[item] = row
            phase07 = phase07_by_id.get(item)
            check(phase07 is not None, 'FINAL_ITEM_HAS_PHASE07',item)
            if phase07:
                check(row['final_phase07_record_sha256'] == object_sha(phase07), 'PHASE07_ROW_DIGEST',item)
                check(row['phase07_item_id']==item and row['source_pdf_sha256']==source_hashes['PDF'], 'PHASE07_ROW_IDENTITY',item)
            direction = {'FINAL_SOURCE':'R','FINAL_CONTROL':'N','FINAL_CLASS':'G'}[kind]
            check(item in reference_index[direction], 'FINAL_ITEM_IN_FROZEN_REFERENCE',item)
            if direction=='R':
                source_scoring[row['scoring_cell']] += 1
                check(row['scoring_cell'] in ('TP','FN') and phase07['final_cell']==row['scoring_cell'], 'R_CELL_LINEAGE',item)
                check(row['source_statement_en']==reference_index['R'][item]['statement_en'], 'R_STATEMENT_LINK',item)
            elif direction=='N':
                control_scoring[row['scoring_cell']] += 1
                check(row['scoring_cell'] in ('FP','TN') and phase07['final_cell']==row['scoring_cell'], 'N_CELL_LINEAGE',item)
                check(row['counterfactual_en']==reference_index['N'][item]['counterfactual_en'], 'N_STATEMENT_LINK',item)
                check(row['affirmed_forbidden_counterfactual'] == (row['scoring_cell']=='FP'), 'N_POLARITY',item)
            else:
                g_scoring[row['diagnostic_cell']] += 1
                provenance[row['provenance_category']] += 1
                check(row['diagnostic_cell'] in ('TP','FP') and phase07['final_cell']==row['diagnostic_cell'], 'G_CELL_LINEAGE',item)
                check(row['generated_statement_en']==reference_index['G'][item]['statement_en'], 'G_STATEMENT_LINK',item)
                check(row['canonical_tp_increment']==0, 'NO_DOUBLE_COUNT_DIAGNOSTIC_G',item)
    check(set(rows_by_id)==set(phase07_by_id),'LEDGER_AND_PHASE07_BINARY_EXACTLY_MATCH')
    check(set(x['class_id'] for x in phase08_excluded)==set(ex_by_id), 'PHASE08_EXCLUSION_CROSSWALK')
    for row in phase08_excluded:
        source_g = reference_index['G'][row['class_id']]
        check(row['original_GC_sha256']==object_sha(source_g) and row['phase07_exclusion_sha256']==object_sha(ex_by_id[row['class_id']]), 'EXCLUSION_IMMUTABLE_LINEAGE',row['class_id'])
        check(row['canonical_scoring_cell'] is None and row['not_counted_as_FP_or_TN'], 'EXCLUDED_G_NOT_SCORED',row['class_id'])

    residual_rows = phase08_by_kind['FINAL_RESIDUAL']
    residual_ids = [x['residual_id'] for x in residual_rows]
    check(len(residual_ids)==len(set(residual_ids)),'UNIQUE_RESIDUAL_IDS')
    residual_by_id = {x['residual_id']:x for x in residual_rows}
    fp_g_classes = {item for item,row in rows_by_id.items() if row['record_type']=='FINAL_CLASS' and row['diagnostic_cell']=='FP'}
    residual_mapping = defaultdict(set)
    for row in residual_rows:
        check(row['scoring_cell']=='FP' and row['method']=='fullload' and row['pdf_sha256']==source_hashes['PDF'], 'VALID_RESIDUAL_ROW',row['residual_id'])
        check(not row['n_overlap_control_ids'], 'NO_N_F_RESIDUAL_OVERLAP',row['residual_id'])
        check(len(row['class_ids'])==len(set(row['class_ids'])) and len(row['class_ids'])>0, 'RESIDUAL_CLASS_REFERENCES',row['residual_id'])
        for cid in row['class_ids']:
            check(cid in fp_g_classes,'RESIDUAL_ONLY_UNSUPPORTED_ELIGIBLE_GC',cid)
            residual_mapping[cid].add(row['residual_id'])
    check(set(residual_mapping)==fp_g_classes, 'ALL_G_FP_CANDIDATES_EXHAUSTIVELY_CONSOLIDATED')
    for cid, resid_set in residual_mapping.items():
        check(set(rows_by_id[cid]['canonical_fp_residual_ids'])==resid_set, 'REVERSE_RESIDUAL_GC_MAPPING',cid)
    check(sum(1 for x in residual_audit if x['record_type']=='CONFIRMED_RESIDUAL_CONSOLIDATION')==8, 'EIGHT_AUDITED_SEMANTIC_MERGE_FAMILIES')
    check(sum(1 for x in residual_audit if x['record_type']=='SPLIT_COMPOSITE_UNSUPPORTED_OBLIGATIONS')==1,'ONE_COMPOSITE_SPLIT')

    atom_map = {x['atom_id']:x for x in go_rows + recovered_go}
    check(len(atom_map)==len(go_rows)+len(recovered_go),'GO_IDENTITIES')
    final_GO_count = 0
    dupe_within = dupe_across = repeated_classes = crossfile_repeated_classes = 0
    for row in g_rows:
        member_ids = row['active_phase02_member_atom_ids']+row['recovered_member_atom_ids']
        check(len(member_ids)==row['effective_occurrence_count'] and len(member_ids)==len(set(member_ids)), 'GC_GO_OCCURRENCE_LINKAGE',row['class_id'])
        if row['class_id'] in ex_by_id: continue
        final_GO_count += len(member_ids)
        members=[]
        for aid in member_ids:
            check(aid in atom_map, 'GC_REFERS_TO_VALID_GO',aid)
            if aid in atom_map:
                atom=atom_map[aid];fn=atom['file']; idx=ROLE_NAMES.index(fn) if fn in ROLE_NAMES else 100
                members.append((idx,atom['line_start'],aid,fn))
        members.sort()
        if len(members)>1: repeated_classes+=1
        seen_files=set()
        for _,_,_,fn in members:
            if seen_files:
                if fn in seen_files:dupe_within+=1
                else:dupe_across+=1
            seen_files.add(fn)
        if len(seen_files)>1: crossfile_repeated_classes+=1
    final_GC_count = len(phase08_by_kind['FINAL_CLASS'])
    check(final_GO_count==2598 and final_GC_count==2551, 'EFFECTIVE_GO_GC_RECOMPUTED',[final_GO_count,final_GC_count])
    check(dupe_within+dupe_across == final_GO_count-final_GC_count,'DUPLICATE_DISJOINT_ACCOUNTING')
    check(len(go_rows)==3111 and len(recovered_go)==16 and phase05_summary['effective_GO']==3119,'PHASE05_OCCURRENCE_LEDGER')

    # Evidence checks independently from the Phase 08 already-reported verified flags.
    quote_counts = Counter()
    for row in phase08_rows + phase08_excluded:
        if row['record_type']=='FINAL_RESIDUAL': continue
        if row['record_type']=='EXCLUDED_NONDEFINITIVE_CLASS':
            ev_list=row.get('generated_evidence',[])
        else:
            ev_list=row.get('generated_evidence',[])
        for ev in ev_list:
            fn=ev.get('file') or ev.get('original_file')
            st,en=ev.get('line_start'),ev.get('line_end')
            actual=markdown_lines.get(fn)
            exists=(actual is not None and type(st)==int and type(en)==int and 1<=st<=en<=len(actual) and normalize(ev.get('quote_en','')) in normalize('\n'.join(actual[st-1:en])))
            check(exists, 'EXACT_MD_EVIDENCE', {'item': row.get('class_id') or row.get('source_id') or row.get('control_id'), 'file':fn,'lines':[st,en]})
            quote_counts['markdown_verified' if exists else 'markdown_failed']+=1
            if exists and ev.get('source_sha256'):
                check(ev['source_sha256']==original_files[re.sub(r'\(\d+\)(?=\.md$)', '', fn)], 'EVIDENCE_MD_DIGEST')
        for ev in row.get('pdf_evidence',[]):
            pg=ev.get('physical_page');q=ev.get('quote_en',ev.get('quote',''))
            exists=bool(type(pg)==int and 1<=pg<=len(pdf_text) and normalize(q) in pdf_text[pg-1])
            check(exists,'EXACT_PDF_PAGE_EVIDENCE',{'page':pg, 'item':row.get('source_id') or row.get('control_id') or row.get('class_id')})
            quote_counts['pdf_text_verified' if exists else 'pdf_failed']+=1

    # Completely separate external run/journals verification; model suggestions do not set the metric.
    external_by_id={x['item_id']:x for x in external}
    check(len(external)==len(external_by_id)==len(queue),'EXTERNAL_3852_DISTINCT_ITEMS')
    check([x['item_id'] for x in external]==qids,'EXTERNAL_AGGREGATE_ORIGINAL_ORDER')
    check(run['model']=='gpt-6.2-sol' and run['batch_size'] in (8,16) and run['limit']==0,'ACTUAL_EXTERNAL_MODEL_BATCH_AND_UNBOUNDED')
    check(run['batch_size']==16 and run['item_count']==len(queue),'EXTERNAL_BATCH_IDENTITY')
    check(run['prompt_sha256'] and run['result_schema_sha256'] and run['filename_alias_policy']=='unique-role-verified-sha256-v1','V5_PROMPT_AND_ALIAS_FINGERPRINT_PRESENCE')
    check(phase06_selection['selected']['K'] == len(queue) if isinstance(phase06_selection.get('selected'),dict) and 'K' in phase06_selection['selected'] else len(queue)==3852,'NO_QUEUE_NUMERIC_TRUNCATION')
    expected_batches=(len(queue)+run['batch_size']-1)//run['batch_size']
    check(expected_batches==241 and external_summary['completed_batches']==expected_batches and external_summary['failed_batches']==0,'EXTERNAL_COMPLETED_BATCHES')
    with ZipFile(root/'batch_journals(3).zip') as archive:
        journal_files = {name for name in archive.namelist() if name.endswith('.json') and name.startswith('batch_journals/')}
        check(len(journal_files)==expected_batches,'IMMUTABLE_JOURNAL_COUNT')
        journal_items=0
        for index in range(expected_batches):
            name=f'batch_journals/B10.6-{index+1:05d}.json'
            check(name in journal_files, 'JOURNAL_PRESENT',name)
            if name not in journal_files:continue
            batch=json.loads(archive.read(name))
            segment=queue[index*run['batch_size']:(index+1)*run['batch_size']]
            identifiers=[x['item_id'] for x in segment]
            check(batch['batch_id']==f'B10.6-{index+1:05d}' and batch['batch_index']==index and batch['batch_size']==len(segment), 'JOURNAL_BATCH_BOUNDARY',name)
            check(batch['pdf_sha256']==source_hashes['PDF'] and batch['queue_sha256']==run['queue_sha256'], 'JOURNAL_SOURCE_IDENTITY',name)
            check(batch['input_digest']==object_sha(segment), 'JOURNAL_BATCH_INPUT_HASH',name)
            outputs=batch['item_records']
            check(batch['content_sha256']==object_sha({'raw_model_json':batch['raw_model_json'],'item_records':outputs}),'JOURNAL_CONTENT_HASH',name)
            check([x['item_id'] for x in outputs]==identifiers and [x['item_id'] for x in batch['raw_model_json']['results']]==identifiers,'JOURNAL_EXACT_ITEM_ORDER',name)
            for output_row in outputs:
                check(output_row==external_by_id.get(output_row['item_id']), 'JOURNAL_TO_EXTERNAL_IDENTITY',output_row['item_id'])
            journal_items += len(outputs)
    check(journal_items == len(queue), 'NO_MISSING_EXTERNAL_ITEM')
    check(len(run['attempts']) == 242, 'EXTERNAL_SUBMISSIONS_HISTORY_COUNT',len(run['attempts']))
    # Logging metadata can show an attempt, but cannot prove a particular reasoning setting
    # unless the original request configuration is available. Preserve this distinction.
    model_status = Counter(x['decision_status'] for x in external)
    model_suggestions = Counter(str(x['suggested_decision']) for x in external)
    pre_unresolved_by_direction=Counter(x['direction'] for x in external if x['decision_status']=='UNRESOLVED')
    model_confidences = [x.get('model_json',{}).get('confidence_estimate') for x in external]
    check(all(isinstance(v,(float,int)) and not isinstance(v,bool) and 0<=v<=1 for v in model_confidences),'V5_CONFIDENCE_VALUES_ARE_IN_RANGE')
    check(model_status['UNRESOLVED']==615 and model_suggestions['None']==609,'EXTERNAL_UNCERTAINTY_COUNTS',dict(model_status))
    check(external_summary['requested_items']==len(queue) and external_summary['remaining_items']==0,'EXTERNAL_SUMMARY_COMPLETE')
    # Preserve the original v5 proposal/final-Phase07 distinction in a full crosswalk.
    external_to_final = defaultdict(Counter)
    unresolved_to_final = Counter()
    for suggestion in external:
        iid = suggestion['item_id']
        terminal = 'EXCLUDED_NONDEFINITIVE' if iid in ex_by_id else f"{suggestion['direction']}:{phase07_by_id[iid]['final_cell']}"
        external_to_final[str(suggestion['suggested_decision'])][terminal] += 1
        if suggestion['decision_status'] == 'UNRESOLVED':
            unresolved_to_final[terminal] += 1
    check(sum(unresolved_to_final.values()) == model_status['UNRESOLVED'], 'ALL_V5_UNRESOLVED_HANDED_TO_PHASE07')
    check(sum(sum(counter.values()) for counter in external_to_final.values()) == len(queue), 'FULL_V5_TO_PHASE07_CROSSWALK')

    TP=source_scoring['TP']; FN=source_scoring['FN']
    TN=control_scoring['TN']; N_FP=control_scoring['FP']
    F=len(residual_rows); FP=N_FP+F
    check(TP+FN==len(r_rows),'TP_FN_EQUALS_R')
    check(TN+N_FP==len(n_rows),'TN_NFP_EQUALS_N')
    check(FP == N_FP+F,'FP_N_AND_RESIDUAL_COUNT')
    check(TP+TN+FP+FN==len(r_rows)+len(n_rows)+F,'CANONICAL_DISJOINT_POPULATION')
    recomputed={
        'R':len(r_rows),'N':len(n_rows),'TP':TP,'FN':FN,'TN':TN,
        'N_derived_FP':N_FP,'unique_generated_only_residual_FP':F,'FP':FP,
        'canonical_population':TP+TN+FP+FN,
        'G_diagnostic_TP':g_scoring['TP'],'G_diagnostic_FP':g_scoring['FP'],
        'G_excluded_nondefinitive':len(ex_by_id),
        'GO_phase05':phase05_summary['effective_GO'],
        'GC_phase05':len(g_rows),'GO_effective':final_GO_count,'GC_effective':final_GC_count,
    }
    prev={'R':phase08_counts['R'],'N':phase08_counts['N'],'TP':phase08_counts['R_TP'],'FN':phase08_counts['R_FN'],
          'TN':phase08_counts['N_TN'],'N_derived_FP':phase08_counts['N_FP'],
          'FP':phase08_counts['FP_total'],'unique_generated_only_residual_FP':phase08_counts['F_unique_residual_units'],
          'canonical_population':phase08_counts['canonical_population_size'],
          'G_diagnostic_TP':phase08_counts['G_diagnostic_TP'],'G_diagnostic_FP':phase08_counts['G_diagnostic_FP'],
          'G_excluded_nondefinitive':phase08_counts['G_nondefinitive_excluded'],
          'GO_phase05':phase08_counts['GO_phase05_frozen'],'GC_phase05':phase08_counts['GC_phase05_frozen'],
          'GO_effective':phase08_counts['GO_effective_eligible'],'GC_effective':phase08_counts['GC_effective_eligible']}
    check(recomputed==prev,'INDEPENDENT_RECOUNT_EQUALS_PHASE08',{'recomputed':recomputed,'phase08':prev})

    if errors:
        metrics={'status':'BLOCKED_INTEGRITY','score_authorized':False,'errors':errors,'metrics':None}
    else:
        precision=Fraction(TP,TP+FP) if TP+FP else None
        recall=Fraction(TP,TP+FN) if TP+FN else None
        f1=Fraction(2*TP,2*TP+FP+FN) if 2*TP+FP+FN else None
        neg_pass=Fraction(TN,len(n_rows)) if n_rows else None
        validity=Fraction(g_scoring['TP'],final_GC_count) if final_GC_count else None
        dup=Fraction(final_GO_count-final_GC_count,final_GO_count) if final_GO_count else None
        metrics={
            'status':'PHASE_COMPLETED','score_authorized':True,'protocol_version':'10.6',
            'record_type':'PHASE09_INDEPENDENT_METRICS','method':'fullload',
            'canonical_counts':recomputed,
            'scores':{
                'precision': float(precision) if precision is not None else None,
                'recall':float(recall) if recall is not None else None,
                'F1':float(f1) if f1 is not None else None,
                'negative_control_pass_rate':float(neg_pass) if neg_pass is not None else None,
                'GC_validity_rate':float(validity) if validity is not None else None,
                'Duplicate':float(dup) if dup is not None else None,
            },
            'percentages':{'precision':percentage(precision),'recall':percentage(recall),'F1':percentage(f1),
                'negative_control_pass_rate':percentage(neg_pass),'GC_validity_rate':percentage(validity),'Duplicate':percentage(dup)},
            'raw_duplicate_accounting':{
                'GO_effective':final_GO_count,'GC_effective':final_GC_count,
                'excess_duplicate_occurrences':final_GO_count-final_GC_count,
                'within_file_excess':dupe_within,'across_file_excess':dupe_across,
                'repeated_class_count':repeated_classes,'cross_file_repeated_class_count':crossfile_repeated_classes,
                'phase05_original_GO':phase05_summary['effective_GO'],
                'phase05_original_GC':len(g_rows),
                'phase07_excluded_classes':len(ex_by_id),
            },
            'original_reference':{
                'source_sha256':source_hashes,'physical_pdf_pages':physical_pages,
                'eight_source_role_sha256':original_files,'reference_status':expected_freeze.get('status'),
            },
            'external_evaluator':{
                'model':run['model'],
                'reasoning_effort_reported_in_phase07_metadata':phase07_summary.get('original_external_evaluator_reasoning_effort'),
                'reasoning_effort_recorded_in_run_state':run.get('reasoning_effort'),
                'reasoning_effort_independently_authenticated_from_request':False,
                'generation_reasoning_effort_operator_requested':source_lock['operator_requested_reasoning_effort'],
                'batch_size':run['batch_size'],'phase06_prepared_batch_size':phase06_selection['batch_size'],
                'phase06_vs_actual_batch_boundary_deviation':phase06_selection['batch_size']!=run['batch_size'],
                'concurrency':run['concurrency'],
                'additional_batch_retries':run['batch_retries'],
                'actual_attempts':len(run['attempts']),
                'completed_batches':expected_batches,'journal_record_count':journal_items,
                'queue_item_count':len(queue),'queue_sha256':run['queue_sha256'],
                'prompt_sha256':run['prompt_sha256'],'result_schema_sha256':run['result_schema_sha256'],
                'confidence_threshold':run['confidence_threshold'],
                'model_suggestion_counts':dict(model_suggestions),
                'model_decision_status_counts':dict(model_status),
                'original_unresolved_count':model_status['UNRESOLVED'],
                'original_unresolved_by_direction':dict(pre_unresolved_by_direction),
                'original_null_suggestion_count':model_suggestions['None'],
                'unresolved_final_dispositions':dict(unresolved_to_final),
                'model_suggestion_to_final_disposition':{k:dict(v) for k,v in external_to_final.items()},
                'no_llm_suggestion_counted_as_a_final_cell_without_phase07':True,
            },
            'generated_provenance_categories':dict(provenance),
            'semantic_consolidation':{
                'unmerged_G_FP_candidates':g_scoring['FP'],
                'canonical_unique_generated_only_residuals':F,
                'confirmed_family_merges':8,'composite_split_groups':1,
                'negative_control_overlap_count':0,
            },
            'verification':{'status':'PASSED','assertion_checks_performed':checks['performed'],
                'assertion_checks_passed':checks['passed'],'source_quote_counts':dict(quote_counts),
                'journal_batches':expected_batches,'journal_items':journal_items,
                'input_integrity_errors':0},
            'cross_method_comparability':{
                'status':'NOT_INDEPENDENTLY_ESTABLISHED',
                'operator_reports_gpt_6_2_sol_across_methods':True,
                'other_methods_source_run_state_files_available_here':False,
                'identical_reference_and_adjudication_policies_unverified_for_other_methods':True,
                'this_external_run_differs_from_printed_protocol_model_and_effort_defaults':True,
                'this_external_run_batch_size_16_is_permitted_by_protocol':True,
                'external_batch_size_differs_from_phase06_frozen_prepared_batch_size':phase06_selection['batch_size']!=run['batch_size'],
            },
            'limitations_en':[
                'Source R/N was frozen and provisionally audited; its completeness was not independently re-established.',
                'Phase 07 semantic decisions were largely machine-assisted; Phase 09 checks their immutable evidence and provenance, not universal substantive correctness.',
                '521 G classes were excluded by documented Phase 07 eligibility supersessions; the original Phase 05 ledger was not rewritten.',
                'A 96-item high-risk review lead list and nonexhaustive FP pair review do not guarantee all semantic duplicates or errors were discovered.',
                'Run state records model gpt-6.2-sol, but does not itself attest reasoning effort; high is drawn from Phase 07 provenance.',
                'Cross-method comparability requires the other methods independent run states and identical reference/adjudication/eligibility settings.',
            ],
        }

    output.mkdir(parents=True,exist_ok=True)
    (output/'09_metrics.json').write_text(json.dumps(metrics,indent=2,ensure_ascii=False,sort_keys=True)+'\n',encoding='utf-8')
    (output/'09_verification_details.json').write_text(json.dumps({'errors':errors,'checks':dict(checks),'recomputed_counts':recomputed,
                'phase08_reported_counts':prev,'original_reference_sha256':source_hashes,'quote_validation':dict(quote_counts),
                'journal_summary':dict(model_status)},indent=2,ensure_ascii=False,sort_keys=True)+'\n',encoding='utf-8')
    if metrics['status'] == 'PHASE_COMPLETED':
        c=metrics['canonical_counts'];sc=metrics['percentages'];du=metrics['raw_duplicate_accounting']
        report=f"""# Phase 09 — Independent Metric Computation

## Scope and authority

- Protocol: **10.6**; generation method: **fullload**.
- Positive/negative reference: frozen R = **{c['R']}**, N = **{c['N']}**, with unchanged SHA-256 identities.
- Canonical count authority: independently parsed `08_final_ledger.jsonl` and verified Phase 07 decisions, **not** the Azure evaluator's item-level proposals.
- Input reference status: `{metrics['original_reference']['reference_status']}`. Full semantic coverage of the PDF was not independently proven by this phase.

## Canonical confusion matrix and metric arithmetic

| Actual population | Predicted requirement present | Predicted requirement absent |
|---|---:|---:|
| PDF-positive R | TP = **{c['TP']}** | FN = **{c['FN']}** |
| Fixed negative controls and unsupported residuals | FP = **{c['FP']}** | TN = **{c['TN']}** |

- `TP + FN = {c['TP']} + {c['FN']} = {c['R']} = R`.
- `TN + N_FP = {c['TN']} + {c['N_derived_FP']} = {c['N']} = N`.
- `FP = N_FP + F = {c['N_derived_FP']} + {c['unique_generated_only_residual_FP']} = {c['FP']}`.
- `TP + TN + FP + FN = {c['canonical_population']} = R + N + F`.

| Metric | Exact equation | Percentage |
|---|---|---:|
| Precision | `{c['TP']} / ({c['TP']} + {c['FP']})` | **{sc['precision']:.4f}%** |
| Recall | `{c['TP']} / ({c['TP']} + {c['FN']})` | **{sc['recall']:.4f}%** |
| F1 | `2 * {c['TP']} / (2 * {c['TP']} + {c['FP']} + {c['FN']})` | **{sc['F1']:.4f}%** |
| Negative-control pass rate | `{c['TN']} / {c['N']}` | {sc['negative_control_pass_rate']:.4f}% |
| GC validity | `{c['G_diagnostic_TP']} / {c['GC_effective']}` | {sc['GC_validity_rate']:.4f}% |
| Duplicate | `({c['GO_effective']} - {c['GC_effective']}) / {c['GO_effective']}` | {sc['Duplicate']:.4f}% |

These scores measure completeness and correctness **relative to the frozen sample reference and this run's adjudication ledger**. They are not independent production performance measurements.

## Generated-population and false-positive reconciliation

- Original Phase 05: GO = **{c['GO_phase05']}**, GC = **{c['GC_phase05']}**.
- Phase 07 excluded **{c['G_excluded_nondefinitive']}** classes as nondefinitive, with superseding audit records; effective GO = **{c['GO_effective']}**, GC = **{c['GC_effective']}**.
- Eligible GC diagnostic labels: **{c['G_diagnostic_TP']}** PDF-supported and **{c['G_diagnostic_FP']}** PDF-unsupported.
- **{c['G_diagnostic_FP']}** unsupported GC claims map to **{c['unique_generated_only_residual_FP']}** unique generated-only residuals. The consolidation log identifies eight merge families and one composite split. No affirmative fixed-negative-control overlap was established; N-derived FP = **{c['N_derived_FP']}**.
- Raw eligible duplicate excess: **{du['excess_duplicate_occurrences']}**, consisting of **{du['within_file_excess']}** within-file and **{du['across_file_excess']}** across-file excess occurrences. Cross-file repeated class count = **{du['cross_file_repeated_class_count']}**. Duplicates do **not** multiply TP or FP.

## Original external review and Phase 07 closure

- Frozen queue: **{metrics['external_evaluator']['queue_item_count']}** IDs, SHA-256 `{metrics['external_evaluator']['queue_sha256']}`.
- Actual external run metadata: **{run['model']}**, batches of **{run['batch_size']}**, concurrency **{run['concurrency']}**, three allowed additional retries, **{expected_batches}** committed batch journals and **{len(run['attempts'])}** submission attempts.
- The original Phase 06 preparation manifest fixed 8-item batch boundaries, whereas the actual external execution used 16-item batches. Item/queue identities and journal content validate, but this execution-contract deviation is documented and must be considered before comparing methods.
- Original v5 proposals: {json.dumps(dict(model_suggestions),sort_keys=True)}.
- Original `decision_status=UNRESOLVED`: **{model_status['UNRESOLVED']}**; `suggested_decision=null`: **{model_suggestions['None']}**. All are linked to the final Phase 07 binary or documented nondefinitive-exclusion disposition; they are not blindly changed to negative cells.
- The file `semantic_decisions(4).jsonl` retains each original confidence estimate and quotation verifier result. Confidence is a model self-report, **not calibrated validity**.
- External model's reasoning effort is reported as **high** in the Phase 07 evidence record, but the supplied `run_state(3).json` does not itself contain a reasoning-effort key; do not call this an independently authenticated request parameter. The original generation setting was operator-specified `xhigh`.

## Independent verification

- {checks['performed']:,} / {checks['performed']:,} assertions passed; zero integrity errors.
- PDF physical pages = {physical_pages}; original Markdown roles = 8.
- Direct PDF-page quotation checks = **{quote_counts['pdf_text_verified']}**; original Markdown-line quotation checks (including exclusions) = **{quote_counts['markdown_verified']}**.
- All 241 original batch journals and 3,852 external item rows were checked against the source queue and aggregated records.
- Per-record Phase 07 adjudication hashes, Phase 08 final cell joins, and complete R/N/GC/residual ID population were reconciled.

## Conclusions and qualifications

The arithmetic single-method metrics above are **complete for the supplied Phase 08 ledger**. This does not certify that every machine-assisted Phase 07 semantic verdict is substantively correct. The original Phase 05 eligibility register was superseded in 521 cases without mutating its bytes. The generated-only residual count reflects documented proof-family checks, not an exhaustive mathematical proof of all possible semantic equivalences.

**Cross-method comparability is NOT independently established in this run.** The operator reports use of `gpt-6.2-sol` across methods, while the protocol's printed model/effort defaults were `gpt-6.1-sol / medium`; the recorded external run here used `gpt-6.2-sol` with effort `high` as reported in Phase 07. No onelevel/twolevel execution fingerprints and completed comparison ledgers were supplied for independent matching in Phase 09. The completed fullload metric remains internally calculable; a cross-method ranking must wait for independent configuration equivalence checks.
"""
        (output/'09_report.md').write_text(report,encoding='utf-8')
        unresolved_map=metrics['external_evaluator']['unresolved_final_dispositions']
        limitations=f"""# Phase 09 — Coverage, Audit Categories, and Limitations

## Population coverage

| Unit | Frozen/phase-05 population | Phase 07/08 effective population | Final result |
|---|---:|---:|---|
| R (PDF-positive source atoms) | {len(r_rows)} | {len(r_rows)} | TP {TP}, FN {FN} |
| N (negative controls) | {len(n_rows)} | {len(n_rows)} | TN {TN}, FP {N_FP} |
| GO (generated occurrences) | {phase05_summary['effective_GO']} | {final_GO_count} | {final_GO_count-final_GC_count} duplicate excess |
| GC (generated semantic classes) | {len(g_rows)} | {final_GC_count} | PDF-supported {g_scoring['TP']}, unsupported {g_scoring['FP']} |
| Nondefinitive G (documented eligibility corrections) | 0 | {len(ex_by_id)} excluded | No TP/TN/FP/FN contribution |
| Unique generated-only unsupported residuals | Not fixed | {F} | FP contribution {F} |

All {len(queue)} externally queued items received a Phase 07 final eligible verdict or a documented nondefinitive eligibility supersession. No source/control ID was silently removed from the fixed denominator.

## v5 uncertainty and assistant review

- External result suggestions: {json.dumps(dict(model_suggestions),sort_keys=True)}.
- 615 external UNRESOLVED statuses, including R=130, N=142 and G=343.
- Original UNRESOLVED item final dispositions: {json.dumps(dict(unresolved_map),sort_keys=True)}. These numbers follow actual ID crosswalks, rather than a rule that converts an abstention to FN or TN.
- Original `FN` suggestions: 4, all retained as R:FN in the final ledger; original `TN` suggestions: 2, retained as N:TN.
- 505 originally suggested NONDEFINITIVE G outcomes were independently reexamined; 497 were excluded and 8 retained as G:FP.
- Original per-item model confidences, evidence checks, reasons, and suggestions are preserved unmodified in the uploaded external JSONL and committed journals.

## Source coverage and FN root causes

- All {FN} final FN records have an explicit `unmet_predicates_en` field and source/generation provenance.
- The frozen Phase 04 root-cause register did **not** certify distinct `TRUE_MISSING`, `PARTIAL_ENTAILMENT` or `corrected matcher miss` counts. Phase 09 does not retroactively infer these labels from term overlap or classify all {FN} misses as absent text.
- Original UNRESOLVED R items producing final TP: {unresolved_map.get('R:TP',0)}. These are verified final coverage outcomes after v5 abstention, **not necessarily corrected retrieval/matcher errors**.
- Cross-file combined proof is permissible when the full source obligation follows, but a shared API path/identifier does not by itself establish complete entailment.

## Generated-only FP and duplicate audits

- Phase 07 diagnostic G:FP = {g_scoring['FP']} independent generated classes, reduced to F={F} distinct source-unsupported residual units.
- Eight affirmed consolidation families and one composite split were explicitly recorded. Eleven lexically similar candidate pairs were **rejected** as insufficiently equivalent.
- No N/F overlap was established from the fixed N/G crosswalk, and all {len(n_rows)} controls remained TN. This is not all-world true-negative accuracy.
- Excluded/nondefinitive G classes = {len(ex_by_id)}. They do not become FP, TN or extra TP.
- Supported noncovering G is a permitted provenance category, but none is separately classified as such in the Phase 08 final-class records; `PDF_ENTAILED` applies to {provenance.get('PDF_ENTAILED',0)} G and `PDF_UNSUPPORTED` to {provenance.get('PDF_UNSUPPORTED',0)} G. Phase 09 cannot infer a more granular supported-noncovering count without new evidence.

## Integrity checks and method restrictions

- Source PDF/R/N, freeze record, eight Markdown files, phase references, queue and Phase 08 artifacts: SHA-256 verified.
- Page count {physical_pages}; {quote_counts['pdf_text_verified']} PDF textual quote checks and {quote_counts['markdown_verified']} Markdown quote checks, plus original Phase 07 rendered-figure audits. Literal quote existence does not itself prove semantic entailment.
- {expected_batches} original complete batch journals, {journal_items} ordered original item records, {len(run['attempts'])} actual submitted attempts, and all unique record IDs were checked independently.
- The model used for recorded external suggestions was `gpt-6.2-sol`; `high` appears in prior Phase 07 metadata, **not** as an independently attested parameter in `run_state.json`. The operator separately requested `xhigh` for generation. These concepts are distinct.
- Protocol 10.6 printed `gpt-6.1-sol` and effort `medium` as evaluator defaults; the actual run differed. Batch size 16 is within protocol-allowed 8/16, but the Phase 06 frozen prepared batch size was 8. Execution used the same ordered 3,852 queue IDs with new 16-item boundaries. Cross-method equivalence cannot be confirmed by model name alone.
- Phase 07 had 521 eligibility supersessions compared with frozen Phase 05 GC. The original ledgers were not modified. Other generation methods must apply an equivalent eligibility-review policy before scores are compared.
- Original reference freeze is **provisional**: it notes bounded semantic audit, shared model-context extraction, and incomplete independent semantic completeness review.
- Phase 07-A/B's majority classifications were machine-assisted, and neither the 96 high-risk lead list nor the 24 high-similarity cross-shard pair screen mathematically proves that every FP semantic duplicate was detected.
- Phase 09 is arithmetic and provenance verification only; Phase 08 final adjudications are not altered by this report.

## Comparative evaluation status

**NOT INDEPENDENTLY ESTABLISHED** for onelevel/twolevel because their original run states, source digests, eligible GC populations, Phase 07 decisions, and Phase 08 canonical ledgers have not been verified in this session. A valid fullload single-method score is not, alone, a defensible cross-method ranking.
"""
        (output/'09_coverage_and_limitations.md').write_text(limitations,encoding='utf-8')
        (output/'09_model_to_final_crosswalk.json').write_text(json.dumps({
            'record_type':'PHASE09_V5_TO_PHASE07_CROSSWALK',
            'suggestions':{k:dict(v) for k,v in external_to_final.items()},
            'unresolved_final_dispositions':dict(unresolved_to_final),
            'original_unresolved_count':model_status['UNRESOLVED'],
            'original_null_suggestion_count':model_suggestions['None'],
            'evaluated_items':len(external),
        },indent=2,ensure_ascii=False,sort_keys=True)+'\n',encoding='utf-8')
    print(json.dumps({'status':metrics['status'],'counts':recomputed,'percentages':metrics.get('percentages'),
            'verification_checks':dict(checks),'errors':errors[:5]},indent=2,ensure_ascii=False))
    return metrics


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root',type=Path,default=Path('/mnt/data'))
    parser.add_argument('--base',type=Path,default=Path('/mnt/data/fullload_v10_6'))
    parser.add_argument('--output',type=Path,default=Path('/mnt/data/fullload_v10_6/phase09'))
    args=parser.parse_args()
    result=main(args.root,args.base,args.output)
    raise SystemExit(0 if result['status']=='PHASE_COMPLETED' else 2)
