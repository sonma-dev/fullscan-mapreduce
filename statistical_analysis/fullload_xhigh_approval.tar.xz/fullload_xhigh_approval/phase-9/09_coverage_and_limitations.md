# Phase 09 — Coverage, Audit Categories, and Limitations

## Population coverage

| Unit | Frozen/phase-05 population | Phase 07/08 effective population | Final result |
|---|---:|---:|---|
| R (PDF-positive source atoms) | 638 | 638 | TP 520, FN 118 |
| N (negative controls) | 142 | 142 | TN 142, FP 0 |
| GO (generated occurrences) | 3119 | 2598 | 47 duplicate excess |
| GC (generated semantic classes) | 3072 | 2551 | PDF-supported 2296, unsupported 255 |
| Nondefinitive G (documented eligibility corrections) | 0 | 521 excluded | No TP/TN/FP/FN contribution |
| Unique generated-only unsupported residuals | Not fixed | 246 | FP contribution 246 |

All 3852 externally queued items received a Phase 07 final eligible verdict or a documented nondefinitive eligibility supersession. No source/control ID was silently removed from the fixed denominator.

## v5 uncertainty and assistant review

- External result suggestions: {"EXCLUDED_NONDEFINITIVE": 505, "FN": 4, "NOT_FP": 2224, "None": 609, "TN": 2, "TP": 508}.
- 615 external UNRESOLVED statuses, including R=130, N=142 and G=343.
- Original UNRESOLVED item final dispositions: {"EXCLUDED_NONDEFINITIVE": 24, "G:FP": 245, "G:TP": 74, "N:TN": 142, "R:FN": 117, "R:TP": 13}. These numbers follow actual ID crosswalks, rather than a rule that converts an abstention to FN or TN.
- Original `FN` suggestions: 4, all retained as R:FN in the final ledger; original `TN` suggestions: 2, retained as N:TN.
- 505 originally suggested NONDEFINITIVE G outcomes were independently reexamined; 497 were excluded and 8 retained as G:FP.
- Original per-item model confidences, evidence checks, reasons, and suggestions are preserved unmodified in the uploaded external JSONL and committed journals.

## Source coverage and FN root causes

- All 118 final FN records have an explicit `unmet_predicates_en` field and source/generation provenance.
- The frozen Phase 04 root-cause register did **not** certify distinct `TRUE_MISSING`, `PARTIAL_ENTAILMENT` or `corrected matcher miss` counts. Phase 09 does not retroactively infer these labels from term overlap or classify all 118 misses as absent text.
- Original UNRESOLVED R items producing final TP: 13. These are verified final coverage outcomes after v5 abstention, **not necessarily corrected retrieval/matcher errors**.
- Cross-file combined proof is permissible when the full source obligation follows, but a shared API path/identifier does not by itself establish complete entailment.

## Generated-only FP and duplicate audits

- Phase 07 diagnostic G:FP = 255 independent generated classes, reduced to F=246 distinct source-unsupported residual units.
- Eight affirmed consolidation families and one composite split were explicitly recorded. Eleven lexically similar candidate pairs were **rejected** as insufficiently equivalent.
- No N/F overlap was established from the fixed N/G crosswalk, and all 142 controls remained TN. This is not all-world true-negative accuracy.
- Excluded/nondefinitive G classes = 521. They do not become FP, TN or extra TP.
- Supported noncovering G is a permitted provenance category, but none is separately classified as such in the Phase 08 final-class records; `PDF_ENTAILED` applies to 2296 G and `PDF_UNSUPPORTED` to 255 G. Phase 09 cannot infer a more granular supported-noncovering count without new evidence.

## Integrity checks and method restrictions

- Source PDF/R/N, freeze record, eight Markdown files, phase references, queue and Phase 08 artifacts: SHA-256 verified.
- Page count 90; 6909 PDF textual quote checks and 4542 Markdown quote checks, plus original Phase 07 rendered-figure audits. Literal quote existence does not itself prove semantic entailment.
- 241 original complete batch journals, 3852 ordered original item records, 242 actual submitted attempts, and all unique record IDs were checked independently.
- The model used for recorded external suggestions was `gpt-6.2-sol`; `high` appears in prior Phase 07 metadata, **not** as an independently attested parameter in `run_state.json`. The operator separately requested `xhigh` for generation. These concepts are distinct.
- Protocol 10.6 printed `gpt-6.1-sol` and effort `medium` as evaluator defaults; the actual run differed. Batch size 16 is within protocol-allowed 8/16, but the Phase 06 frozen prepared batch size was 8. Execution used the same ordered 3,852 queue IDs with new 16-item boundaries. Cross-method equivalence cannot be confirmed by model name alone.
- Phase 07 had 521 eligibility supersessions compared with frozen Phase 05 GC. The original ledgers were not modified. Other generation methods must apply an equivalent eligibility-review policy before scores are compared.
- Original reference freeze is **provisional**: it notes bounded semantic audit, shared model-context extraction, and incomplete independent semantic completeness review.
- Phase 07-A/B's majority classifications were machine-assisted, and neither the 96 high-risk lead list nor the 24 high-similarity cross-shard pair screen mathematically proves that every FP semantic duplicate was detected.
- Phase 09 is arithmetic and provenance verification only; Phase 08 final adjudications are not altered by this report.

## Comparative evaluation status

**NOT INDEPENDENTLY ESTABLISHED** for onelevel/twolevel because their original run states, source digests, eligible GC populations, Phase 07 decisions, and Phase 08 canonical ledgers have not been verified in this session. A valid fullload single-method score is not, alone, a defensible cross-method ranking.
