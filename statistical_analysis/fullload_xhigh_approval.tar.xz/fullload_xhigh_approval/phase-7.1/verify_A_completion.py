#!/usr/bin/env python3
"""Independent immutable SHA, evidence, partition and provenance audit."""
import json,hashlib,pathlib,collections,unicodedata,fitz,re
ROOT=pathlib.Path('/mnt/data/fullload_v10_6');out=ROOT/'phase07_A_completed';MD=pathlib.Path('/mnt/data')
read=lambda p:[json.loads(s) for s in open(p,encoding='utf-8') if s.strip()]
sh=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
lines={f:(MD/f).read_text(encoding='utf8').splitlines() for f in ['01_screen_functions(2).md','02_api(2).md','03_data(2).md','04_batch_functions(3).md','05_business_rules(2).md','06_exception_handling(4).md','07_processing_flows(4).md','08_architecture_decision(3).md']}
qsha=sh(ROOT/'phase06/06_llm_queue_v10.6.jsonl'); inp=read(ROOT/'phase07_sharded/07_shard_A_input.jsonl')
doc=fitz.open(MD/'OrionDesk_AI_Detailed_Design_Specification(2).pdf'); page_text=[[p.get_text(sort=False),p.get_text(sort=True)] for p in doc]
def norm(v):return ' '.join(unicodedata.normalize('NFKC',v).casefold().split())
errors=[];flags=[]; counts=collections.Counter()
fin=read(out/'07_assistant_adjudications_A.jsonl');exc=read(out/'07_eligibility_supersessions_A.jsonl'); blockers=read(out/'07_input_blockers_A.jsonl')
ids={x['item_id'] for x in inp};checkids=[x['item_id'] for x in fin+exc+blockers]
if len(checkids)!=len(set(checkids)): errors.append('DUPLICATED_TARGET_IDS')
if ids!=set(checkids):errors.append(f'ID_COVERAGE_MISMATCH missing={len(ids-set(checkids))} unexpected={len(set(checkids)-ids)}')
if len(doc)!=90:errors.append('PDF_PAGE_COUNT')
if sh(MD/'OrionDesk_AI_Detailed_Design_Specification(2).pdf')!=inp[0]['source_pdf_sha256']:errors.append('PDF_SHA_MISMATCH')
if qsha!=inp[0]['queue_sha256']:errors.append('QUEUE_SHA_MISMATCH')
byid={x['item_id']:x for x in inp}
for z in fin:
 id=z['item_id'];di=z['direction'];ce=z['final_cell'];counts[f'{di}:{ce}']+=1
 if z['source_pdf_sha256']!=byid[id]['source_pdf_sha256']:errors.append(f'PDF_ID_SHA:{id}')
 if di=='R' and ce not in ('TP','FN'):errors.append(f'CELL_DIRECTION:{id}')
 if di=='G' and ce not in ('TP','FP'):errors.append(f'CELL_DIRECTION:{id}')
 if di=='R' and z['decision_rule_id']!=('P7-R-TP' if ce=='TP' else 'P7-R-FN'):errors.append(f'DECISION_RULE:{id}')
 if di=='G' and z['decision_rule_id']!=('P7-G-SUPPORTED' if ce=='TP' else 'P7-G-UNSUPPORTED'):errors.append(f'DECISION_RULE:{id}')
 # Revalidate all new and earlier accepted PDF quotations; page is 1-indexed.
 for e in z['pdf_evidence']:
  p=e.get('physical_page');txt=e.get('quote_en','')
  if not isinstance(p,int) or not (1<=p<=90):errors.append(f'PDF_PAGE:{id}');continue
  if not any(norm(txt) in norm(t) for t in page_text[p-1]):
   flags.append({'item_id':id,'type':'ORIGINAL_PDF_QUOTE_NOT_FOUND_IN_EXTRACTION','physical_page':p,'quote_en':txt[:220]})
 for e in z['generated_evidence']:
  f=e['file'];st=e['line_start'];ed=e['line_end'];tx=e['quote_en']
  if f not in lines or not isinstance(st,int) or not isinstance(ed,int) or st<1 or ed<st or ed>len(lines[f]):errors.append(f'GEN_RANGE:{id}');continue
  if norm(tx) not in norm('\n'.join(lines[f][st-1:ed])):flags.append({'item_id':id,'type':'ORIGINAL_MARKDOWN_QUOTE_NOT_FOUND_IN_EXACT_RANGE','file':f,'line_start':st,'line_end':ed,'quote_en':tx[:220]})
for z in exc:
 id=z['item_id']; counts['G:EXCLUDED_NONDEFINITIVE']+=1
 if z['direction']!='G' or z.get('final_cell') is not None:errors.append(f'EXCLUSION_SEMANTICS:{id}')
 if not z.get('generated_evidence'):errors.append(f'EXCLUSION_WITHOUT_ORIGINAL_SOURCE:{id}')
 for e in z.get('generated_evidence',[]):
  f=e.get('file') or e.get('original_file');st=e.get('line_start');ed=e.get('line_end');txt=e.get('quote_en','')
  if f not in lines or not isinstance(st,int) or not isinstance(ed,int) or st<1 or ed<st or ed>len(lines[f]):flags.append({'item_id':id,'type':'EXCLUSION_LINE_RANGE','file':f});continue
  if norm(txt) not in norm('\n'.join(lines[f][st-1:ed])):flags.append({'item_id':id,'type':'EXCLUSION_QUOTE_NO_MATCH','file':f,'line_start':st,'line_end':ed,'quote_en':txt[:120]})
# Identity/strongest proof conditions; flags are visible and prohibit unqualified
# claims that every semantic verdict is manually certified.
if counts['R:TP']+counts['R:FN']!=638:errors.append('R_COUNTS')
if counts['G:TP']+counts['G:FP']+counts['G:EXCLUDED_NONDEFINITIVE']!=1288:errors.append('G_COUNTS')
if len(fin)+len(exc)+len(blockers)!=1926:errors.append('TOTAL_COUNTS')
if blockers:errors.append('INPUT_OR_EVIDENCE_BLOCKERS')
if not (len(fin)==1706 and len(exc)==220):flags.append({'type':'TOTALS_DIFFER_FROM_PRESENT_COMPLETION','decisions':len(fin),'exclusions':len(exc)})
record={'record_type':'PHASE07A_INDEPENDENT_VERIFICATION','status':'PASSED' if not errors else 'FAILED','protocol_version':'10.6','assigned_total':1926,'final_eligible_binary_cells':len(fin),'nondefinitive_eligibility_supersessions':len(exc),'unresolved_eligible_items':len(blockers),'source_pdf_sha256':sh(MD/'OrionDesk_AI_Detailed_Design_Specification(2).pdf'),'queue_sha256':qsha,'cell_counts':dict(counts),'errors':errors,'quotation_flags_count':len(flags),'quotation_flags_by_type':dict(collections.Counter(x['type'] for x in flags)),'limitations_en':'Evidence-string verification proves provenance, not semantic entailment. Disputed scope and systematic full/partial mismatches need Phase 07-C cross-shard review. Previously frozen reference and external outputs remain unmodified. Exclusions are separately retained rather than fabricated binary cells.','shard_B_started':False,'shard_C_started':False}
(out/'07_independent_verification_A.json').write_text(json.dumps(record,indent=2,ensure_ascii=False)+'\n',encoding='utf8')
with open(out/'07_quotation_validation_flags_A.jsonl','w',encoding='utf8') as f:
 for z in flags:f.write(json.dumps(z,sort_keys=True,ensure_ascii=False)+'\n')
print(json.dumps(record,indent=2,ensure_ascii=False))
