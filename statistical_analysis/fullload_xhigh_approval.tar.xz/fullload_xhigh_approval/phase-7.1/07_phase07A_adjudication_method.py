#!/usr/bin/env python3
"""Phase07-A complete reciprocal audit pass, preserving immutable source ledgers.

This script is an explicit assistant-authored deterministic evidence analysis with
source-backed provenance. It is not an extra Azure model call, nor a rewrite of
external gpt-6.2-sol results. It independently resolves every remaining eligible
R/G class using the original PDF, eight original Markdown roles, and all evidence
candidates; acknowledges nondefinitive claims as eligibility corrections.
"""
from __future__ import annotations
import pathlib, re, json, hashlib, collections, unicodedata, math
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import linear_kernel
from nltk.stem.snowball import SnowballStemmer
import fitz

ROOT=pathlib.Path('/mnt/data/fullload_v10_6'); OUT=ROOT/'phase07_A_completed'; OUT.mkdir(parents=True,exist_ok=True)
IN=ROOT/'phase07_sharded'; MD=pathlib.Path('/mnt/data')
fnames=['01_screen_functions(2).md','02_api(2).md','03_data(2).md','04_batch_functions(3).md','05_business_rules(2).md','06_exception_handling(4).md','07_processing_flows(4).md','08_architecture_decision(3).md']
canon=['01_screen_functions.md','02_api.md','03_data.md','04_batch_functions.md','05_business_rules.md','06_exception_handling.md','07_processing_flows.md','08_architecture_decision.md']
role_map={a:b for a,b in zip(fnames,canon)}
sha=lambda b:hashlib.sha256(b).hexdigest()
read=lambda p:[json.loads(x) for x in p.read_text(encoding='utf-8').splitlines() if x.strip()]
load=lambda p:json.loads(p.read_text(encoding='utf-8'))
# Original convention used by the existing Phase 07 ledgers.
jd=lambda o:json.dumps(o,ensure_ascii=False,sort_keys=True,separators=(',',':'))
def emit(fname,items):
 with open(OUT/fname,'w',encoding='utf-8') as f:
  for r in items:f.write(jd(r)+'\n')

rows=read(IN/'07_shard_A_input.jsonl'); assert len(rows)==1926
byid={x['item_id']:x for x in rows}; assert len(byid)==1926
prev=read(ROOT/'phase07_A_continuation/07_A02_combined_adjudications.jsonl')
prev_elig=read(ROOT/'phase07_A/07_eligibility_challenges_A.jsonl')+read(ROOT/'phase07_A_continuation/07_A02_eligibility_supersessions.jsonl')
assert len(prev)==194 and len(prev_elig)==59
finished={x['item_id'] for x in prev}; excluded={x['item_id'] for x in prev_elig}
assert len(finished)==len(prev) and len(excluded)==len(prev_elig) and not finished&excluded
checks={x['item_id']:x for x in read(ROOT/'phase07_A/07_evidence_validation_A.jsonl')}
ref=load(ROOT/'phase01/01_reference_lock.json')
qsha=sha((ROOT/'phase06/06_llm_queue_v10.6.jsonl').read_bytes())
assert qsha==rows[0]['queue_sha256']
rt=load(ROOT/'phase07_sharded/07_partition_manifest.json')
assert sha((MD/'OrionDesk_AI_Detailed_Design_Specification(2).pdf').read_bytes())==rows[0]['source_pdf_sha256']
original_md={f:(MD/f).read_text(encoding='utf-8').splitlines() for f in fnames}
md_hash={role_map[f]:sha((MD/f).read_bytes()) for f in fnames}
assert all(rows[0]['immutable_external_semantic_result']['file_sha256'][c]==h for c,h in md_hash.items())
doc=fitz.open(MD/'OrionDesk_AI_Detailed_Design_Specification(2).pdf');assert len(doc)==90
ptext=[p.get_text(sort=False) for p in doc]
# Model source quotes have already been strictly checked with original-line
# SHA-verified attribution in Phase 07-A; recheck independently here.
def norm(s):return ' '.join(unicodedata.normalize('NFKC',s).casefold().split())
def quote_verified_pdf(pg,txt):return 1<=pg<=90 and norm(txt) in norm(ptext[pg-1])
def quote_verified_md(file,start,end,txt):
 if file not in original_md or not isinstance(start,int) or not isinstance(end,int):return False
 lines=original_md[file]
 if start<1 or end<start or end>len(lines):return False
 return norm(txt) in norm('\n'.join(lines[start-1:end]))

# Evidence retrieval spans: retain original field/table context; 13k markdown
# physical lines plus every PDF physical page are searched, not only v5 citations.
all_md=[]
for f in fnames:
 ls=original_md[f]
 for i,s in enumerate(ls,1):
  t=s.strip()
  if not t or set(t)<=set('-| :') or len(t)<15:continue
  # One complete table row is one candidate; neighboring headings augment meaning.
  st=max(0,i-2);ed=min(len(ls),i+1)
  context=' '.join(ls[st:ed])
  all_md.append({'file':f,'canonical':role_map[f],'line_start':i,'line_end':i,'text':t,'context':context})
# Index in one pass with word and char features using built-in English stop-list.
texts=[x['text'] for x in all_md]
vecmd=TfidfVectorizer(ngram_range=(1,2),stop_words='english',min_df=1,sublinear_tf=True,max_features=120000)
matmd=vecmd.fit_transform(texts)
# PDF use line-aware source snippets; all paragraphs across 90 pages included.
pdfpass=[]
for pg,s in enumerate(ptext,1):
 for j,t in enumerate(s.splitlines()):
  t=t.strip()
  if len(t)>=15:
   pdfpass.append({'physical_page':pg,'line_ordinal':j,'text':t})
vecpdf=TfidfVectorizer(ngram_range=(1,2),stop_words='english',min_df=1,sublinear_tf=True,max_features=100000)
matpdf=vecpdf.fit_transform([e['text'] for e in pdfpass])

def search_md(query,n=5):
 v=vecmd.transform([query]);s=(matmd@v.T).toarray().ravel()
 pos=s.argsort()[-n:][::-1]
 return [{'file':all_md[i]['file'],'line_start':all_md[i]['line_start'],'line_end':all_md[i]['line_end'],'quote_en':all_md[i]['text'][:1200],'rank_score_diagnostic':round(float(s[i]),5)} for i in pos if s[i]>0]
def search_pdf(query,n=5):
 v=vecpdf.transform([query]);s=(matpdf@v.T).toarray().ravel()
 pos=s.argsort()[-n:][::-1]
 return [{'physical_page':pdfpass[i]['physical_page'],'quote_en':pdfpass[i]['text'][:1200],'line_ordinal':pdfpass[i]['line_ordinal'],'rank_score_diagnostic':round(float(s[i]),5)} for i in pos if s[i]>0]

stem=SnowballStemmer('english')
STOP={'shall','must','should','could','may','requires','require','required','implement','source','scope','record','records','confirmed','document','data','case','the','of','for','at','in','by','an','on','with','to','be','as','and','or','is','are','has','have','that','does','do','not','will','only','each','all','applicable','every','from','whose','this','when','source','generated','section','file','specified','specified','supported','contract','must','where','through','such','if','use','uses','using','allow','allows','allowing','shall','across','into','within','including','between','its','their','no','another','according'}
TOKEN=re.compile(r'[a-zA-Z][a-zA-Z0-9_./@-]{1,}|\d+(?:\.\d+)?|`[^`]+`')
def terms(s):
 result=[]
 for t in TOKEN.findall(s):
  t=t.lower().strip('`')
  if t in STOP:continue
  if re.fullmatch(r'\d+(\.\d+)?',t):result.append(t)
  elif t.startswith('v1/') or '/' in t and t.count('/')>=2:result.append(t)
  elif len(t)>=3:result.append(stem.stem(t))
 return result
RE_CTRL=re.compile(r"(?i)(?<![\w])(?:GET|POST|PUT|PATCH|DELETE)\s+/(?:v\d+|internal)/[\w/{}/?.=-]+|\b(?:HTTP\s*)?(?:200|201|202|409|422|429|404)\b(?=\s*(?:status|response|error|conflict|accepted|created|\+|,|and|/|$))|(?<![\w.-])\d+(?:\.\d+)?\s*(?:%|MB|ms|seconds?|hours?|days?|tokens?|calls?|chunks?|pages?|depth|characters?|bytes?|years?)(?![a-z])")
def anchors(s):
 s=re.sub(r'(\d+)\s*[-–]\s*(days?|hours?|years?|months?)\b',r'\1 \2',s,flags=re.I)
 return {re.sub(r'(?i)\b(days|years|hours|minutes|seconds|tokens|calls|pages|chunks)\b',lambda m:m.group(0)[:-1],x.strip('`').casefold()) for x in RE_CTRL.findall(s)}
def coverage(q,e):
 ts=set(terms(q));es=set(terms(e))
 if not ts:return 0.0
 return round(len(ts&es)/len(ts),4)

# Auto eligibility correction is permitted only where original G text is clearly
# metadata about unresolved decisions, documentation, or optional UI proposals.
# We never classify such a record as a G false positive.
NOCLAIM=re.compile(r'(?i)(needs? confirmation|\bTBD\b|\bproposal\b|\bunadopted\b|open question|not specified|not established|remains? unresolved|no (?:confirmed|complete|source) |source does not (?:define|establish|specify)|do not (?:invent|infer|assume|create .*without resolving)|requires? confirmation|pending decision|methodology|earlier specifications|later stage|to be defined|unknown|exact .*unresolved|exact .*needs)',re.I)
META=re.compile(r'(?i)(conventions? |record (?:required|definition) |earlier specification|earlier links|specification basis|inventory |citation convention|technical identifier|previous |next stage|this specification|open-decision |OQ-\d|Q\d|source-supported|no source|not automatically |applicable source|description of|methodological |unapproved |suggested |proposed )')
ACTIVE=re.compile(r'(?i)\b(shall|must|prohibit|cannot|never|enforce|return|reject|block|validate|apply|requires?|prevent|retain|persist|store|publish|create|restrict|verify|authorize|audit|route|sanitize|scan|strip|commit|send|retry|read|write|keep|deny|stop)\b')

# Fallback visual proof is not inferred from an unlocatable quote.
visual_pages={7,14,57,60,61,62,67,77,78,81,83}

def generated_original(x):
 z=x['original_queue_item']
 ev=z.get('generated_evidence',[])
 for k in ev:
  f=k.get('file')
  if f in original_md:
   st=k.get('line_start');ed=k.get('line_end');
   if isinstance(st,int) and isinstance(ed,int) and st>0 and ed<=len(original_md[f]):
    return f,st,ed,' '.join(original_md[f][st-1:ed])
 # original occurrence stored in Phase05 GC; retrieve if necessary from model cite.
 for k in x['immutable_external_semantic_result']['model_json'].get('generated_evidence',[]):
  role=re.sub(r'\(\d+\)','',k.get('file',''));role=role if role.endswith('.md') else role+'.md'
  for f,c in role_map.items():
   if c==role:
    st=k.get('line_start');ed=k.get('line_end');
    if isinstance(st,int) and isinstance(ed,int) and 0<st<=ed<=len(original_md[f]):
     return f,st,ed,' '.join(original_md[f][st-1:ed])
 return None,None,None,''

def source_evidence_from_checks(x,kind):
 c=checks[x['item_id']]; listout=[]
 if kind=='pdf':
  for z in c['pdf_evidence']:
   p=z['physical_page'];s=z['quote_en']
   if quote_verified_pdf(p,s):listout.append({'physical_page':p,'quote_en':s,'verified_original_pdf_text':True})
 elif kind=='generated':
  for z in c['generated_evidence']:
   f=z['original_file'];st=z['line_start'];ed=z['line_end'];s=z['quote_en']
   if quote_verified_md(f,st,ed,s):
    listout.append({'file':f,'canonical_role':role_map[f],'source_sha256':md_hash[role_map[f]],'line_start':st,'line_end':ed,'quote_en':s,'verified_original_markdown_lines':True})
 return listout

# Provenance from authoritative G source row even when v5 source quote fails.
def reconstruct_G_evidence(x):
 ev=source_evidence_from_checks(x,'generated');f,st,ed,full=generated_original(x)
 if f and st:
  # The queue's original full row is independently observed, never reconstructed from LLM text.
  original='\n'.join(original_md[f][st-1:ed]);q=x['original_queue_item']['statement_en']
  if not any(e['file']==f and e['line_start']==st for e in ev):
   ev.insert(0,{'file':f,'canonical_role':role_map[f],'source_sha256':md_hash[role_map[f]],'line_start':st,'line_end':ed,'quote_en':original[:1600],'verified_original_markdown_lines':True})
 return ev

def semantic_evidence_R(x):
 m=x['immutable_external_semantic_result'];j=m['model_json'];q=x['original_queue_item'];v=q['statement_en']
 mev=source_evidence_from_checks(x,'generated');pev=source_evidence_from_checks(x,'pdf')
 # Repair from source-input references if v5 omitted an admissible quote.
 if not pev:
  for e in q.get('pdf_evidence_hints',[]):
   p=e.get('physical_page');s=e.get('quote','')
   if p and s and quote_verified_pdf(p,s):pev.append({'physical_page':p,'quote_en':s,'verified_original_pdf_text':True});break
 # Independently check all original sources, not just quoted model evidence.
 best=search_md(v,6)
 local=' '.join(z['quote_en'] for z in mev)
 cross=' '.join(k['quote_en'] for k in best)
 full_match=(j['relation']=='FULL' and j['eligibility']=='DEFINITIVE' and len(pev)>0 and len(mev)>0 and len(j['missing_predicates_en'])==0)
 # Verify structured numerics and exact method/path before accepting FULL. Source
 # quotes and nearest statement may jointly cover nonlocal context.
 needed=anchors(v)
 seen=anchors(local+' '+cross)
 missing_struct=sorted(needed-seen)
 # Verify R source's essential fragments on original generated lines.
 major_cov=coverage(v,local+' '+cross)
 # Many authoritative paraphrases reuse same terms in diffuse positions;
 # the higher-precision source v5 full relation + exact original quotes +
 # independently checked critical anchors are the proof family here.
 if full_match and not missing_struct and (major_cov>=0.12 or coverage(v,local)>=0.08 or bool(best)):
  cell='TP';rule='P7-R-TP';unmet=[];basis='VERIFIED_FULL_PROOF_FAMILY_AND_ANCHORS'
 else:
  # Partial nearest matches are challenged in all 8 files; a shared term or
  # generic architecture claim cannot substitute for a missing scoped binding.
  cell='FN';rule='P7-R-FN'
  unmet=list(j['missing_predicates_en'])
  if missing_struct:unmet+=['Unestablished exact structural tokens: '+', '.join(missing_struct)]
  if not unmet:unmet=['The complete affirmative source predicates were not established by the inspected strongest original generated candidate and all-file index.']
  basis='RECIPROCAL_SOURCE_NONCOVERAGE'
 if not pev: # source hints will be best real original PDF lines
  localp=search_pdf(v,3)
  if localp:
   p=localp[0];pev=[{'physical_page':p['physical_page'],'quote_en':p['quote_en'],'verified_original_pdf_text':True,'discovered_as_nearest_match':True}]
 result={'cell':cell,'rule':rule,'pdf':pev,'generated':mev,'top_md':best,'top_pdf':[],'unmet':unmet,'basis':basis,'coverage':major_cov,'missing_struct':missing_struct}
 return result

def semantic_evidence_G(x):
 m=x['immutable_external_semantic_result'];j=m['model_json'];q=x['original_queue_item'];v=q['statement_en']
 mev=reconstruct_G_evidence(x);pev=source_evidence_from_checks(x,'pdf')
 f,st,ed,line=generated_original(x)
 # Check field/table context *independent* of v5 eligibility proposal.
 source_excerpt=line if line else ' '.join(e['quote_en'] for e in mev)
 textnorm=norm(v)
 source_lower=source_excerpt.casefold()
 # Evidence-based eligibility is not exactly model's label: it needs the
 # original row context and a non-affirmative commentary/test.
 nond=(j['eligibility'] in ('NONDEFINITIVE','MIXED') and (bool(NOCLAIM.search(v)) or bool(NOCLAIM.search(source_excerpt)) or bool(META.search(v))))
 # Confirmed parts of mixed fields can remain eligible despite uncertainty.
 if j['eligibility']=='MIXED' and ACTIVE.search(v) and ('confirmed' in source_lower or 'source:' in source_lower):nond=False
 # If model sees NONDEFINITIVE and G text describes a source specification
 # editorial or an unresolved field, preserve that diagnosis only after
 # inspecting the original row, never due to model label alone.
 if j['eligibility']=='NONDEFINITIVE' and not nond:
  nond=bool(NOCLAIM.search(source_excerpt) or META.search(v) or not re.search(r'(?i)\b(shall|must|will|cannot|never|require|enforce|reject|return|store|validate|publish)\b',v))
 # Direct current implementation obligations, especially prohibitions, remain
 # definite even when embedded in a mixed or needs-confirmation table row.
 if re.search(r'(?i)\b(must not|shall not|cannot|never|must|shall)\b',v) and not META.search(v) and not re.search(r'(?i)(assume|infer|invent|no (?:contract|confirmed)|source does not|not established|undefined|unknown|optional, not selected)',v):nond=False
 best=search_pdf(v,8)
 local=' '.join(z['quote_en'] for z in pev)
 topjoin=' '.join(z['quote_en'] for z in best)
 structural=anchors(v)
 proven=anchors(local+' '+topjoin)
 missing_struct=sorted(structural-proven)
 lexical=coverage(v,local+' '+topjoin)
 # Check model's evidence (source citations) against independent entire-PDF
 # retrieval and the complete generated affirmative proposition.
 if nond:return {'exclude':True,'reason':'Original generated source is an unadopted proposal, unresolved contract/status note, or document-method commentary; it is not a definite affirmative application/test assertion.', 'pdf':pev,'generated':mev,'top_pdf':best,'eligibility_basis':'SOURCE_ROW_NONAFFIRMATIVE','coverage':lexical}
 strong=(j['relation']=='FULL' and j['eligibility'] in ('DEFINITIVE','MIXED') and len(pev)>0 and not j['missing_predicates_en'] and not missing_struct)
 # Use full claim plus prior source evidence and independent PDF index. Low
 # lexical overlap can still be direct paraphrase; keep a modest anchor gate.
 if strong and (lexical>=0.10 or coverage(v,local)>=0.10 or len(pev)>0):
  cell='TP';basis='PDF_SOURCE_PROOF_FAMILY_AND_ANCHORS';unmet=[]
 else:
  cell='FP';basis='GEN_AFFIRMATIVE_UNSUPPORTED_RESIDUAL'
  unmet=list(j['missing_predicates_en'])
  if missing_struct:unmet+=['Missing exact constraints in source: '+', '.join(missing_struct)]
  if not unmet:unmet=['The complete generated claim is not entailed by the original PDF after checking source evidence and the strongest full-document matches.']
 if not pev and best:
  p=best[0];pev=[{'physical_page':p['physical_page'],'quote_en':p['quote_en'],'verified_original_pdf_text':True,'nearest_source_only':True}]
 return {'exclude':False,'cell':cell,'rule':'P7-G-SUPPORTED' if cell=='TP' else 'P7-G-UNSUPPORTED','pdf':pev,'generated':mev,'top_pdf':best,'unmet':unmet,'basis':basis,'coverage':lexical,'missing_struct':missing_struct}

# Audit previously decided items with same independent reciprocal classifier,
# and flag divergences. Original accepted judgments remain authoritative as
# the operator insisted on immutable histories, not silently overwritten.
calibration=[]
for r in prev:
 x=byid[r['item_id']];y=semantic_evidence_R(x) if x['direction']=='R' else semantic_evidence_G(x)
 calibration.append({'item_id':r['item_id'],'existing':r['final_cell'],'new_diagnostic':y.get('cell'),'agreement':r['final_cell']==y.get('cell'),'basis':y.get('basis')})

new=[];elig_new=[];audits=[];unresolved=[];status=collections.Counter();analysis_counts=collections.Counter()
for x in rows:
 id=x['item_id']
 if id in finished or id in excluded:continue
 m=x['immutable_external_semantic_result'];q=x['original_queue_item'];j=m['model_json'];v=q['statement_en']
 res=semantic_evidence_R(x) if x['direction']=='R' else semantic_evidence_G(x)
 if res.get('exclude'):
  # Save source-excerpt grounded eligibility supersession, not a fabricated FP.
  ges=res['generated'];
  if not ges:
   unresolved.append({'item_id':id,'direction':x['direction'],'reason_en':'Could not verify original generated occurrence required for eligibility supersession.'});continue
  ec={'record_type':'PHASE07A_ELIGIBILITY_SUPERSESSION','item_id':id,'direction':'G','method':'fullload','shard':'A','protocol_version':'10.6','prior_phase05_eligibility':'DEFINITIVE','reviewed_eligibility':'NONDEFINITIVE','final_cell':None,'not_counted_as_a_final_binary_cell':True,'source_reference_unchanged':True,'generated_evidence':ges,'pdf_evidence':res['pdf'],'decision_reason_en':res['reason']+' Original source context was independently read from the SHA-verified Markdown line.','eligibility_basis':res['eligibility_basis'],'input_item_hash':sha(jd(x).encode()),'external_result_sha256':sha(jd(m).encode()),'prior_v5_suggested_decision':m['suggested_decision'],'prior_v5_decision_status':m['decision_status']}
  elig_new.append(ec);status['G:EXCLUDED_NONDEFINITIVE']+=1
  audits.append({'record_type':'PHASE07A_DECISION_EVIDENCE_AUDIT','item_id':id,'final_disposition':'EXCLUDED_NONDEFINITIVE','generated_evidence':ges,'original_full_statement_en':v,'original_source_shas_verified':True,'independent_source_row_check':True})
  continue
 if not res['pdf'] or not res['generated']:
  # A semantic label without source provenance is not written to final ledger.
  unresolved.append({'item_id':id,'direction':x['direction'],'reason_en':'Original PDF or generated source evidence could not be verified without inventing a quotation.','independent_result_candidate':res.get('cell')});continue
 source_id= x['direction']
 cell=res['cell'];status[f'{source_id}:{cell}']+=1
 rule=res['rule'];basis=res['basis']
 if cell=='TP':
  if x['direction']=='R':why=f'PDF-positive requirement: {v}. Independently checked original PDF quotation and source-role-verified generated lines, including source-specific structural anchors where present; full-predicate evidence was accepted under {basis}. Evidence candidates were re-ranked against all eight original generated files.'
  else:why=f'PDF support for the complete definitive generated proposition: {v}. Physical-page source excerpts, original Markdown context, and named constraints were reciprocally checked using {basis}; this is G diagnostic support, not a canonical source TP.'
 else:
  if x['direction']=='R':why=f'After reciprocal search across all eight original Markdown sources, full coverage of the PDF-positive statement {v} is not established. Strongest generated near-matches and the unmet source predicates are recorded; broad topical similarity alone cannot prove source coverage.'
  else:why=f'The original definitive generated proposition {v} goes beyond the relevant PDF authority in an essential predicate; the nearest original PDF passages do not establish the entire claim. Unmet support and PDF search witnesses are recorded; this G:FP is diagnostic and must be deduplicated in Phase 08.'
 record={'record_type':'ASSISTANT_ADJUDICATION','item_id':id,'direction':source_id,'method':'fullload','shard':'A','protocol_version':'10.6','local_phase07_amendment':'P7-3SHARD-2026-11-22','final_cell':cell,'canonical_counting_scope':'R_SOURCE' if source_id=='R' else ('G_DIAGNOSTIC_NOT_CANONICAL_TP' if cell=='TP' else 'G_FP_CANDIDATE_NEEDS_PHASE08_DEDUP'),'decision_rule_id':rule,'source_pdf_sha256':x['source_pdf_sha256'],'generated_file_sha256':md_hash,'input_item_hash':sha(jd(x).encode()),'external_result_sha256':sha(jd(m).encode()),'pdf_evidence':res['pdf'],'generated_evidence':res['generated'],'examined_candidate_ids':[id],'support_bridge_ids':[],'unmet_predicates_en':res['unmet'],'decision_reason_en':why,'decision_origin':'PHASE07_ASSISTANT','prior_v5_suggested_decision':m['suggested_decision'],'prior_v5_decision_status':m['decision_status'],'was_external_llm_selected':True,'source_reference_unchanged':True,'evidence_proof_method':basis,'algorithmically_adjudicated_not_manually_certified':True}
 new.append(record)
 audits.append({'record_type':'PHASE07A_DECISION_EVIDENCE_AUDIT','item_id':id,'direction':source_id,'final_cell':cell,'original_statement_en':v,'original_model_relation':j['relation'],'original_model_eligibility':j['eligibility'],'original_v5_suggestion':m['suggested_decision'],'source_checked':True,'eight_generated_files_searched':True,'ninety_pdf_pages_indexed':True,'real_pdf_quote_count':len(res['pdf']),'real_generated_quote_count':len(res['generated']),'unmet_predicates_en':res['unmet'],'document_witnesses':res.get('top_md',[]),'pdf_witnesses':res.get('top_pdf',[]),'independent_search_score_not_a_truth_measure':res['coverage'],'exact_structured_anchor_gaps':res['missing_struct'],'outcome_basis':basis,'decision_reason_en':why})

allfin=prev+new
allelig=prev_elig+elig_new
acnt=collections.Counter(y['direction']+':'+y['final_cell'] for y in allfin)
assert len(set(y['item_id'] for y in allfin+allelig))==len(allfin)+len(allelig)
assert len(allfin)+len(allelig)+len(unresolved)==1926
order={x['item_id']:i for i,x in enumerate(rows)}
for ar in [allfin,allelig,audits,new,elig_new,unresolved]:ar.sort(key=lambda z:order[z['item_id']])
assert all(y['final_cell'] in ('TP','FN','FP') for y in allfin)
emit('07_assistant_adjudications_A.jsonl',allfin)
emit('07_decision_audit_A.jsonl',audits)
emit('07_eligibility_supersessions_A.jsonl',allelig)
emit('07_new_adjudications_A.jsonl',new)
emit('07_new_eligibility_supersessions_A.jsonl',elig_new)
emit('07_input_blockers_A.jsonl',unresolved)
emit('07_independent_classifier_calibration_A.jsonl',calibration)
summary={'record_type':'PHASE07A_ADJUDICATION_SUMMARY','method':'fullload','shard':'A','protocol_version':'10.6','local_phase07_amendment':'P7-3SHARD-2026-11-22','status':'COMPLETE' if not unresolved else 'INCOMPLETE','assigned_items_total':1926,'source_positive_R_total':638,'original_generated_G_total':1288,'original_adjudications_preserved':len(prev),'new_evidence_decisions':len(new),'active_eligible_final_binary_cells':len(allfin),'eligibility_supersessions_preserved':len(prev_elig),'new_eligibility_supersessions':len(elig_new),'nondf_excluded_from_scoring':len(allelig),'total_exclusions_after_reinspection':len(allelig),'unresolved_eligible_items':len(unresolved),'id_partition_complete':len(allfin)+len(allelig)+len(unresolved)==1926,'final_cell_counts':dict(acnt),'R_complete':acnt['R:TP']+acnt['R:FN']==638,'active_G_complete':acnt['G:TP']+acnt['G:FP']+len(allelig)==1288,'model_execution':'gpt-6.2-sol','external_reasoning_effort':'high','external_item_count':3852,'queue_sha256':qsha,'source_pdf_sha256':rows[0]['source_pdf_sha256'],'original_evaluator_suggestions_unmodified':True,'source_reference_unchanged':True,'original_phase07A_decisions_unmodified':True,'phase07_B_started':False,'phase07_C_started':False,'metric_not_computed':True,'independent_decision_method_en':'Assistant-developed deterministic bidirectional source quotation, structured-anchor and full-corpus near-match adjudication. This is a machine-assisted evidence evaluation; no representation of expert manual certification for every item. Full external suggestions are considered but never directly copied without independently checking original PDF and Markdown witnesses. Scope, contextual exceptions, and implicit cross-file semantic entailment may require later audit.','important_eligibility_disclosure_en':'Phase 05 definitive classes that are actually unresolved proposals, status-only questions or editorial statements receive explicit Phase 07 eligibility supersessions and are excluded from diagnostic G TP/FP. Original Phase 05 and Phase 06 files remain byte-preserved. The final Phase 07-C reconciliation must account for these supersessions and may not coerce them into FP/TN.','calibration_agreement':sum(x['agreement'] for x in calibration),'calibration_original_decisions':len(calibration),'calibration_disagreements':[x['item_id'] for x in calibration if not x['agreement']]}
(OUT/'07_adjudication_summary_A.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(summary,ensure_ascii=False,indent=2))
