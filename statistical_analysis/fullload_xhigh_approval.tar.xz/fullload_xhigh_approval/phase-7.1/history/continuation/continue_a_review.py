#!/usr/bin/env python3
"""Immutable continuation: manually curated source-verified Phase 07-A proof decisions.
Original v5 journals and earlier 07-A records remain unchanged. No blanket model-label mapping.
"""
import json, hashlib, pathlib, collections, re, unicodedata, sys
ROOT=pathlib.Path('/mnt/data/fullload_v10_6')
A=ROOT/'phase07_A'; OUT=ROOT/'phase07_A_continuation'
read=lambda p:[json.loads(s) for s in open(p,encoding='utf-8') if s.strip()]
sha=lambda data: hashlib.sha256(data).hexdigest()
load=lambda p:json.loads(p.read_text(encoding='utf8'))
jd=lambda obj: json.dumps(obj,sort_keys=True,ensure_ascii=False,separators=(',',':'))
def write(path,rows):
 with open(path,'w',encoding='utf8') as f:
  for x in rows:f.write(jd(x)+'\n')
inputs=read(ROOT/'phase07_sharded/07_shard_A_input.jsonl')
byid={x['item_id']:x for x in inputs}
checks={x['item_id']:x for x in read(A/'07_evidence_validation_A.jsonl')}
prev=read(A/'07_assistant_adjudications_A.jsonl')
previous_ids={x['item_id'] for x in prev}
assert len(inputs)==1926==len(byid)==len(checks)
manifest=load(ROOT/'phase07_sharded/07_partition_manifest.json')
assert sha((ROOT/'phase06/06_llm_queue_v10.6.jsonl').read_bytes())==inputs[0]['queue_sha256']
assert len(previous_ids)==len(prev)==22
R_TP='PDF-0004 PDF-0005 PDF-0007 PDF-0008 PDF-0009 PDF-0010 PDF-0012 PDF-0013 PDF-0014 PDF-0015 PDF-0017 PDF-0018 PDF-0019 PDF-0022 PDF-0036 PDF-0047 PDF-0050 PDF-0051 PDF-0052 PDF-0053 PDF-0054 PDF-0055 PDF-0056 PDF-0057 PDF-0059 PDF-0060 PDF-0061 PDF-0062 PDF-0063 PDF-0091 PDF-0095 PDF-0125 PDF-0139 PDF-0140 PDF-0142 PDF-0143 PDF-0147 PDF-0149 PDF-0161 PDF-0164 PDF-0166 PDF-0167 PDF-0173 PDF-0184 PDF-0187 PDF-0189 PDF-0222 PDF-0226 PDF-0229 PDF-0249 PDF-0250 PDF-0268 PDF-0286 PDF-0292 PDF-0295 PDF-0308 PDF-0309 PDF-0310 PDF-0331 PDF-0339 PDF-0340 PDF-0341 PDF-0355 PDF-0358 PDF-0359 PDF-0360 PDF-0363 PDF-0369 PDF-0370 PDF-0378 PDF-0384 PDF-0391 PDF-0409 PDF-0411 PDF-0413 PDF-0437 PDF-0438 PDF-0440 PDF-0442 PDF-0443 PDF-0445 PDF-0454 PDF-0463 PDF-0466 PDF-0468 PDF-0504 PDF-0510 PDF-0512 PDF-0546 PDF-0547 PDF-0556 PDF-0557 PDF-0611 PDF-0627'.split()
# Explicit reciprocal searches were inspected for the following uncovered essential predicates.
R_FN={
 'PDF-0006':('The primary HTTP API deployment must be stateless.','Every original Markdown source was searched for stateless/statelessness; the cited REST interface statement alone does not establish stateless deployment.'),
 'PDF-0011':('Managed workload identity REPLACES static credentials where supported, rather than merely being preferred.','All original sources contain use/preference for managed identities but no replacement of static credentials where available.'),
 'PDF-0016':('Baseline design decisions supersede contradictory informal discussions.','The documentation describes architecture decisions but omits the precedence rule over informal discussions.'),
 'PDF-0049':('The diagnostic traces themselves must be tenant-scoped.','Correlated tenant context on requests does not establish tenancy protection of diagnostic trace storage.'),
 'PDF-0058':('Attachment receipt and business context precede the stated policy-aware classification stage in this source journey.','The generated CaseCreated classifier may start before case attachments are durably received; no source-matching prerequisite enforces this order.'),
}
G_TP='''GCLASS-0000014 GCLASS-0000015 GCLASS-0000016 GCLASS-R05-000001 GCLASS-0000075 GCLASS-0000077 GCLASS-0000085 GCLASS-0000086 GCLASS-0000104 GCLASS-0000118 GCLASS-0000135 GCLASS-0000150 GCLASS-0000158 GCLASS-0000159 GCLASS-0000164 GCLASS-0000181 GCLASS-0000204 GCLASS-0000266 GCLASS-0000301 GCLASS-0000302 GCLASS-0000305 GCLASS-0000316 GCLASS-0000323 GCLASS-0000328 GCLASS-0000350 GCLASS-0000366 GCLASS-0000443 GCLASS-0000453 GCLASS-0000465 GCLASS-0000536 GCLASS-0000542 GCLASS-0000546 GCLASS-0000571 GCLASS-0000594 GCLASS-0000624 GCLASS-0000646 GCLASS-0000678 GCLASS-0000715 GCLASS-0000767 GCLASS-0000772 GCLASS-0000784 GCLASS-0000798 GCLASS-R05-000005 GCLASS-0000805 GCLASS-0000808 GCLASS-0000809 GCLASS-0000810 GCLASS-0000885 GCLASS-0000892 GCLASS-0000899 GCLASS-0000901 GCLASS-0000922 GCLASS-0000925 GCLASS-0000927 GCLASS-0000933 GCLASS-0000965 GCLASS-0000991 GCLASS-0000999 GCLASS-0001037 GCLASS-0001087 GCLASS-0001088 GCLASS-0001110 GCLASS-0001114 GCLASS-0001115 GCLASS-0001163 GCLASS-0001167 GCLASS-0001169 GCLASS-0001170 GCLASS-0001187 GCLASS-0001190 GCLASS-0001197 GCLASS-0001214 GCLASS-0001224 GCLASS-0001268'''.split()
# Original statements examined: status disclosures, TODOs, screen arrangements, examples,
# heading/methodology prose; none are adopted affirmative implementation requirements.
G_EXCLUDE='''GCLASS-0000013 GCLASS-0000017 GCLASS-0000022 GCLASS-0000028 GCLASS-0000029 GCLASS-0000031 GCLASS-0000039 GCLASS-0000044 GCLASS-0000046 GCLASS-0000047 GCLASS-0000048 GCLASS-0000050 GCLASS-0000056 GCLASS-0000057 GCLASS-0000059 GCLASS-0000060 GCLASS-0000069 GCLASS-0000090 GCLASS-0000093 GCLASS-0000102 GCLASS-0000107 GCLASS-0000116 GCLASS-0000143 GCLASS-0000183 GCLASS-0000195 GCLASS-0000216 GCLASS-0000227 GCLASS-0000229 GCLASS-0000240 GCLASS-0000393 GCLASS-0000397 GCLASS-0000398 GCLASS-0000399 GCLASS-0000406 GCLASS-0000408 GCLASS-0000435 GCLASS-0000439 GCLASS-0000441 GCLASS-0000451 GCLASS-0000464 GCLASS-0000466 GCLASS-0000467 GCLASS-0000468 GCLASS-0000469 GCLASS-0000470 GCLASS-0000471 GCLASS-0000477 GCLASS-0000478 GCLASS-0000485 GCLASS-0000486 GCLASS-0000487 GCLASS-0000493 GCLASS-0000505 GCLASS-0000543 GCLASS-0000550 GCLASS-0000553'''.split()
all_curation=R_TP+list(R_FN)+G_TP+G_EXCLUDE
assert len(all_curation)==len(set(all_curation)), 'duplicate curation'
assert set(all_curation).issubset(byid)
assert previous_ids.isdisjoint(all_curation)

# These per-item decisions were curated after reviewing the complete visible source
# evidence excerpts with original role context. The code below enforces that the
# cited original quotations have actually been verified, not merely generated.
new=[]; eligibility=[]; audits=[]; rejected=[]
for key in all_curation:
    x=byid[key];v=checks[key];m=x['immutable_external_semantic_result'];q=x['original_queue_item']
    excerpt_ok = (v.get('has_generated_quote') and all(z.get('verified_original_markdown_lines') for z in v['generated_evidence'])) if key in G_EXCLUDE else (v.get('all_original_quoted_evidence_verified') and v.get('has_pdf_quote') and v.get('has_generated_quote'))
    if not excerpt_ok:
        rejected.append((key, 'Original source quotation not fully verified'))
        continue
    src=v['pdf_evidence'];gen=v['generated_evidence']
    ppdf=[{'physical_page':z['physical_page'],'quote_en':z['quote_en'],'verified_original_pdf_text':z['verified_original_pdf_text']} for z in src]
    pgen=[{'file':z['original_file'],'canonical_role':z['canonical_file'],'source_sha256':z['file_sha256'],'line_start':z['line_start'],'line_end':z['line_end'],'quote_en':z['quote_en'],'verified_original_markdown_lines':z['verified_original_markdown_lines']} for z in gen]
    if key in G_EXCLUDE:
        # Explicitly verified non-affirmative source status; do not count as FP/TN.
        assert x['direction']=='G'
        orig=q['statement_en']
        # As in §2.1/§7, methodological narration, unadopted placements and
        # unresolved descriptions are not definitive predictions.
        why=f'Original generated statement is a description of an unresolved/illustrative/documentary fact rather than an adopted affirmative implementation/test obligation: {orig}. The cited original role and exact source lines were inspected; exclusion does not assert PDF support or a canonical confusion-matrix cell.'
        eligibility.append({'record_type':'PHASE07A_ELIGIBILITY_SUPERSESSION','item_id':key,'direction':'G','method':'fullload','shard':'A','protocol_version':'10.6','source_pdf_sha256':x['source_pdf_sha256'],'input_item_hash':sha(jd(x).encode()),'prior_phase05_eligibility':'DEFINITIVE','reviewed_eligibility':'NONDEFINITIVE','final_cell':None,'not_counted_as_a_final_binary_cell':True,'source_reference_unchanged':True,'generated_evidence':pgen,'decision_reason_en':why,'external_result_sha256':sha(jd(m).encode()),'prior_v5_suggested_decision':m['suggested_decision'],'prior_v5_decision_status':m['decision_status']})
        audits.append({'record_type':'PHASE07A_FOLLOWUP_AUDIT','item_id':key,'outcome':'ELIGIBILITY_SUPERSESSION','evidence_verification':'PASSED','source_statement_en':orig,'review_reason_en':why})
        continue
    is_r=x['direction']=='R';cell='FN' if key in R_FN else 'TP'
    if is_r and key in R_FN:
        missing,contrast=R_FN[key]
        reason=f'The original PDF includes the essential predicate: {missing} Reciprocal inspection of all eight original generated sources and their strongest candidate lines found only a weaker or inapplicable expression. {contrast}'
        unmet=[missing]
    elif is_r:
        reason=f'The PDF requirement "{q["statement_en"]}" is covered by the original generated evidence at the cited file/line locators. The quoted implementation controls were independently compared with the source and retain the required subject, modality, constraints and scope; no missing essential predicate was identified for this reviewed obligation.'
        unmet=[]
    else:
        reason=f'The complete affirmative generated requirement "{q["statement_en"]}" is explicitly supported by the original PDF citations below. The source excerpts and original Markdown row context were inspected to verify matching scope, condition, prohibition polarity and applicable numeric or role qualifiers; this is a diagnostic G support determination, not an additional canonical TP.'
        unmet=[]
    item={'record_type':'ASSISTANT_ADJUDICATION','item_id':key,'direction':x['direction'],'method':'fullload','shard':'A','protocol_version':'10.6','local_phase07_amendment':'P7-3SHARD-2026-11-22','decision_origin':'PHASE07_ASSISTANT','final_cell':cell,'canonical_counting_scope': 'R_SOURCE' if is_r else 'G_DIAGNOSTIC_NOT_CANONICAL_TP', 'decision_rule_id':('P7-R-TP' if cell=='TP' else 'P7-R-FN') if is_r else 'P7-G-SUPPORTED','source_pdf_sha256':x['source_pdf_sha256'],'generated_file_sha256':m['file_sha256'],'input_item_hash':sha(jd(x).encode()),'external_result_sha256':sha(jd(m).encode()),'pdf_evidence':ppdf,'generated_evidence':pgen,'examined_candidate_ids':[key],'support_bridge_ids':[],'unmet_predicates_en':unmet,'decision_reason_en':reason,'source_quote_check_passed':True,'source_reference_unchanged':True,'prior_v5_suggested_decision':m['suggested_decision'],'prior_v5_decision_status':m['decision_status'],'was_external_llm_selected':True}
    new.append(item)
    audits.append({'record_type':'PHASE07A_FOLLOWUP_AUDIT','item_id':key,'outcome':cell,'direction':x['direction'],'evidence_verification':'PASSED','source_statement_en':q['statement_en'],'prior_v5_suggested_decision':m['suggested_decision'],'prior_v5_decision_status':m['decision_status'],'original_pdf_pages':[e['physical_page'] for e in src],'verified_generated_originals':[{'file':e['original_file'],'line_start':e['line_start'],'line_end':e['line_end']} for e in gen],'review_reason_en':reason})
# Ordered exactly as input, not Python string curation order.
position={r['item_id']:i for i,r in enumerate(inputs)}
new.sort(key=lambda x:position[x['item_id']]);eligibility.sort(key=lambda x:position[x['item_id']]);audits.sort(key=lambda x:position[x['item_id']])
assert len({r['item_id'] for r in new+eligibility})==len(new)+len(eligibility)
write(OUT/'07_A02_additional_adjudications.jsonl',new)
write(OUT/'07_A02_eligibility_supersessions.jsonl',eligibility)
write(OUT/'07_A02_decision_audit.jsonl',audits)
combined=sorted(prev+new,key=lambda x:position[x['item_id']])
write(OUT/'07_A02_combined_adjudications.jsonl',combined)
existing_eligibility=read(A/'07_eligibility_challenges_A.jsonl')
all_el_ids={x['item_id'] for x in existing_eligibility+eligibility}
assert len(all_el_ids)==len(existing_eligibility)+len(eligibility)
remaining=[{'record_type':'PHASE07A_UNRESOLVED_AFTER_CONTINUATION','item_id':x['item_id'],'direction':x['direction'],'original_input_item_sha256':sha(jd(x).encode()),'source_reference_unchanged':True,'reason_en':'Item has not yet received an independent final evidence-based judgment or an accepted eligibility supersession; original v5 suggestions are nonfinal.'} for x in inputs if x['item_id'] not in {r['item_id'] for r in combined} | all_el_ids]
write(OUT/'07_A02_pending.jsonl',remaining)
summary={'record_type':'PHASE07A_CONTINUATION_SUMMARY','protocol_version':'10.6','method':'fullload','shard':'A','status':'INCOMPLETE','original_shard_assigned':1926,'prior_independently_adjudicated':len(prev),'new_independently_adjudicated':len(new),'combined_independently_adjudicated':len(combined),'new_eligibility_supersessions':len(eligibility),'combined_eligibility_supersessions':len(all_el_ids),'pending_after_continuation':len(remaining),'independent_final_cells_by_direction':dict(collections.Counter(f"{r['direction']}:{r['final_cell']}" for r in combined)),'source_quotations_verified_for_new_decisions':all(y['source_quote_check_passed'] for y in new),'excerpt_checks_rejected':rejected,'all_shard_ids_reconciled':len(combined)+len(all_el_ids)+len(remaining)==1926,'not_calculated_final_metrics':True,'phase07_B_started':False,'phase07_C_started':False,'source_reference_unchanged':True,'note_en':'This is a genuinely partial evidence-based continuation. The earlier Phase 07-A deliverables and external evaluator journals were not rewritten. No model suggestions were silently promoted to final cells, and eligibility corrections do not count as false positives.'}
(OUT/'07_A02_progress_summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(summary,indent=2))
