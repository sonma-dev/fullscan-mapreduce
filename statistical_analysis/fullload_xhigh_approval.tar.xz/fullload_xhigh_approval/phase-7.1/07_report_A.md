# Phase 07-A — Completion and Evidence Audit

**Protocol:** 10.6, local amendment `P7-3SHARD-2026-11-22`  
**Method:** `fullload`  
**External evaluator:** `gpt-6.2-sol`, reasoning effort `high`  
**Status:** All assigned original IDs processed and reconciled; the eligibility supersessions below require global Phase 07-C reconciliation.

## Population

| Record category | Count |
|---|---:|
| Assigned Phase 07-A source R | 638 |
| Assigned Phase 07-A generated G | 1,288 |
| Canonical R:TP | 520 |
| Canonical R:FN | 118 |
| Diagnostic G:TP (PDF-supported) | 935 |
| Diagnostic G:FP (unsupported; requires Phase 08 N/F dedup) | 133 |
| G eligibility supersessions: nondefinitive | 220 |
| Unclassified eligible items / missing IDs | 0 |

The 220 eligibility supersessions are **not** canonical negatives, TPs, or FPs. They are source-grounded corrections to Phase 05's definitive-class extraction. They must be reconciled with frozen GO/GC identity and the original local amendment before global counting. The original Phase 01–06 files were not rewritten.

## Method and audit strength

- Reopened and hashed the 90-page original PDF and all eight Markdown originals.
- Preserved 241 committed external-batch results, `gpt-6.2-sol` source judgments, and previous 194 accepted assistant decisions without mutation.
- Performed bidirectional full-corpus text indexing, checked original source quotes, route/status/numeric anchors, source-specific scope and cited full/partial evidence; excluded local document-only commentary where affirmative eligibility failed.
- Every active binary result has original PDF and Markdown evidence, source hashes and original line/page locators. Quotations were independently checked in the final verification pass.
- Numeric search scores are candidate-discovery diagnostics and **not** semantic proof, calibrated probability, or independent expert judgment. This machine-assisted pass is not a claim of manual human validation of all 1,926 items.
- Original `FULL`, `PARTIAL`, `NOT_FOUND`, and model self-confidence fields have been retained for audit. Semantic disagreement between the original external model and the assistant adjudication is not silently resolved by rewriting the original model output.

## Important methodological exception

The 3-Shard amendment speaks of one final binary cell per assigned original ID, but the original source contains nondefinitive, unadopted and open-question text that Phase 05 erroneously entered as eligible GC. Forcing one of those 220 nondefinitive items into TP/FP would invent a scored assertion. Instead, all 1,926 original IDs appear exactly once in the inclusive disposition index: 1,706 eligible binary decisions plus 220 explicitly excluded nondefinitive corrections. Phase 07-C must resolve the population-adjustment implication and use source evidence for any later supersession.

## Limits and sequencing

Phase 07-B and Phase 07-C were not run. No final confusion matrix, Precision, Recall, F1 or generated-only deduplicated FP was computed. A complete global metric remains contingent on Phase 07-B and Phase 07-C reconciliation and the independent Phase 08/09 gates.

## Cross-method invariance requirement

This Phase 07-A uses the original v5 semantic results from `gpt-6.2-sol` with `high` reasoning, followed by the disclosed deterministic source-grounded assistant evaluation. The complete adjudication/eligibility procedure (not just the external model name), the frozen PDF/R/N identities, and exact class/duplicate policy must be applied equally to `onelevel` and `twolevel` before treating metric differences as comparable. An externally recorded `high` reasoning effort must not be mislabeled as the specification-generation `xhigh` effort or the v10.6 printed `medium` default.
