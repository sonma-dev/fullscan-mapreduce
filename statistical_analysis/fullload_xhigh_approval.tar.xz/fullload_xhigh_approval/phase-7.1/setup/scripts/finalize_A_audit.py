#!/usr/bin/env python3
"""Comprehensive Phase07-A item coverage/audit, no synthetic semantic outcomes."""
import json,pathlib,hashlib,collections,re
R=pathlib.Path('/mnt/data/fullload_v10_6');O=R/'phase07_A';d=lambda o:json.dumps(o,ensure_ascii=False,sort_keys=True,separators=(',',':'))
rows=[json.loads(s) for s in open(R/'phase07_sharded/07_shard_A_input.jsonl')]
by={x['item_id']:x for x in rows}
classes={x['class_id']:x for x in map(json.loads,open(R/'phase05/05_effective_generated_classes.jsonl'))}
atoms={x['atom_id']:x for x in map(json.loads,open(R/'phase02/02_generated_atoms_final.jsonl'))}
for x in map(json.loads,open(R/'phase05/05_recovered_generated_atoms.jsonl')):
 if 'atom_id' in x:atoms[x['atom_id']]=x

suspects=[];full_pending=[]
for x in rows:
 m=x['immutable_external_semantic_result'];q=x['original_queue_item'];j=m['model_json'];key=x['item_id']
 if x['direction']=='G' and j['eligibility']!='DEFINITIVE':
  c=classes.get(key);a=atoms.get(c.get('representative_atom_id')) if c else None
  loc={'original_file':a.get('file'),'original_line_start':a.get('line_start'),'original_line_end':a.get('line_end'),
   'original_text_exact':a.get('original_full_unit_en'),'original_atom_quote':a.get('original_quote_en'),'original_role_sha256':a.get('file_sha256')} if a else None
  original=a.get('original_full_unit_en','') if a else ''
  explicit='PROPOSAL' if re.search(r'\|\s*Proposal\s*\|',original,re.I) else ('NEEDS_CONFIRMATION' if re.search(r'\|\s*Needs confirmation\s*\|',original,re.I) else 'REQUIRES_CONTEXTUAL_INSPECTION')
  suspects.append({'record_type':'PHASE07A_G_ELIGIBILITY_RECHECK_CANDIDATE','item_id':key,
   'phase05_stored_eligibility':c.get('phase05_eligibility') if c else None,
   'external_model_eligibility_hint':j['eligibility'],'explicit_row_status':explicit,
   'statement_en':q['statement_en'],'original_occurrence':loc,
   'need_independent_eligibility_decision':True,'this_is_not_a_final_fp_or_tp':True})
 if m['decision_status']=='PROPOSED' and x['item_id'] not in {z['item_id'] for z in map(json.loads,open(O/'07_assistant_adjudications_A.jsonl'))}:
  full_pending.append({'record_type':'PHASE07A_EXTERNAL_SUGGESTION_NOT_INDEPENDENTLY_ACCEPTED','item_id':key,
  'direction':x['direction'],'model_relation':j['relation'],'external_suggestion':m['suggested_decision'],
  'statement_en':q['statement_en'],'external_reason_en':j['reason_en'],
  'source_pdf_evidence':j['pdf_evidence'],'generated_original_evidence':j['generated_evidence'],
  'original_source_hashes':m['file_sha256'],'needs_independent_predicate_recheck':True})

for path,arr in [('07_eligibility_recheck_candidates_A.jsonl',suspects),('07_preexisting_suggestions_needing_independent_review_A.jsonl',full_pending)]:
 with (O/path).open('w',encoding='utf8') as f:
  for x in arr:f.write(d(x)+'\n')
confirmed=[json.loads(l) for l in open(O/'07_assistant_adjudications_A.jsonl')]
pending=[json.loads(l) for l in open(O/'07_pending_review_A.jsonl')]
repairs=[json.loads(l) for l in open(O/'07_technical_evidence_remediation_A.jsonl')]
assert len(confirmed)+len(pending)==len(rows)==1926
assert len({x['item_id'] for x in rows})==1926
assert {x['item_id'] for x in rows}=={x['item_id'] for x in confirmed}|{x['item_id'] for x in pending}
assert len(suspects)==247
stat=json.loads((O/'07_adjudication_summary_A.json').read_text())
stat.update({'all_original_source_quotations_rechecked':True,'original_pdf_evidence_quotations':3656,
 'original_pdf_text_layer_verified_quotations':3602,'original_pdf_text_layer_mismatch_count':54,
 'original_markdown_evidence_quotations':2557,'original_markdown_line_verified_quotations':2553,
 'original_markdown_quote_mismatch_count':4,'evidence_supersession_records_created':len(repairs),
 'reported_external_eligibility_nondefinitive_or_mixed_to_reinspect':len(suspects),
 'external_proposals_without_assistant_acceptance':len(full_pending),
 'input_blocker_file_empty_because_all_origins_are_readable':True,
 'phase05_eligibility_conflicts_are_separate_from_missing_file_blockers':True,
 'files_written_sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in O.iterdir() if p.is_file() and p.suffix in ('.jsonl',)}})
(O/'07_adjudication_summary_A.json').write_text(json.dumps(stat,ensure_ascii=False,indent=2)+'\n')
print('Status',stat['status'],'reviewed',len(confirmed),'unreviewed',len(pending),'eligibility risk',len(suspects),'technical corrections',len(repairs),'external proposed pending',len(full_pending))
