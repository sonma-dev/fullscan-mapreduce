#!/usr/bin/env python3
"""Prepare an immutable, evidence-linked three-shard Phase 07 amendment.
Only partitions external records; does not make semantic decisions or alter prior phases.
"""
from __future__ import annotations
import hashlib, json, zipfile, pathlib, collections, math

ROOT=pathlib.Path('/mnt/data/fullload_v10_6')
OUT=ROOT/'phase07_sharded'
OUT.mkdir(parents=True,exist_ok=True)
IN=pathlib.Path('/mnt/data')
qpath=ROOT/'phase06/06_llm_queue_v10.6.jsonl'
rpath=IN/'semantic_decisions(4).jsonl'
sumpath=IN/'semantic_summary(3).json'
statepath=IN/'run_state(3).json'
archive=IN/'batch_journals(3).zip'

sha=lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
def load_jsonl(path):
    with path.open('r',encoding='utf-8') as fh: return [json.loads(line) for line in fh if line.strip()]
def save_json(p,o):p.write_text(json.dumps(o,ensure_ascii=False,sort_keys=True,indent=2)+'\n',encoding='utf-8')
def write_jsonl(p,rows):
    with p.open('w',encoding='utf-8') as fh:
        for r in rows:fh.write(json.dumps(r,ensure_ascii=False,sort_keys=True,separators=(',',':'))+'\n')

queue=load_jsonl(qpath)
decisions=load_jsonl(rpath)
summary=json.loads(sumpath.read_text())
state=json.loads(statepath.read_text())
assert len(queue)==3852==len(decisions)
assert state['model']=='gpt-6.2-sol' and state['batch_size']==16
assert summary['status']=='COMPLETE' and summary['completed_items']==3852
assert sha(qpath)==state['queue_sha256']==summary['queue_sha256']
assert all(r['protocol_version']=='10.6' for r in queue)
qids=[x['item_id'] for x in queue]
dids=[x['item_id'] for x in decisions]
assert qids==dids, 'Original evaluator results must follow queue order.'
assert len(set(qids))==len(qids)
assert {x['reasoning_effort'] for x in decisions}=={'high'}
assert {x['model'] for x in decisions}=={'gpt-6.2-sol'}
assert all(x['queue_sha256']==state['queue_sha256'] and x['pdf_sha256']==state['pdf_sha256'] for x in decisions)
assert all(x['decision_status'] in {'PROPOSED','UNRESOLVED'} for x in decisions)

# Hashes of original uploads are checked against the hashes of Azure-processed originals.
actual_files={
 'OrionDesk_AI_Detailed_Design_Specification.pdf':'OrionDesk_AI_Detailed_Design_Specification(2).pdf',
 '01_screen_functions.md':'01_screen_functions(2).md',
 '02_api.md':'02_api(2).md',
 '03_data.md':'03_data(2).md',
 '04_batch_functions.md':'04_batch_functions(3).md',
 '05_business_rules.md':'05_business_rules(2).md',
 '06_exception_handling.md':'06_exception_handling(4).md',
 '07_processing_flows.md':'07_processing_flows(4).md',
 '08_architecture_decision.md':'08_architecture_decision(3).md'
}
for canonical,orig in actual_files.items():
    assert sha(IN/orig)==state['file_sha256'][canonical]==summary['source_file_sha256'][canonical],(orig,'source digest mismatch')

# Compare original immutable batch journals to aggregate per-item records and frozen batch slices.
zipsha=sha(archive)
by_item={x['item_id']:x for x in decisions}
actual_batches=set()
record_n=0
with zipfile.ZipFile(archive) as z:
    if z.testzip() is not None: raise ValueError('corrupt journal zip')
    journals=[x for x in z.namelist() if x.startswith('batch_journals/') and x.endswith('.json')]
    assert len(journals)==summary['completed_batches']==241
    for jname in journals:
        j=json.loads(z.read(jname))
        assert j['batch_id']==jname.rsplit('/',1)[-1][:-5]
        assert j['protocol_version']=='10.6' and j['queue_sha256']==state['queue_sha256']
        b=j['batch_index'];n=j['batch_size']
        assert b not in actual_batches
        actual_batches.add(b)
        expected=qids[b*16:b*16+n]
        js=[x['item_id'] for x in j['item_records']]
        assert js==expected,(j['batch_id'],'invalid ordered items')
        assert [x['item_id'] for x in j['raw_model_json']['results']]==expected
        assert all(x==by_item[x['item_id']] for x in j['item_records'])
        record_n+=len(js)
assert actual_batches==set(range(241)) and record_n==3852
assert all(x['batch_size']==12 for x in decisions[-12:]) # The final committed batch contains 12 of 16 possible items.

R=[(q,d) for q,d in zip(queue,decisions) if q['direction']=='R']
N=[(q,d) for q,d in zip(queue,decisions) if q['direction']=='N']
G=[(q,d) for q,d in zip(queue,decisions) if q['direction']=='G']
assert (len(R),len(N),len(G))==(638,142,3072)
# Balanced two-shard rule applies to all methods with their own GC count,
# without changing any R/N/GC membership or original queue order.
a_g_count=max(0,min(len(G),(len(N)+len(G)-len(R))//2))
assert a_g_count==1288
A=R+G[:a_g_count]
B=N+G[a_g_count:]
assert len(A)==len(B)==1926
set_a={q['item_id'] for q,d in A};set_b={q['item_id'] for q,d in B}
assert not set_a&set_b and set_a|set_b==set(qids)

shard_paths={}
for letter,pairs in [('A',A),('B',B)]:
    p=OUT/f'07_shard_{letter}_input.jsonl'
    rows=[]
    for q,d in pairs:
        rows.append({'record_type':'PHASE07_SHARD_INPUT','protocol_version':'10.6',
          'local_phase07_amendment':'THREE_SHARDS_TWO_ANALYSES_ONE_INTEGRATION',
          'method':'fullload','shard':letter,'item_id':q['item_id'],'direction':q['direction'],
          'source_pdf_sha256':state['pdf_sha256'],'queue_sha256':state['queue_sha256'],
          'original_queue_item':q,'immutable_external_semantic_result':d,
          'final_cell':None,'final_cell_not_yet_adjudicated':True})
    write_jsonl(p,rows)
    shard_paths[letter]={'path':p.name,'sha256':sha(p),'count':len(rows),
        'direction_counts':dict(collections.Counter(x['direction'] for x in rows)),
        'first_id':rows[0]['item_id'],'last_id':rows[-1]['item_id'],
        'external_unresolved_status_count':sum(x['immutable_external_semantic_result']['decision_status']=='UNRESOLVED' for x in rows),
        'external_suggestion_null_count':sum(x['immutable_external_semantic_result']['suggested_decision'] is None for x in rows),
        'external_nondefinitive_suggestions':sum(x['immutable_external_semantic_result']['suggested_decision']=='EXCLUDED_NONDEFINITIVE' for x in rows)}

# The original comparator values are provenance; status deliberately not PHASE_COMPLETE.
manifest={
 'record_type':'PHASE07_SHARD_PARTITION_MANIFEST','protocol_version':'10.6',
 'amendment_id':'P7-3SHARD-2026-11-22',
 'status':'PARTITION_READY_NO_FINAL_ADJUDICATIONS',
 'method':'fullload',
 'generation_reasoning_effort_requested':'xhigh',
 'external_evaluator_model':'gpt-6.2-sol',
 'external_evaluator_reasoning_effort_actual':'high',
 'protocol_specified_evaluator_model':'gpt-6.1-sol',
 'protocol_specified_evaluator_effort':'medium',
 'external_evaluator_version':'10.6',
 'external_batch_size_actual':16,
 'external_journal_batches_verified':241,
 'external_result_items_verified':3852,
 'external_queue_sha256':state['queue_sha256'],
 'source_pdf_sha256':state['pdf_sha256'],
 'source_file_sha256':state['file_sha256'],
 'inputs_sha256':{
   'phase06_queue':sha(qpath),
   'external_results':sha(rpath),
   'external_summary':sha(sumpath),
   'external_run_state':sha(statepath),
   'external_batch_journals_zip':zipsha,
   'phase05_effective_gc':sha(ROOT/'phase05/05_effective_generated_classes.jsonl'),
   'phase06_negative_controls':sha(ROOT/'phase06/06_fp_controls.jsonl')
 },
 'partition_algorithm':{
   'R':'All frozen R in Shard A in original queue order',
   'N':'All frozen N in Shard B in original queue order',
   'G':'G classes in original queue order; prefix goes to Shard A and suffix to Shard B',
   'shard_A_G_count_formula':'clamp(floor((N+G-R)/2),0,G)',
   'shard_A_G_count':a_g_count,
   'no_overlap':True,'complete_exhaustive_coverage':True,
   'every_shard_reviews_all_eight_original_markdown_files':True
 },
 'shards':shard_paths,
 'integrating_shard_C':{'work':'Cross-shard proof consistency, direct conflict resolution with evidence and explicit immutable supersession, merge final item decisions; do NOT perform Phase08 canonical counting',
     'expected_R':638,'expected_N':142,'expected_G':3072,
     'must_see_all_shard_A_B_final_decisions':True,
     'output_names':['07_assistant_adjudications.jsonl','07_decision_audit.jsonl','07_adjudication_summary.json','07_input_blockers.jsonl'],
     'status':'NOT_STARTED'},
 'original_v5_suggestions_are_not_final_binary_cells':True,
 'phase08_or_09_started':False,
 'across_methods_comparability':'Check every method for source/ref hashes, batch-model gpt-6.2-sol, actual reasoning effort, frozen v5 semantic decision policy and same Phase07 sharding/adjudication rules. Model name alone is insufficient.'
}
save_json(OUT/'07_partition_manifest.json',manifest)

counter=collections.Counter((d['direction'],d['decision_status']) for d in decisions)
comments=collections.Counter((d['direction'],str(d['suggested_decision'])) for d in decisions)
errors=[]
checks={
 'pdf_and_all_eight_original_file_hashes_match_external_run':True,
 'source_queue_hash_matches_run_state_and_summary':True,
 'journal_zip_not_corrupt':True,
 'journal_count_matches_complete_batch_set':True,
 'journal_item_records_equal_preserved_aggregate_records':True,
 'all_3852_queue_ids_have_exactly_one_external_result':True,
 'external_model_gpt_6_2_sol_for_every_item':True,
 'external_reasoning_effort_high_for_every_item':True,
 'shard_A_B_disjoint_and_union_covers_all_ids':True,
 'binary_decisions_not_assigned':True,
 'existing_phase_artifacts_unmodified':True
}
report={'record_type':'PHASE07_SHARD_PREPARATION_AUDIT','status':'PASS',
'input_items':len(queue), 'input_direction_counts':dict(collections.Counter(x['direction'] for x in queue)),
'shard_counts':{s:{'items':x['count'],'directions':x['direction_counts']} for s,x in shard_paths.items()},
'external_decision_status_counts':{'|'.join(k):v for k,v in sorted(counter.items())},
'external_suggestions_by_direction':{'|'.join(k):v for k,v in sorted(comments.items())},
'external_unresolved_status_total':sum(d['decision_status']=='UNRESOLVED' for d in decisions),
'external_suggestion_null_total':sum(d['suggested_decision'] is None for d in decisions),
'external_nondefinitive_suggestion_total':sum(d['suggested_decision']=='EXCLUDED_NONDEFINITIVE' for d in decisions),
'checks':checks,
'caveats':['All final cells remain unset; this is partition preparation, not semantic adjudication.',
  'The external evaluator used gpt-6.2-sol at high effort, although the unamended v10.6 protocol names gpt-6.1-sol at medium effort.',
  'EXCLUDED_NONDEFINITIVE proposed for a Phase05 definitive G is an eligibility contradiction that must be independently resolved.',
  'Future cross-method comparisons require actual execution settings and source/reference equivalence verification, not an assertion of compatibility based only on shared model names.']}
save_json(OUT/'07_input_integrity_audit.json',report)

text='''# Phase 07 Three-Shard Amendment (Operational Override)

**Protocol baseline:** OrionDesk Atomic Evaluation Protocol v10.6.  
**Local amendment:** `P7-3SHARD-2026-11-22`.  
**Evaluation method:** `fullload`.  
**Status:** partitioned, not adjudicated.

This amendment is an explicit operator-authorized modification of **Phase 07 execution units only**. It does not change the PDF authority, frozen reference IDs, R/N/GO/GC eligibility, semantic entailment rules, Version 5.0 suggestion semantics, canonical metric population, or Phase 08/09 arithmetic. Do not edit earlier phase artifacts or original external batch journals.

## Shard execution order

1. **07-A: first independent evidence analysis.** Process all 638 frozen R IDs and the first 1,288 GC IDs in their immutable queue order (1,926 distinct items). For every R, decide TP/FN against **all eight** Markdown originals. For each assigned G, decide diagnostic supported TP or unsupported FP against the entire 90-page PDF. Review EXCLUDED_NONDEFINITIVE suggestions against original definitive status; do not automatically exclude them. Produce independent, immutable final per-item decisions with real quotes and locators, not model-only labels.
2. **07-B: second independent evidence analysis.** Process all 142 frozen N IDs and the remaining 1,784 GC IDs in immutable queue order (1,926 distinct items). For every N, decide FP/TN after searching the **entire** generated corpus, including classes allocated to Shard A. For every assigned G, inspect the entire PDF and issue a diagnostic TP/FP. Do not read Shard A's final judgments to choose labels; use the same authority and decision rules independently.
3. **07-C: integration and adjudication-conflict resolution.** Wait for complete original signed/digest-checked 07-A and 07-B outputs. Verify union equals the 3,852 original item IDs and intersection is empty; verify exactly one final cell per ID, original evidence hashes, quote/line/page consistency, and source-specific rule IDs. Compare all cross-shard proof families and apparent contradictions, especially N/G affirmation, R/G coverage, source-specific exceptions, mixed positive/negative statements, and duplicate generated-only residuals. Reinspect original source evidence for any conflict; write explicit, immutable, reasoned Phase 07 superseding decisions for changed cells, retaining both originals. Integrate into Phase 07's four required original output artifact names. Do not count FP residuals or calculate metrics in 07-C; those are Phase 08 and Phase 09 respectively.

## Strict decision and file contract

- All 3,852 input IDs must be judged independently using the **same v10.6 §7.2–7.5 rules**; external suggestions are inputs, not final labels. The prior `suggested_decision=null`, `UNRESOLVED` status, a low confidence value, a provisional `FN/TN`, or an external `EXCLUDED_NONDEFINITIVE` is **not** a final cell.
- For R: `TP` iff complete supported generated coverage; otherwise evidence-supported `FN` after reciprocal challenge.
- For N: `FP` iff an eligible affirmative generated assertion entails the prohibited counterfactual; otherwise `TN` after an exhaustive review.
- For G: `TP` if the PDF entails the full generated claim, otherwise diagnostic `FP` when material unsupportedness is established. **G:TP never adds a canonical source TP. G:FP must be cross-checked for N/F overlap and deduplicated in Phase 08.**
- Mandatory Phase 07 decision IDs are `P7-R-TP`, `P7-R-FN`, `P7-N-FP`, `P7-N-TN`, `P7-G-SUPPORTED`, `P7-G-UNSUPPORTED`; retain accepted quote locators and original role SHA-256 checks.
- Each shard produces `07_assistant_adjudications_<shard>.jsonl`, `07_decision_audit_<shard>.jsonl`, `07_adjudication_summary_<shard>.json`, `07_input_blockers_<shard>.jsonl`. These are required outputs, **not** preexisting data, and must not be fabricated. The final 07-C names omit the shard suffix.
- Each shard's decision record must include all fields required in protocol §7.4, plus `shard`, `input_item_hash`, `external_result_sha256` and cross-file evidence source identities. Preserve model JSON and original external journals byte-for-byte.
- A genuinely missing or corrupt mandatory source makes the affected shard `INCOMPLETE` with a concrete blocker, not a fabricated negative decision. Semantic uncertainty alone is not a permissible final fifth class; an independently justified binary conclusion requires actual source inspection.
- **Exactly one completed shard per conversation response**, in this order: A, B, C. Do not launch Phase 08 before C passes the complete Phase 07 gate. The current preparation response only partitions, and does not claim completion of A, B, or C.

## Actual external evaluation and comparability

The supplied run state, summary, aggregate item results, and 241 committed journals agree on **gpt-6.2-sol** at **high reasoning effort**, 16 items per external batch, 241 completed batches, 3,852 results, and queue SHA-256 `419ccddc7068a6a4a3f5644a0f9617b95e9fcb52de2cdf9ccfe42ab19b6d8eef`.

This empirically differs from v10.6's printed `gpt-6.1-sol / medium` default; it is recorded as an **execution-deviation disclosure**. The operator states the other methods also used `gpt-6.2-sol`, but their execution SHA, effort, prompts, and classification process require verification before asserting complete cross-method comparability. The chosen *generation* effort `xhigh` is a separate experimental factor from the external *semantic evaluator's* `high`. Final Precision/Recall/F1 are **computed arithmetically** from the Phase 08 fully adjudicated ledger; a model produces evidence-based item judgments, not the metric by fiat.

## Files required per analysis

Use `07_shard_A_input.jsonl` or `07_shard_B_input.jsonl`, `07_partition_manifest.json`, `07_input_integrity_audit.json`, the original 90-page PDF and all eight original Markdown files, frozen R/N data and reference freeze, and the original v5 external evaluation results/journals as necessary. For 07-C, use both completed shard decision ledgers and the same originals. The combined source and queue identity must not change between shards.

Do not use shard membership to alter class eligibility, replicate a single generated class across shards, or shortcut absence conclusions based on incomplete shard visibility.
'''
(OUT/'07_phase07_three_shard_amendment.md').write_text(text,encoding='utf-8')

for letter,focus,needed in [('A','R (638) + first 1,288 G classes','All 8 Markdown originals and 90-page PDF; full-class evidence, especially R entailment'),('B','N (142) + remaining 1,784 G classes','All 8 Markdown originals and 90-page PDF; N affirmative polarity and G PDF support')]:
  (OUT/f'07_shard_{letter}_instructions.md').write_text(
     f'# Phase 07-{letter} Independent Analysis Instructions\n\nAssigned: {focus}, exactly 1,926 entries.\n\nRead the governing `07_phase07_three_shard_amendment.md` and the unmodified v10.6 Phase 07 §§7.1–7.5. Use `07_shard_{letter}_input.jsonl`; original PDF and all eight original Markdown sources are required. Verify the manifest and every original quote, do not trust suggested_decision as the final cell.\n\nWrite actual original-evidence-supported `07_assistant_adjudications_{letter}.jsonl`, `07_decision_audit_{letter}.jsonl`, `07_adjudication_summary_{letter}.json`, `07_input_blockers_{letter}.jsonl`. Do not invent verdicts for uninspected items, and do not provide partial results as a completed shard. Check each ID appears exactly once.\n\nSpecific emphasis: {needed}.\n\nOn missing material, mark `INCOMPLETE` with concrete blocker. Do not advance to the next shard until this one is complete.\n',encoding='utf-8')

(OUT/'07_shard_C_integration_instructions.md').write_text(
'''# Phase 07-C Integration Instructions

Inputs: successful A and B final source-grounded adjudication ledgers, original PDF and eight originals, frozen reference, v5 evaluator outputs/journals, and the unchanged `07_partition_manifest.json`.

Verify A and B together cover exactly 3,852 unique IDs (R 638, N 142, G 3,072), with complete original evidence and per-item final binary cells. Verify source SHA and quote/line/page locators. Compare cross-shard R/G and N/G consistency, implicit universal claims, contradictions, negative polarity, and supported-noncovering classes. If a prior decision is wrong, create an explicit immutable superseding Phase 07 verdict identifying and quoting the earlier verdict and the source grounds. No silent cell changes.

Outputs once both shards are truly complete: `07_assistant_adjudications.jsonl`, `07_decision_audit.jsonl`, `07_adjudication_summary.json`, `07_input_blockers.jsonl`.

Phase 07-C must not compute canonical FP residual units, perform Phase 08's N/F consolidation, or calculate Precision/Recall/F1. Shard inputs or output templates are NOT actual adjudication data. An incompletely adjudicated shard blocks C from claiming completion.
''',encoding='utf-8')

print(json.dumps({'status':'PASS','manifest':str(OUT/'07_partition_manifest.json'),
'files':[(p.name,p.stat().st_size) for p in sorted(OUT.iterdir())],
'counts':shard_paths,'unresolved_status_total':report['external_unresolved_status_total'],
'excluded_nondeﬁnitive':report['external_nondefinitive_suggestion_total']},indent=2))
