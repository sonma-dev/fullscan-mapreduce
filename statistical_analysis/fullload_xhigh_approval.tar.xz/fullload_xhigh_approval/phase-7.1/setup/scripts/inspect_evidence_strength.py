import json,re,collections,unicodedata
from sklearn.feature_extraction.text import ENGLISH_STOP_WORDS
from rapidfuzz.fuzz import ratio
S=set(ENGLISH_STOP_WORDS)|{'must','shall','require','required','include','includes','including','may','use','uses','based','source','pdf','specific','exact','confirmed','specified','support','supported','generated','is','are','with','without','also','other','all','each','every','only','where','given','from','within','through','these','those','under','existing','against','this','that','the','for','and','not','do','but','be','by','an','a','to','of','in','on','at','or'}
def tokens(s):return set(z.lower() for z in re.findall(r'[A-Za-z]+(?:[-_][A-Za-z0-9]+)*|\d+(?:\.\d+)?',unicodedata.normalize('NFKC',s)) if z.lower() not in S and len(z)>2)
def calc(t,q):
 a=tokens(t); b=tokens(q);return round(len(a&b)/max(1,len(a)),2),round(len(a&b)/max(1,len(b)),2),len(a),len(a&b)
rows=[json.loads(l) for l in open('/mnt/data/fullload_v10_6/phase07_sharded/07_shard_A_input.jsonl')]
for d in ('R','G'):
 print('\nDIRECTION',d)
 groups=collections.defaultdict(list)
 for r in rows:
  if r['direction']!=d:continue
  e=r['immutable_external_semantic_result'];m=e['model_json'];q=r['original_queue_item'];x=q['statement_en'];pg=' '.join(z['quote_en'] for z in m['pdf_evidence']);gg=' '.join(z['quote_en'] for z in m['generated_evidence']);
  rat=calc(x,gg if d=='R' else pg)[0]
  gr=(m['eligibility'],m['relation'])
  groups[gr].append(rat)
 for k,v in sorted(groups.items(),key=lambda x:-len(x[1])):
  print(k,len(v),'mean',round(sum(v)/len(v),2),'ge .3',sum(x>=.3 for x in v),'ge .5',sum(x>=.5 for x in v),'ge .7',sum(x>=.7 for x in v))
