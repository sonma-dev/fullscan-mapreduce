from __future__ import annotations
import hashlib,json,unicodedata,re,zipfile,collections,pathlib,fitz
ROOT=pathlib.Path('/mnt/data/fullload_v10_6')
IN=pathlib.Path('/mnt/data')
OUT=ROOT/'phase07_A'
OUT.mkdir(exist_ok=True)
ORIG={'01':'01_screen_functions(2).md','02':'02_api(2).md','03':'03_data(2).md','04':'04_batch_functions(3).md','05':'05_business_rules(2).md','06':'06_exception_handling(4).md','07':'07_processing_flows(4).md','08':'08_architecture_decision(3).md'}
canon={i:v.split('(')[0]+'.md' for i,v in ORIG.items()}
sha=lambda b:hashlib.sha256(b).hexdigest()
filehash={r:sha((IN/p).read_bytes()) for r,p in ORIG.items()}
all_lines={r:(IN/p).read_text(encoding='utf8').splitlines() for r,p in ORIG.items()}
with fitz.open(IN/'OrionDesk_AI_Detailed_Design_Specification(2).pdf') as doc:
 assert len(doc)==90
 pages=[p.get_text(sort=False)+'\n'+p.get_text(sort=True) for p in doc]
assert sha((IN/'OrionDesk_AI_Detailed_Design_Specification(2).pdf').read_bytes())=='b71541e74564559d2cc0a84e9827086946998fbc6c627488fb9e7a7f9b0137c3'
rows=[json.loads(l) for l in open(ROOT/'phase07_sharded/07_shard_A_input.jsonl')]
qsha=sha((ROOT/'phase06/06_llm_queue_v10.6.jsonl').read_bytes())
assert qsha==rows[0]['queue_sha256']
seen=set()
for r in rows:
 assert r['item_id'] not in seen
 seen.add(r['item_id']);assert r['shard']=='A' and r['queue_sha256']==qsha
 assert r['item_id']==r['original_queue_item']['item_id']==r['immutable_external_semantic_result']['item_id']
 assert r['source_pdf_sha256']=='b71541e74564559d2cc0a84e9827086946998fbc6c627488fb9e7a7f9b0137c3'
 assert all(r['immutable_external_semantic_result']['file_sha256'][canon[k]]==filehash[k] for k in ORIG)
assert len(rows)==1926

def norm(s):return ' '.join(unicodedata.normalize('NFKC',str(s)).split()).casefold()
def roles_for_reported(fn):
 z=fn.replace('02_api_.md','02_api.md')
 stem=re.sub(r'\(\d+\)(?=\.md$)','',z)
 return [k for k,c in canon.items() if c==stem]

vcounts=collections.Counter();problems=[]
verify_rows=[]
for idx,r in enumerate(rows):
 m=r['immutable_external_semantic_result']['model_json'];ev=[];pv=[]
 for e in m['pdf_evidence']:
  p=e['physical_page']; ok=type(p)==int and 1<=p<=90 and norm(e['quote_en']) in norm(pages[p-1]) and bool(norm(e['quote_en']))
  pv.append({'physical_page':p,'quote_en':e['quote_en'],'verified_original_pdf_text':ok})
  vcounts['pdf_quotes']+=1;vcounts['pdf_verified']+=bool(ok)
  if not ok:problems.append({'item_id':r['item_id'],'type':'PDF_QUOTE_NOT_VERIFIED','physical_page':p,'quote_en':e['quote_en'][:200]})
 for e in m['generated_evidence']:
  fn=e['file'];rr=roles_for_reported(fn);a,b=e['line_start'],e['line_end'];valid=len(rr)==1 and type(a)==int and type(b)==int and 1<=a<=b<=len(all_lines[rr[0]])
  ok=bool(valid and norm(e['quote_en']) in norm('\n'.join(all_lines[rr[0]][a-1:b])))
  ev.append({'reported_file':fn,'original_file':ORIG[rr[0]] if valid else None,'canonical_file':canon[rr[0]] if valid else None,'file_sha256':filehash[rr[0]] if valid else None,'line_start':a,'line_end':b,'quote_en':e['quote_en'],'verified_original_markdown_lines':ok})
  vcounts['generated_quotes']+=1;vcounts['generated_verified']+=bool(ok)
  if not ok:problems.append({'item_id':r['item_id'],'type':'GENERATED_QUOTE_NOT_VERIFIED','file':fn,'line_start':a,'line_end':b,'quote_en':e['quote_en'][:200]})
 verify_rows.append({'record_type':'PHASE07A_ORIGINAL_QUOTATION_CHECK','item_id':r['item_id'],'direction':r['direction'],'pdf_evidence':pv,'generated_evidence':ev,'all_original_quoted_evidence_verified':all(x['verified_original_pdf_text'] for x in pv) and all(x['verified_original_markdown_lines'] for x in ev),'has_pdf_quote':bool(pv),'has_generated_quote':bool(ev)})
 vcounts[r['direction']+'_items']+=1
 vcounts['full_pdf_verified']+=bool(pv and all(x['verified_original_pdf_text'] for x in pv))
 vcounts['full_generated_verified']+=bool(ev and all(x['verified_original_markdown_lines'] for x in ev))

# Verify all 241 original journals and the source's actual model JSON in each.
archive=IN/'batch_journals(3).zip'
z=zipfile.ZipFile(archive)
all_records={}
batches={}
for name in z.namelist():
 if not name.endswith('.json'):continue
 j=json.loads(z.read(name));b=j['batch_index'];batches[b]=j
 assert j['queue_sha256']==qsha and len(j['item_records'])==j['batch_size']
 for rec in j['item_records']:
  assert rec['item_id'] not in all_records
  all_records[rec['item_id']]=rec
assert len(batches)==241 and len(all_records)==3852
assert all(r['immutable_external_semantic_result']==all_records[r['item_id']] for r in rows)

with (OUT/'07_evidence_validation_A.jsonl').open('w',encoding='utf8') as f:
 for r in verify_rows:f.write(json.dumps(r,ensure_ascii=False,sort_keys=True)+'\n')
with (OUT/'07_quotation_issues_A.jsonl').open('w',encoding='utf8') as f:
 for r in problems:f.write(json.dumps(r,ensure_ascii=False,sort_keys=True)+'\n')
with (OUT/'07_source_integrity_A.json').open('w') as f:
 json.dump({'record_type':'PHASE07A_ORIGINAL_SOURCE_INTEGRITY','status':'PASS' if not problems else 'SOURCE_QUOTE_MISMATCH','method':'fullload','protocol_version':'10.6','source_pdf_sha256':'b71541e74564559d2cc0a84e9827086946998fbc6c627488fb9e7a7f9b0137c3','source_markdown_sha256':{ORIG[k]:v for k,v in filehash.items()},'queue_sha256':qsha,'input_item_count':len(rows),'unique_input_ids':len(seen),'all_241_original_external_journals_verified':True,'all_3852_original_external_item_results_verified':True,'external_model':'gpt-6.2-sol','external_reasoning_effort':'high','source_quotation_checks':dict(vcounts),'unverified_quote_count':len(problems)},f,indent=2)
print('status:', 'PASS' if not problems else 'ISSUES',len(problems));print(vcounts)
print('problem sample',problems[:12]);
