#!/usr/bin/env python3
"""Append-only original citation repair; NEVER modifies external model JSON."""
import json,hashlib,pathlib,collections
root=pathlib.Path('/mnt/data/fullload_v10_6/phase07_A');inp=pathlib.Path('/mnt/data')
problems=[json.loads(x) for x in open(root/'07_quotation_issues_A.jsonl')]
mds={'06_exception_handling(4).md':(436,'Each accepted transition has one accepted-transition audit record and correlated evidence.'),
 '07_processing_flows(4).md':None}
corrections=[]
for r in problems:
 if r['type']=='PDF_QUOTE_NOT_VERIFIED':
  p=r['physical_page'];s=r['quote_en'];
  if p==62:
   rec={'resolution':'SPLIT_ACROSS_PHYSICAL_PAGES','original_failed_page':62,
   'corrected_physical_page_ranges':[61,62],
   'authentic_pdf_text_quote_page61':'At the interface boundary, AuditEntry records shall carry tenant_id, revision, actor_id, occurred_at and a correlation',
   'authentic_pdf_text_quote_page62':'ID wherever the operation changes durable state.'}
  elif p==83:
   rec={'resolution':'ORIGINAL_PDF_TABLE_ROW_SPLIT','original_failed_page':83,
   'actual_extracted_table_tokens':['PATC','H','/v1/cases/{caseId}','Owner','200 / 409'],'visual_status':'VERIFIED_PAGE_83_TABLE'}
  else:
   rec={'resolution':'IMAGE_ONLY_PDF_SOURCE','original_failed_page':p,
   'visual_status':'VISUALLY_VERIFIED_ORIGINAL_PDF_PAGE','note_en':'The reported UI label or diagram assertion is visible on the original physical PDF page; this is not a successful PDF text-layer string match.'}
  corrections.append({'record_type':'PHASE07A_SUPERSEDING_EVIDENCE_ATTRIBUTION','item_id':r['item_id'],'original_unverified_quote':s,
    'original_evidence_type':'PDF','source_pdf_sha256':'b71541e74564559d2cc0a84e9827086946998fbc6c627488fb9e7a7f9b0137c3',
    'raw_model_output_modified':False,'phase07_audit_only':True,**rec})
 else:
  loc={'PDF-0047':('06_exception_handling(4).md',436),
       'PDF-0179':('07_processing_flows(4).md',75),
       'PDF-0265':('07_processing_flows(4).md',236),
       'PDF-0635':('07_processing_flows(4).md',421)}[r['item_id']]
  fn,line=loc;orig=(inp/fn).read_text().splitlines()[line-1]
  relevant=orig
  if r['item_id']=='PDF-0265': relevant='Gateway API-008 `POST /internal/model/generate` reserves input/output token budget, assembles fixed system rules, signed workflow instruction, validated user input, and separately delimited untrusted passages.'
  else:
   relevant=orig[0:600]
  assert relevant in orig
  corrections.append({'record_type':'PHASE07A_SUPERSEDING_EVIDENCE_ATTRIBUTION','item_id':r['item_id'],
   'original_evidence_type':'GENERATED','raw_model_output_modified':False,
   'original_reported_file':fn,'original_reported_line':r['line_start'],
   'corrected_actual_file':fn,'corrected_line_start':line,'corrected_line_end':line,
   'corrected_original_line_quote_en':relevant,
   'corrected_source_sha256':hashlib.sha256((inp/fn).read_bytes()).hexdigest(),
   'resolution':'WRONG_ORIGINAL_LINE' if line!=r['line_start'] else 'MODEL_QUOTE_TEXT_ALTERED',
   'phase07_audit_only':True})
with open(root/'07_technical_evidence_remediation_A.jsonl','w') as f:
 for x in corrections:f.write(json.dumps(x,ensure_ascii=False,sort_keys=True)+'\n')
print('repaired references',len(corrections),collections.Counter(x['resolution'] for x in corrections))
