#!/usr/bin/env python3
"""Record only manually reviewed Phase 07-A source-grounded judgments.
This script explicitly refuses to invent outcomes for unreviewed records.
All input/output content is English; the external model results remain immutable.
"""
from __future__ import annotations
import json,hashlib,collections,pathlib,re,unicodedata
ROOT=pathlib.Path('/mnt/data/fullload_v10_6');OUT=ROOT/'phase07_A';OUT.mkdir(exist_ok=True)
sha=lambda b:hashlib.sha256(b).hexdigest()
rows=[json.loads(l) for l in open(ROOT/'phase07_sharded/07_shard_A_input.jsonl',encoding='utf8')]
checks=[json.loads(l) for l in open(OUT/'07_evidence_validation_A.jsonl',encoding='utf8')]
check_by={x['item_id']:x for x in checks}
byid={x['item_id']:x for x in rows}
assert len(byid)==1926==len(checks)

def jd(o):return json.dumps(o,ensure_ascii=False,sort_keys=True,separators=(',',':'))
def writej(path,items):
 with open(path,'w',encoding='utf8') as f:
  for o in items:f.write(jd(o)+'\n')

# Each entry here is independently reviewed with the original PDF and Markdown
# passages. All other records remain unadjudicated, not default negatives.
manual={
 'PDF-0001':('TP','The source describes the entire ingestion-to-retrieval-to-generation-to-gate journey; the generated end-to-end FLOW-007 and FLOW-006 procedures explicitly implement all stages.'),
 'PDF-0002':('TP','A confirmed screen-level prohibition expressly bars arbitrary browser tool definitions, including when addressed to the orchestrator.'),
 'PDF-0003':('TP','The generated review and publication contracts bind an accepted decision to the exact reviewed artifact hash.'),
 'PDF-0027':('FN','PDF page 9 assigns acceptance-criterion status to the OBLIGATORY label. A full eight-file text search finds uses of the word obligatory but no rule connecting that source notation label to acceptance criteria.'),
 'PDF-0120':('FN','PDF page 19 requires the SAME images and deployment templates plus ISOLATED secrets and quotas for each environment. The generated staging/production discussions lack those artifact-parity and environment-specific quota obligations; all eight files were searched.'),
 'PDF-0402':('FN','PDF page 56 classifies ApiOperation as an Owner aggregate with UUIDv7 and tenant scope. The generated inventory names ApiOperation and gives a universal Owner-aggregate policy, but never binds the named component to that role.'),
 'PDF-0403':('FN','PDF page 56 classifies ErrorEnvelope as an Immutable derivative with SHA-256 source/revision provenance. Generated text gives a safe error representation plus generic derivative provenance but does not make ErrorEnvelope an instance of that category.'),
 'PDF-0508':('TP','A generated numbered business rule expressly requires rollback plans to state the readability of writes from new binaries.'),
 'PDF-0509':('TP','The generated canary rule explicitly compares all four source-mandated dimensions against baseline.'),
 'PDF-0520':('TP','The business-rule acceptance gate explicitly requires zero exceptions for critical isolation and approval tests.'),
 'PDF-0522':('FN','PDF page 74 calls for consumer-driven contracts pinning provider-facing adapters. A full-text search across the eight original Markdown files finds no consumer-driven adapter contract; general contract testing and provider adapters do not establish that association.'),
 'PDF-0533':('TP','The generated processing-flow acceptance journey expressly includes poisoned-document quarantine.'),
 'PDF-0581':('TP','The generated endpoint table retains the exact approval-decision path, Reviewer scope, 200/409 results, and the reviewed-hash binding.'),
 'PDF-0636':('TP','Signed test outputs and release-digest reference are both expressly present in generated release-check procedures.'),
 'PDF-0637':('TP','The generated business-rule decision record specifies all six required selection categories before implementation lock.'),
 'PDF-0638':('TP','The same generated source expressly requires dated architecture decisions rather than assumed defaults.'),
 'GCLASS-0000002':('TP','The original PDF page 57 enumerates exactly the eight primary screens that the generated assertion requires.'),
 'GCLASS-0000019':('TP','The PDF page 11 explicitly prohibits an analyst from approving their own high-risk recommendation.'),
 'GCLASS-0000154':('TP','The original PDF prohibits high-risk self-approval and requires the applicable review gate before publishing.'),
 'GCLASS-0000405':('TP','PDF page 55 explicitly requires signed, exponentially retried optional webhooks, recipient verification of signature and age, and nonrollback of committed case transitions.'),
 'GCLASS-0000864':('TP','PDF page 35 specifies five evidence item fields, and page 57 requires click-through highlighting of the cited anchor.'),
 'GCLASS-0001064':('TP','The PDF requires policy evaluations to store the applied rule-set version alongside normalized inputs and result.'),
}

# These source assertions were improperly included in Phase 05 eligible GC;
# the governing protocol forbids coercing nondefinitive material into FP/TN.
eligibility_corrections={
 'GCLASS-0000004':('NONDEFINITIVE','Statement describes what a figure does NOT specify and is methodological commentary, not an affirmative implementation or test obligation.'),
 'GCLASS-0000055':('NONDEFINITIVE','The originating SF-NAV-005 row is explicitly status Proposal and states adoption requires a later decision. The proposed navigation is not a binding obligation.'),
 'GCLASS-0000089':('NONDEFINITIVE','The originating SF-GEN-012 row is explicitly status Needs confirmation; it is a list of undefined presentation decisions, not a definite UI requirement.'),
}

output=[];aud=[]
for key,(cell,reason) in manual.items():
 x=byid[key];v=check_by[key];m=x['immutable_external_semantic_result'];q=x['original_queue_item'];model=m['model_json']
 # A final positive must have an original quote from both sides. Negative R
 # uses positive PDF provenance and a documented entire-corpus missing check.
 if cell=='TP' and (not v['has_pdf_quote'] or not v['has_generated_quote'] or not v['all_original_quoted_evidence_verified']):
  raise RuntimeError(('Unverified quote in accepted direct support',key))
 if cell=='FN' and not v['has_pdf_quote']:
  raise RuntimeError(('No PDF source evidence',key))
 direction=x['direction'];rule={'R':('P7-R-TP' if cell=='TP' else 'P7-R-FN'),'G':('P7-G-SUPPORTED' if cell=='TP' else 'P7-G-UNSUPPORTED')}[direction]
 pdf_evidence=[{'physical_page':e['physical_page'],'quote_en':e['quote_en'],'verified_original_pdf_text':e['verified_original_pdf_text']} for e in v['pdf_evidence']]
 gen_evidence=[{'file':e['original_file'],'canonical_role':e['canonical_file'],'source_sha256':e['file_sha256'],'line_start':e['line_start'],'line_end':e['line_end'],'quote_en':e['quote_en'],'verified_original_markdown_lines':e['verified_original_markdown_lines']} for e in v['generated_evidence']]
 item={'record_type':'ASSISTANT_ADJUDICATION','item_id':key,'direction':direction,'method':'fullload','shard':'A','protocol_version':'10.6','local_phase07_amendment':'P7-3SHARD-2026-11-22',
    'final_cell':cell,'canonical_counting_scope':'R_SOURCE' if direction=='R' else 'G_DIAGNOSTIC_NOT_CANONICAL_TP',
    'decision_rule_id':rule,'source_pdf_sha256':x['source_pdf_sha256'],
    'generated_file_sha256':m['file_sha256'],'pdf_evidence':pdf_evidence,'generated_evidence':gen_evidence,
    'examined_candidate_ids':[key],'support_bridge_ids':[],'unmet_predicates_en':model.get('missing_predicates_en',[]) if cell=='FN' else [],
    'decision_reason_en':reason,'decision_origin':'PHASE07_ASSISTANT','prior_v5_suggested_decision':m['suggested_decision'],
    'prior_v5_decision_status':m['decision_status'],'was_external_llm_selected':True,'source_reference_unchanged':True,
    'input_item_hash':sha(jd(x).encode()),'external_result_sha256':sha(jd(m).encode()),'source_quote_check_passed':v['all_original_quoted_evidence_verified']}
 output.append(item)
 aud.append({'record_type':'PHASE07A_MANUAL_ADJUDICATION_AUDIT','item_id':key,'status':'SOURCE_GROUNDED_MANUAL_REVIEW','final_cell':cell,'decision_rule_id':rule,'original_pdf_pages':[e['physical_page'] for e in pdf_evidence],
    'original_generated_locations':[{'file':e['file'],'line_start':e['line_start'],'line_end':e['line_end']} for e in gen_evidence],
    'original_external_proposal':m['suggested_decision'],'note_en':reason})

eligibility=[]
for key,(status,reason) in eligibility_corrections.items():
 x=byid[key];v=check_by[key]
 eligibility.append({'record_type':'PHASE07A_ELIGIBILITY_CHALLENGE','item_id':key,'direction':'G','method':'fullload','shard':'A',
  'prior_phase05_eligibility':'DEFINITIVE','reviewed_eligibility':status,'final_cell':None,
  'not_scored_as_fp_or_tn':True,'not_counted_as_final_binary_decision':True,
  'decision_reason_en':reason,'generated_evidence':v['generated_evidence'],
  'source_pdf_sha256':x['source_pdf_sha256'],'input_item_hash':sha(jd(x).encode()),'external_result_sha256':sha(jd(x['immutable_external_semantic_result']).encode()),
  'source_reference_unchanged':True})

remaining=[x for x in rows if x['item_id'] not in manual]
pending=[{'record_type':'PHASE07A_NOT_YET_ADJUDICATED','item_id':x['item_id'],'direction':x['direction'],'source_pdf_sha256':x['source_pdf_sha256'],
 'prior_v5_suggested_decision':x['immutable_external_semantic_result']['suggested_decision'],
 'prior_v5_decision_status':x['immutable_external_semantic_result']['decision_status'],
 'model_reported_eligibility':x['immutable_external_semantic_result']['model_json']['eligibility'],
 'evidence_provenance_checked':check_by[x['item_id']]['all_original_quoted_evidence_verified'],
 'not_treated_as_false_positive_or_false_negative_without_review':True,
 'requires_followup_action_en':'Evidence-grounded, independent full-predicate semantic review; review phase05 eligibility if the generated occurrence is nondefinitive.',
 'input_item_hash':sha(jd(x).encode())} for x in remaining]

writej(OUT/'07_assistant_adjudications_A.jsonl',output)
writej(OUT/'07_decision_audit_A.jsonl',aud)
writej(OUT/'07_eligibility_challenges_A.jsonl',eligibility)
writej(OUT/'07_pending_review_A.jsonl',pending)

p=OUT/'07_input_blockers_A.jsonl';
# All required originals are readable; semantic workload not finished is not
# misrepresented as a missing-file blocker.
p.write_text('',encoding='utf8')
counts=collections.Counter((x['direction'],x['final_cell']) for x in output)
summary={'record_type':'PHASE07A_ADJUDICATION_SUMMARY','protocol_version':'10.6','amendment_id':'P7-3SHARD-2026-11-22','method':'fullload','status':'INCOMPLETE',
 'reason_en':'This response verified every input/source identity and all original textual citations and reviewed a real subset, but did not independently adjudicate every full semantic proposition. Completing by copying the external model label or coercing nondefinitive text into a false positive would fabricate the semantic decision.',
 'shard':'A','assigned_total':len(rows),'assigned_R':638,'assigned_G':1288,
 'manually_adjudicated_total':len(output),'manually_adjudicated_R':sum(x['direction']=='R' for x in output),'manually_adjudicated_G':sum(x['direction']=='G' for x in output),
 'manual_cells_by_direction':{'|'.join(k):v for k,v in counts.items()},
 'incomplete_eligible_or_eligibility_review_count':len(pending),
 'concrete_confirmed_phase05_eligibility_conflicts':len(eligibility),
 'external_evaluator_model':'gpt-6.2-sol','external_evaluator_reasoning_effort':'high',
 'external_model_proposals_are_not_final':True,
 'all_1926_original_item_ids_identified':True,'all_241_original_journals_reconciled':True,
 'original_source_digests_verified':True,'phase08_or_phase09_started':False,'phase07_B_started':False,
 'source_reference_unchanged':True,'no_synthetic_final_binary_cells':True}
(OUT/'07_adjudication_summary_A.json').write_text(json.dumps(summary,indent=2,ensure_ascii=False)+'\n',encoding='utf8')
assert len({x['item_id'] for x in output})==len(output)
assert not set(manual) & {x['item_id'] for x in pending}
assert len(output)+len(pending)==1926
print(summary)
