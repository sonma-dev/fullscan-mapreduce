# Phase 07-A Independent Analysis Instructions

Assigned: R (638) + first 1,288 G classes, exactly 1,926 entries.

Read the governing `07_phase07_three_shard_amendment.md` and the unmodified v10.6 Phase 07 §§7.1–7.5. Use `07_shard_A_input.jsonl`; original PDF and all eight original Markdown sources are required. Verify the manifest and every original quote, do not trust suggested_decision as the final cell.

Write actual original-evidence-supported `07_assistant_adjudications_A.jsonl`, `07_decision_audit_A.jsonl`, `07_adjudication_summary_A.json`, `07_input_blockers_A.jsonl`. Do not invent verdicts for uninspected items, and do not provide partial results as a completed shard. Check each ID appears exactly once.

Specific emphasis: All 8 Markdown originals and 90-page PDF; full-class evidence, especially R entailment.

On missing material, mark `INCOMPLETE` with concrete blocker. Do not advance to the next shard until this one is complete.
