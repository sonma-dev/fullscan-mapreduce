# Phase 07 Three-Shard Amendment (Operational Override)

**Protocol baseline:** OrionDesk Atomic Evaluation Protocol v10.6.  
**Local amendment:** `P7-3SHARD-2026-11-22`.  
**Evaluation method:** `fullload`.  
**Status:** partitioned, not adjudicated.

This amendment is an explicit operator-authorized modification of **Phase 07 execution units only**. It does not change the PDF authority, frozen reference IDs, R/N/GO/GC eligibility, semantic entailment rules, Version 5.0 suggestion semantics, canonical metric population, or Phase 08/09 arithmetic. Do not edit earlier phase artifacts or original external batch journals.

## Shard execution order

1. **07-A: first independent evidence analysis.** Process all 638 frozen R IDs and the first 1,288 GC IDs in their immutable queue order (1,926 distinct items). For every R, decide TP/FN against **all eight** Markdown originals. For each assigned G, decide diagnostic supported TP or unsupported FP against the entire 90-page PDF. Review EXCLUDED_NONDEFINITIVE suggestions against original definitive status; do not automatically exclude them. Produce independent, immutable final per-item decisions with real quotes and locators, not model-only labels.
2. **07-B: second independent evidence analysis.** Process all 142 frozen N IDs and the remaining 1,784 GC IDs in immutable queue order (1,926 distinct items). For every N, decide FP/TN after searching the **entire** generated corpus, including classes allocated to Shard A. For every assigned G, inspect the entire PDF and issue a diagnostic TP/FP. Do not read Shard A's final judgments to choose labels; use the same authority and decision rules independently.
3. **07-C: integration and adjudication-conflict resolution.** Wait for complete original digest-checked 07-A and 07-B outputs. Verify union equals the 3,852 original item IDs and intersection is empty; verify exactly one final cell per ID, original evidence hashes, quote/line/page consistency, and source-specific rule IDs. Compare all cross-shard proof families and apparent contradictions, especially N/G affirmation, R/G coverage, source-specific exceptions, mixed positive/negative statements, and duplicate generated-only residuals. Reinspect original source evidence for any conflict; write explicit, immutable, reasoned Phase 07 superseding decisions for changed cells, retaining both originals. Integrate into Phase 07's four required original output artifact names. Do not count FP residuals or calculate metrics in 07-C; those are Phase 08 and Phase 09 respectively.

## Strict decision and file contract

- All 3,852 input IDs must be judged independently using the **same v10.6 §7.2–7.5 rules**; external suggestions are inputs, not final labels. The prior `suggested_decision=null`, `UNRESOLVED` status, a low confidence value, a provisional `FN/TN`, or an external `EXCLUDED_NONDEFINITIVE` is **not** a final cell.
- For R: `TP` iff complete supported generated coverage; otherwise evidence-supported `FN` after reciprocal challenge.
- For N: `FP` iff an eligible affirmative generated assertion entails the prohibited counterfactual; otherwise `TN` after an exhaustive review.
- For G: `TP` if the PDF entails the full generated claim, otherwise diagnostic `FP` when material unsupportedness is established. **G:TP never adds a canonical source TP. G:FP must be cross-checked for N/F overlap and deduplicated in Phase 08.**
- Mandatory Phase 07 decision IDs are `P7-R-TP`, `P7-R-FN`, `P7-N-FP`, `P7-N-TN`, `P7-G-SUPPORTED`, `P7-G-UNSUPPORTED`; retain accepted quote locators and original role SHA-256 checks.
- Each shard produces `07_assistant_adjudications_<shard>.jsonl`, `07_decision_audit_<shard>.jsonl`, `07_adjudication_summary_<shard>.json`, `07_input_blockers_<shard>.jsonl`. These are required outputs, **not** preexisting data, and must not be fabricated. The final 07-C names omit the shard suffix.
- Each shard's decision record must include all fields required in protocol §7.4, plus `shard`, `input_item_hash`, `external_result_sha256` and cross-file evidence source identities. Preserve model JSON and original external journals byte-for-byte.
- A genuinely missing or corrupt mandatory source makes the affected shard `INCOMPLETE` with a concrete blocker, not a fabricated negative decision. Semantic uncertainty alone is not a permissible final fifth class; an independently justified binary conclusion requires actual source inspection.
- **Exactly one completed shard per conversation response**, in this order: A, B, C. Do not launch Phase 08 before C passes the complete Phase 07 gate. The current preparation response only partitions, and does not claim completion of A, B, or C.

## Actual external evaluation and comparability

The supplied run state, summary, aggregate item results, and 241 committed journals agree on **gpt-6.2-sol** at **high reasoning effort**, 16 items per external batch, 241 completed batches, 3,852 results, and queue SHA-256 `419ccddc7068a6a4a3f5644a0f9617b95e9fcb52de2cdf9ccfe42ab19b6d8eef`.

This empirically differs from v10.6's printed `gpt-6.1-sol / medium` default; it is recorded as an **execution-deviation disclosure**. The operator states the other methods also used `gpt-6.2-sol`, but their execution SHA, effort, prompts, and classification process require verification before asserting complete cross-method comparability. The chosen *generation* effort `xhigh` is a separate experimental factor from the external *semantic evaluator's* `high`. Final Precision/Recall/F1 are **computed arithmetically** from the Phase 08 fully adjudicated ledger; a model produces evidence-based item judgments, not the metric by fiat.

## Files required per analysis

Use `07_shard_A_input.jsonl` or `07_shard_B_input.jsonl`, `07_partition_manifest.json`, `07_input_integrity_audit.json`, the original 90-page PDF and all eight original Markdown files, frozen R/N data and reference freeze, and the original v5 external evaluation results/journals as necessary. For 07-C, use both completed shard decision ledgers and the same originals. The combined source and queue identity must not change between shards.

Do not use shard membership to alter class eligibility, replicate a single generated class across shards, or shortcut absence conclusions based on incomplete shard visibility.
