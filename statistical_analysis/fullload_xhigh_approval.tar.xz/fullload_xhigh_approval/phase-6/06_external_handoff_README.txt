ORIONDESK V10.6 -- PHASE 06 EXTERNAL EVALUATION HANDOFF

Phase 06 status: COMPLETE (exhaustive queue preparation and offline verification).
External evaluator submission status: NOT STARTED. No Azure API credentials or endpoint
were available during this phase; zero paid Azure requests were made.

Frozen method: fullload
Reference population: R=638; N=142; effective GO=3119; effective GC=3072.
Unadjudicated queue: K=C=3852 (R=638, N=142, G=3072).
Batch size=8; 482 primary batches (481 full batches plus a final batch of 4).
Concurrency=4; additional per-batch retries=3; worst-case 1928 submissions
if every batch exhausts its allowed retry capacity (NOT a planned call count).

Queue SHA-256:
419ccddc7068a6a4a3f5644a0f9617b95e9fcb52de2cdf9ccfe42ab19b6d8eef

The evaluator defaults to reasoning effort MEDIUM under the protocol, while the
operator requested XHIGH. This discrepancy is recorded; do not claim the
runs have identical reasoning settings or cross-method comparability without
resolving the discrepancy under the governing experiment rules.

Before any paid handoff, confirm the chosen experimental reasoning setting,
review the complete 482-batch queue and the estimated Azure usage/cost, and
provide your Azure endpoint and API key through a secure environment.
The offline source-alias regression suite passed all 24 tests; the dry-run passed.
The provided v10.6 evaluator source was preserved. The separately named
operational derivative changes only BATCH_SIZE_DEFAULT from 16 to 8, to match
the governing protocol. Its SYSTEM_PROMPT, RESULT_SCHEMA, suggest(), and
SHA-verified filename-alias verifier are unchanged.

Suggested command (run in an authenticated environment after confirming
reasoning-effort comparability and cost):

python "/mnt/data/fullload_v10_6/phase06/semantic_decision_evaluator_v10.6_unlimited.py" \
  --pdf "/mnt/data/OrionDesk_AI_Detailed_Design_Specification(2).pdf" \
  --spec-dir "/mnt/data" \
  --source-lock "/mnt/data/fullload_v10_6/phase06/06_evaluator_source_lock.json" \
  --queue "/mnt/data/fullload_v10_6/phase06/06_llm_queue_v10.6.jsonl" \
  --out-dir "/mnt/data/fullload_v10_6/external_v5_results" \
  --batch-size 8 --concurrency 4 --batch-retries 3

The following environment variables are required by the evaluator:
  AZURE_OPENAI_ENDPOINT
  AZURE_OPENAI_API_KEY
  AZURE_OPENAI_DEPLOYMENT (defaults to gpt-6.1-sol)

Do not use an arbitrary --limit. Do not replace this queue with a Phase 05
subset. Do not treat per-item suggested_decision as a canonical final cell.
After a complete or safely documented failed external submission, Phase 07
must independently adjudicate every eligible remaining undecided item. No
Phase 07, 08, or 09 outputs have been generated here.

Primary Phase 06 artifacts:
  06_fp_controls.jsonl
  06_residual_candidate_audit.jsonl
  06_llm_queue_v10.6.jsonl
  06_queue_selection.json
  06_evaluator_source_lock.json
  06_alias_regression_result.json
  06_evaluator_dry_run.log
  06_provenance_excerpt_corrections.jsonl
  06_phase_summary.json
  06_completion_gate.json
