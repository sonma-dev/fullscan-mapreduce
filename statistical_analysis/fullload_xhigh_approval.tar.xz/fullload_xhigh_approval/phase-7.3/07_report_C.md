# Phase 07-C — Cross-Shard Adjudication Integration

Status: COMPLETE_WITH_SEMANTIC_AUDIT_LIMITATIONS

Protocol: v10.6 with operator-authorized Phase07 three-shard amendment.
Method: fullload. The original external evaluator ran gpt-6.2-sol, reasoning effort high.

- Original assessed IDs: 3,852 (R=638; N=142; initial eligible G=3,072).
- Final eligible binary judgments: 3331. Eligibility supersessions: 521.
- R cells: TP=520, FN=118.
- N cells: FP=0, TN=142.
- G diagnostic cells: supported TP=2296, unsupported FP=255.
- Phase07C explicit immutable supersessions: 7 (IDs: GCLASS-0001251, GCLASS-0002053, GCLASS-0001698, GCLASS-0002317, GCLASS-0002538, GCLASS-0002958, GCLASS-0002960).
- Original Markdown quotations revalidated: 4542.
- Original PDF text quotations matched: 7751; 0 cross-column/table/figure quotations required a separate rendered-page interpretation beyond direct text matching.
- Entire original external journal: 241 committed batches and 3,852 source-identity-matching records.
- R/G nearest-evidence crosswalk: 638 source obligations; N/G polarity crosswalk: 142 controls. High-similarity cross-shard G pairs: 24.

**Counting boundary.** G supported TP labels are diagnostic, not extra canonical TPs. G unsupported FP labels are candidates requiring Phase08 N/F overlap and within-method residual semantic consolidation. No Precision, Recall or F1 has been calculated.

**Important source semantics.** The mixed-classification fixture was not required by the original Appendix E, while the generated cross-file test lists asserted it as mandatory. This warrants GCLASS-0002053: TP→FP and aligns it with the separate original Shard A findings for GCLASS-0000859 and GCLASS-0001234. The original API appendix explicitly lists HTTP 202 for approved export/delete requests, so GCLASS-0002317: FP→TP. Additional specific source-grounded supersessions are recorded individually. All old A/B verdicts remain immutable.

**Limitations.** Machine-assisted lexical and predicate evidence auditing is not a proof of complete natural-language semantic correctness, especially for implication across files. The 521 revised G eligibility decisions are preserved in their own ledger. A future evidence-based supersession must reference the applicable original and current decision; it cannot silently change its cell.
