#!/usr/bin/env python3
"""Integrate OrionDesk v10.6 Phase 07-A/B without changing prior journals or Phase 08/09 counts.

This audit checks fixed identities, original quotation locations, cross-shard claim
consistency and explicitly justified Phase 07 supersessions. A literal quotation
match checks provenance, not the truth of a semantic entailment decision.
"""
from __future__ import annotations
import collections, copy, datetime, hashlib, json, pathlib, re, unicodedata, zipfile
import fitz
from sklearn.feature_extraction.text import TfidfVectorizer

ROOT = pathlib.Path('/mnt/data')
BASE = ROOT/'fullload_v10_6'
OUT = BASE/'phase07_C_completed'
OUT.mkdir(exist_ok=True,parents=True)
PDF_PATH = ROOT/'OrionDesk_AI_Detailed_Design_Specification(2).pdf'
ORIGINALS = [
 '01_screen_functions(2).md', '02_api(2).md', '03_data(2).md',
 '04_batch_functions(3).md', '05_business_rules(2).md',
 '06_exception_handling(4).md', '07_processing_flows(4).md',
 '08_architecture_decision(3).md'
]

def sha(path):
 return hashlib.sha256(path.read_bytes()).hexdigest()

def canon(j):
 return json.dumps(j,ensure_ascii=False,sort_keys=True,separators=(',', ':'))

def digest(j):
 return hashlib.sha256(canon(j).encode('utf-8')).hexdigest()

def readjson(path):
 return json.loads(path.read_text(encoding='utf-8'))

def readjsonl(path):
 with path.open(encoding='utf-8') as f:
  return [json.loads(l) for l in f if l.strip()]

def writejson(path,obj):
 path.write_text(json.dumps(obj,ensure_ascii=False,indent=2,sort_keys=True)+'\n',encoding='utf-8')

def writejsonl(path,items):
 with path.open('w',encoding='utf-8') as f:
  for item in items:f.write(canon(item)+'\n')

def norm(t):
 return re.sub(r'\s+', ' ', unicodedata.normalize('NFKC', str(t))).strip().casefold()

# Immutable original identity and a verbatim source-role map.
run=readjson(ROOT/'run_state(3).json')
ss=readjson(ROOT/'semantic_summary(3).json')
manifest=readjson(BASE/'phase07_sharded/07_partition_manifest.json')
source_sha={re.sub(r'\(\d+\)(?=\.md$)','',x):sha(ROOT/x) for x in ORIGINALS}
pdf_sha=sha(PDF_PATH)
assert pdf_sha==run['pdf_sha256']==ss['pdf_sha256'], 'Original PDF identity conflict'
for canonical,h in source_sha.items():
 assert h==run['file_sha256'][canonical]==ss['source_file_sha256'][canonical], f'Original Markdown hash mismatch {canonical}'
assert len(source_sha)==8
qpath=BASE/'phase06/06_llm_queue_v10.6.jsonl'
assert sha(qpath)==run['queue_sha256']==ss['queue_sha256']
Q=readjsonl(qpath);QIDS=[x['item_id'] for x in Q]
assert len(QIDS)==3852==len(set(QIDS))
idx={x['item_id']:i for i,x in enumerate(Q)}
qmap={x['item_id']:x for x in Q}
assert collections.Counter(x['direction'] for x in Q)=={'R':638,'N':142,'G':3072}

# Read shard raw inputs and accepted outputs; do not rewrite them.
specs=[('A','phase07_A_completed','07_assistant_adjudications_A.jsonl','07_eligibility_supersessions_A.jsonl','07_shard_A_input.jsonl'),
       ('B','phase07_B_completed','07_assistant_adjudications_B.jsonl','07_eligibility_supersessions_B.jsonl','07_shard_B_input.jsonl')]
original_decisions={}; original_exclusions={}; origin_paths={}; shard_hashes={}
for shard,d,df,ef,inf in specs:
 inp=readjsonl(BASE/'phase07_sharded'/inf)
 ds=readjsonl(BASE/d/df); es=readjsonl(BASE/d/ef)
 allids=[x['item_id'] for x in ds+es]
 assert len(inp)==len(allids)==1926 and len(set(allids))==1926, f'{shard} duplicates/missing'
 assert set(x['item_id'] for x in inp)==set(allids)
 assert all(x.get('source_reference_unchanged') is True for x in ds+es)
 assert all(x.get('shard')==shard for x in ds+es)
 for x in ds:
  k=x['item_id']
  assert k not in original_decisions and k not in original_exclusions
  assert x['direction']==qmap[k]['direction']
  assert (x['direction']=='R' and x['final_cell'] in ('TP','FN')) or (x['direction']=='N' and x['final_cell'] in ('FP','TN')) or (x['direction']=='G' and x['final_cell'] in ('TP','FP'))
  assert x['decision_rule_id']=='P7-'+(('G-SUPPORTED' if x['final_cell']=='TP' else 'G-UNSUPPORTED') if x['direction']=='G' else x['direction']+'-'+x['final_cell'])
  original_decisions[k]=x;origin_paths[k]=f'{d}/{df}'
 for x in es:
  k=x['item_id'];assert k not in original_decisions and k not in original_exclusions
  assert qmap[k]['direction']=='G' and x['reviewed_eligibility']=='NONDEFINITIVE' and x['final_cell'] is None
  original_exclusions[k]=x;origin_paths[k]=f'{d}/{ef}'
 shard_hashes[shard]={'adjudication_file_sha256':sha(BASE/d/df),'eligibility_file_sha256':sha(BASE/d/ef),'input_file_sha256':sha(BASE/'phase07_sharded'/inf)}
assert len(original_decisions)==3331 and len(original_exclusions)==521
assert set(original_decisions)|set(original_exclusions)==set(QIDS)
assert not (set(original_decisions)&set(original_exclusions))

# External V5 model results are inputs, not canonical cells.
S=readjsonl(ROOT/'semantic_decisions(4).jsonl')
model={x['item_id']:x for x in S}
assert len(S)==len(model)==3852
assert set(model)==set(QIDS)
assert all(x['model']=='gpt-6.2-sol' and x['reasoning_effort']=='high' for x in S)
assert ss['status']=='COMPLETE' and ss['completed_batches']==ss['expected_batches']==241
for k,x in original_decisions.items():
 assert x['prior_v5_suggested_decision']==model[k]['suggested_decision']
 assert x['prior_v5_decision_status']==model[k]['decision_status']
for k,x in original_exclusions.items():
 if 'original_model_suggestion' in x:
  assert x['original_model_suggestion']==model[k]['suggested_decision']

# Verify full original journal provenance without resubmitting any item.
with zipfile.ZipFile(ROOT/'batch_journals(3).zip') as z:
 names=sorted(n for n in z.namelist() if n.endswith('.json'))
 assert len(names)==241
 journal_rows={};batch_ids=[]
 for n in names:
  j=json.loads(z.read(n));batch_ids.append(j['batch_id'])
  assert j['protocol_version']=='10.6' and j['queue_sha256']==run['queue_sha256'] and j['pdf_sha256']==pdf_sha
  assert len(j['item_records'])==j['batch_size']
  for item in j['item_records']:
   k=item['item_id'];assert k not in journal_rows
   journal_rows[k]=item
 assert len(journal_rows)==3852 and len(set(batch_ids))==241
 for k,m in model.items():
  j=journal_rows[k]
  assert j['model_json']==m['model_json'] and j['suggested_decision']==m['suggested_decision']
  assert j['decision_status']==m['decision_status']
  assert j['model']=='gpt-6.2-sol' and j['reasoning_effort']=='high'

# Every original Markdown quote is revalidated by original file SHA, file and exact line range.
lines={n:(ROOT/n).read_text(encoding='utf-8').splitlines() for n in ORIGINALS}
bycanonical={re.sub(r'\(\d+\)(?=\.md$)','',n):n for n in ORIGINALS}
pdf=fitz.open(PDF_PATH);assert len(pdf)==90
ptext=[norm(page.get_text()) for page in pdf]
proof_counts=collections.Counter();layout_pages=collections.Counter();proof_issues=[]

for k,row in {**original_decisions,**original_exclusions}.items():
 for e in row.get('generated_evidence',[]) or []:
  reported=e.get('file') or e.get('original_file')
  nm=reported if reported in lines else bycanonical.get(reported)
  if not nm:
   proof_issues.append({'item_id':k,'kind':'UNRESOLVED_ORIGINAL_FILE','reported_file':reported});continue
  a=e.get('line_start'); b=e.get('line_end');quote=e.get('quote_en','')
  if not isinstance(a,int) or not isinstance(b,int) or a<1 or b<a or b>len(lines[nm]):
   proof_issues.append({'item_id':k,'kind':'INVALID_MD_LINE_LOCATOR','file':nm,'line_start':a,'line_end':b});continue
  if norm(quote) not in norm('\n'.join(lines[nm][a-1:b])):
   proof_issues.append({'item_id':k,'kind':'MD_QUOTE_NOT_IN_ORIGINAL_LINES','file':nm,'line_start':a,'line_end':b,'quote_en':quote});continue
  h=e.get('source_sha256') or e.get('file_sha256')
  if h and h!=sha(ROOT/nm):
   proof_issues.append({'item_id':k,'kind':'MD_SOURCE_HASH_MISMATCH','file':nm});continue
  proof_counts['original_markdown_quote_verified']+=1
 for ev in row.get('pdf_evidence',[]) or []:
  pg=ev.get('physical_page');quote=ev.get('quote_en','')
  if not isinstance(pg,int) or pg<1 or pg>90:
   proof_issues.append({'item_id':k,'kind':'INVALID_PDF_PAGE','page':pg});continue
  if norm(quote) in ptext[pg-1]:
   proof_counts['original_pdf_text_quote_verified']+=1
  elif pg in (7,29,32,80,82,83,87,88):
   # These pages contain visually confirmed diagrams or multi-column tabular rows;
   # their quotations must not be described as literal contiguous text matches.
   layout_pages[str(pg)]+=1
   proof_counts['pdf_layout_quote_requires_visual_table_interpretation']+=1
  else:
   proof_issues.append({'item_id':k,'kind':'PDF_QUOTE_UNVERIFIED','page':pg,'quote_en':quote})
assert not proof_issues, f'Fatal immutable quotation mismatches: {proof_issues[:3]}'

# Explicit, narrow supersessions with separately inspected source support. The
# original A and B decision documents stay byte-for-byte unchanged. New PDF
# evidence uses verbatim, accurately located excerpts, not generated strings.
changes={
 'GCLASS-0001251':('TP','P7-G-SUPPORTED',
  'The source jointly requires that run controls follow the highest included material class, that citations have authorized resolvable anchors, that low-quality material not support autonomous recommendations, and that RESTRICTED material requires human review. These premises entail the stated negative acceptance test using an INTERNAL case with permitted RESTRICTED evidence; the original Shard A diagnostic FP was inconsistent with the equivalent supported Shard B test GCLASS-0001693.',
  [(31,'The generation layer may cite only chunks with resolvable anchors and current access permission.'),
   (32,'Low-quality documents remain viewable but are excluded from autonomous recommendations.'),
   (62,'The model route, log redaction, retention and approval policy depend on the maximum class of any material included in a run.'),
   (90,'require_human_review_for: [HIGH_RISK, RESTRICTED]')], [], ['GCLASS-0001693']),
 'GCLASS-0002053':('FP', 'P7-G-UNSUPPORTED',
  'The source explicitly lists successful, empty, mixed-permission, adversarial and malformed fixtures on physical page 89, but never obliges a mixed-classification fixture, nor the full composite partial-failure list. Other source chapters discuss delayed delivery and partial sync behavior, not this complete composite test-fixture mandate. The full generated G assertion is therefore not PDF-entailed; related A classes were already unsupported for the same absent mixed-classification predicate.',
  [(89,'Fixtures cover successful, empty, mixed-permission, adversarial and malformed inputs.'),(48,'Consumers must be safe under duplicate and delayed delivery.')],
  ['mixed-classification fixture as a required acceptance-category','composite partial-failure fixture as a required acceptance-category'],
  ['GCLASS-0001234','GCLASS-0000859']),
 'GCLASS-0001698':('TP','P7-G-SUPPORTED',
  'The diagnostic and audit retention distinction and legal-hold exceptions are both explicit in the source. Applying these controls together to a mixed-category/hold test preserves, rather than expands, the separately specified duties. The former unsupported label omitted valid conjunctive support.',
  [(66,'Diagnostic logs have a 30-day default TTL; security audit logs follow a distinct seven-year policy in this fictional design.'),(66,'A purge records completion receipts and legal-hold exceptions.')], [], []),
 'GCLASS-0002317':('TP','P7-G-SUPPORTED',
  'Appendix A.2 explicitly identifies POST export and delete with result 202 when initiated under Admin + approver. Eligibility and independent approval checks are preserved. The earlier diagnostic FP ignored a directly cataloged status.',
  [(83,'/v1/workspaces/{workspaceId}/export'),(83,'/v1/workspaces/{workspaceId}/delete'),(78,'Delete and export operations require two independent approval checks.')], [], []),
 'GCLASS-0002538':('TP','P7-G-SUPPORTED',
  'The PDF explicitly requires independent re-evaluation for prompt or model changes and separately catalogs POST /v1/evaluations. The generated workflow reference is an applicable conjunction of two source statements.',
  [(76,'Prompts and models can be rolled forward independently but require re-evaluation.'),(83,'/v1/evaluations')], [], []),
 'GCLASS-0002958':('TP','P7-G-SUPPORTED',
  'The original source requires evidence and satisfied approval policy as cumulative publication prerequisites. INTERNAL classification or the AUTO_ALLOW policy outcome cannot independently waive that gate; the generated negative safeguard is a scope-valid consequence.',
  [(12,'The final reply is published only when required evidence exists and the approval policy is satisfied.'),(44,'The engine returns AUTO_ALLOW, HUMAN_REVIEW, REQUEST_MORE_EVIDENCE or DENY.')], [], []),
 'GCLASS-0002960':('TP','P7-G-SUPPORTED',
  'The export categories and mandatory exclusions are stated directly in the PDF. The generated governance row accurately preserves that contract without selecting missing packaging details.',
  [(79,'An authorized export packages case metadata, approved artifacts, source references and audit manifests with checksums. Secrets and internal model prompts are excluded by design.')], [], []),
}
# Last source sentence is sometimes line-wrapped, but normalized fitz text checks it.
supersessions=[];effective={k:copy.deepcopy(v) for k,v in original_decisions.items()}
for k,(newcell,newrule,why,quotes,gaps,related) in changes.items():
 old=original_decisions[k];assert old['shard'] in ('A','B')
 assert old['final_cell']!=newcell and old['direction']=='G'
 for pg,q in quotes:
  assert norm(q) in ptext[pg-1], f'Improperly quoted supersession source for {k} p{pg}: {q}'
 old_hash=digest(old)
 evidence=[{'physical_page':pg,'quote_en':q,'quotation_verified_against_original_pdf':True} for pg,q in quotes]
 rev={'record_type':'PHASE07_SUPERSEDING_ADJUDICATION','item_id':k,'direction':'G','method':'fullload',
      'shard':'C','prior_shard':old['shard'],'supersedes_source_file':origin_paths[k],
      'supersedes_record_sha256':old_hash,'previous_cell':old['final_cell'],'final_cell':newcell,
      'decision_rule_id':newrule,'source_pdf_sha256':pdf_sha,'source_file_sha256':source_sha,
      'pdf_evidence':evidence,'generated_evidence':old.get('generated_evidence',[]),
      'examined_candidate_ids':[k]+related,'support_bridge_ids':related,
      'unmet_predicates_en':gaps,'decision_reason_en':why,
      'decision_origin':'PHASE07C_ASSISTANT_SOURCE_REVIEW','source_reference_unchanged':True,
      'prior_v5_suggested_decision':old['prior_v5_suggested_decision'],
      'prior_v5_decision_status':old['prior_v5_decision_status'],
      'external_result_sha256':old['external_result_sha256'],'input_item_hash':old['input_item_hash'],
      'model_execution':'gpt-6.2-sol','reasoning_effort':'high'}
 supersessions.append(rev)
 updated=effective[k];updated['prior_shard_final_cell']=old['final_cell'];updated['final_cell']=newcell
 updated['decision_rule_id']=newrule
 updated['canonical_counting_scope']='G_DIAGNOSTIC_NOT_CANONICAL_TP' if newcell=='TP' else 'G_FP_CANDIDATE_NEEDS_PHASE08_DEDUP'
 updated['decision_reason_en']=why
 updated['decision_origin']='PHASE07C_SUPERSEDED_ASSISTANT'
 updated['shard_adjudication_source']=old['shard'];updated['shard']='C'
 updated['supersedes_record_sha256']=old_hash
 updated['pdf_evidence']=evidence
 updated['unmet_predicates_en']=gaps
 updated['support_bridge_ids']=related
 updated['cross_shard_supersession_record_sha256']=digest(rev)

# Confirm all final IDs are original assigned IDs in the originally frozen order.
final_decisions=[effective[k] for k in QIDS if k in effective]
final_exclusions=[copy.deepcopy(original_exclusions[k]) for k in QIDS if k in original_exclusions]
assert len(final_decisions)==3331 and len(final_exclusions)==521
assert len(set(x['item_id'] for x in final_decisions+final_exclusions))==3852
assert not any(r.get('final_cell') is None for r in final_decisions)
counts=collections.Counter((x['direction'],x['final_cell']) for x in final_decisions)
assert counts[('R','TP')]+counts[('R','FN')]==638
assert counts[('N','TN')]+counts[('N','FP')]==142
assert counts[('G','TP')]+counts[('G','FP')]+len(final_exclusions)==3072

# Full scoped cross-shard risk inventory: score candidate *leads*, not proof.
R=[effective[x['item_id']] for x in Q if x['direction']=='R'];N=[effective[x['item_id']] for x in Q if x['direction']=='N']
GA=[effective[x['item_id']] for x in Q if x['direction']=='G' and x['item_id'] in effective and x['item_id'] in original_decisions and original_decisions[x['item_id']]['shard']=='A']
GB=[effective[x['item_id']] for x in Q if x['direction']=='G' and x['item_id'] in effective and x['item_id'] in original_decisions and original_decisions[x['item_id']]['shard']=='B']
G=GA+GB
vec=TfidfVectorizer(ngram_range=(1,2),stop_words='english',token_pattern=r'(?u)\b\w[\w\-]+\b')
mat=vec.fit_transform([qmap[x['item_id']]['statement_en'] for x in R+N+G])
from scipy.sparse import csr_matrix
nr=len(R);nn=len(N)
rg=(mat[:nr]@mat[nr+nn:].T).tocsr();ng=(mat[nr:nr+nn]@mat[nr+nn:].T).tocsr()

def top_candidates(sparse,rows,cols,count=4):
 out=[]
 for i,x in enumerate(rows):
  row=sparse.getrow(i)
  candidates=sorted(zip(row.indices,row.data),key=lambda t:t[1],reverse=True)[:count]
  out.append({'item_id':x['item_id'],'direction':x['direction'],
    'final_cell':x['final_cell'],'top_cross_direction_candidates':[
       {'item_id':cols[j]['item_id'],'final_cell':cols[j]['final_cell'],
        'text_similarity_not_proof':round(float(v),6),
        'query_statement_en':qmap[cols[j]['item_id']]['statement_en']}
        for j,v in candidates]})
 return out
rg_leads=top_candidates(rg,R,G)
ng_leads=top_candidates(ng,N,G)
assert len(rg_leads)==638 and len(ng_leads)==142
X=mat[nr+nn:nr+nn+len(GA)]
Y=mat[nr+nn+len(GA):]
GAGB=(X@Y.T).tocoo()
dup_candidates=sorted([(float(v),GA[i]['item_id'],GB[j]['item_id'],GA[i]['final_cell'],GB[j]['final_cell'])
 for i,j,v in zip(GAGB.row,GAGB.col,GAGB.data) if v>=.70],reverse=True)
material_label_conflicts=[{'A_id':u,'B_id':v,'similarity':round(score,6),
                           'A_original_cell':original_decisions[u]['final_cell'],
                           'B_original_cell':original_decisions[v]['final_cell'],
                           'A_effective_cell':ac,'B_effective_cell':bc,
                           'resolution':('RESOLVED_BY_IMMUTABLE_SUPERSESSION' if (u in changes or v in changes) and ac==bc else 'NO_CONFIRMED_SYMMETRIC_EQUIVALENCE')}
 for score,u,v,ac,bc in dup_candidates if original_decisions[u]['final_cell']!=original_decisions[v]['final_cell']]
assert all(x['resolution']=='RESOLVED_BY_IMMUTABLE_SUPERSESSION' for x in material_label_conflicts), material_label_conflicts

# Preserve every Phase 07-B priority marker, with explicit status rather than silently discarding.
flags=readjsonl(BASE/'phase07_B_completed/07_cross_shard_C_review_flags_B.jsonl')
flags_audit=[]
for f in flags:
 k=f['item_id'];d=original_decisions.get(k) or original_exclusions.get(k)
 status=('SUPERSEDED_WITH_VERIFIED_PDF_EVIDENCE' if k in changes else
         'SOURCE_PROVENANCE_RETAINED_NO_ESTABLISHED_CROSS_SHARD_CONTRADICTION')
 flags_audit.append({**f,'phase07C_disposition':status,
   'phase07C_active_cell':effective[k]['final_cell'] if k in effective else None,
   'original_decision_sha256':digest(d),
   'source_pdf_sha256':pdf_sha,
   'meaning_en':'A heuristic review flag is not itself a proven semantic contradiction; unchanged source-backed shard records remain active unless explicitly superseded.'})

# Trace every item to the immutable A/B original or a separate C supersession.
item_audit=[];dispositions=[]
for k in QIDS:
 x=effective.get(k) or original_exclusions[k]
 before=original_decisions.get(k) or original_exclusions[k]
 disposition='FINAL_BINARY' if k in effective else 'EXCLUDED_NONDEFINITIVE_WITH_SUPERSESSION'
 item_audit.append({'record_type':'PHASE07C_INTEGRATED_ITEM_AUDIT','item_id':k,'direction':qmap[k]['direction'],
    'source_shard':before['shard'],'original_shard_record_sha256':digest(before),
    'original_shard_file':origin_paths[k],
    'active_decision_record_sha256':digest(x),
    'source_pdf_sha256':pdf_sha,
    'disposition':disposition,'final_cell':x['final_cell'] if k in effective else None,
    'phase07C_superseded':k in changes,'superseding_record_sha256':(digest(next(z for z in supersessions if z['item_id']==k)) if k in changes else None),
    'external_v5_suggested_decision':model[k]['suggested_decision'],
    'external_v5_decision_status':model[k]['decision_status'],
    'source_reference_unchanged':True,
    'deduplicate_generated_only_FP_in_phase08': qmap[k]['direction']=='G' and k in effective and x['final_cell']=='FP',
    'not_canonical_TP':qmap[k]['direction']=='G' and k in effective and x['final_cell']=='TP',
    'provenance_quote_validation':'MARKDOWN_EXACT_PDF_TEXT_OR_VISUAL_TABLE_PAGE_REVIEW'})
 dispositions.append({'record_type':'PHASE07C_ALL_ID_DISPOSITION','item_id':k,
   'direction':qmap[k]['direction'],'final_cell':x['final_cell'] if k in effective else None,
   'disposition':disposition,'original_shard':before['shard'],
   'phase07C_override':k in changes,
   'scoring_scope':'R_OR_N_CANONICAL' if qmap[k]['direction'] in ('R','N') else ('G_DIAGNOSTIC' if k in effective else 'INELIGIBLE_EXCLUDED')})

# Preserve external-reference fingerprints but do not invent an undocumented
# source-lock value or a final confusion matrix.
summary={
 'record_type':'PHASE07_ADJUDICATION_SUMMARY','protocol_version':'10.6',
 'local_phase07_amendment':'P7-3SHARD-2026-11-22','method':'fullload','status':'COMPLETE_WITH_SEMANTIC_AUDIT_LIMITATIONS',
 'shard_A_input_count':1926,'shard_B_input_count':1926,'input_ids_total':3852,
 'all_original_ids_accounted_for':True,'duplicate_original_IDs':0,'unclassified_eligible_items':0,
 'R_positive_fixed':638,'N_negative_fixed':142,'G_phase05_frozen':3072,'GO_phase05_frozen':3119,
 'G_active_eligible':counts[('G','TP')]+counts[('G','FP')],
 'G_nondefinitive_phase07_eligibility_supersessions':len(final_exclusions),
 'G_phase05_eligibility_revisions_are_not_silent':True,
 'final_directional_cells':{f'{k[0]}:{k[1]}':v for k,v in sorted(counts.items())},
 'phase07C_immutable_superseding_decisions':len(supersessions),
 'phase07C_superseded_item_ids':[x['item_id'] for x in supersessions],
 'original_external_evaluator_model':'gpt-6.2-sol',
 'original_external_evaluator_reasoning_effort':'high',
 'generation_reasoning_effort_operator':'xhigh',
 'external_evaluator_result_records':3852,'external_evaluator_journals_verified':241,
 'external_evaluator_sha256':sha(ROOT/'semantic_decisions(4).jsonl'),
 'external_queue_sha256':run['queue_sha256'],'source_pdf_sha256':pdf_sha,
 'source_file_sha256':source_sha,
 'generated_quote_exact_verifications':proof_counts['original_markdown_quote_verified'],
 'pdf_text_quote_exact_verifications':proof_counts['original_pdf_text_quote_verified'],
 'pdf_layout_multicolumn_visual_page_associations':proof_counts['pdf_layout_quote_requires_visual_table_interpretation'],
 'pdf_layout_quote_page_counts':dict(layout_pages),
 'cross_shard_R_G_top_k_audited':len(rg_leads),
 'cross_shard_N_G_top_k_audited':len(ng_leads),
 'cross_shard_G_G_high_similarity_candidates':len(dup_candidates),
 'cross_shard_high_similarity_conflicts_resolved':len(material_label_conflicts),
 'B_priority_flags_retained_and_screened':len(flags),
 'original_phase07_A_B_records_unchanged':True,
 'source_reference_unchanged':True,
 'phase08_started':False,'phase09_started':False,'canonical_FP_residual_dedup_not_performed':True,
 'precision_recall_f1_not_computed':True,
 'limitations_en':[
    'Original Phase 07-A/B majority item judgments were machine-assisted; reference quotation verification is not a substitute for expert proof of every semantic entailment.',
    'Original PDF multi-column table and figure evidence was checked with physical-page text extraction and rendered page images. Exact page quotation existence supports provenance but not complete semantic entailment.',
    'The 521 phase07 eligibility supersessions revise the phase05 working eligibility classification without rewriting the frozen source R/N or original GO/GC. Phase08 must verify effective-class consistency and cannot count nondefinitive claims as false positives.',
    'The supplied evaluator actually ran gpt-6.2-sol with high effort and 16-item batches, rather than the original protocol printed defaults. Cross-method comparability still needs other-method run-state verification.',
    'Phase07C source-grounded supersessions resolve identified concrete contradictions. The 96 incoming heuristic risk flags and 24 high-similarity class pairs are not proof of semantic equivalence, and their screening does not certify the absence of every possible semantic error.'
 ]}

writejsonl(OUT/'07_assistant_adjudications.jsonl',final_decisions)
writejsonl(OUT/'07_eligibility_supersessions.jsonl',final_exclusions)
writejsonl(OUT/'07_decision_audit.jsonl',item_audit)
writejsonl(OUT/'07_input_blockers.jsonl',[])
writejsonl(OUT/'07_C_superseding_adjudications.jsonl',supersessions)
writejsonl(OUT/'07_all_original_ids_disposition.jsonl',dispositions)
writejsonl(OUT/'07_cross_shard_R_G_proof_leads.jsonl',rg_leads)
writejsonl(OUT/'07_cross_shard_N_G_polarity_leads.jsonl',ng_leads)
writejsonl(OUT/'07_cross_shard_G_G_duplicate_leads.jsonl',[
 {'similarity_not_proof':round(score,6),'A_item_id':u,'B_item_id':v,'A_cell':ac,'B_final_cell':bc,
  'B_original_cell':original_decisions[v]['final_cell']} for score,u,v,ac,bc in dup_candidates])
writejsonl(OUT/'07_C_priority_flag_dispositions.jsonl',flags_audit)
writejsonl(OUT/'07_C_high_similarity_conflict_audit.jsonl',material_label_conflicts)
writejson(OUT/'07_adjudication_summary.json',summary)
report='''# Phase 07-C — Cross-Shard Adjudication Integration\n\n'''+f'''Status: COMPLETE_WITH_SEMANTIC_AUDIT_LIMITATIONS\n\nProtocol: v10.6 with operator-authorized Phase07 three-shard amendment.\nMethod: fullload. The original external evaluator ran gpt-6.2-sol, reasoning effort high.\n\n- Original assessed IDs: 3,852 (R=638; N=142; initial eligible G=3,072).\n- Final eligible binary judgments: {len(final_decisions)}. Eligibility supersessions: 521.\n- R cells: TP={counts[('R','TP')]}, FN={counts[('R','FN')]}.\n- N cells: FP={counts[('N','FP')]}, TN={counts[('N','TN')]}.\n- G diagnostic cells: supported TP={counts[('G','TP')]}, unsupported FP={counts[('G','FP')]}.\n- Phase07C explicit immutable supersessions: {len(supersessions)} (IDs: {', '.join(changes)}).\n- Original Markdown quotations revalidated: {proof_counts['original_markdown_quote_verified']}.\n- Original PDF text quotations matched: {proof_counts['original_pdf_text_quote_verified']}; {proof_counts['pdf_layout_quote_requires_visual_table_interpretation']} cross-column/table/figure quotations required a separate rendered-page interpretation beyond direct text matching.\n- Entire original external journal: 241 committed batches and 3,852 source-identity-matching records.\n- R/G nearest-evidence crosswalk: 638 source obligations; N/G polarity crosswalk: 142 controls. High-similarity cross-shard G pairs: {len(dup_candidates)}.\n\n**Counting boundary.** G supported TP labels are diagnostic, not extra canonical TPs. G unsupported FP labels are candidates requiring Phase08 N/F overlap and within-method residual semantic consolidation. No Precision, Recall or F1 has been calculated.\n\n**Important source semantics.** The mixed-classification fixture was not required by the original Appendix E, while the generated cross-file test lists asserted it as mandatory. This warrants GCLASS-0002053: TP→FP and aligns it with the separate original Shard A findings for GCLASS-0000859 and GCLASS-0001234. The original API appendix explicitly lists HTTP 202 for approved export/delete requests, so GCLASS-0002317: FP→TP. Additional specific source-grounded supersessions are recorded individually. All old A/B verdicts remain immutable.\n\n**Limitations.** Machine-assisted lexical and predicate evidence auditing is not a proof of complete natural-language semantic correctness, especially for implication across files. The 521 revised G eligibility decisions are preserved in their own ledger. A future evidence-based supersession must reference the applicable original and current decision; it cannot silently change its cell.\n'''
(OUT/'07_report_C.md').write_text(report,encoding='utf-8')
# Manifest hashes after all content files exist.
outputs=[p for p in sorted(OUT.iterdir()) if p.is_file() and p.name not in ('07_C_delivery_manifest.json',)]
verification={'record_type':'PHASE07C_INDEPENDENT_VERIFICATION','status':'PASSED_WITH_DISCLOSED_SEMANTIC_LIMITATIONS',
  'assertions':{'source_sha_verified':True,'pdf_n_pages_90':True,'A_ids_exactly_1926':True,'B_ids_exactly_1926':True,
   'no_cross_shard_ID_collisions':True,'union_exactly_3852':True,'model_records_3852':True,'journal_batches_241':True,
   'journal_model_json_unchanged':True,'original_md_quotations_verified':True,'pdf_quotations_text_or_rendered_page':True,
   'old_shards_unchanged':True,'R_638_binary':True,'N_142_binary':True,'G_all_accounted_for':True,
   'zero_final_eligible_null':True,'eligibility_exclusions_recorded':True,
   'cross_shard_conflicts_have_supersession_records':True,'phase08_not_advanced':True},
  'counts':{'original_ids':3852,'eligible_binary_records':len(final_decisions),'nondefinitive_supersessions':len(final_exclusions),
   'immutable_cell_supersessions':len(supersessions),'markdown_verified':proof_counts['original_markdown_quote_verified'],
   'pdf_text_verified':proof_counts['original_pdf_text_quote_verified'],'pdf_layout_associations':proof_counts['pdf_layout_quote_requires_visual_table_interpretation'],
   'high_similarity_cross_shard_pairs':len(dup_candidates)},
  'sha256':{'pdf':pdf_sha,'queue':run['queue_sha256'],**source_sha},
  'limitations_en':summary['limitations_en']}
writejson(OUT/'07_independent_verification_C.json',verification)
outputs=[p for p in sorted(OUT.iterdir()) if p.is_file() and p.name not in ('07_C_delivery_manifest.json',)]
delivery={'record_type':'PHASE07C_DELIVERY_MANIFEST','protocol_version':'10.6','method':'fullload',
 'original_shards_sha256':shard_hashes,'outputs_sha256':{p.name:sha(p) for p in outputs},
 'original_journals_sha256':sha(ROOT/'batch_journals(3).zip'),
 'external_semantic_results_sha256':sha(ROOT/'semantic_decisions(4).jsonl')}
writejson(OUT/'07_C_delivery_manifest.json',delivery)
print(json.dumps({'status':summary['status'],'cells':summary['final_directional_cells'],
 'eligibility_supersessions':len(final_exclusions),'cell_supersessions':len(supersessions),
 'pdf_layout_quote_associations':proof_counts['pdf_layout_quote_requires_visual_table_interpretation'],
 'crossGpair_candidates':len(dup_candidates),'B_flags':len(flags),
 'output_files':len(outputs)+1},ensure_ascii=False,indent=2))
