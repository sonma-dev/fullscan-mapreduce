#!/usr/bin/env python3
"""Independent post-generation integrity validation for Phase 07-C.

Checks file identity, merged row populations, immutable supersession links,
external model provenance, and referential completeness. Does not claim to
certify 3,852 natural-language entailment judgments or compute metrics.
"""
import pathlib,json,hashlib,collections
P=pathlib.Path('/mnt/data/fullload_v10_6')
O=P/'phase07_C_completed'
read=lambda x: json.loads(pathlib.Path(x).read_text(encoding='utf-8'))
parse=lambda x: [json.loads(l) for l in pathlib.Path(x).read_text(encoding='utf-8').splitlines() if l.strip()]
H=lambda p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
D=lambda x:hashlib.sha256(json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
qa=parse(P/'phase06/06_llm_queue_v10.6.jsonl');qr={x['item_id']:x for x in qa}
rows=parse(O/'07_assistant_adjudications.jsonl');X=parse(O/'07_eligibility_supersessions.jsonl');audit=parse(O/'07_decision_audit.jsonl');dis=parse(O/'07_all_original_ids_disposition.jsonl');sup=parse(O/'07_C_superseding_adjudications.jsonl')
oldA=parse(P/'phase07_A_completed/07_assistant_adjudications_A.jsonl');oldB=parse(P/'phase07_B_completed/07_assistant_adjudications_B.jsonl')
oldE=parse(P/'phase07_A_completed/07_eligibility_supersessions_A.jsonl')+parse(P/'phase07_B_completed/07_eligibility_supersessions_B.jsonl')
OLD={x['item_id']:x for x in oldA+oldB}
R={x['item_id']:x for x in rows}
checks={}
def test(name,cond):
 checks[name]=bool(cond)
 if not cond:raise AssertionError(name)
ids=[x['item_id'] for x in rows+X]
test('all_3852_input_ids_in_integrated_disposition',len(ids)==3852 and len(set(ids))==3852 and set(ids)==set(qr))
test('complete_phase07C_row_sets',len(rows)==3331 and len(X)==521 and len(audit)==len(dis)==3852)
test('original_id_order_preserved',[x['item_id'] for x in dis]==[x['item_id'] for x in qa])
test('exclusive_binary_or_eligibility_exclusion',all(x['final_cell'] in {'TP','TN','FP','FN'} for x in rows) and all(x.get('final_cell') is None for x in X))
C=collections.Counter((x['direction'],x['final_cell']) for x in rows)
test('source_r_638',C['R','TP']+C['R','FN']==638)
test('negative_controls_n_142',C['N','FP']+C['N','TN']==142)
test('diagnostic_g_3072_eligible_excluded',C['G','TP']+C['G','FP']+len(X)==3072)
test('all_source_specific_rule_identifiers',all(x['decision_rule_id']=='P7-'+(('G-SUPPORTED' if x['final_cell']=='TP' else 'G-UNSUPPORTED') if x['direction']=='G' else x['direction']+'-'+x['final_cell']) for x in rows))
test('exact_7_immutable_supersessions',len(sup)==7 and len(set(x['item_id'] for x in sup))==7)
test('original_decision_hashes_preserved',all(x['supersedes_record_sha256']==D(OLD[x['item_id']]) for x in sup))
test('current_decision_has_supersession',all(R[x['item_id']]['cross_shard_supersession_record_sha256']==D(x) and R[x['item_id']]['final_cell']==x['final_cell'] for x in sup))
test('unchanged_judgments_have_exact_original_cell',all(x['final_cell']==OLD[x['item_id']]['final_cell'] for x in rows if x['item_id'] not in {s['item_id'] for s in sup}))
test('every_excluded_original_is_preserved',set(x['item_id'] for x in oldE)==set(x['item_id'] for x in X))
test('no_generated_diagnostic_tp_is_canonical_source_tp',all(x['canonical_counting_scope'] in {'G_DIAGNOSTIC_NOT_CANONICAL_TP','G_FP_CANDIDATE_NEEDS_PHASE08_DEDUP'} for x in rows if x['direction']=='G'))
run=read(pathlib.Path('/mnt/data/run_state(3).json')); summary=read(pathlib.Path('/mnt/data/semantic_summary(3).json'))
test('source_lock_pdf_unchanged',H('/mnt/data/OrionDesk_AI_Detailed_Design_Specification(2).pdf')==run['pdf_sha256'])
test('external_queue_and_run_identity',H(P/'phase06/06_llm_queue_v10.6.jsonl')==summary['queue_sha256']==run['queue_sha256'])
test('external_model_metadata_recorded',summary['completed_items']==3852 and summary['completed_batches']==241 and run['model']=='gpt-6.2-sol' and run['batch_size']==16)
Gflags=parse(O/'07_C_priority_flag_dispositions.jsonl')
test('all_prior_priority_flags_accounted_for',len(Gflags)==96)
clashes=parse(O/'07_C_high_similarity_conflict_audit.jsonl')
test('all_detected_high_similarity_label_disagreements_superseded',all(x['resolution']=='RESOLVED_BY_IMMUTABLE_SUPERSESSION' for x in clashes))
test('source_positive_crosswalk_638',len(parse(O/'07_cross_shard_R_G_proof_leads.jsonl'))==638)
test('negative_polarity_crosswalk_142',len(parse(O/'07_cross_shard_N_G_polarity_leads.jsonl'))==142)
test('no_phase08_counts',read(O/'07_adjudication_summary.json')['precision_recall_f1_not_computed'] is True)
manifest=read(O/'07_C_delivery_manifest.json')
test('all_manifested_output_files_sha256_match',all(H(O/k)==v for k,v in manifest['outputs_sha256'].items()))
test('unmodified_original_shard_files',all(H(P/('phase07_'+s+'_completed')/('07_assistant_adjudications_'+s+'.jsonl'))==manifest['original_shards_sha256'][s]['adjudication_file_sha256'] for s in ('A','B')))
print(json.dumps({'status':'PASS','checks_passed':sum(checks.values()),'checks_total':len(checks),'cells':{f'{k[0]}:{k[1]}':v for k,v in C.items()},'phase07_supersessions':len(sup),'eligibility_supersessions':len(X),'semantic_verification_note':'Correct file/quote locations do not formally establish entailment.'},ensure_ascii=False,indent=2))
