# Phase 07-C Integration Instructions

Inputs: successful A and B final source-grounded adjudication ledgers, original PDF and eight originals, frozen reference, v5 evaluator outputs/journals, and the unchanged `07_partition_manifest.json`.

Verify A and B together cover exactly 3,852 unique IDs (R 638, N 142, G 3,072), with complete original evidence and per-item final binary cells. Verify source SHA and quote/line/page locators. Compare cross-shard R/G and N/G consistency, implicit universal claims, contradictions, negative polarity, and supported-noncovering classes. If a prior decision is wrong, create an explicit immutable superseding Phase 07 verdict identifying and quoting the earlier verdict and the source grounds. No silent cell changes.

Outputs once both shards are truly complete: `07_assistant_adjudications.jsonl`, `07_decision_audit.jsonl`, `07_adjudication_summary.json`, `07_input_blockers.jsonl`.

Phase 07-C must not compute canonical FP residual units, perform Phase 08's N/F consolidation, or calculate Precision/Recall/F1. Shard inputs or output templates are NOT actual adjudication data. An incompletely adjudicated shard blocks C from claiming completion.
