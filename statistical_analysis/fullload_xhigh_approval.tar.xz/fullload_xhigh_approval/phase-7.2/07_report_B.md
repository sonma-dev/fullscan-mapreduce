# Phase 07-B — Independent Negative-Control and Generated-Claim Analysis

**Execution status:** Complete for the assigned Shard B inventory (operational disposition of all IDs), subject to independent semantic reconciliation at Shard C.  
**Method:** fullload. **Protocol:** v10.6 plus the explicit three-shard Phase 07 amendment.  
**External evaluator actually used:** `gpt-6.2-sol`, reasoning effort `high`, not the `gpt-6.1-sol / medium` wording in the original protocol. The external model suggestions are preserved as original evidence only.

## Scope and result

| Item | Count |
|---|---:|
| Original assigned N controls | 142 |
| Original assigned G classes | 1,784 |
| All original IDs accounted for | 1,926 |
| N: TN | 142 |
| N: FP | 0 |
| G: PDF-supported (diagnostic TP, not canonical R TP) | 1,356 |
| G: unsupported generated residual candidates (diagnostic FP) | 127 |
| G: Phase 05 eligibility superseded to NONDEFINITIVE | 301 |
| Unassigned/blocked items | 0 |
| Cross-shard C priority flags (audit findings, not undecided ledger rows) | 96 |

Every assigned ID appears in exactly one of the final G/N diagnostic ledger or the explicit eligibility-supersession ledger. Nondefinitive material is not counted as an FP or a TN. Every diagnostic G:FP must undergo N-overlap and cross-file semantic consolidation in Phase 08, and a supported G:TP is never an extra canonical R:TP.

## Independent source checks and original records

* 90 original PDF pages, original hashes, and all eight original Markdown files were validated against the frozen manifest.
* 4,247 PDF citations and 1,988 Markdown citations in delivered verdict or eligibility records were checked against their exact original physical pages or original line ranges.
* All 241 committed external journals, covering 3,852 original external items, were checked against the supplied immutable records. Every Shard B original LLM JSON result was compared against its journal record.
* 34 mechanical integrity checks passed with no missing or duplicated Shard B IDs. The source PDF and frozen R/N, earlier phases and Shard A judgments were not changed.
* Shard B uses actual external `gpt-6.2-sol / high` records. No new external inference submission and no final metric computation were performed.

## Concrete original-evidence examples

**Negative control `NEG-0001`, TN.** The forbidden proposition would permit a browser to send arbitrary tool definitions. The original PDF (physical page 7) says the browser never does this. `01_screen_functions(2).md`, original lines 154 and 225, restate that prohibition. A prohibition is not an affirmative assertion of the forbidden counterfactual.

**Generated `GCLASS-0002149`, diagnostic TP.** The generated exception specification states that permission failures are permanent and not automatically retried. The PDF (physical page 49) states that validation and permission failures are permanent and not retried. This is PDF support for the generated assertion, not an additional source R true positive.

**Generated `GCLASS-0001468`, diagnostic FP candidate.** The generated retention/purge argument table includes a time cutoff. The closest PDF obligations define eligibility and scheduled purge but do not clearly establish this exact cutoff input; the missing predicate and original page citations are recorded. The resulting candidate is not yet a counted, unique FP, and Shard C may issue a superseding source-based determination.

## Required follow-up audit, not silent relabeling

N control polarity must remain affirmative-counterfactual; G classes must be fully supported, not merely about the same topic. Items where the source model said `PARTIAL` but the independent source search found support, source-model `FULL` claims rejected by the evidence process, and mixed/eligibility boundaries were independently flagged. **96 flagged records** are provided for explicit Shard C review. Original decisions are preserved; any correction must be a new superseding decision with authentic evidence and the old ID.

## Limitations

This is an assistant-authored, programmatic reciprocal evidence audit. A successful literal quotation check proves that a passage exists at the cited page/line; it does not mathematically prove complete semantic entailment or exhaustive absence of a counterfactual. The deterministic matching and external model proposals are subject to false positive/negative judgments, especially around unstated applicability conditions and cross-file conjunctions. No claim is made that 1,926 independent expert human judgments were performed. Accordingly, **the operational Shard B ledger is complete, but no final scientific validity or Precision/Recall/F1 metric is certified**. Phase 07-C must audit cross-shard consistency before Phase 08/09 may publish metrics.
