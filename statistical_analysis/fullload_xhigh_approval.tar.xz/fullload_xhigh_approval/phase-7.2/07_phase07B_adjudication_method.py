#!/usr/bin/env python3
"""Phase 07-B original-evidence audit and bounded automated semantic adjudication.
Preserves external gpt-6.2-sol records and v10.6 frozen inputs. No network model
call, fabricated quote, or fabricated original decision is permitted.
"""
from __future__ import annotations
import json, hashlib, re, unicodedata, pathlib, collections, itertools, math, sys
import fitz
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from nltk.stem.snowball import SnowballStemmer
ROOT=pathlib.Path('/mnt/data/fullload_v10_6')
HERE=ROOT/'phase07_sharded'
OUT=ROOT/'phase07_B_completed'; OUT.mkdir(parents=True,exist_ok=True)
BASE=pathlib.Path('/mnt/data')
ORIG=['01_screen_functions(2).md','02_api(2).md','03_data(2).md','04_batch_functions(3).md','05_business_rules(2).md','06_exception_handling(4).md','07_processing_flows(4).md','08_architecture_decision(3).md']
CANON=['01_screen_functions.md','02_api.md','03_data.md','04_batch_functions.md','05_business_rules.md','06_exception_handling.md','07_processing_flows.md','08_architecture_decision.md']
ALIASES=dict(zip(ORIG,CANON));ALIAS_REV={v:k for k,v in ALIASES.items()}
sha=lambda x:hashlib.sha256(x).hexdigest()
def fromjsonl(p):return [json.loads(t) for t in p.open(encoding='utf-8') if t.strip()]
def jsonout(p,v):p.write_text(json.dumps(v,ensure_ascii=False,sort_keys=True,indent=2)+'\n',encoding='utf-8')
def rowsout(p,arr):
 with p.open('w',encoding='utf-8') as f:
  for item in arr:f.write(json.dumps(item,ensure_ascii=False,sort_keys=True,separators=(',',':'))+'\n')
def norm(s):return ' '.join(unicodedata.normalize('NFKC',s).casefold().split())
ref=json.loads((HERE/'07_partition_manifest.json').read_text())
rows=fromjsonl(HERE/'07_shard_B_input.jsonl')
assert len(rows)==1926 and collections.Counter(x['direction'] for x in rows)=={'N':142,'G':1784}
assert len(set(x['item_id'] for x in rows))==1926
assert sha((HERE/'07_shard_B_input.jsonl').read_bytes())==ref['shards']['B']['sha256']
assert sha((ROOT/'phase06/06_llm_queue_v10.6.jsonl').read_bytes())==ref['external_queue_sha256']
assert sha((BASE/'semantic_decisions(4).jsonl').read_bytes())==ref['inputs_sha256']['external_results']
assert sha((BASE/'batch_journals(3).zip').read_bytes())==ref['inputs_sha256']['external_batch_journals_zip']
assert sha((BASE/'run_state(3).json').read_bytes())==ref['inputs_sha256']['external_run_state']
assert sha((BASE/'semantic_summary(3).json').read_bytes())==ref['inputs_sha256']['external_summary']
md={fn:(BASE/fn).read_text(encoding='utf-8').splitlines() for fn in ORIG}
mdhash={ALIASES[fn]:sha((BASE/fn).read_bytes()) for fn in ORIG}
assert mdhash=={k:v for k,v in ref['source_file_sha256'].items() if k.endswith('.md')}
pdf=fitz.open(BASE/'OrionDesk_AI_Detailed_Design_Specification(2).pdf')
assert len(pdf)==90
pdfhash=sha((BASE/'OrionDesk_AI_Detailed_Design_Specification(2).pdf').read_bytes())
assert pdfhash==ref['source_pdf_sha256']
ptexts=[p.get_text(sort=False) for p in pdf]
pages=[{'physical_page':i,'text':s} for i,s in enumerate(ptexts,1)]

# Content preserving original line/page index, not generated source statement.
segments=[]
for pidx,txt in enumerate(ptexts,1):
 chunks=re.split(r'(?<=\.)\s+(?=[A-Z])|\n+',txt)
 for part in chunks:
  part=part.strip()
  if len(part)>=28:
   segments.append({'physical_page':pidx,'quote_en':part[:1200]})
# Include full page windows for multi-line context.
segments.extend([{'physical_page':pidx,'quote_en':txt[:7000]} for pidx,txt in enumerate(ptexts,1) if txt.strip()])
vector=TfidfVectorizer(ngram_range=(1,2),stop_words='english',sublinear_tf=True,min_df=1,max_features=90000)
mtx=vector.fit_transform([z['quote_en'] for z in segments]);print('PDF_SEARCH_UNITS',len(segments),flush=True)
# Index original Markdown rows across all 8 files to inspect N counterfactuals.
mdrows=[]
for fn in ORIG:
 for i,t in enumerate(md[fn],1):
  if len(t.strip())>=22 and not re.fullmatch(r'[|\s\-:]+',t):
   mdrows.append({'file':fn,'line_start':i,'line_end':i,'quote_en':t[:1600]})
vm=TfidfVectorizer(ngram_range=(1,2),stop_words='english',sublinear_tf=True,min_df=1,max_features=120000)
matm=vm.fit_transform([z['quote_en'] for z in mdrows]);print('MD_SEARCH_UNITS',len(mdrows),flush=True)

def best_pdf(query,k=5):
 a=(mtx@vector.transform([query]).T).toarray().ravel();inds=np.argsort(a)[-k:][::-1]
 return [{**segments[i], 'retrieval_similarity':round(float(a[i]),5)} for i in inds if a[i]>0]
def best_md(query,k=8):
 a=(matm@vm.transform([query]).T).toarray().ravel();inds=np.argsort(a)[-k:][::-1]
 return [{**mdrows[i], 'retrieval_similarity':round(float(a[i]),5)} for i in inds if a[i]>0]

def check_md(ev):
 name=ev.get('file');name=name if name in md else ALIAS_REV.get(name)
 a=ev.get('line_start');b=ev.get('line_end');q=ev.get('quote_en','')
 if not name or not isinstance(a,int) or not isinstance(b,int) or a<1 or b<a or b>len(md[name]) or not q:return None
 txt='\n'.join(md[name][a-1:b]);
 if norm(q) not in norm(txt):return None
 return {'file':name,'canonical_role':ALIASES[name],'source_sha256':mdhash[ALIASES[name]],'line_start':a,'line_end':b,'quote_en':q,'verified_original_markdown_lines':True}

def check_pdf(ev):
 i=ev.get('physical_page');q=ev.get('quote_en','')
 if isinstance(i,int) and 1<=i<=90 and q and norm(q) in norm(ptexts[i-1]):
  return {'physical_page':i,'quote_en':q,'verified_original_pdf_text':True}
 return None

def original_generated(x):
 q=x['original_queue_item'];ev=q.get('generated_evidence',[])
 valid=[]
 for e in ev:
  r=check_md(e)
  if r:valid.append(r)
 return valid

def valid_model_evidence(x,typ):
 m=x['immutable_external_semantic_result']['model_json'];valid=[];bad=[]
 for ev in m.get(typ+'_evidence',[]):
  e=check_pdf(ev) if typ=='pdf' else check_md(ev)
  if e:valid.append(e)
  else:bad.append(ev)
 return valid,bad

# Stable numeric qualifiers and endpoint/identifier constraints (not arbitrary number tokens)
ANCHOR=re.compile(r'(?i)\b(?:GET|POST|PATCH|PUT|DELETE)\s+/(?:v\d+|internal)/[\w\-/{}/.?&=]+|\b\d+(?:\.\d+)?\s*(?:MB|GB|ms|seconds?|minutes?|hours?|days?|years?|tokens?|chunks?|pages?|calls?|\%)\b|\b(?:WCAG\s*2\.2\s*AA|PKCE|RFC\s*3339|UUIDv7|OIDC|RLS|mTLS|TLS|SHA-256)\b')
def anchors(s):
 return {re.sub(r'\s+',' ',v.casefold().strip('` .,')) for v in ANCHOR.findall(s)}
STEM=SnowballStemmer('english')
STOP=set('a an the and to by on for in of with are is or it that this these those shall should must may will be been have has had where how who when what while all each every as from not no only use uses used if else then source pdf original generation generated author code case data spec requirement confirmed available exists does do can cannot need needs confirmation must should required source file role input output statuses status number item example test table fields any'.split())
TOK=re.compile(r'[A-Za-z][\w/@.-]{2,}|\d+(?:\.\d+)?')
def token_set(s):
 toks=[]
 for t in TOK.findall(s):
  t=t.lower().strip('`');
  if t in STOP:continue
  if t.startswith('http') or t.startswith('/v') or t.startswith('/internal'):toks.append(t)
  elif t.isdigit():continue
  else:toks.append(STEM.stem(t))
 return set(toks)
def overlap(a,b):
 ta=token_set(a);tb=token_set(b)
 return round(len(ta&tb)/max(1,len(ta)),4)

# Identify statements which are documentation of a missing decision, a proposed
# arrangement, a status illustration, or an unadopted alternative, not a definite
# app implementation/test obligation. Preserve valid affirmative fragments.
DOCUMENTARY=re.compile(r'(?i)(\bneeds? confirmation\b|\bTBD\b|\bunadopted\b|\bproposal\b|\bopen question\b|\bno (?:confirmed|complete|explicit|separate|independent|public) (?:contract|endpoint|api|job|response|control|method|screen|scope|role|layout|source)\b|\bnot (?:specified|defined|established|confirmed|selected|provided|described|a default|an approval)\b|\bremains? unresolved\b|\bdoes not (?:define|establish|specify|provide|confirm|assign)\b|\bnot automatically\b|\bno (?:final|approved) (?:choice|option|behavior)\b|\bis (?:not|only) an? (?:illustration|proposal|example|source note|indication)\b|\brequires? (?:confirmation|decision|clarification)\b)')
META=re.compile(r'(?i)\b(this specification|earlier specifications|the source does not|no (?:source|independent) contract|do not invent|do not infer|no (?:(?:public|complete|confirmed|new|additional) )?(?:endpoint|api|schedule|table)|not an? (?:approved|confirmed)|neither .* nor|remains? (?:unresolved|open)|cannot infer|needs? confirmation|open decision|pending approval|unadopted proposal|not a selected implementation|not an implementation|needs? to be (?:defined|confirmed)|exact .*? unresolved)\b')
HARD_OBLIGATION=re.compile(r'(?i)\b(must|shall|cannot|never|prohibit|enforce|recheck|validate|reject|publish|preserve|persist|require|deny|restore|store|is not permitted|not allowed|fails closed|should not|not be treated as|must not|shall not)\b')

# N source evidence is from the locked negative row's physical page and PDF quote.
# A negated assertion is not an affirmative assertion of that counterfactual.
NEGATION=re.compile(r'(?i)\b(?:must not|shall not|cannot|not permitted|not supported|no (?:direct|unrestricted|unauthorized)|prohibited|forbidden|deny|reject|exclude|deferred|does not|never|without|not (?:allow|grant|authorize|permit|support|implement|expose))\b')

results=[];excluded=[];audit=[];blockers=[];flags=[]
stat=collections.Counter()
for idx,x in enumerate(rows):
 id=x['item_id'];direc=x['direction'];m=x['immutable_external_semantic_result'];v=m['model_json'];q=x['original_queue_item'];statement=q['statement_en']
 mdep,badmd=valid_model_evidence(x,'generated');pp,badpdf=valid_model_evidence(x,'pdf')
 pdf_hints=[]
 for ev in q.get('pdf_evidence_hints',[]):
  # See original row shape; no fabricated hints.
  if isinstance(ev,dict):
   r=check_pdf({'physical_page':ev.get('physical_page'), 'quote_en':ev.get('quote_en',ev.get('quote',''))})
   if r:pdf_hints.append(r)
 origin=original_generated(x) if direc=='G' else []
 if direc=='G' and not origin:
  blockers.append({'item_id':id,'direction':'G','reason_en':'No original generated source line verified for the effective GC class.'});continue
 if direc=='N' and not (pp or pdf_hints):
  # N freeze evidence recovers from original negative source inventory.
  neg=next((z for z in fromjsonl(BASE/'common_negative_controls(2).jsonl') if z.get('control_id',z.get('negative_control_id'))==id),None)
  if neg:
   for e in neg.get('evidence',[]):
    if isinstance(e,dict):
     y=check_pdf({'physical_page':e.get('physical_page'),'quote_en':e.get('quote_en',e.get('quote',''))})
     if y:pdf_hints.append(y)
 # independent nearest source references on all 90 pages
 refs=best_pdf(statement,8) if direc=='G' else []
 witnesses=best_md(statement,12) if direc=='N' else []
 if direc=='N':
  # Negative criterion: an explicit generated *affirmative* permission is
  # required for FP. The model's own CONTRADICTED/NOT_FOUND is cross-checked
  # against the eight-file witness set and the original prohibition.
  if not (pp or pdf_hints):
   blockers.append({'item_id':id,'direction':'N','reason_en':'The original PDF prohibition cannot be located from its provided physical-page evidence.'});continue
  affirmative=[];negative=[]
  for e in witnesses:
   val=e['quote_en'];o=overlap(statement,val)
   if o<.18:continue
   if NEGATION.search(val) or DOCUMENTARY.search(val):negative.append(e)
   elif re.search(r'(?i)\b(may|can|will|shall|must|allows?|permitted|implemented|enabled|unrestricted|authorizes?)\b',val):affirmative.append(e)
  if v['relation']=='CONTRADICTED' and negative:
   cell='TN';basis='ORIGINAL_NEGATED_COUNTERFACTUAL_AND_RETRIEVAL'
  elif v['relation']=='NOT_FOUND' and not affirmative:
   cell='TN';basis='EXHAUSTIVE_DOCUMENT_CANDIDATE_NONASSERTION'
  elif affirmative and v['relation'] in ('FULL','PARTIAL'):
   # any semantic assertion of forbidden behavior must be examined, not merely lexical.
   cell='FP';basis='AFFIRMATIVE_FORBIDDEN_COUNTERFACTUAL_CANDIDATE'
  else:
   cell='TN';basis='AFFIRMATIVE_COUNTERFACTUAL_NOT_ESTABLISHED'
  gev=mdep or ([negative[0]] if negative else witnesses[:1]);pev=pp or pdf_hints
  if not gev:
   blockers.append({'item_id':id,'direction':'N','reason_en':'Cannot establish an actual generated nearest witness for negative-control reciprocal audit.'});continue
  rule='P7-N-TN' if cell=='TN' else 'P7-N-FP'
  unmet=[] if cell=='FP' else ['No eligible affirmative generated predicate was established for the prohibited counterfactual; inspected original nearby negations, not treated as positive affirmation.']
  reason=('The forbidden affirmative counterfactual has a generated assertion; verified candidate must be reconciled in Phase 07-C.' if cell=='FP' else 'The prohibited proposition is not asserted as an affirmative definite obligation: the generated text instead prohibits, excludes or leaves unadopted the counterfactual. Original source candidate sentences and PDF negative control inspected.')
  entity_scope='N_CONTROL'
 else:
  src=' '.join(e['quote_en'] for e in origin)
  # See row itself and the normativity designation, not only the v5 eligibility label.
  editorial=bool(DOCUMENTARY.search(statement) or META.search(statement))
  headline=statusword=src.casefold()
  # If source table says Needs confirmation or proposal and statement describes
  # missing schema/unknown detail, the absent contract is not a new obligation.
  status_nondef=bool(re.search(r'(?i)(\|\s*(?:needs? confirmation|proposal|unadopted|tbd)\s*\||\b(?:source does not|not confirmed|no source|not specified|exact .* unresolved)\b)',src))
  explicit_norm=bool(HARD_OBLIGATION.search(statement))
  model_nondef=v['eligibility']=='NONDEFINITIVE'
  # Conservative: model nondef + concrete documentary source, or explicit
  # unadopted proposal/needs confirmation. Preserve mandatory affirmative
  # isolated fragments despite adjacent unresolved statements.
  nondef=(model_nondef or (v['eligibility']=='MIXED' and editorial and not explicit_norm))
  if not model_nondef and re.search(r'(?i)\b(must not|shall not|cannot|never|is prohibited|is required|must|shall)\b',statement) and not re.search(r'(?i)(needs? confirmation|proposal|source does not|no (?:source|confirmed|complete) |unknown|not specified|not established)',statement):
   nondef=False
  if nondef:
   ec={'record_type':'PHASE07B_ELIGIBILITY_SUPERSESSION','protocol_version':'10.6','shard':'B','item_id':id,'direction':'G','method':'fullload','prior_phase05_eligibility':'DEFINITIVE','reviewed_eligibility':'NONDEFINITIVE','original_statement_en':statement,'final_cell':None,'not_counted_as_final_binary_cell':True,'not_scored_as_fp_or_tn':True,'generated_evidence':origin,'pdf_evidence':pp,'reason_en':'The original generated row/claim documents a missing decision, example, unadopted proposal or editorial qualification rather than committing a definite application/test obligation. Preserve any independently definite neighboring obligations separately.','original_model_eligibility':v['eligibility'],'original_model_relation':v['relation'],'original_model_suggestion':m['suggested_decision'],'original_model_status':m['decision_status'],'input_item_sha256':sha(json.dumps(x,sort_keys=True).encode()),'source_reference_unchanged':True}
   excluded.append(ec);stat['G:NONDEFINITIVE']+=1
   audit.append({'record_type':'PHASE07B_EVIDENCE_AUDIT','item_id':id,'disposition':'NONDEFINITIVE','original_source_excerpt':src,'original_statement_en':statement,'independent_eligibility_check':True,'prior_model_eligibility':v['eligibility'],'reviewed_eligibility':'NONDEFINITIVE','source_pdf_sha256':pdfhash,'generated_quote_verification':True,'not_a_binary_cell':True})
   continue
  # Whole G proposition must be supported: prefer verified original PDF excerpts
  # and then independently challenged source retrieval; a key word alone does not prove.
  if not pp:
   found=[]
   for e in refs[:8]:
    pp0=check_pdf(e)
    if pp0:found.append(pp0)
   pp=found[:3]
  if not pp:
   blockers.append({'item_id':id,'direction':'G','reason_en':'Cannot verify any original PDF text witness; no invented quote or automatic unsupported label permitted.'});continue
  ptext=' '.join(z['quote_en'] for z in pp)
  independent=' '.join(z['quote_en'] for z in refs[:8])
  ex=overlap(statement,ptext+' '+independent)
  required=anchors(statement)
  check=anchors(ptext+' '+independent)
  gaps=sorted(required-check)
  complete_model=(v['relation']=='FULL' and v['eligibility'] in ('DEFINITIVE','MIXED') and not v['missing_predicates_en'] and not v.get('unsupported_residual_en','').strip() and len(valid_model_evidence(x,'pdf')[0])>0)
  # For complete, source-verified model proofs, demand independent lexical
  # witness and matching explicit structural constraints. Other propositions
  # are challenged with whole-PDF top candidates and source-specific predicates.
  explicit_support=(complete_model and ex>=.12 and not gaps) or (complete_model and ex>=.08 and len(pp)>0 and len(origin)>0)
  potential_support=(v['relation'] in ('PARTIAL','MIXED','UNRESOLVED','NOT_FOUND','FULL') and ex>=.68 and not gaps and overlap(statement,independent)>=.6 and not re.search(r'(?i)\b(unknown|not documented|needs confirmation|never (?:specified|defined))\b',statement))
  if explicit_support or potential_support:
   cell='TP';basis='PDF_FULL_QUOTE_AND_RECIPROCAL_MATCH' if explicit_support else 'PDF_INDEPENDENT_NEAR_ENTAILMENT_CHALLENGE';unmet=[]
  else:
   # Source statement remains definitive; the most similar original PDF
   # passage does not satisfy the whole substantive assertion.
   cell='FP';basis='PDF_UNSUPPORTED_AFFIRMATIVE_RESIDUAL_CANDIDATE'
   unmet=list(v['missing_predicates_en'])
   if gaps:unmet+=['No verified original PDF evidence for exact constraints: '+', '.join(gaps)]
   if not unmet:unmet=['An essential part of the definitive proposition is not established by the verified original source quotations after full-document reciprocal search; the strongest candidates are indexed for review.']
  gev=origin
  pev=pp
  rule='P7-G-SUPPORTED' if cell=='TP' else 'P7-G-UNSUPPORTED'
  reason=('The definitive original Markdown assertion is supported by source-page evidence and independent whole-PDF reciprocal retrieval; explicit method/path/numeric qualifiers were checked.' if cell=='TP' else 'The generated assertion is definitive but source evidence inspected does not fully establish its complete predicates. Its PDF nearest matches and unmet conditions are recorded; this is a diagnostic G candidate, NOT an automatically counted canonical false positive.')
  entity_scope='G_DIAGNOSTIC_NOT_CANONICAL_TP' if cell=='TP' else 'G_FP_CANDIDATE_NEEDS_PHASE08_DEDUP'
 record={'record_type':'ASSISTANT_ADJUDICATION','protocol_version':'10.6','method':'fullload','shard':'B','local_phase07_amendment':'P7-3SHARD-2026-11-22','item_id':id,'direction':direc,'final_cell':cell,'canonical_counting_scope':entity_scope,'decision_rule_id':rule,'decision_origin':'PHASE07_ASSISTANT','original_statement_en':statement,'pdf_evidence':pev,'generated_evidence':gev,'examined_candidate_ids':[id],'support_bridge_ids':[],'unmet_predicates_en':unmet,'decision_reason_en':reason,'evidence_proof_method':basis,'original_source_retrieval_witnesses':refs[:6] if direc=='G' else [],'original_generated_retrieval_witnesses':witnesses[:6] if direc=='N' else [],'original_model_relation':v['relation'],'original_model_eligibility':v['eligibility'],'prior_v5_suggested_decision':m['suggested_decision'],'prior_v5_decision_status':m['decision_status'],'was_external_llm_selected':True,'source_pdf_sha256':pdfhash,'generated_file_sha256':mdhash,'input_item_hash':sha(json.dumps(x,ensure_ascii=False,sort_keys=True).encode()),'external_result_sha256':sha(json.dumps(m,ensure_ascii=False,sort_keys=True).encode()),'source_reference_unchanged':True,'source_quote_check_passed':True,'algorithmically_adjudicated_not_manually_certified':True}
 results.append(record);stat[f'{direc}:{cell}']+=1
 audit.append({'record_type':'PHASE07B_EVIDENCE_AUDIT','item_id':id,'direction':direc,'final_cell':cell,'decision_rule_id':rule,'decision_basis':basis,'pdf_verified_quote_count':len(pev),'generated_verified_quote_count':len(gev),'model_original_relation':v['relation'],'model_original_eligibility':v['eligibility'],'model_original_suggestion':m['suggested_decision'],'source_pdf_sha256':pdfhash,'md_hashes_checked':True,'nine_source_files_checked':True,'unmet_predicates_en':unmet,'strongest_original_pdf_matches':refs[:4] if direc=='G' else [],'strongest_original_md_matches':witnesses[:8] if direc=='N' else [],'external_invalid_pdf_quotes':badpdf[:3],'external_invalid_markdown_quotes':badmd[:3],'original_statement_en':statement,'decision_reason_en':reason})
 if idx%250==0:print('ROW',idx,'JUDGED',len(results),'ELIG',len(excluded),'BLOCK',len(blockers),flush=True)

order={x['item_id']:i for i,x in enumerate(rows)}
for a in [results,excluded,audit,blockers,flags]:a.sort(key=lambda z:order[z['item_id']])
assert len(results)+len(excluded)+len(blockers)==len(rows)
assert len(set(z['item_id'] for z in results+excluded+blockers))==len(rows)
assert all(x['final_cell'] in ({'TN','FP'} if x['direction']=='N' else {'TP','FP'}) for x in results)
assert len([x for x in results if x['direction']=='N']) + len([x for x in blockers if x['direction']=='N'])==142
rowsout(OUT/'07_assistant_adjudications_B.jsonl',results)
rowsout(OUT/'07_eligibility_supersessions_B.jsonl',excluded)
rowsout(OUT/'07_decision_audit_B.jsonl',audit)
rowsout(OUT/'07_input_blockers_B.jsonl',blockers)
rowsout(OUT/'07_all_original_ids_disposition_B.jsonl',[{'item_id':r['item_id'],'direction':r['direction'],'disposition':next((x['final_cell'] for x in results if x['item_id']==r['item_id']), ('EXCLUDED_NONDEFINITIVE' if any(x['item_id']==r['item_id'] for x in excluded) else 'BLOCKED'))} for r in rows])
summary={'record_type':'PHASE07B_ADJUDICATION_SUMMARY','protocol_version':'10.6','method':'fullload','shard':'B','local_phase07_amendment':'P7-3SHARD-2026-11-22','status':'COMPLETE' if not blockers else 'INCOMPLETE','original_assigned_count':len(rows),'original_direction_counts':dict(collections.Counter(x['direction'] for x in rows)),'scored_eligible_decisions':len(results),'eligibility_supersessions':len(excluded),'blockers':len(blockers),'disposition_counts':dict(stat),'all_original_ids_accounted':len(results)+len(excluded)+len(blockers)==len(rows),'negative_control_complete':stat['N:TN']+stat['N:FP']==142,'G_effective_complete':stat['G:TP']+stat['G:FP']+stat['G:NONDEFINITIVE']==1784,'external_model_actual':'gpt-6.2-sol','external_reasoning_effort_actual':'high','external_batch_count_actual':241,'external_model_suggestions_preserved':True,'source_pdf_sha256':pdfhash,'external_queue_sha256':ref['external_queue_sha256'],'source_file_sha256':mdhash,'source_reference_unchanged':True,'phase07_C_started':False,'phase08_started':False,'phase09_started':False,'final_metrics_not_computed':True,'method_disclosure_en':'Evidence-based automated reciprocal source verification; matches verified literal page and Markdown-line quotations with a full-PDF retrieval challenge and context-based definitiveness check. It is not 1,926 independent expert semantic judgments; any automated semantic ambiguity remains an acknowledged reliability limitation requiring cross-shard audit. Generated G diagnostic FP candidates require Phase08 N/F and class-level semantic consolidation.'}
jsonout(OUT/'07_adjudication_summary_B.json',summary)
print(json.dumps(summary,indent=2,ensure_ascii=False),flush=True)
