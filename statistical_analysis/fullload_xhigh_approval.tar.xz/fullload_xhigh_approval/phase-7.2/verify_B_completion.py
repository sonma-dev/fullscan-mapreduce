#!/usr/bin/env python3
"""Independent integrity audit of Phase 07-B; reads all original sources and journals."""
import pathlib,json,hashlib,collections,re,unicodedata,zipfile
import fitz
P=pathlib.Path('/mnt/data');R=P/'fullload_v10_6';D=R/'phase07_B_completed';I=R/'phase07_sharded'
J=lambda p:json.loads(p.read_text(encoding='utf-8'))
L=lambda p:[json.loads(s) for s in p.open(encoding='utf-8') if s.strip()]
sha=lambda b:hashlib.sha256(b).hexdigest()
norm=lambda x:' '.join(unicodedata.normalize('NFKC',x).casefold().split())
inrows=L(I/'07_shard_B_input.jsonl');ad=L(D/'07_assistant_adjudications_B.jsonl');ex=L(D/'07_eligibility_supersessions_B.jsonl');a=L(D/'07_decision_audit_B.jsonl');block=L(D/'07_input_blockers_B.jsonl');manifest=J(I/'07_partition_manifest.json');s=J(D/'07_adjudication_summary_B.json')
ori=['01_screen_functions(2).md','02_api(2).md','03_data(2).md','04_batch_functions(3).md','05_business_rules(2).md','06_exception_handling(4).md','07_processing_flows(4).md','08_architecture_decision(3).md']
canon=['01_screen_functions.md','02_api.md','03_data.md','04_batch_functions.md','05_business_rules.md','06_exception_handling.md','07_processing_flows.md','08_architecture_decision.md']
roles=dict(zip(ori,canon));rev={v:k for k,v in roles.items()};md={p:(P/p).read_text(encoding='utf-8').splitlines() for p in ori}
mdhash={roles[p]:sha((P/p).read_bytes()) for p in ori}
pdf=fitz.open(P/'OrionDesk_AI_Detailed_Design_Specification(2).pdf');pgtext=[p.get_text(sort=False) for p in pdf];pd=sha((P/'OrionDesk_AI_Detailed_Design_Specification(2).pdf').read_bytes())
checks={}
def chk(name,boolean):checks[name]=bool(boolean);return bool(boolean)
chk('input_hash',sha((I/'07_shard_B_input.jsonl').read_bytes())==manifest['shards']['B']['sha256'])
chk('queue_hash',sha((R/'phase06/06_llm_queue_v10.6.jsonl').read_bytes())==manifest['external_queue_sha256'])
chk('pdf_hash',pd==manifest['source_pdf_sha256'])
chk('pdf_90_pages',len(pdf)==90)
chk('eight_original_markdown_hashes',mdhash=={k:v for k,v in manifest['source_file_sha256'].items() if k in canon})
chk('input_count',len(inrows)==1926)
chk('input_direction_counts',dict(collections.Counter(x['direction'] for x in inrows))=={'N':142,'G':1784})
chk('all_IDs_unique',len(set(x['item_id'] for x in inrows))==1926)
chk('partition_counts',len(ad)+len(ex)+len(block)==1926)
chk('zero_blockers',not block)
ids0=[x['item_id'] for x in inrows]; ids1=[x['item_id'] for x in ad+ex+block]
chk('no_duplicate_output_ids',len(set(ids1))==1926)
chk('identical_output_id_set',set(ids0)==set(ids1))
chk('all_audit_items_covered',set(x['item_id'] for x in a)==set(ids0))
chk('N_cell_invariant',all(x['final_cell'] in ['FP','TN'] for x in ad if x['direction']=='N'))
chk('G_cell_invariant',all(x['final_cell'] in ['TP','FP'] for x in ad if x['direction']=='G'))
chk('no_nondefinitive_counted_as_FP',all(x.get('final_cell') is None and x.get('not_counted_as_final_binary_cell') for x in ex))
chk('N_complete',sum(x['direction']=='N' for x in ad)==142)
chk('G_complete',sum(x['direction']=='G' for x in ad)+len(ex)==1784)
chk('actual_external_model_metadata',all(x['immutable_external_semantic_result']['model']=='gpt-6.2-sol' and x['immutable_external_semantic_result']['reasoning_effort']=='high' for x in inrows))
chk('external_run_finished',J(P/'semantic_summary(3).json')['completed_items']==3852)
chk('unchanged_external_results',sha((P/'semantic_decisions(4).jsonl').read_bytes())==manifest['inputs_sha256']['external_results'])
chk('unchanged_external_journals',sha((P/'batch_journals(3).zip').read_bytes())==manifest['inputs_sha256']['external_batch_journals_zip'])
chk('unchanged_prior_shard_A',J(R/'phase07_A_completed/07_adjudication_summary_A.json')['status']=='COMPLETE')
quote_failures=[];num_pdf=num_md=0
for row in ad+ex:
 for e in row.get('pdf_evidence',[]):
  num_pdf+=1;i=e.get('physical_page');q=e.get('quote_en','')
  if not isinstance(i,int) or i<1 or i>len(pgtext) or not q or norm(q) not in norm(pgtext[i-1]):quote_failures.append((row['item_id'],'PDF',i,q[:150]))
 for e in row.get('generated_evidence',[]):
  num_md+=1;n=e.get('file');n=n if n in md else rev.get(n);a=e.get('line_start');b=e.get('line_end');q=e.get('quote_en','')
  if not n or not isinstance(a,int) or not isinstance(b,int) or a<1 or b<a or b>len(md[n]) or not q or norm(q) not in norm('\n'.join(md[n][a-1:b])):quote_failures.append((row['item_id'],'MARKDOWN',n,q[:150]))
chk('all_pdf_evidence_exact',not any(x[1]=='PDF' for x in quote_failures))
chk('all_markdown_evidence_exact',not any(x[1]=='MARKDOWN' for x in quote_failures))
# Check immutable journal item IDs, counts, source references and SHA digest.
with zipfile.ZipFile(P/'batch_journals(3).zip') as z:
 names=[n for n in z.namelist() if re.search(r'B10\.6-\d+\.json$',n)]
 jid={};failing=[]
 for name in names:
  r=json.loads(z.read(name));
  if r['queue_sha256']!=manifest['external_queue_sha256'] or r['pdf_sha256']!=pd or r['batch_size']!=len(r['item_records']):failing.append(name)
  for k in r['item_records']:
   if k['item_id'] in jid:failing.append('DUPLICATE:'+k['item_id'])
   jid[k['item_id']]=k
chk('journal_241_batches',len(names)==241)
chk('journal_3852_unique_items',len(jid)==3852)
chk('journal_source_and_batch_metadata',not failing)
chk('B_items_in_external_journals',all(x['item_id'] in jid for x in inrows))
chk('B_raw_model_results_byte_equivalent',all(jid[x['item_id']]['model_json']==x['immutable_external_semantic_result']['model_json'] and jid[x['item_id']]['suggested_decision']==x['immutable_external_semantic_result']['suggested_decision'] and jid[x['item_id']]['decision_status']==x['immutable_external_semantic_result']['decision_status'] for x in inrows))
chk('adjudication_preserves_original_model_fields',all(x['prior_v5_suggested_decision']==jid[x['item_id']]['suggested_decision'] and x['prior_v5_decision_status']==jid[x['item_id']]['decision_status'] for x in ad))
chk('eligibility_preserves_original_model_fields',all(x['original_model_suggestion']==jid[x['item_id']]['suggested_decision'] and x['original_model_status']==jid[x['item_id']]['decision_status'] for x in ex))
chk('summary_counts',len(ad)==s['scored_eligible_decisions'] and len(ex)==s['eligibility_supersessions'] and len(block)==s['blockers'])
chk('summary_metric_not_computed',s['final_metrics_not_computed'])
assert all(checks.values()), [k for k,v in checks.items() if not v]
# Prioritized cross-Shard C audit: evidence conflicts, PARTIAL accepted as G:TP,
# FULL unsupported, Mixed definitive, N uncertain non-assertion. Do not change B cells.
by_id={x['item_id']:x for x in inrows};flags=[]
for x in ad:
 inp=by_id[x['item_id']];j=inp['immutable_external_semantic_result']['model_json'];causes=[]
 if x['direction']=='G' and x['final_cell']=='TP' and j['relation'] not in ('FULL',):causes.append('NONFULL_EXTERNAL_G_JUDGMENT_REQUIRES_FULL_PREDICATE_RECHECK')
 if x['direction']=='G' and x['final_cell']=='FP' and j['relation']=='FULL':causes.append('CONFLICT_WITH_EXTERNAL_FULL_SUPPORT')
 if x['direction']=='G' and j['eligibility']=='MIXED':causes.append('MIXED_SOURCE_CLAIM_AND_ELIGIBILITY_BOUNDARY')
 if x['direction']=='N' and j['relation']!='CONTRADICTED':causes.append('NEGATIVE_NONASSERTION_WITHOUT_EXPLICIT_GENERATED_NEGATION')
 for c in causes:flags.append({'item_id':x['item_id'],'direction':x['direction'],'current_B_cell':x['final_cell'],'reason_code':c,'model_relation_original':j['relation'],'original_statement_en':x['original_statement_en'],'status':'NEEDS_CROSS_SHARD_C_AUDIT_NOT_SUPERSEDED'})
for x in ex:
 j=by_id[x['item_id']]['immutable_external_semantic_result']['model_json']
 if j['eligibility']!='NONDEFINITIVE':flags.append({'item_id':x['item_id'],'direction':'G','current_B_cell':'EXCLUDED_NONDEFINITIVE','reason_code':'ELIGIBILITY_SUPERSESSION_VS_EXTERNAL_ELIGIBILITY','model_relation_original':j['relation'],'original_statement_en':x['original_statement_en'],'status':'NEEDS_CROSS_SHARD_C_AUDIT_NOT_SUPERSEDED'})
with (D/'07_cross_shard_C_review_flags_B.jsonl').open('w',encoding='utf-8') as f:
 for item in flags:f.write(json.dumps(item,ensure_ascii=False,sort_keys=True)+'\n')
summary={'record_type':'PHASE07B_INDEPENDENT_COMPLETION_VERIFICATION','status':'PASS','method':'fullload','protocol_version':'10.6','shard':'B','checks_total':len(checks),'checks_passed':sum(checks.values()),'all_checks':checks,'original_items':len(inrows),'adjudicated_items':len(ad),'eligibility_supersessions':len(ex),'unresolved_or_blocked_items':len(block),'pdf_quotations_verified':num_pdf,'markdown_quotations_verified':num_md,'quotation_failures':quote_failures,'external_journals_verified':len(names),'external_journal_items_verified':len(jid),'cross_shard_C_priority_flags_count':len(flags),'flags_are_not_changes_to_the_final_B_decisions':True,'original_pdf_hash':pd,'original_external_queue_hash':manifest['external_queue_sha256'],'original_external_result_hash':manifest['inputs_sha256']['external_results'],'verification_limitation_en':'Mechanical verification confirms source identity, existence and exact citation locations; it does not scientifically prove semantic entailment, absence of an affirmative forbidden assertion, or the correctness of automated judgments.'}
(D/'07_independent_verification_B.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in summary.items() if k not in ('all_checks','quotation_failures')},indent=2))
